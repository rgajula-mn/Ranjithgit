#!/usr/bin/python
import re
import collections


def natural_sort(a_list):
    convert = lambda text: int(text) if text.isdigit() else text
    alphanum_key = lambda key: [convert(c) for c in re.split('([0-9]+)', key)]
    return sorted(a_list, key=alphanum_key)


def regexp_sort(a_list, include_mask=[], exclude_mask=[]):
    if isinstance(a_list, collections.Iterable) and type(a_list) is not str:
        a_list = list(a_list)
    if type(a_list) is not list:
        a_list = [a_list]

    if isinstance(include_mask, collections.Iterable) and type(include_mask) is not str:
        include_mask = list(include_mask)
    if type(include_mask) is not list:
        include_mask = [include_mask]

    if isinstance(exclude_mask, collections.Iterable) and type(exclude_mask) is not str:
        exclude_mask = list(exclude_mask)
    if type(exclude_mask) is not list:
        exclude_mask = [exclude_mask]

    initial = a_list
    for e in list(exclude_mask):
        pattern = re.compile("^.*" + e + ".*$")
        matched = list(filter(pattern.match, initial))
        initial = [x for x in initial if x not in matched]

    result = []
    for i in list(include_mask):
        pattern = re.compile("^.*" + i + ".*$")
        matched = list(filter(pattern.match, initial))
        result.extend(matched)
        initial = [x for x in initial if x not in matched]
    result.extend(initial)
    return result


class FilterModule(object):
    def filters(self):
        return {
            'natural_sort': natural_sort,
            'regexp_sort': regexp_sort
        }
