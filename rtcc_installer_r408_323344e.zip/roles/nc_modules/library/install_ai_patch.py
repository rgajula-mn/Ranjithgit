#!/usr/bin/python

from ansible.module_utils.basic import *
import os
import re
import fileinput
from zipfile import ZipFile


def main():
    module = AnsibleModule(
        argument_spec=dict(
            netcracker_home=dict(required=True, type='str'),
            patch=dict(required=True, type='str'),
            args=dict(default='', type='str'),
            config_files=dict(default='[]', type='list'),
            properties=dict(default='{}', type='dict')
        )
    )

    netcracker_home = module.params['netcracker_home']
    patch = module.params['patch']
    args = module.params['args']
    config_files = module.params['config_files']
    properties = module.params['properties']

    if not os.path.exists(netcracker_home):
        module.fail_json(msg="Path %s not found" % netcracker_home)
    if not os.access(netcracker_home, os.W_OK):
        module.fail_json(msg="Directory %s not writable" % netcracker_home)

    if not os.path.isfile(patch):
        module.fail_json(msg="File %s not found" % patch)
    if not os.access(netcracker_home, os.R_OK):
        module.fail_json(msg="File %s not readable" % netcracker_home)

    if (not os.path.isfile(netcracker_home + "/AutoInstaller/build.xml")) and (
            not os.path.isfile(netcracker_home + "/AutoInstaller/install.sh")):
        module.fail_json(msg="AutoInstaller not found in %s" % netcracker_home)

    if not config_files and any(properties):
        module.fail_json(msg="Both config_files and properties parameters should be defined")

    ai_patch = ZipFile(patch, 'r')
    ai_patch.extractall(netcracker_home)
    ai_patch.close()

    if config_files:
        for val in config_files:
            etalon_config_file = netcracker_home + "/AutoInstaller/etalon_" + val
            if os.path.isfile(etalon_config_file):
                config_file_path = netcracker_home + "/AutoInstaller/" + val
                os.rename(etalon_config_file, config_file_path)
                for k, v in properties.items():
                    k_esc = re.escape(k)
                    for line in fileinput.input(config_file_path, inplace=1):
                        line = re.sub('^\s*?#?\s*?%s[ \t]*=.*$' % k_esc, "%s = %s" % (k, v), line.rstrip(), flags=re.M)
                        print(line)

    chdir = os.path.abspath(netcracker_home)
    os.chdir(chdir)
    os.chmod("install.sh", 0775)

    startd = datetime.datetime.now()
    args = "./install.sh " + args

    rc, out, err = module.run_command(args)

    endd = datetime.datetime.now()
    delta = endd - startd

    result = dict(
        cmd=args,
        stdout=out.rstrip(b"\r\n"),
        stderr=err.rstrip(b"\r\n"),
        rc=rc,
        start=str(startd),
        end=str(endd),
        delta=str(delta),
        changed=True,
    )

    if rc != 0:
        module.fail_json(msg='non-zero return code', **result)

    module.exit_json(**result)


if __name__ == '__main__':
    main()
