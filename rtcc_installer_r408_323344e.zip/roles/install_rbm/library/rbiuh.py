#!/usr/bin/python
from distutils import dir_util

from ansible.module_utils.basic import *
import os
import re
import socket
import tempfile
import shutil
import zipfile
import xml.etree.ElementTree as ET

def zipFile(path, dest):
    zipf = zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED)
    for root, dirs, files in os.walk(path):
        for file in files:
            zipf.write(os.path.join(root, file), os.path.join(root, file).replace(path, ''))
    zipf.close()


def rbiuh(rbm_path, rbm_license_dir, rbm_src, rbm_name, internal_upgrade, db_host, db_port, db_sid, ora_user,
          pkg_dir, ws_port, ws_home, ora_home, ora_db_data_dir, jdk, activemq, activemq_cms, apr, dc_ap, tm_pp, tm_sm):
    from xml.dom.minidom import xml
    from os import listdir
    from os.path import isfile, join
    from zipfile import ZipFile
    from shutil import copyfile

    # Define vars
    INFINYS_ROOT = rbm_path + "/" + rbm_name + '/infinys_root'
    PKG_ROOT = pkg_dir
    HOST = socket.gethostname()
    LIC_XML_TEMP = '.xml.' + HOST
    LIC_CRT_TEMP = '.crt.' + HOST
    RBTEST_FILE = 'none'
    CVG_INFINYS_PF = ora_db_data_dir

    # Check packages
    PF_PKG = 'NO'
    RB_PKG = 'NO'
    UTILITIES_PKG = 'NO'
    ECA_PKG = 'NO'
    TAP3_PKG = 'NO'
    RBTEST_PKG = 'NO'

    files = [f for f in listdir(rbm_src) if isfile(join(rbm_src, f))]
    for name in files:
        if 'PF-' in name:
            PF_PKG = 'YES'
            PF_FILE = name
        if 'RB-' in name:
            RB_PKG = 'YES'
            RB_FILE = name
        if 'UTILITIES_' in name:
            UTILITIES_PKG = 'YES'
            UTILITIES_FILE = name
        if 'ECA-' in name:
            ECA_PKG = 'YES'
            ECA_FILE = name
        if 'TAP3-' in name:
            TAP3_PKG = 'YES'
            TAP3_FILE = name
        if 'rbtest-' in name:
            RBTEST_PKG = 'YES'
            RBTEST_FILE = name
    if ECA_PKG == 'YES':
        if 'WebLogic' in ECA_FILE:
            WEB_SERVER_TYPE = 'wls'
        elif 'JBoss' in ECA_FILE:
            WEB_SERVER_TYPE = 'jboss'
        else:
            WEB_SERVER_TYPE = 'none'
    else:
        WEB_SERVER_TYPE = 'none'

    # Unzip files
    if RB_PKG == 'YES':
        rb_file = ZipFile(rbm_src + "/" + RB_FILE, 'r')
        rb_file.extract('RB/RB/RBIUH/RB_IU_Handler.ksh', rbm_src)
        rb_file.extract('RB/RB/RBIUH/rbiuh_config_sample.xml', rbm_src)
        utl_file = ZipFile(rbm_src + "/" + UTILITIES_FILE, 'r')
        utl_file.extractall(INFINYS_ROOT)
        copyfile(rbm_src + "/RB/RB/RBIUH/RB_IU_Handler.ksh", INFINYS_ROOT + "/RB_IU_Handler.ksh")
        copyfile(rbm_src + "/RB/RB/RBIUH/rbiuh_config_sample.xml", INFINYS_ROOT + "/rbiuh_config_sample.xml")

    # Check license
    LIC_CRT = 'license.crt'
    LIC_XML = 'license.xml'
    LIC_DIR = rbm_license_dir
    # if 'RB-6' in RB_FILE:
    #     RB_VERSION = 'RB6'
    # elif 'RB-7' in RB_FILE:
    #     RB_VERSION = 'RB7'
    # elif 'RB-8' in RB_FILE:
    #     RB_VERSION = 'RB8'
    # else:
    #     RB_VERSION = 'RB9'

    licenses = [f for f in listdir(rbm_license_dir) if isfile(join(rbm_license_dir, f))]
    for name in licenses:
        if LIC_CRT_TEMP in name:
            LIC_CRT = name
        if LIC_XML_TEMP in name:
            LIC_XML = name

    # Create light weight packages for upgrade
    if os.path.isfile(INFINYS_ROOT + "/rbiuh_config.xml"):
        if RB_PKG == 'NO' and os.path.isdir(INFINYS_ROOT + "/RB") and os.path.isdir(INFINYS_ROOT + "/RBIUH"):
            rb_tmp_dir = tempfile.mkdtemp()
            os.makedirs(rb_tmp_dir + "/RB/RB/bin")
            os.makedirs(rb_tmp_dir + "/RB/RB/lib")
            os.makedirs(rb_tmp_dir + "/RB/RB/RBIUH")
            shutil.copy(INFINYS_ROOT + "/RB/bin/release_info.xml", rb_tmp_dir + "/RB/RB/bin")
            shutil.copy(INFINYS_ROOT + "/RB/lib/CheckDupTags.jar", rb_tmp_dir + "/RB/RB/lib")
            dir_util.copy_tree(INFINYS_ROOT + "/RBIUH", rb_tmp_dir + "/RB/RB/RBIUH")

            RB_ver = ET.parse(INFINYS_ROOT + "/RB/bin/release_info.xml").getroot().attrib['version']
            RB_FILE = 'RB-'+RB_ver+'lX12c.zip'
            zipFile(rb_tmp_dir, rbm_src + '/' + RB_FILE)
            shutil.rmtree(rb_tmp_dir)

        if PF_PKG == 'NO' and os.path.isdir(INFINYS_ROOT + "/PF"):
            pf_tmp_dir = tempfile.mkdtemp()
            os.makedirs(pf_tmp_dir + "/PF/platform/bin")
            os.makedirs(pf_tmp_dir + "/PF/platform/lib")
            shutil.copy(INFINYS_ROOT + "/PF/bin/sysreg_db_version.ksh", pf_tmp_dir + "/PF/platform/bin/sysreg_db_version.ksh")
            shutil.copy(INFINYS_ROOT + "/PF/bin/common_functions", pf_tmp_dir + "/PF/platform/bin/common_functions")
            dir_util.copy_tree(INFINYS_ROOT + "/PF/bin/apache-ant", pf_tmp_dir + "/PF/platform/bin/apache-ant")
            dir_util.copy_tree(INFINYS_ROOT + "/PF/lib", pf_tmp_dir + "/PF/platform/lib")

            PF_ver = ET.parse(INFINYS_ROOT + "/PF/manifest/manifest.xml").getroot().attrib['version']
            PF_FILE = 'PF-' + PF_ver + 'jJ.64.GenericJ2EE.zip'
            zipFile(pf_tmp_dir, rbm_src + '/' + PF_FILE)
            shutil.rmtree(pf_tmp_dir)

        if UTILITIES_PKG == 'NO' and os.path.isdir(INFINYS_ROOT + "/UTILITIES"):
            utl_tmp_dir = tempfile.mkdtemp()
            os.makedirs(utl_tmp_dir + "/UTILITIES/Installation")
            shutil.copy(INFINYS_ROOT + "/UTILITIES/Installation/infinys.env",
                        utl_tmp_dir + "/UTILITIES/Installation/infinys.env")
            shutil.copy(INFINYS_ROOT + "/UTILITIES/Installation/schema_params_utility.zip",
                        utl_tmp_dir + "/UTILITIES/Installation/schema_params_utility.zip")

            with open(INFINYS_ROOT + "/UTILITIES/version.txt") as f:
                content = f.readline()

            UTL_ver = content.rstrip('\n').split("v", 1)[1]
            UTILITIES_FILE = 'UTILITIES_' + UTL_ver + '.zip'
            zipFile(utl_tmp_dir, rbm_src + '/' + UTILITIES_FILE)
            shutil.rmtree(utl_tmp_dir)

    ## Parsing rbiuh_config_sample.xml
    if os.path.isfile(INFINYS_ROOT + "/rbiuh_config_sample.xml"):
        f = open(INFINYS_ROOT + "/rbiuh_config_sample.xml", 'rt')
        data = xml.dom.minidom.parseString(f.read())
        f.close()

        # !!!!!!!  rbiuh   !!!!!!!!
        INFINYS_ENV = data.getElementsByTagName('rbiuh')[0]
        INFINYS_ENV.setAttribute('INFINYS_ENV', 'infinys.env')
        INFINYS_ENV.setAttribute('INFINYS_ROOT', INFINYS_ROOT)

        ##!!!!!!!  extensions   !!!!!!!!
        extensions = data.getElementsByTagName('extensions')[0]
        for attrName, attrValue in extensions.attributes.items():
            extensions.setAttribute(attrName, 'NO')
        extensions.setAttribute('PF', PF_PKG)
        extensions.setAttribute('RB', RB_PKG)
        extensions.setAttribute('ECA', ECA_PKG)
        extensions.setAttribute('TAP3', TAP3_PKG)
        # extensions.setAttribute('$ICBS_PKG', 'YES')

        ##!!!!!!!  packages   !!!!!!!!
        PF = data.getElementsByTagName('packages')[0]
        PF.setAttribute('PKG_ROOT', PKG_ROOT)
        PF.setAttribute('CHECKSUM', 'false')

        Utilities_packages = data.getElementsByTagName('Utilities')[0]
        Utilities_packages.setAttribute('dir', rbm_src)
        Utilities_packages.setAttribute('file', UTILITIES_FILE)

        PF_packages = data.getElementsByTagName('PF')[0]
        PF_packages.setAttribute('dir', rbm_src)
        PF_packages.setAttribute('file', PF_FILE)

        RB_packages = data.getElementsByTagName('RB')[0]
        RB_packages.setAttribute('dir', rbm_src)
        RB_packages.setAttribute('file', RB_FILE)

        ECA_packages = data.getElementsByTagName('ECA')[0]
        if ECA_PKG == 'YES':
            ECA_packages.setAttribute('dir', rbm_src)
            ECA_packages.setAttribute('file', ECA_FILE)

        TAP3_packages = data.getElementsByTagName('TAP3')[0]
        if TAP3_PKG == 'YES':
            TAP3_packages.setAttribute('dir', rbm_src)
            TAP3_packages.setAttribute('file', TAP3_FILE)

        # icbs = ${ICBS_FILE}
        # if icbs:
        # ICBS_packages = data.getElementsByTagName('ICBS')[0]
        # ICBS_packages.setAttribute('file', '$ICBS_FILE')
        # ICBS_packages.setAttribute('dir', '{{ kits_dir }}/$RBM_VERSION')

        ##!!!!!!!  oracle   !!!!!!!!!
        skipLocalValidation = data.getElementsByTagName('oracle')[0]
        skipLocalValidation.setAttribute('skipLocalValidation', 'yes')

        database = data.getElementsByTagName('database')[0]
        database.setAttribute('CVG_INFINYS_PF', CVG_INFINYS_PF)
        database.setAttribute('globalName', db_sid)
        database.setAttribute('host', db_host)
        database.setAttribute('jobQueueProcesses', '20')
        database.setAttribute('listenerPort', db_port)
        database.setAttribute('oracleUnixUser', ora_user)
        database.setAttribute('rac', 'NO')
        database.setAttribute('sid', db_sid)
        database.setAttribute('skipDefaultTableSpaceCheck', 'no')
        database.setAttribute('twoTask', db_sid)

        ##!!!!!!!  servers   !!!!!!!!!
        servers = data.getElementsByTagName('servers')[0]
        servers.setAttribute('os', 'lX')
        server1 = data.getElementsByTagName('server1')[0]
        server1.setAttribute('name', HOST)

        webServer = data.getElementsByTagName('webServer')[0]
        webServer.setAttribute('container', WEB_SERVER_TYPE)
        webServer.setAttribute('domainName', rbm_name)
        webServer.setAttribute('home', ws_home)
        webServer.setAttribute('port', str(ws_port))

        ##!!!!!!!  directories   !!!!!!!!!
        cvg_license = data.getElementsByTagName('cvg_license')[0]
        cvg_license.setAttribute('cert', LIC_CRT)
        cvg_license.setAttribute('file', LIC_XML)
        cvg_license.setAttribute('dir', LIC_DIR)

        oracle_home = data.getElementsByTagName('oracle_home')[0]
        oracle_home.setAttribute('dir', ora_home)

        java_home = data.getElementsByTagName('java_home')[0]
        java_home.setAttribute('dir', jdk)

        try:
            activemq_home = data.getElementsByTagName('activemq_home')[0]
            activemq_home.setAttribute('dir', activemq)
            activemq_cms_home = data.getElementsByTagName('activemq_cms_home')[0]
            activemq_cms_home.setAttribute('dir', activemq_cms)
            apr_home = data.getElementsByTagName('apr_home')[0]
            apr_home.setAttribute('dir', apr)
        except IndexError:
            print ('NO AMQ')

        ##!!!!!!!  taskMaster   !!!!!!!!!
        taskMaster = data.getElementsByTagName('taskMaster')[0]
        taskMaster.setAttribute('DConfigAgentPort', str(dc_ap))
        taskMaster.setAttribute('childProcessPort', str(tm_pp))
        taskMaster.setAttribute('hostName', HOST)
        taskMaster.setAttribute('systemMonitorPort', str(tm_sm))

        ##!!!!!!!  schemaUpgrade   !!!!!!!!!
        schemaUpgrade = data.getElementsByTagName('schemaUpgrade')[0]
        schemaUpgrade.setAttribute('InternalUpgrade', 'no')
        if RBTEST_PKG == 'YES':
            if internal_upgrade == 'auto':
                releaseInfo = INFINYS_ROOT + "/RB/bin/release_info.xml"
                if os.path.isfile(releaseInfo):
                    rData = ET.parse(releaseInfo).getroot()
                    previousVersion = rData.attrib['version']
                    currentVersion = re.search('RB-([0-9.]+).*', RB_FILE).group(1)
                    if previousVersion == currentVersion:
                        schemaUpgrade.setAttribute('InternalUpgrade', 'yes')
                else:
                    schemaUpgrade.setAttribute('InternalUpgrade', 'yes')
            else:
                schemaUpgrade.setAttribute('InternalUpgrade', internal_upgrade)

        schemaUpgrade.setAttribute('SchemaTopUpDir', rbm_src)
        schemaUpgrade.setAttribute('SchemaTopUpFile', RBTEST_FILE)
        schemaUpgrade.setAttribute('SkipY9SchemaReport', 'yes')

        f = open(INFINYS_ROOT + "/rbiuh_config.xml", 'wt')
        f.write(data.toxml('utf-8'))
        f.close()
    return 0


def main():
    module = AnsibleModule(
        argument_spec=dict(
            rbm_path=dict(required=True, type='str'),
            rbm_license_dir=dict(required=True, type='str'),
            rbm_src=dict(required=True, type='str'),
            rbm_name=dict(required=True, type='str'),
            internal_upgrade=dict(required=True, choices=['auto', 'yes', 'no']),
            db_host=dict(required=True, type='str'),
            db_port=dict(required=True, type='str'),
            db_sid=dict(required=True, type='str'),
            ora_user=dict(required=True, type='str'),
            pkg_dir=dict(required=True, type='str'),
            ws_port=dict(required=True, type='str'),
            ws_home=dict(required=True, type='str'),
            ora_home=dict(required=True, type='str'),
            ora_db_data_dir=dict(required=True, type='str'),
            jdk=dict(required=True, type='str'),
            activemq=dict(default='none', type='str'),
            activemq_cms=dict(default='none', type='str'),
            apr=dict(default='none', type='str'),
            dc_ap=dict(required=True, type='str'),
            tm_pp=dict(required=True, type='str'),
            tm_sm=dict(required=True, type='str')
        )
    )

    rbm_path = os.path.expanduser(module.params['rbm_path'])
    rbm_license_dir = os.path.expanduser(module.params['rbm_license_dir'])
    rbm_src = os.path.expanduser(module.params['rbm_src'])
    rbm_name = os.path.expanduser(module.params['rbm_name'])
    internal_upgrade = os.path.expanduser(module.params['internal_upgrade'])
    db_host = os.path.expanduser(module.params['db_host'])
    db_port = os.path.expanduser(module.params['db_port'])
    db_sid = os.path.expanduser(module.params['db_sid'])
    ora_user = os.path.expanduser(module.params['ora_user'])
    pkg_dir = os.path.expanduser(module.params['pkg_dir'])
    ws_port = os.path.expanduser(module.params['ws_port'])
    ws_home = os.path.expanduser(module.params['ws_home'])
    ora_home = os.path.expanduser(module.params['ora_home'])
    ora_db_data_dir = os.path.expanduser(module.params['ora_db_data_dir'])
    jdk = os.path.expanduser(module.params['jdk'])
    activemq = os.path.expanduser(module.params['activemq'])
    activemq_cms = os.path.expanduser(module.params['activemq_cms'])
    apr = os.path.expanduser(module.params['apr'])
    dc_ap = os.path.expanduser(module.params['dc_ap'])
    tm_pp = os.path.expanduser(module.params['tm_pp'])
    tm_sm = os.path.expanduser(module.params['tm_sm'])

    rbiuh_new = rbiuh(rbm_path, rbm_license_dir, rbm_src, rbm_name, internal_upgrade, db_host, db_port, db_sid,
                      ora_user, pkg_dir, ws_port, ws_home, ora_home, ora_db_data_dir, jdk, activemq, activemq_cms,
                      apr, dc_ap, tm_pp, tm_sm)

    if rbiuh_new != 0:
        print json.dumps({
            "failed": True,
            "msg": "Parsing rbiuh_config_sample.xml is failed"
        })
    else:
        print json.dumps({
            "changed": True,
        })


if __name__ == '__main__':
    main()
