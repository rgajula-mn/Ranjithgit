RTCC installer can execute an installation of RBM and RTCC solution to:
* install RBM using RBIUH
* install RBM using NC AutoInstaller
* install RTCC
* update RTCC

Playbooks:
* cleanup.yml - remove&umount $INFINYS_ROOT and $HA_ROOT
* install_rbm.yml - install/upgrade RBM using NC AutoInstaller
* install_rtcc.yml - install RTCC
* install_with_rbiuh.yaml - install/upgrade RBM using RBIUH
* update_rtcc.yml - upgrade RTCC (DB upgrade; provisioning)

To be removed:
* tmp_generate_rtcc_configs.yml
