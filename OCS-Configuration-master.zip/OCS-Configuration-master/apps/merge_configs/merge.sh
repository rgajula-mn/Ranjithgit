#!/usr/bin/env bash

# This script merges YAML files from the specified destination directory into the source directory recursively
# If no arguments are specified, it relies on a specific directory structure:
#   ./config-parts contains snapshots of ansible config files which are applied in a lexicographical order
#   merge output is placed directly into the script execution path
# Requires Spruce binary to be present in pwd
# See https://github.com/geofffranks/spruce

function check_yaml {
  python -c 'import yaml,sys;yaml.safe_load(sys.stdin)' < $1 2>/dev/null
}


function traverse {
  for file in "$1"/*; do
    if [ ! -d "${file}" ] ; then
      relFileName=${file#$srcDir/}
      mergeFile="$2${relFileName}"
      
      if [ ! -f "${mergeFile}" ] ; then
        echo "${mergeFile} not found, skipping $(basename ${file})"
      else
        echo "Merging ${mergeFile} into ${relFileName#/}"

        #if some file empty, we should take 2nd    
        uncomm_file1=$(cat ${file} | grep -ve '^#' -e '^$')
        uncomm_file2=$(cat ${mergeFile} | grep -ve '^#' -e '^$')
        
        if check_yaml $file && check_yaml ${mergeFile} && [[ -n ${uncomm_file1} && -n ${uncomm_file2} ]]; then
          ./spruce-linux-amd64 merge "${file}" "${mergeFile}" > ./tmpfile && cat ./tmpfile > "${file}"
        else
          echo "${relFileName} is not a YAML file or empty, just overwriting it"
          cp "${mergeFile}" "${file}"
        fi

      fi
    else
      traverse "${file}" "$2"
    fi
  done
}

if [ "$#" -eq 2 ]; then
  srcDir=$(readlink -f $1)
  mrgDir=$(readlink -f $2)

  traverse $srcDir $mrgDir
  rsync -av --ignore-existing "${mrgDir}" "${srcDir}"

elif [ "$#" -eq 0 ]; then
  srcDir=./merge-result
  rm -rf ${srcDir} && mkdir -p ${srcDir}

  if [ ! -d "$(dirname $0)/config-parts" ]; then
    echo "No arguments specified and no config-parts directory in the execution path, exiting..." >> /dev/stderr
    exit 2
  fi

  for dir in $(dirname $0)/config-parts/*/; do
    echo -e "\n#### Merging directory: $dir"
    if [ -d "${dir}" ]; then
      if [[ -z "$(ls $srcDir)" ]]; then
        echo "## directory ${srcDir} empty. Just copy ${dir}"
        cp -r "${dir}"/* ${srcDir}
      else
        traverse "${srcDir}" "${dir}"
        rsync -av --ignore-existing "${dir}" "${srcDir}"
      fi
    fi
  done

  echo -e "\n#### Merge finished:"
#  tree ${srcDir}

  rm -f ./tmpfile
else
  echo "Usage: merge.sh [<source-dir> <merge-dir>]" >> /dev/stderr
  exit 2
fi
