#!/bin/bash

# This scripts show difference between merged version and actually applied one

function compare {
  for file in "$1"/*; do
    if [ ! -d "${file}" ] ; then
      relFileName=${file#$srcDir}
      mergeFile="$2${relFileName}"

      if [ ! -f "${mergeFile}" ] ; then
        echo "${mergeFile} not found, skipping $(basename ${file})"
      else
        echo "Comparing ${mergeFile} with ${relFileName#/}"
        diff "${file}" "${mergeFile}"
      fi
    else
      compare "${file}" "$2"
    fi
  done
}

srcDir=./merge-result
compare $srcDir ../cube_installer/ansible