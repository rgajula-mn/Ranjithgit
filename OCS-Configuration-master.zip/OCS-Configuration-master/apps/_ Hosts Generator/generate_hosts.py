# This should run on python v3

import csv

import os,sys

import re

LAB_DOMAIN = "ocs-lab.netcracker.com"

HOST_VAR_TEMPLATE = """
# The node name returned by uname -n
nodename: {host.hostname}

# DNS Domain Name. Just for the sake of simplicity
dns_domain: "{LAB_DOMAIN}"

# The fully qualified node name for example: examplemachine.netcracker.com
nodename_fqdn: {host.hostname}.{LAB_DOMAIN}

# The ip address on the host to use for CUBE traffic
ip: {host.ip}

# Site Number (integer value)
site: {host.site}

# Zookeeper and Kafka Host specific information. Only needed on nodes that host a Zookeeper or Kafka instance:
zookeeper_nodeid: "{host.zk_nodeid}"

# Cassandra Host specific information. Only needed on nodes that host a Cassandra instance:
cassandra_rac: 1

# You need an odd number of consul applications acting as servers, 3 will allow 1 failure, 5 will allow two consul server failures.
consul_server_mode: {consul_server_mode_printable}

# You need an odd number of consul applications acting as servers, 3 will allow 1 failure, 5 will allow two consul server failures.
oracle_service_name: {host.oracle_service_name}

# used for FE caches only
db_domain_groups_active: [{db_domain_groups_active}]

# used for FE caches only
db_domain_groups_standby: [{db_domain_groups_standby}]
"""

STATIC_GROUPS_CUBE = \
"""
[CUBE:children]

ACTION_MANAGER
CASSANDRA_CLIENT
CASSANDRA_LINE
CASSANDRA_SHARED
CASSANDRA_UIM
DDRS
KAFKA_CUBE
KPI_AGGREGATOR
ALERT_MANAGER
SNMP_PROXY
OAM
PCC
QCM
QCM_API
TOKENMANAGER
UIM
ZK

[JAVA:children]

CUBE

[CM_AGENT:children]
QCM
DDRS
KPI_AGGREGATOR
ALERT_MANAGER
SNMP_PROXY
PCC
UIM
ACTION_MANAGER

[DSE_OPSCENTER_AGENT:children]

CASSANDRA_LINE
CASSANDRA_SHARED
CASSANDRA_UIM

[COLLECTD:children]
COLLECTD_SERVER
COLLECTD_CLIENT

[COLLECTD_SERVER:children]
OAM

[CASSANDRA_CLIENT:children]
OAM
"""

class Host(object):
    def __init__(self, hostname: str, ip: str, cube_groups, smart_groups, devops_groups, rtcc_groups, site: int, zk_nodeid: str, oracle_service_name, dgs_active, dgs_standby, consul_server_mode: bool):
        self.dgs_standby = dgs_standby
        self.dgs_active = dgs_active
        self.rtcc_groups = rtcc_groups
        self.oracle_service_name = oracle_service_name
        self.devops_groups = devops_groups
        self.consul_server_mode = consul_server_mode
        self.site = site
        self.smart_groups = smart_groups
        self.zk_nodeid = zk_nodeid
        self.hostname = hostname
        self.ip = ip
        self.cube_groups = cube_groups

    def __str__(self):
        return "<Host '{self.hostname}', CUBE='{self.cube_groups}', SMART='{self.smart_groups}'>".format(self=self)

def read_hosts(fname: str):
    all_hosts = []

    with open(fname, newline='', encoding='utf-8-sig') as hosts_source_file:
        hosts_reader = csv.reader(hosts_source_file, delimiter=';', quotechar='"')
        for row in hosts_reader:
            hostname, \
            machine, \
            cube_groups, \
            smart_groups, \
            devops_groups, \
            rtcc_groups, \
            site, \
            zk_nodeid, \
            oracle_service_names, \
            dg_active, \
            dg_standby, \
            consul_server_mode, \
            _, _, _, \
            fixed_ip = row

            if hostname:

                all_hosts.append(Host(
                    hostname.strip(),
                    fixed_ip.strip(),
                    cube_groups.splitlines(False),
                    smart_groups.splitlines(False),
                    devops_groups.splitlines(False),
                    rtcc_groups.splitlines(False),
                    site.strip(),
                    zk_nodeid.strip(),
                    oracle_service_names.strip().split(","),
                    dg_active.strip().split(","),
                    dg_standby.strip().split(","),
                    True if consul_server_mode == "TRUE" else False,
                ))
    return all_hosts

def write_hosts(hosts, output_file, host_to_group_func, static_groups = "", use_ips = False):
    group_to_host = {}

    for host in hosts:
        for group_name in host_to_group_func(host):
            group_to_host.setdefault(group_name,[]).append(host)


    all_groups = sorted(group_to_host.keys())

    with open(output_file, "w") as f:
        for group_name in all_groups:
            f.write("[{group_name}]\n".format(group_name=group_name))

            for host in group_to_host[group_name]:
                f.write("{host_id}  ansible_shell_type=sh\n".format(host_id=host.ip if use_ips else host.hostname))

            f.write("\n")

        all_groups_by_site = {}
        for group in all_groups:
            match = re.search(r"^(?P<name>.+)_S(?P<site>\d+)$",group)
            if match:
                all_groups_by_site.setdefault(match.group("name"),[]).append(group)

        f.write("\n")
        f.write("######################################################\n")
        f.write("# Aggregation groups\n")
        f.write("######################################################\n")
        f.write("\n")
        for upper_group, groups in all_groups_by_site.items():
            f.write("[{upper_group}:children]\n".format(upper_group=upper_group))
            for group in groups:
                f.write("{group}\n".format(group=group))
            f.write("\n")


        if static_groups:
            f.write("\n")
            f.write("######################################################\n")
            f.write("# Static groups\n")
            f.write("######################################################\n")
            f.write("\n")
            f.write(static_groups)


def write_host_vars(hosts, output_dir: str, use_ips = False):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for host in hosts:
        fpath = os.path.join(output_dir, host.ip if use_ips else host.hostname)
        with open(fpath,"w") as f:
            f.write(
                HOST_VAR_TEMPLATE.format(
                    host=host,
                    consul_server_mode_printable=str(host.consul_server_mode).lower(),
                    LAB_DOMAIN=LAB_DOMAIN,
                    db_domain_groups_active=",".join(host.dgs_active),
                    db_domain_groups_standby=",".join(host.dgs_standby),
                    host_ip=host.ip if use_ips else "{}.{}".format(host.hostname,LAB_DOMAIN)
                )
            )

def main():
    all_hosts = read_hosts(sys.argv[1])

    write_host_vars(all_hosts,sys.argv[2]+"/output/cube/host_vars", use_ips = False)
    write_hosts(all_hosts, sys.argv[2]+"/output/cube/hosts", lambda x: x.cube_groups, static_groups=STATIC_GROUPS_CUBE, use_ips = False)

    write_host_vars(all_hosts, sys.argv[2]+"/output/smart/host_vars", use_ips = False)
    write_hosts(all_hosts, sys.argv[2]+"/output/smart/hosts", lambda x: x.smart_groups, use_ips = False)

    write_host_vars(all_hosts, sys.argv[2]+"/output/devops/host_vars", use_ips = True)
    write_hosts(all_hosts, sys.argv[2]+"/output/devops/hosts", lambda x: x.smart_groups + x.cube_groups + x.devops_groups + ["ALL_HOSTS"], use_ips = True)

    write_host_vars(all_hosts, sys.argv[2]+"/output/rtcc/host_vars", use_ips=False)
    write_hosts(all_hosts, sys.argv[2]+"/output/rtcc/hosts", lambda x: x.rtcc_groups, use_ips=False)

if __name__ == '__main__':
    main()
