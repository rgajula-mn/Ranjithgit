#!/bin/bash
#it is from run from $SMART_HOME/bin

for var in 0 1 2 3
  do
  nextmonth=$(date +"%y%m" --date="$(date +%Y-%m-15) +$var months")
  ./generateCE_Eseq.sh -m $nextmonth -c ./config.txt -u ocs_superuser -p password
  ./generateCES_Eseq.sh -m $nextmonth -c ./config.txt -u ocs_superuser -p password
done
