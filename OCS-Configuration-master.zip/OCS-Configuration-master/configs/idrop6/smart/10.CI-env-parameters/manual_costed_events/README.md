work around for put costed events on smart:

For 1 month

```
. smart.env
cd ./bin
./generateCE_Eseq.sh -m `date +%y%m` -c ./config.txt 
./generateCES_Eseq.sh -m `date +%y%m` -c ./config.txt

```

For 3 month in advance

```
. smart.env
cd ./bin 
for var in 0 1 2 3
do
nextmonth=$(date +"%y%m" --date="$(date +%Y-%m-15) +$var months")
./generateCE_Eseq.sh -m $nextmonth -c /path/to/config.txt 
./generateCES_Eseq.sh -m $nextmonth -c /path/to/config.txt 
done
```
