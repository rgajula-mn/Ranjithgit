---
#
# All files from ../all.templates goes here vithout extension
#
