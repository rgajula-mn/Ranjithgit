# Environments
We have 3 environments in Telenet:
* INT – for integration tickets
* UAT - for UAT
* LAT – for SVT and Migration
* CI - for internal CI enviroments

## INT
See schema - https://bass.netcracker.com/display/TELN/INT

## UAT
See schema - https://bass.netcracker.com/display/TELN/UAT

## LAT
See schema - https://bass.netcracker.com/display/TELN/LAT

## Internal LAB environments
* Lab 1 - https://bass.netcracker.com/display/TELN/OCS+Installation+LAB 
* Lab 2 - https://bass.netcracker.com/display/TELN/OCS+Installation+LAB2
* Lab 3 - https://bass.netcracker.com/display/TELN/OCS+Installation+LAB3

## Internal CI environment
* See schema - https://bass.netcracker.com/display/TELN/CI.Telenet-v5-env6