Mandatory variables: oracle_service_name, dst_patch_zip


dst_patch_zip:
- p19396455_112030_Linux-x86-64.zip
- p19396455_112040_Linux-x86-64.zip
- p19396455_121010_Linux-x86-64.zip
- p19396455_121020_Linux-x86-64.zip

chosen based on the Oracle db version
for example: p19396455_112030_Linux-x86-64.zip for Oracle 11.2.0.3.0
