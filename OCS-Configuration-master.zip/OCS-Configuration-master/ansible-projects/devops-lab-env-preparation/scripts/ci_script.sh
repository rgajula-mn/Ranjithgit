#!/bin/bash
set -e

export LD_LIBRARY_PATH=/opt/tools/python/lib
export PATH=/opt/tools/python/bin:$PATH
export https_proxy=artifactorycn.netcracker.com:12033

#can be remove
which python
python --version
env | grep '^LD_LIBRARY_PATH'

export https_proxy=artifactorycn.netcracker.com:12033


ANSIBLE_DIR=${WORKSPACE}/${BUILD_NUMBER}/ansible-projects/devops-lab-env-preparation
HOSTS_FILE=${ANSIBLE_DIR}/hosts
SSH_PRIV_FILE=${ANSIBLE_DIR}/ci_key
EXTRA_VARS_FILE=${ANSIBLE_DIR}/extra_vars



#### Prepare virtualenv and install pip requirements
echo "###### INFO: Prepare virtual env"
cd ${BUILD_NUMBER}
virtualenv venv
. venv/bin/activate

echo "###### INFO: install pip requirements"
pip install -r ${ANSIBLE_DIR}/requirements.txt

#### Check ansible version
cd ${ANSIBLE_DIR}
ansible --version



#### Prepare ssh key
echo "###### INFO: Prepare ssh key"
SSH_WITH_PASS="false"

if [[ "${SSH_KEY}" != '' ]]; then
    if [[ -n "$(echo ${SSH_KEY} |grep 'BEGIN RSA PRIVATE KEY')" ]]; then
        echo "${SSH_KEY}" > ${SSH_PRIV_FILE}
        sed -i 's/ /\n/g' ${SSH_PRIV_FILE}
        sed -i ':a;N;$!ba;s/\nRSA\nPRIVATE\n/ RSA PRIVATE /g' ${SSH_PRIV_FILE}
        chmod 600 ${SSH_PRIV_FILE}
    else
        SSH_WITH_PASS="true"
    fi
fi
if [[ ! -f ${SSH_PRIV_FILE} && ${SSH_WITH_PASS} == "false" ]]; then
    echo "###### ERROR: ssh private key file ${SSH_PRIV_FILE}: not found"
    exit 1
fi




KEY_VAR=""
if [[ ${SSH_WITH_PASS} == "false" ]]; then
    KEY_VAR="--private-key=${SSH_PRIV_FILE}"
fi


#### Run ansible
echo "###### INFO: Run ansible"

export ANSIBLE_STDOUT_CALLBACK=debug
export ANSIBLE_FORCE_COLOR=true


## PACKAGES
if [[ "${INSTALL_PACKAGES}" = "true" ]]; then
    cd ${ANSIBLE_DIR}
    echo "ansible-playbook ${KEY_VAR} -v playbooks/packages.yaml"
    ansible-playbook ${KEY_VAR} -v playbooks/packages.yaml
fi


## USERS
if [[ "${CREATE_USERS}" = "true" ]]; then
    cd ${ANSIBLE_DIR}
    echo "ansible-playbook ${KEY_VAR} -v playbooks/users.yaml"
    ansible-playbook ${KEY_VAR} -v playbooks/users.yaml
fi


## DNS
if [[ "${SETUP_DNS}" = "true" ]]; then
    cd ${ANSIBLE_DIR}
    echo "ansible-playbook ${KEY_VAR} -v playbooks/cloud_dns.yaml"
    ansible-playbook ${KEY_VAR} -v playbooks/cloud_dns.yaml
fi