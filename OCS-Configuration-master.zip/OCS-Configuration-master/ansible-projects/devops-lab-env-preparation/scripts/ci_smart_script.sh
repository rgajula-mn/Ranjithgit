#!/bin/bash


OAM_SERVER=10.106.4.83
USERNAME=Locscub
PASSWORD=netcracker
HOME_DIR=/sft/Locscub
INTEGRATION_BUILD=Telenet.BSS.OCS.SMART.Integration.1.1.5_build8.zip
LAST_PATCH_NAME=${INTEGRATION_BUILD}
THRIDPARTY_BUILD=SMART.thirdparties.1.1.5.zip
REMOTE_WORKDIR=SMART-CD/${BUILD_NUMBER}
ORCH_BRANCH=master
SSH_PRIV_FILE=~/ocs_ci_key

INSTALLER_HOME=$HOME_DIR/${REMOTE_WORKDIR}/smart_installer/ansible
PACKAGE_STORE=$HOME_DIR/${REMOTE_WORKDIR}/pkgstore


#### Prepare ssh key
echo "###### INFO: Prepare ssh key"
SSH_WITH_PASS="false"

if [[ "${SSH_KEY}" != '' ]]; then
    if [[ -n "$(echo ${SSH_KEY} |grep 'BEGIN RSA PRIVATE KEY')" ]]; then
        echo "${SSH_KEY}" > ${SSH_PRIV_FILE}
        sed -i 's/ /\n/g' ${SSH_PRIV_FILE}
        sed -i ':a;N;$!ba;s/\nRSA\nPRIVATE\n/ RSA PRIVATE /g' ${SSH_PRIV_FILE}
        chmod 600 ${SSH_PRIV_FILE}
    else
        SSH_WITH_PASS="true"
    fi
fi
if [[ ! -f ${SSH_PRIV_FILE} && ${SSH_WITH_PASS} == "false" ]]; then
    echo "###### ERROR: ssh private key file ${SSH_PRIV_FILE}: not found"
    exit 1
fi




KEY_VAR=""
if [[ ${SSH_WITH_PASS} == "false" ]]; then
    KEY_VAR="--private-key=${SSH_PRIV_FILE}"
fi


#### Unarchive repo and builds

tar xzf ${BUILD_NUMBER}.tar.gz -C .

unzip -oq $LAST_PATCH_NAME
unzip -oq $THRIDPARTY_BUILD


#### SMART installer configs preparation
cd $HOME_DIR/${REMOTE_WORKDIR}/config_sources/config-parts
cp -r $HOME_DIR/$REMOTE_WORKDIR/${BUILD_NUMBER}/configs/smart/00.solution-specific-parameters ./
cp -r $HOME_DIR/$REMOTE_WORKDIR/${BUILD_NUMBER}/configs/smart/10.LAB-env-parameters ./
cd $HOME_DIR/${REMOTE_WORKDIR}/config_sources
./merge.sh


cp -r $HOME_DIR/${REMOTE_WORKDIR}/config_sources/merge-result/* $HOME_DIR/${REMOTE_WORKDIR}/smart_installer/ansible


mv $HOME_DIR/${REMOTE_WORKDIR}/smart_installer/ansible/vars/packages_vars.yml $HOME_DIR/${REMOTE_WORKDIR}/smart_installer/ansible/vars/packages_vars


#### Run ansible
echo "###### INFO: Run ansible"

if [[ -n `echo $TAGS` ]]; then
  SMART_TAGS="create_app_dir, create_env_file, $TAGS"
else
  SMART_TAGS="create_app_dir, create_env_file"
fi

echo $SMART_TAGS

cd $HOME_DIR/${REMOTE_WORKDIR}/smart_installer/ansible

echo 'ansible-playbook smart.yml -t "$SMART_TAGS" -e "INSTALLER_HOME=$INSTALLER_HOME" -e "PACKAGE_STORE=$PACKAGE_STORE"'
ansible-playbook smart.yml -t "$SMART_TAGS" -e "INSTALLER_HOME=$INSTALLER_HOME" -e "PACKAGE_STORE=$PACKAGE_STORE" 