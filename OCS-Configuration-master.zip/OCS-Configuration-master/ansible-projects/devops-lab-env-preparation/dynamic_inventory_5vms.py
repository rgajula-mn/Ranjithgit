#!/usr/bin/env python

import ConfigParser
import argparse
from StringIO import StringIO

PROPERTIES_FILE = "ENV.properties"

try:
    import json
except ImportError:
    import simplejson as json

class Host(object):
    def __init__(self, nodename, ip):
        self.nodename = nodename # type: str
        self.ip = ip

    def vars(self):
        return {
            "nodename": self.nodename
        }

class OracleMachine(Host):
    def vars(self):
        vars = super(OracleMachine, self).vars()
        vars["install_oracle_version"] = "oracle_12.1.0.2_EE" if self.nodename == "rbm-be" else "oracle_12.1.0.2"
        return vars


class FiveMachinesInventory(object):

    def __init__(self):
        self._load_inventory()

    def _load_inventory(self):
        config = ConfigParser.RawConfigParser()
        with open(PROPERTIES_FILE) as stream:
            stream = StringIO("[root]\n" + stream.read())  # This line does the trick.
            config.readfp(stream)

        self.dns_suffix = config.get('root', 'DNS_SUFFIX')
        self.rbm_be = OracleMachine("rbm-be", config.get('root', 'RBM_BE_IP'))
        self.rbm_fe_01 = OracleMachine("rbm-fe-01", config.get('root', 'RBM_FE_IP'))
        self.rbm_fe_02 = OracleMachine("rbm-fe-02", config.get('root', 'RBM_FE_02_IP'))
        self.cube = Host("cube", config.get('root', 'CUBE_IP'))
        self.smart = Host("smart", config.get('root', 'SMART_IP'))
        self.cluster_name = config.get('root', 'CLUSTER_NAME')

        self.hosts = {
            self.rbm_be.ip: self.rbm_be,
            self.rbm_fe_01.ip: self.rbm_fe_01,
            self.rbm_fe_02.ip: self.rbm_fe_02,
            self.cube.ip: self.cube,
            self.smart.ip: self.smart
        }

    def get_inventory(self):
        return {
            "all": {
                "hosts": [
                    self.rbm_be.ip,
                    self.rbm_fe_01.ip,
                    self.rbm_fe_02.ip,
                    self.cube.ip,
                    self.smart.ip,
                ],
                "vars": {
                    "ansible_shell_type": "sh",
                    "dns_domain": self.dns_suffix,
                    "nodename_fqdn": "{{ nodename }}.{{ dns_domain }}",
                    "ip": "{{ ansible_default_ipv4.address }}",
                    "CLUSTER_NAME": self.cluster_name
                }
            },
            "SIMULATOR": [],
            "BIND": [self.rbm_be.ip],
            "CUBE" : [self.cube.ip],
            "DDRS": [self.cube.ip],
            "QCM_API": [self.cube.ip],
            "OAM": [self.cube.ip],
            "CASSANDRA": [
                self.cube.ip,
                self.smart.ip
            ],
            "ORACLE": [
                self.rbm_be.ip,
                self.rbm_fe_01.ip,
                self.rbm_fe_02.ip
            ],
            "RBM": {
              "children": ["RBM_BE","RBM_FE"]
            },
            "RBM_BE": [self.rbm_be.ip],
            "RBM_FE": [
                self.rbm_fe_01.ip,
                self.rbm_fe_02.ip
            ],
            "SMART": [self.smart.ip],
            "UIM": [self.cube.ip],
            "WEBLOGIC": [self.rbm_be.ip],
            "_meta": {
                "hostvars": dict((host.ip,host.vars()) for host in self.hosts.itervalues())
            }
        }

if __name__ == "__main__":
    inventory = FiveMachinesInventory()
    print json.dumps(inventory.get_inventory(), indent=True, sort_keys=False) 
