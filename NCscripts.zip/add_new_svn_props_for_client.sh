#/bin/sh
set -x

die () {
    echo >&2 "$@"
    exit 1
}
usage=$"This script will add new svn external properties for the given SVN URL of multiple projects,\n\
$0 svn_uri\n\,
eg: https://svnca.netcracker.com/RB/branches/Patches/O2/ (upto client name and including '/') \n\
"
[ "$#" -ge 1 ] || die "SVN URI is not provided. $usage"

SVNURL=$1
		cd /irb/bce/svn_nagidi
#        . /home/geneva/pavu0613
. ~/pavu0613
		rm -rf .svn
svn co --depth=empty $SVNURL /irb/bce/svn_nagidi
projects=$(svn ls $SVNURL)
echo "projects  : $projects"
for i in $projects
  do
		echo " subproject URL :  $SVNURL$i"
	        subprojects=$(svn ls $SVNURL$i)
        	echo "subprojects  : $subprojects"

	        for j in $subprojects
                do
                        if [ "$j" = "RBAPI/" ] 
				then
				rm -rf .svn
                                svn co --depth=empty ${SVNURL}${i}${j} /irb/bce/svn_nagidi 
				svn propdel svn:externals /irb/bce/svn_nagidi
cat > tmp << EOF
${SVNURL}${i}RB/SCHEMA SCHEMA
${SVNURL}${i}RB/GNVUA GNVUA
${SVNURL}${i}RB/APICAT APICAT
${SVNURL}${i}RB/APICORE APICORE
${SVNURL}${i}RB/APICUSTACC APICUSTACC
${SVNURL}${i}RB/APISYSCONFIG APISYSCONFIG
${SVNURL}${i}RB/CORE/BUILD CORE/BUILD
${SVNURL}${i}RB/CORE/TOOL CORE/TOOL
EOF
				svn propset svn:externals -F tmp /irb/bce/svn_nagidi
				svn ci -m "updating properties for RBAPI RBM-78794"
				rm -rf tmp
				
                        fi

			if [ "$j" = "WIN/" ]
                                  then
                            	        rm -rf .svn
                                        svn co --depth=empty ${SVNURL}${i}${j} /irb/bce/svn_nagidi
                                        svn propdel svn:externals /irb/bce/svn_nagidi
cat > tmp << EOF
${SVNURL}${i}RB/REPORTS REPORTS
EOF
                                        svn propset svn:externals -F tmp /irb/bce/svn_nagidi
                                        svn ci -m "updating properties for WIN  RBM-78794"
					rm -rf tmp .svn
					
					svn co --depth=empty ${SVNURL}${i}${j}PC/REPOSITORY/SRC /irb/bce/svn_nagidi
					svn up genevamessages.txt
						if [ -f genevamessages.txt ]
	                                        then
        	                                svn rm genevamessages.txt
                	                        fi
                                        svn propdel svn:externals /irb/bce/svn_nagidi
cat > tmp << EOF
${SVNURL}${i}RB/APICORE/genevamessages.txt genevamessages.txt
EOF
                                        svn propset svn:externals -F tmp /irb/bce/svn_nagidi
                                        svn ci -m "updating properties for WIN/PC/REPOSITORY/SRC/geneavemessages.txt  RBM-78794"
					rm -rf tmp .svn
					

                                fi

done

