#!/bin/sh
#
#  Script:              check_auto_gen_build_objs.sh
#  Instance:            CB1_1
#  Author:              sg
#  Start date:          Tue Oct 14 10:01:58 2003
#  Version:             %full_filespec: check_auto_gen_build_objs.sh-7:shsrc:CB1#1 %
#
#  Description:
#
#
# (C) Convergys, 2002.
# Convergys refers to Convergys Corporation or any of its wholly owned
# subsidiaries.

CCM_ROOT=$1
BUILD_LOG=$2

if [ -z "$CCM_ROOT" -o ! -d "$CCM_ROOT" ]
then
	echo "$0: Invalid CCM_ROOT: $CCM_ROOT"
	exit 1
fi

if [ -z "$BUILD_LOG" -o ! -f "$BUILD_LOG" ]
then
	echo "$0: Invalid Build Log: $BUILD_LOG"
	exit 2
fi

diff_files ()
{
	file1=$1
	file2=$2
	no_count=$3

	diff $file1 $file2 > /dev/null
	if [ $? -ne 0 ]
	then
		echo "$0: Differences detected in $file1 to $file2" >> $BUILD_LOG
		no_count=`expr $no_count + 1`
	fi

	echo $no_count	

}

no_of_errors=0

no_of_errors=`diff_files $CCM_ROOT/autogen/dropproc.sql $CCM_ROOT/SCHEMA/SRC/dropproc.sql $no_of_errors`

no_of_errors=`diff_files $CCM_ROOT/autogen/dropproc_event.sql $CCM_ROOT/SCHEMA/SRC/dropproc_event.sql $no_of_errors`

no_of_errors=`diff_files $CCM_ROOT/autogen/dropprocsyn.sql $CCM_ROOT/SCHEMA/synonyms/dropprocsyn.sql $no_of_errors`

no_of_errors=`diff_files $CCM_ROOT/autogen/dropprocsyn_event.sql $CCM_ROOT/SCHEMA/synonyms/dropprocsyn_event.sql $no_of_errors`

no_of_errors=`diff_files $CCM_ROOT/autogen/procsyn.sql $CCM_ROOT/SCHEMA/synonyms/procsyn.sql $no_of_errors`

no_of_errors=`diff_files $CCM_ROOT/autogen/procsyn_event.sql $CCM_ROOT/SCHEMA/synonyms/procsyn_event.sql $no_of_errors`

no_of_errors=`diff_files $CCM_ROOT/autogen/adminrole_proc.sql $CCM_ROOT/SCHEMA/roles/adminrole_proc.sql $no_of_errors`

no_of_errors=`diff_files $CCM_ROOT/autogen/adminrole_proc_event.sql $CCM_ROOT/SCHEMA/roles/adminrole_proc_event.sql $no_of_errors`


if [ -f "${CCM_ROOT}/autogen/GenevaDeltas.xsd" ]
then
    no_of_errors=`diff_files $CCM_ROOT/autogen/GenevaDeltas.xsd $CCM_ROOT/APICAT/ppetimport/RTEST/GenevaDeltas.xsd | grep -v Version: $no_of_errors`
fi

echo $no_of_errors 

