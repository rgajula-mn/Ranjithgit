#!/bin/sh
#
#  Script:              create_last_language_files.sh
#  Instance:            CB1_1
#  Author:              sg
#  Start date:          Tue Jan 20 15:24:24 2004
#  Version:             %full_filespec: language_merge.sh-12:shsrc:CB1#1 %
#
#  Description:
#
#
# (C) Convergys, 2002.
# Convergys refers to Convergys Corporation or any of its wholly owned
# subsidiaries.

# The location of the build scripts to use. If set in the env then use that else use proper place
. ${BCE_BUILD_SCRIPTS}/core_functions.sh

create_file ()
{
	mess_dir=$1
	last_release=$2

	last_dir=$mess_dir/last

	mkdir -p $last_dir
	if [ $? -ne 0 ]
	then
		echo "Cannot create $last_dir"
		exit 1
	fi
	
	for lang in `ls $mess_dir | grep -v last`
	do
		mkdir -p $last_dir/$lang
		if [ $? -ne 0 ]
		then
			echo "Cannot create $last_dir/$lang"
			exit 1
		fi

		if [ $lang = dev ]
		then
			dot_lang=""
		else
			dot_lang=".$lang"
		fi

		ccm query "name='geneva_messages$dot_lang' and is_member_of('$last_release')"
		if [ $? -ne 0 ]
		then
			echo "Cannot find geneva_messages$dot_lang in $last_release"
			continue
		fi

		ccm cat @1 > $last_dir/$lang/geneva_messages$dot_lang
	done

	return 0
}


# Main Program
############################################

# Check Arguments
if [ $# -ne 2 ]
then
	echo "Invalid Arguments to script."
	echo "Usage:"
	echo "$0 <CCM Project> <Release>"
	echo ""
	echo "Example:"
	echo "$0 GENEVA-sqa5.2.20.solaris.oracle9i2 5.2.20"
	exit 1
fi

ccm_project=$1
my_release=$2

my_project=`echo $ccm_project | cut -d- -f1`
my_version=`echo $ccm_project | cut -d- -f2`

# Only need to do strings if project = GENEVA
if [ $my_project = GENEVA -o $my_project = RB ]
then
	continue
else
	echo "Only localise strings if GENEVA or RB: I am $my_project"
	exit 3
fi

# Check CCM is running, else quit
ccm_working=`ccm set role`
if [ "$ccm_working" = '' ]
then
	echo "CCM not running"
	exit 2
fi

am_i_a_patch
if [ $? -eq 0 ]
then
	# I am a patch, ignore
	echo "I am a patch, do not localise strings"
	exit 3
fi

# Work out last release

# Take the current release, strip off the last number (minor release) and minus one.
echo my_release = $my_release
minor_release=`echo $my_release | cut -d'.' -f3`
echo minor_release = $minor_release
major_release=`echo $my_release | cut -d'.' -f1-2`
echo major_release = $major_release

last_release_minor=`expr $minor_release - 1`
echo last_release_minor = $last_release_minor
last_release="${major_release}.${last_release_minor}"
echo last_release = $last_release

echo ccm_project = $ccm_project
last_ccm_project=`echo $ccm_project | sed -e "s/$my_release/$last_release/g"`
echo last_ccm_project = $last_ccm_project

# Make the files

echo "ccm query -t project \"name = '${my_project}' and version = '${my_version}'\" -f \"%wa_path\" -u"
workarea=`ccm query -t project "name = '${my_project}' and version = '${my_version}'" -f "%wa_path" -u`
echo "workarea = $workarea"

full_workarea=`echo $workarea/$my_project/mess | sed -e 's/ //g'`
echo "full_workarea=$full_workarea"
if [ ! -d "$full_workarea" ]
then
	echo "Error: Cannot find path $full_workarea"
	exit 1
fi

if [ ! -f $full_workarea/last/dev/geneva_messages ]
then
	echo create_file $full_workarea $last_ccm_project
	create_file $full_workarea $last_ccm_project
	error_status=$?
	if [ $error_status -ne 0 ]
	then
		echo "Error received from create_file: $error_status"
		exit 4
	fi
else
	echo "INFO: Creation of last release mess files already ran once for this release"
fi

dateToday=`date "+%Y%m%d%H%M%S"`

case $major_release in
	4.*)
		echo "Not running the Language Merge process on VPA Messages"
		echo "	because this release does not have localised VPA messages."
		;;
	*)
		echo "Running the Language Merge Process for VPA Messages"
		
		locale_email_dir=${BCE_LOG}/language_strings/$my_project/$my_release/
		mkdir -p $locale_email_dir

		# Check that this version is not to be fully localised by looking in the config file
		grep -i "${my_release},enu" ${BCE_ADMIN}/config/who_to_localise > /dev/null
		if [ $? -ne 0 ]
		then
			echo "Subject: Language Merge: ${my_project} ${my_release} geneva_messages.enu" > $locale_email_dir/geneva_messages_enu.diff
			echo "Running: ${BCE_BUILD_SCRIPTS}/language_merge.pl $full_workarea/last/dev/geneva_messages $full_workarea/dev/geneva_messages $full_workarea/enu $full_workarea/enu/geneva_messages.enu"
			${BCE_BUILD_SCRIPTS}/language_merge.pl $full_workarea/last/dev/geneva_messages $full_workarea/dev/geneva_messages $full_workarea/enu $full_workarea/enu/geneva_messages.enu >> $locale_email_dir/geneva_messages_enu.diff 2>&1
			cat ${locale_email_dir}/geneva_messages_enu.diff | /usr/lib/sendmail -F "Language Merge" -f "RBMCIBERGroup@NetCracker.com" `cat ${BCE_ADMIN}/email/test`
			update_build_information.sh -S bs_misc_build -I "UNIX Language Merge" -p GENEVA -v $my_release -y ${dateToday}
		fi

		for i in `ls $full_workarea | grep -v dev | grep -v enu | grep -v last`
		do
			# Check that this version is not to be fully localised by looking in the config file
			grep -i "${my_release},$i" ${BE_ADMIN}/config/who_to_localise > /dev/null
			if [ $? -ne 0 ]
			then
				echo "Subject: Language Merge: ${my_project} ${my_release} geneva_messages.$i" > $locale_email_dir/geneva_messages_$i.diff
				echo "Running: ${BCE_BUILD_SCRIPTS}/language_merge.pl $full_workarea/last/dev/geneva_messages $full_workarea/dev/geneva_messages $full_workarea/$i $full_workarea/last/$i/geneva_messages.$i $full_workarea/enu/geneva_messages.enu"
				${BCE_BUILD_SCRIPTS}/language_merge.pl $full_workarea/last/dev/geneva_messages $full_workarea/dev/geneva_messages $full_workarea/$i $full_workarea/last/$i/geneva_messages.$i $full_workarea/enu/geneva_messages.enu >> $locale_email_dir/geneva_messages_$i.diff 2>&1
				cat ${locale_email_dir}/geneva_messages_$i.diff | /usr/lib/sendmail -F "Language Merge" -f "RBMCIBERGroup@NetCracker.com" `cat ${BCE_ADMIN}/email/test`
				update_build_information.sh -S bs_misc_build -I "UNIX Language Merge" -p GENEVA -v $my_release -y ${dateToday}				
			else
				echo "Config file states: This release is to be FULLY LOCALISED"
			fi
		done
		;;
esac

echo Exiting 0
exit 0
