#!/bin/ksh
set -x
export CURL_HOME=/tools/curl/curl-7.19.7_ssh
export PATH=$CURL_HOME/bin/:$PATH
export PATH=/tools/json/json-master:$PATH
export PATH=/tools/json/node-v0.10.30-linux-x64/bin:$PATH
export PATH=/tools/json/jqtool/bin:$PATH
export LD_LIBRARY_PATH=/tools/json/node-v0.10.30-linux-x64/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=$CURL_HOME/lib:$LD_LIBRARY_PATH
BCE_BUILD_SCRIPTS=/irb/bce/admin/ccm_wa/PRD-bce/PRD/build_scripts

#. /irb/bce/users/pavu0613/Myhtmls/functions.sh
. ${BCE_BUILD_SCRIPTS}/metadata_functions.sh

#rel=$1
#rel=echo "\"$rel\""

MAILTO=`cat /irb/bce/admin/email/head_build_managers`

if [ $# -ne 2 ]
then

echo "usage:"
exit
fi
while getopts u:d: the_option
do
        case $the_option in
        d)
		chosen="delete"
		rel=${OPTARG}
                ;;
        u)
                chosen="update"
		rel=${OPTARG}
		;;
	*)
                echo "Found $the_option Not supported"
                exit 1
                ;;
        esac
done



















echo $rel
id=`curl -k -H "Content-Type: application/json" -X GET -u ciber:8d#d56hg 'https://tms.netcracker.com/rest/api/2/project/RBM/versions?expand=id'|tr '},{' '},\n{'|grep -F "\"$rel\""|awk '{print $1}'|cut -d',' -f2`
echo "Fectched Id: $id"
count=`curl -k -H "Content-Type: application/json" -X GET -u ciber:8d#d56hg 'https://tms.netcracker.com/rest/api/2/project/RBM/versions?expand=id'|tr '},{' '},\n{'|grep -F "\"$rel\""|awk '{print $1}'|cut -d',' -f2|wc -l`






if [ "$count" -eq "0" ]
then
echo "[INFO ] No Ids found"
exit
fi

if [ "$count" -ne "0" -a "$count" -ne "1" ]
then
echo "[INFO ] More then one id is returned"
exit
fi

if [ "$count" -eq "1" ]
then
echo "[INFO ]ID FOUND FOR release $rel: $id"
pr_id=`echo $id|cut -d ':' -f2|sed 's/"//g'`
echo "ID: $pr_id"
echo "UPDATING THE METADATA"

count=`echo $rel|awk -F'.' '{print NF}'`
	if [ "$count" -eq 4 ]
	then
	echo "[INFO] ITS A PATCH: $rel"
	svn_link=`derivePatch $rel`

		if [ "$chosen" == "update" ]
		then
		echo "chosen to update"

		echo "[INFO] UPDATING"

		echo "curl -k -H \"Content-Type: application/json\" -X POST -u ciber:8d#d56hg https://tms.netcracker.com/rest/tms-toolkit/1.0/metadata/version/$pr_id/SVN%20Branch%20Path -d\"$svn_link\""

		run_out=`curl -k -H "Content-Type: application/json" -X POST -u ciber:8d#d56hg https://tms.netcracker.com/rest/tms-toolkit/1.0/metadata/version/$pr_id/SVN%20Branch%20Path -d"$svn_link"`
		echo "Metadata Status: $run_out" | mailx -s "Update metadata $rel" $MAILTO
#exit
		fi
	
		 if [ "$chosen" == "delete" ]
                then
                echo "chosen to delete"

		echo "curl -k -H \"Content-Type: application/json\" -X DELETE -u ciber:8d#d56hg https://tms.netcracker.com/rest/tms-toolkit/1.0/metadata/version/$pr_id/SVN%20Branch%20Path -d\"$svn_link\""

                echo "[INFO] DELETING"

                run_out=`curl -k -H "Content-Type: application/json" -X DELETE -u ciber:8d#d56hg https://tms.netcracker.com/rest/tms-toolkit/1.0/metadata/version/$pr_id/SVN%20Branch%20Path -d"$svn_link"`
		echo "Metadata Status: $run_out" | mailx -s "Deleted metadata $rel" $MAILTO
#exit
                fi



	fi

	if [ "$count" -eq 3 ]
	then
	echo "[INFO] ITS A Maint/Head: $rel"
	exit
	fi



fi
MAILTO=`cat /irb/bce/admin/email/head_build_managers`
echo "Meta_data test mail for $rel" | mailx -s "Update metadata $rel" $MAILTO





#derivePatch $rel

