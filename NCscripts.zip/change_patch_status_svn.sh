#!/bin/ksh

release_tag=$1
patch_tag=`echo $release_tag | cut -d"_" -f2`
echo $patch_tag
sleep 100

DATABASE=buildweb/georgespass@webca.world

logfile=/tmp/patch_status_update.log

while [ 1 ]
do
echo $patch_tag
status=`sqlplus -s $DATABASE << +ENDSQL
                set heading off
                set PAGESIZE 5000
                select STATUS from BATCH_COMMAND_SUMMARY where COMMAND like '%checkout_script%$release_tag%' and rownum <2;
                exit
	+ENDSQL`

if [ $status = "success" ]
then
	echo "update patch_summary set PATCH_STATUS='Setup' where version='$patch_tag' and PATCH_STATUS='Entered';"
	update=`sqlplus -s $DATABASE << +ENDSQL
                set heading off
                set PAGESIZE 5000
                update patch_summary set PATCH_STATUS='Setup' where version='$patch_tag' and PATCH_STATUS='Entered';
		commit;
                exit
	+ENDSQL` 
	exit 0
fi

if [ $status = "failed" ]
then
	echo "Batch command filed for $release_tag Please investigate" > $logfile
	mailx -s " Check out Batch Command failed for $release_tag " venu.gopal.r.pulimamidi@convergys.com  sridhar.davuluru@NetCracker.com < $logfile
	exit 
fi

sleep 50

done
