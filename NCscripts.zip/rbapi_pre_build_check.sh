#!/bin/ksh
#set -x
BCE_BUILD_SCRIPTS=/irb/bce/admin/ccm_wa/PRD-bce/PRD/build_scripts
#rbapi_workarea="/irb/bce/build/web/${project}-sqa${release}/${project}"
getOracleVersion()
{
        oracle_name=`sqlplus -s $BUILDWEB_DB << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                select ORACLE_NAME from PATCH_PLATFORMS where VERSION='${release}';
                exit
EOF`
        ora_ver=`echo $oracle_name|awk '{ print substr( $0, length($0) - 2, length($0) ) }'`

        oper_sys=`sqlplus -s $BUILDWEB_DB << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                select ORACLE_NAME from PATCH_PLATFORMS where VERSION='${release}';
                exit
EOF`
        RB_WORKAREA="/irb/bce/build/rb/${majorrelease}/RB-sqa${release}.${oper_sys}.${oracle_name}/RB"
}

check_env_merc_prop()
{
        mj_rel=`cat ${rbapi_workarea}/env.properties|grep PRODUCT_MAJOR_VERSION|cut -d'=' -f2`
        mn_rel=`cat ${rbapi_workarea}/env.properties|grep PRODUCT_MINOR_VERSION|cut -d'=' -f2`
        ptch_rel=`cat ${rbapi_workarea}/env.properties|grep PRODUCT_PATCH_VERSION|cut -d'=' -f2`

        env_rel=`echo "${mj_rel}.${mn_rel}.${ptch_rel}"`
        ecount=0
        if [ ${release} = ${env_rel} ]
        then
                echo "Release No. is Correct, in env.proeprties file"
#        else
#               ecount=`expr $ecount + 1`
        fi
        merc_file1=`echo "mercbuild_sqa_${mj_rel}_${mn_rel}_${ptch_rel}.properties"`
        merc_file2=`echo "mercbuild_sqa_${mj_rel}_${mn_rel}_${ptch_rel}.properties.template"`

        if [ -f /home/genadmin/${merc_file1} ] && [ -f /home/genadmin/${merc_file2} ]
        then
                echo "Merc Properties file is present"
		HOST_NAME=`hostname`
		WL_Version=`cat /home/genadmin/${merc_file1}|grep weblogic|grep -v '#'|sed -n '1p'|cut -d"=" -f1`
		WL_PATH=`cat /home/genadmin/${merc_file1}|grep weblogic|grep -v '#'|sed -n '1p'|cut -d"=" -f2`
		WL_HostName=`cat /home/genadmin/${merc_file1}|grep weblogic|grep -v '#'|sed -n '2p'|cut -d"=" -f2`
		if [ -d $WL_PATH ]
		then
			echo "Weblogic is Present in this $HOST_NAME,Build can proceed further"
		else
			echo "Incorrect Machine, Weblogic is NOT INSTALLED on this machine $HOST_NAME. Please check and start the build on proper machine"
			Message="Incorrect Machine, Weblogic is NOT INSTALLED on this machine $HOST_NAME. Please check and start the build on proper machine"
			ecount=`expr $ecount + 1`
		fi	
        else
		Message="Merc Properties file is not present, please create and rerun the build"
                ecount=`expr $ecount + 1`
        fi

        if [ ${ecount} -ge 1 ]
        then
                echo "Build cant proceed further, either merc propertes file doesnt exits or incorrect release no. in env.properties file"
                stat="F"
                echo "Build is Failed, Please check"
                /irb/bce/admin/ccm_wa/PRD-bce/PRD/build_scripts/test_eca_mail.sh -p ${project} -r ${release} -s ${stat} -m "${Message}"
                exit
        else
                echo "env.properties is correct and merc properties files exists, build can proceed further"
        fi
}

findExpectedRC()
{
        expectedRC=`sqlplus -s $BUILDWEB_DB << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                select cand_name from test_cand_summary where rowid=(select max(rowid) from test_cand_summary where project='RB' and version='${release}');
                exit
EOF`
        tmp=`echo $expectedRC | cut -c3`
if [ "${tmp}" = "" ]
then
        tmp=0
        tmp=`expr $tmp + 1`
fi
        if [ $tmp -gt 1  ]
        then
                previousRC=`expr $tmp - 1`
        fi
        expectedRC="RC$tmp"
        printf "\t[INFO] Next RC to be given: $expectedRC\n"
}


insertECAcompany()
{
        sqlquery="select COMPANY from buildweb.patch_company where PROJECT='RB' and VERSION='${release}'"

                Company=`sqlplus -s $BUILDWEB_DB << +END
                set feed off;
                set head off;
                set lines 32767;
                $sqlquery;
                exit;
+END`
Company=`echo $Company|awk '{$1=$1;print}'`
echo "$Company"

        eca_comp=`sqlplus -s $BUILDWEB_DB << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                select PROJECT from patch_company where PROJECT='ECA' and VERSION='${release}';
                exit
EOF`

        if [ "$eca_comp" = "" ]
        then
                stmt="insert into patch_company values('ECA','${release}','$Company');"
                sqlplus -s $BUILDWEB_DB << +END
                        set feed off
                        set head off
                        $stmt
                        exit
+END
                echo "$project_${release} is  added in table PATCH_COMPANY"
        else
                echo "$project_${release} is already added in table PATCH_COMPANY"
        fi

}

checkBuildStatus()
{

        echo "Arun Testing of Status Mail after the RBAPI build compleation"
        dots_in_release=`echo $release|tr -d -c '.'|wc -c`
        findExpectedRC
        getOracleVersion
        insertECAcompany
        if [ "$dots_in_release" -eq 2 ]
        then
               patch_rc="rc"
        elif [ "$dots_in_release" -eq 3 ]
        then
               patch_rc="patch"
        fi
        cat ${makeLog}|tail -20|grep 'BUILD SUCCESSFUL'
        if [ $? -eq 0 ]
        then
                stat="T"
                releaseTime=`date "+%Y%m%d%H%M%S"`
                candPath="/irb/candidate/${patch_rc}/rb/${majorrelease}/RB_${release}.${expectedRC}/full"
                echo "**********Generating ECA Package**********"
                echo "$BCE_BUILD_SCRIPTS/eca_zip_generate.sh ${release} jJ${ora_ver}.64 ${CCM_ROOT} ${candPath}"
                $BCE_BUILD_SCRIPTS/eca_zip_generate.sh ${release} jJ${ora_ver}.64 ${CCM_ROOT} ${candPath}
                if [ "$dots_in_release" -eq 3 ]
                then
                        echo "update_build_information_svn.sh -T -p RB -v $release -u arku1015 -j PATCH -s sqa -y $releaseTime -i ${expectedRC} -L $candPath"
                        ${BCE_BUILD_SCRIPTS}/update_build_information.sh -T -p "RB" -v "$release" -u "arku1015" -j "PATCH" -s "sqa" -y "$releaseTime" -i "${expectedRC}" -L "${candPath}"
                fi
                echo "**********ECA Package Generated**********"
                /irb/bce/admin/ccm_wa/PRD-bce/PRD/build_scripts/test_eca_mail.sh -p ${project} -r ${release} -s ${stat} -d ${candPath}
        else
                stat="F"
                echo "Build is Failed, Please check"
		Message="Build is Failed, Please check ${makeLog} and report the errors"
                /irb/bce/admin/ccm_wa/PRD-bce/PRD/build_scripts/test_eca_mail.sh -p ${project} -r ${release} -s ${stat} -m "${Message}"
        fi
}
