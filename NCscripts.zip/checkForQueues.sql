set verify off
set echo on

prompt Checking for queues on &&1...

column num_queue new_value exitcode

select count(*) num_queue
from dba_queues
where owner='&&1';

exit &&exitcode
