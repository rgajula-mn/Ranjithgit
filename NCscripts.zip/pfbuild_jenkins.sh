#!/bin/ksh
set -x
#####calling PF jenkins build script from APS page itself##########
. ${BCE_BUILD_SCRIPTS}/db_functions.sh
. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh


BUILDWEB_DB=`buildweb_connection`


usage()
{	
 	echo "$0 "
        echo ""
        echo "Usage : $0 <-r release>"
        echo ''
        echo "pfbuild_jenkins.sh -r 5.2.9"
        echo ''
        echo "  e.g. build_project "
	return 1
}

release=$1
URL="https://svncn.netcracker.com"
run_CI_job()
{
	export PATH=/tools/curl/curl-7.19.7/bin:$PATH
	curl -k -u genadmin:Fr0sties -FSubmit=Build "https://cisrvcn.netcracker.com/job/PF_Build/buildWithParameters?SVN_DEVLINE_URL=$URL_FNL&BUILD_RELEASE=$bld_release&BUILD_NAME=$bld_name&ORACLE_VERSION=$ora_ver_f&RC_NUNBER=$expectedRC&JAVA_HOME=$jdk_home"
}
dots_in_release=`echo $release|tr -d -c '.'|wc -c`
if [ "$dots_in_release" -eq 3 ]
then
RELEASE_PATCH=`echo $release|cut -d'.' -f1-3`
	gpcode=`sqlplus -s ${BUILDWEB_DB} << +END
        set pagesize 0 feedback off verify off heading off echo off;
        select a.GP_CODE from COMPANY_GPCODE a, patch_company b where b.version='${release}' and b.PROJECT='PF' and b.COMPANY=a.COMPANY_NAME;
        exit
+END`
ora_ver=`sqlplus -s ${BUILDWEB_DB} << +END
        set pagesize 0 feedback off verify off heading off echo off;
        select a.oracle_name from patch_platforms  a, patch_company b where b.version='${release}' and b.PROJECT='PF' and b.VERSION=a.VERSION;
        exit
+END`
	type="PATCH"
elif [ "$dots_in_release" -eq 2 ]
then
	ora_ver="oracle12c"
	type="MAINT"
fi
if [ "$ora_ver" = "oracle12c" ]
then
	ora_ver_f="12c"
elif [ "$ora_ver" = "oracle11g" ]
then
	ora_ver_f="11g"
elif [ "$ora_ver" = "oracle10g" ]
then
	ora_ver_f="10g"
fi
if [ "$type" = "MAINT" ]
then
        jdk_home="/apps/jdk1.8.0_65"
        URL_FNL="$URL/PF/trunk"
else 
	if [ "$gpcode" = "TFNCAM" -o "$gpcode" = "BOUYGT" -o "$gpcode" = "TLNT" -o "$gpcode" = "CSPIRE" ]
	then
		jdk_home="/apps/jdk1.8.0_65"
		URL_FNL="$URL/PF/branches/Patches/${gpcode}/${gpcode}_${RELEASE_PATCH}.x"
	else
		jdk_home="/apps/jdk1.7.0_25"
		URL_FNL="$URL/PF/branches/Patches/${gpcode}/${gpcode}_${RELEASE_PATCH}.x"
	fi
fi
bld_name=`echo $release`
bld_release=`echo $release|cut -d'.' -f1-2`
expectedRC=`sqlplus -s $BUILDWEB_DB << EOF
      whenever sqlerror exit failure
      set feed off
      set head off
      select cand_name from test_cand_summary where rowid=(select max(rowid) from test_cand_summary where project='${project}' and version='${releaseNum}');
      exit
EOF`
tmp=`echo $expectedRC | cut -c3`
if [ "${tmp}" = "" ]
then
        tmp=0
fi
        tmp=`expr $tmp + 1`
        if [ $tmp -gt 1  ]
        then
                previousRC=`expr $tmp - 1`
        fi
        expectedRC="RC$tmp"
        printf "\t[INFO] Next RC to be given: $expectedRC\n"

run_CI_job
