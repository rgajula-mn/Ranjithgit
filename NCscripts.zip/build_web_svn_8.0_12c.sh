#!/bin/ksh

#  Script:              build_web.sh
#  Instance:            1
#  Author:              sfp
#  Start date:          Thu Sep 01 2003
#  Version:             %full_filespec: build_web.sh-60.1.14.1.18:shsrc:CB1#1 %full_filespec: build_web.sh-31:shsrc:CB1#1 %Y%m%d"
#
#  Description:		Determines the version of javacore required for an
#					API project and updates the buildweb database.
#					Errors are displayed on the screen and no debugging
#					option.
#
# (C) Convergys, 2006.
# Convergys refers to Convergys Corporation or any of its wholly owned subsidiaries.

# General initialization section
# Set script paths and data files

. ~/.bce.ini

adminPath=$BCE_ADMIN

# includes
. ${BCE_BUILD_SCRIPTS}/web_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh

echo $BCE_BUILD_SCRIPTS

# variables
host=`uname -n`
whoami=`whoami`
platform=`platform`
#debug=`echo $debug_flag`
debug_flag='T'
APICUSTACC=${CCM_ROOT}/APICUSTACC

BUILDWEB_DB=`buildweb_connection`

export host whoami platform APICUSTACC debug_flag

showDebugMessage "Version:  %full_filespec: build_web.sh-60.1.14.1.18:shsrc:CB1#1 %Y%m%d"

usage()
{
	echo "$0 "
	echo ''
	echo "Usage : `basename $0` <-p project> <-r release> <-l logDate> <-s projectStates> [-q] [-u] [-c] [-o] [-h] [-b] [-t]"
	echo ''
	echo 'build_web.sh -p GENEVAAPI -r 5.4.23 -l 20061215_day -s sqa[all] -q'
	echo 'build_web.sh -p RBAPI -r 3.0.3 -l 20061215_day -s sqa[all] -q -t release'
	echo ''
	echo '  e.g. build_web.sh '
	echo ''
	echo ' <-p project> 		Project to build, either GENEVAAPI or RBAPI'
	echo ' <-r release> 		release to build eg. 5.4.23'
	echo ' <-l logDate> 		Folder for build logs'
	echo ' <-s projectStates> 	Project states and make mode for the builds eg. sqa[all]'
	echo ''
	echo ' [-q] 			Flag used for skipping reconfigures' 
	echo ''
	echo ' [-u db user] 		Use this db user. Can have optional SID eg.' 
	echo ' 				sqa5_4_23_web' 
	echo ' 				or sqa5_4_23_web@GRA1' 
	echo ''
	echo ' [-c] 			Flag used to specify a halfClean build'
	echo '				The halfClean target is intended for build managers whom are building manually,'
	echo '				this might be at the request of a web developer to establish a fault in the java code.'
	echo '				Usually the build will conduct a realClean on the code, which will remove all'
	echo '				references to java, plsql and core libraries. The introduction of the clean target enables'
	echo '				the build manager to only remove the java code and leave the plsql references, which is the'
	echo '				longest part of the build'
	echo ''
	echo ' [-b] 			Flag used for skipping regression test runs' 
	echo ''
	echo ' [-o] 			If building project that is already locking a db the lock is removed for the new build.' 
	echo ''
	echo ' [-t] 			For 3.0 RBAPI builds.'
	echo ' 				Set to - rtests - for regression test builds.' 
	echo ' 				Set to - release - for release builds.'
	echo ' 				Set to - twin - for executing rtests builds and then release builds in sequence.'
	echo ''
	echo ' [-h] 			Displays this help regarding usage' 

}

checkFlags()
{
	showDebugMessage "checkFlags: START"
	flag_SkipReconfigure=0

	for i in "$@"
	do
		if [ "$i" = "-SR" ] 
		then
			flag_SkipReconfigure=1
		fi
	done

	export flag_SkipReconfigure  
	showDebugMessage "checkFlags: flag_SkipReconfigure=$flag_SkipReconfigure"
	showDebugMessage "checkFlags: END"
}


db_load() {

    DATABASE=$1
    TARGETFILE=$2
    LOGFILE=$3
    export DATABASE TARGETFILE LOGFILE

    sqlplus -s "${DATABASE}" >> ${LOGFILE} 2>&1 << +ENDSQL
    whenever sqlerror exit 1
    @${TARGETFILE}
    @${CCM_ROOT}/CORE/BUILD/show_filtered_errors.sql
    commit;
    exit 0
+ENDSQL
	
    return $?

}


messString()
{
	echo "${*}" >> ${makeLog} 2>&1
	echo "" >> ${makeLog} 2>&1
}

preBuildCheck()
{
	showDebugMessage "preBuildCheck: START"
	showDebugMessage "preBuildCheck: ------------- SECTION BREAK --------------"
	showDebugMessage "preBuildCheck: Setting variables ..."

	project=$1
	showDebugMessage "preBuildCheck: project=$project"
	
	CCM_PREFIX=$2
	showDebugMessage "preBuildCheck: CCM_PREFIX=$CCM_PREFIX"
	
	release=$3
	showDebugMessage "preBuildCheck: release=$release"

	PRODUCT_MAJOR_VERSION=`echo "$release" | cut -d '.' -f1`
	PRODUCT_MINOR_VERSION=`echo "$release" | cut -d '.' -f2`
	PRODUCT_PATCH_VERSION=`echo "$release" | cut -d '.' -f3`
	PRODUCT_SUB_VERSION=`echo "$release" | cut -d '.' -f4`
	PRODUCT_PATCH_VERSION=`echo "$PRODUCT_PATCH_VERSION.$PRODUCT_SUB_VERSION"`

	showDebugMessage "preBuildCheck: PRODUCT_MAJOR_VERSION=$PRODUCT_MAJOR_VERSION"
	showDebugMessage "preBuildCheck: PRODUCT_MINOR_VERSION=$PRODUCT_MINOR_VERSION"
	showDebugMessage "preBuildCheck: PRODUCT_PATCH_VERSION=$PRODUCT_PATCH_VERSION"
	showDebugMessage "preBuildCheck: PRODUCT_SUB_VERSION=$PRODUCT_SUB_VERSION"

	buildSkip="no"
	showDebugMessage "preBuildCheck: buildSkip=$buildSkip"
	systemBuild="yes"
	showDebugMessage "preBuildCheck: systemBuild=$systemBuild"
	showDebugMessage "preBuildCheck: ... Done"

	export project CCM_PREFIX release systemBuild PRODUCT_MAJOR_VERSION PRODUCT_MINOR_VERSION PRODUCT_PATCH_VERSION

	showDebugMessage "preBuildCheck: Calling splitValue $release..."
	splitValue $release
	showDebugMessage "preBuildCheck: ... Returning from splitValue"

	if [ -d "${CCM_ROOT}" ]
	then		
		ccm_tool=`which_change_control ${project}`

		if [ "$ccm_tool" = "ccm" ]
		then			
			showDebugMessage "preBuildCheck: Calling reconfigureWait ${project}-${CCM_PREFIX}${release} 240 ${logPath} ..."
			
			if [ $flag_SkipReconfigure -eq 1 ]
			then
				showDebugMessage "preBuildCheck: Skipping reconfigure"
			else
				reconfigureWait ${project}-${CCM_PREFIX}${release} 240 ${logPath}
			fi

			showDebugMessage "preBuildCheck: ... Returning from reconfigureWait"

			error_status=$?
			if [ $error_status -ne 0 ]
			then
				error="Build of ${project}-${CCM_PREFIX}${release} `platform`"
				if [ $error_status -eq 1 ]
				then
					error="${error} aborted because there is a failed Reconfigure flag in the log directory."
				else
					error="${error} aborted because a time out occured whilst waiting for reconfigure"
				fi

				echo ${error} >> ${makeLog}
				buildSkip="yes"
				
				showDebugMessage "preBuildCheck: Calling mailResults ..."
				mailResults
				showDebugMessage "preBuildCheck: ... Returning from mailResults"
				return 3
			fi
		else
			CCM_ROOT="${CCM_ROOT}/../convergys/${projectsm}"
		fi

		if [ -d "${CCM_ROOT}" ]
		then
			messString "INFO: ${CCM_ROOT} is valid"
		else
			messString "ERROR: ${CCM_ROOT} is invalid - INVESTIGATE"
		fi

		cd ${CCM_ROOT}
		buildFile="${CCM_ROOT}/build.sh"
		if [ "$PRODUCT_MAJOR_VERSION" = "3" ]
		then
			if [ "$PRODUCT_MINOR_VERSION" = "0" -o "$PRODUCT_MINOR_VERSION" = "2" ]
			then

				if [ "$release" != "3.0.3.c2" -a "$release" != "3.0.4" ]
				then
					# All 3.0 streams except 3.0.3.c2 and 3.0.4 use the refactored build
					buildFile="${CCM_ROOT}/build_rf.sh"
				fi
			fi
		fi
		echo "$buildFile"
		export buildFile

		if [ -n "$buildFile" ]
		then
			messString "INFO: Located main build file: ${buildFile}."
		else
			messString "ERROR: No build file present."
		fi
	else
		messString "No workarea found for project."
		buildSkip="yes"
	fi
	
	showDebugMessage "preBuildCheck: END"

}

buildRelease()
{
	showDebugMessage "buildRelease: START"

	# Ensure we are in correct location
	# The script build_web.sh results in build.sh being called which loads the environment via build/env.sh
	showDebugMessage "buildRelease: Changing directory to ${CCM_ROOT}"
	cd ${CCM_ROOT}

	if [ -z "$halfClean" ]
	then
		if [ "$PRODUCT_MAJOR_VERSION" = "3" -o "$PRODUCT_MAJOR_VERSION" = "4" -o "$PRODUCT_MAJOR_VERSION" = "5" -o "$PRODUCT_MAJOR_VERSION" = "6" -o "$PRODUCT_MAJOR_VERSION" = "7" -o "$PRODUCT_MAJOR_VERSION" = "8" -o "$PRODUCT_MAJOR_VERSION" = "9" ]
		then
			if [ "$release" = "3.0.3.c2" -o "$release" = "3.0.4" ]
			then
				# Still the old build.sh
				messString "${buildFile} ${makeArgs} ${clean}"
				showDebugMessage "buildRelease: Calling ${buildFile} ${makeArgs} ${clean} ..."
				${buildFile} ${makeArgs} ${clean} >> ${makeLog} 2>&1
				showDebugMessage "buildRelease: ... Returning from ${buildFile}"
			else
				# The new refactored build
				messString "${buildFile} ${clean}"
				showDebugMessage "buildRelease: Calling ${buildFile} ${clean} ..."
				${buildFile} ${clean} >> ${makeLog} 2>&1
				showDebugMessage "buildRelease: ... Returning from ${buildFile}"
			fi
		else
			messString "${buildFile} ${makeArgs} ${clean}"
			showDebugMessage "buildRelease: Calling ${buildFile} ${makeArgs} ${clean} ..."
			${buildFile} ${makeArgs} ${clean} >> ${makeLog} 2>&1
			showDebugMessage "buildRelease: ... Returning from ${buildFile}"
		fi
	else
		messString "${buildFile} ${makeArgs} clean"
		showDebugMessage "buildRelease: Calling ${buildFile} ${makeArgs} clean ..."
		${buildFile} ${makeArgs} clean >> ${makeLog} 2>&1
		showDebugMessage "buildRelease: ... Returning from ${buildFile}"
	fi

	if [ "$PRODUCT_MAJOR_VERSION" = "3" -o "$PRODUCT_MAJOR_VERSION" = "4" -o "$PRODUCT_MAJOR_VERSION" = "5" -o "$PRODUCT_MAJOR_VERSION" = "6"  -o "$PRODUCT_MAJOR_VERSION" = "7" -o "$PRODUCT_MAJOR_VERSION" = "8" -o "$PRODUCT_MAJOR_VERSION" = "9" ]
	then
		if [ "$release" != "3.0.3.c2" -a "$release" != "3.0.4" ]
		then
			messString "${buildFile} ${build} ${makeArgs}"
			echo "Build started: `date`" >> ${makeLog} 2>&1
	
			showDebugMessage "buildRelease: Calling ${buildFile} ${build} ${makeArgs} ..."
			${buildFile} ${build} ${makeArgs} >> ${makeLog} 2>&1
		else
			messString "${buildFile} ${makeArgs} ${build}"
			echo "Build started: `date`" >> ${makeLog} 2>&1
	
			showDebugMessage "buildRelease: Calling ${buildFile} ${makeArgs} ${build} ..."
			${buildFile} ${makeArgs} ${build} >> ${makeLog} 2>&1
		fi
	else
		messString "${buildFile} ${makeArgs} ${build}"
		echo "Build started: `date`" >> ${makeLog} 2>&1
	
		showDebugMessage "buildRelease: Calling ${buildFile} ${makeArgs} ${build} ..."
		${buildFile} ${makeArgs} ${build} >> ${makeLog} 2>&1
	fi

	showDebugMessage "buildRelease: ... Returning from ${buildFile}"
	echo "Build finished: `date +'%a %b %d %T %Z %G'`" >> ${makeLog} 2>&1
	
	showDebugMessage "buildRelease: END"

}

create_database()
{
	showDebugMessage "create_database: START"

	showDebugMessage "create_database: Setting variables ..."
	SCHEMA_DIR=${CCM_ROOT}/SCHEMA
	showDebugMessage "create_database: SCHEMA_DIR=$SCHEMA_DIR"
	export SCHEMA_DIR
	showDebugMessage "create_database: ... Done"

	messString "Creating schema using build_project_svn"

	if [ "${project}" = "GENEVAAPI" ]
	then
		showDebugMessage "create_database: Calling build_project_svn -p GENEVA -o ${oracle} -r ${release}.solaris.${oracle} -m ${majorRelease} -d ${logDir} -t dbuser -s ${CCM_PREFIX} -u "${db_user}@${db_sid}" -L -l 0.7 "
		${BCE_BUILD_SCRIPTS}/build_project_svn -p GENEVA -o ${oracle} -r ${release}.solaris.${oracle} -m ${majorRelease} -d ${logDir} -t dbuser -s ${CCM_PREFIX} -u "${db_user}@${db_sid}" -L -l 0.7
		db_log_prefix=make_GENEVA_${CCM_PREFIX}${release}.solaris.${oracle}_dbuser
	else
		showDebugMessage "create_database: Calling build_project_svn -p RB -o ${oracle} -r ${release}.linux.${oracle} -m ${majorRelease} -d ${logDir} -t dbuser -s ${CCM_PREFIX} -u "${db_user}@${db_sid}" -L -l 0.7 "
		${BCE_BUILD_SCRIPTS}/build_project_svn -p RB -o ${oracle} -r ${release}.linux.${oracle} -m ${majorRelease} -d ${logDir} -t dbuser -s ${CCM_PREFIX} -u "${db_user}@${db_sid}" -L -l 0.7
		db_log_prefix=make_RB_${CCM_PREFIX}${release}.linux.${oracle}_dbuser			
		showDebugMessage "majorrelease = ${majorrelease} majorRelease=$majorRelease CCM_PREFIX=${CCM_PREFIX}"
		if [ "${majorrelease}" = "3.1" ]
		then
			if [ "${CCM_PREFIX}" != "sqa" ]
			then
				showDebugMessage "create_database: Calling db_load ${DATABASE} "${CCM_ROOT}/SCHEMA/SRC/trigger.sql" ${rtestLog} ..."
				db_load ${DATABASE} "${CCM_ROOT}/SCHEMA/SRC/trigger.sql" ${makeLog}
				showDebugMessage "create_database: Completed db_load of trigger.sql"
				showDebugMessage "create_database: Calling db_load ${DATABASE} "${CCM_ROOT}/SCHEMA/SRC/development_owned/3.1A_3.1C/S1_trigger.sql" ${rtestLog} ..."
				db_load ${DATABASE} "${CCM_ROOT}/SCHEMA/SRC/development_owned/3.1A_3.1C/S1_trigger.sql" ${makeLog}
				showDebugMessage "create_database: Completed db_load of S1_trigger.sql"
			fi
		fi
	fi
	
	export db_log_prefix

	showDebugMessage "create_database: ... Returning from build_project_svn"

	if [ $? -eq 0 ]
	then
		showDebugMessage "create_database: ------------- SECTION BREAK --------------"
		showDebugMessage "create_database: Loading ECA"
		showDebugMessage "create_database: Setting variables ..."
		
		echo  "Loading ECA specific procedures.."
		showDebugMessage "create_database: Changing directory to ${CCM_ROOT}/ECA/schema/debugScripts"
		cd ${CCM_ROOT}/ECA/schema/debugScripts
		
		sqlFiles=`ls | grep sql`
		showDebugMessage "create_database: sqlFiles=$sqlFiles"
		spcFiles=`ls | grep spc`
		showDebugMessage "create_database: spcFiles=$spcFiles"
		specialspc=`find ${CCM_ROOT}/ECA/api -name gnvj2eeaudit.spc -print`
		showDebugMessage "create_database: specialspc=$specialspc"
		bdyFiles=`ls | grep bdy`
		showDebugMessage "create_database: bdyFiles=$bdyFiles"
	
		showDebugMessage "create_database: ... Done"

		for f in ${sqlFiles} ${specialspc} ${spcFiles} ${bdyFiles}
		do
			showDebugMessage "create_database: Calling db_load ${DATABASE} ${f} ${makeLog} ..."
			db_load ${DATABASE} ${f} ${makeLog}
			showDebugMessage "create_database: ... Returning from db_load"
		done

		showDebugMessage "create_database: Changing directory to ${CCM_ROOT}/ECA/api"
		cd ${CCM_ROOT}/ECA/api

		for t in sql spc bdy
		do
			files=`find . -name *.$t -print | grep -v tca/rtests`
			
			for f in $files
			do
				showDebugMessage "create_database: Calling db_load ${DATABASE} ${f} ${makeLog} ..."
				db_load ${DATABASE} ${f} ${makeLog}
				showDebugMessage "create_database: ... Returning from db_load"
			done
		done

		showDebugMessage "create_database: Changing directory to ${CCM_ROOT}/ECA/schema/geneva/SAMPLE_DATA/attributes"
		cd ${CCM_ROOT}/ECA/schema/geneva/SAMPLE_DATA/attributes

		echo "Loading: attributetablechanges.sql"
		showDebugMessage "create_database: Calling db_load ${DATABASE} attributetablechanges.sql ${makeLog} ..."
		db_load ${DATABASE} attributetablechanges.sql ${makeLog}
		showDebugMessage "create_database: ... Returning from db_load"

		showDebugMessage "create_database: Calling loadStaticData ${CCM_ROOT} ${DATABASE} ${makeLog} ${majorRelease} ${release} ${project}..."
		loadStaticData ${CCM_ROOT} ${DATABASE} ${makeLog} ${majorRelease} ${release} ${project}
		showDebugMessage "create_database: ... Returning from loadStaticData"
	else
		echo "ERROR: An error was encountered when creating the schema, please check and try again"
	fi

	showDebugMessage "create_database: END"
}

mailResults()
{
	showDebugMessage "mailResults: START"
	
	showDebugMessage "mailResults: Calling ${BCE_BUILD_SCRIPTS}/check_overnight_builds.pl ${makeLog} ..."
	${BCE_BUILD_SCRIPTS}/check_overnight_builds.pl ${makeLog}
	showDebugMessage "mailResults: ... Returning from ${BCE_BUILD_SCRIPTS}/check_overnight_builds.pl"

	showDebugMessage "mailResults: END"
}

checkBuild()
{
	showDebugMessage "checkBuild: START"

	if [ "$release" = "3.0.3.c2" -o "$release" = "3.0.4" ]
	then
  		showDebugMessage "checkBuild: Calling getBuildArgs ${project} ${majorRelease} ${CCM_PREFIX} ${release} ..."
		getBuildArgs ${project} ${majorRelease} ${CCM_PREFIX} ${release}
	else
		showDebugMessage "checkBuild: Calling getBuildArgs ${project} ${majorRelease} ${CCM_PREFIX} ..."
		getBuildArgs ${project} ${majorRelease} ${CCM_PREFIX}
	fi

	showDebugMessage "checkBuild: ... Returning from getBuildArgs"

	if [ ! -d "${CCM_ROOT}/${jarloc}" ]
	then
		messString "ERROR: No compiled jar files could be found for testing." >> ${makeLog}
		skipRTests="T"
	else
		showDebugMessage "checkBuild: Changing directory to ${CCM_ROOT}"
		cd ${CCM_ROOT}
		
		messString "Deliverables build for testing." >> ${makeLog}
		find . -name geneva_j2ee.jar -print | grep ${jarloc} | uniq >> ${makeLog}
		skipRTests="F"
	fi
	
	showDebugMessage "checkBuild: skipRTests=$skipRTests"
	export skipRTests
	
	showDebugMessage "checkBuild: END"
}

get_db_machine_from_sid ()
{
	my_db_sid=$1
	sid_uc=`echo $my_db_sid | tr '[a-z]' '[A-Z]'`
	sql="select host from bce_databases where sid='$sid_uc'"
	
	sql_query $BUILDWEB_DB "$sql" "n"
	
}

get_db ()
{

	CCM_PREFIX=$1

	if [ "$db_arg" = "" ]
	then
		db_user=`echo ${CCM_PREFIX}${relUnderscore}_web | tr '.' '_'`

		echo "Running choose_build_db.sh"

		echo $BCE_BUILD_SCRIPTS/choose_build_db.sh -p "${project}-${CCM_PREFIX}${release}.web.${oracle}" -m "${majorRelease}" -o "$oracle" -t "${CCM_PREFIX} -i"
		
		db_sid=`$BCE_BUILD_SCRIPTS/choose_build_db.sh -p "${project}-${CCM_PREFIX}${release}.web.${oracle}" -m "${majorRelease}" -o "$oracle" -t "${CCM_PREFIX}" -i`
		
		status=$?
		if [ $status -ne 0 ]
		then
			echo "Error in choose_build_db.sh:"	
			echo "$db_sid"
			echo "status = $status"
			exit 1
		else
			echo "Database from choose_build_db: $db_sid"
		fi
		    
	else
		db_user=`echo $db_arg | sed -e 's/@.*$//'`
		db_sid=`echo $db_arg | sed -e "s/$db_user//" -e "s/@//"`
		
		if [ "$db_sid" != "" ]
		then
			db_sid=${db_sid}".world"
		else
			db_sid=`$BCE_BUILD_SCRIPTS/choose_build_db.sh -p "${project}-${CCM_PREFIX}${release}.web.${oracle}" -m "${majorRelease}" -o "$oracle" -t "${CCM_PREFIX}" "$rem_lock" -i`
			if [ $? -ne 0 ]
			then
				echo "Error in choose_build_db.sh:"	
				echo "$db_sid"
				exit 1
			fi
		fi
	fi

	DATABASE="${db_user}/${db_user}@${db_sid}"

	db_sid=`echo $db_sid | sed -e "s/\.world//"`

	#Need this bit because check_overnight_builds.pl depends on it to display the DB used in build information
	dbsid=`echo $db_sid`

	db_machine_tmp=`get_db_machine_from_sid $db_sid`
	db_machine=`echo $db_machine_tmp`

	export DATABASE db_user db_sid dbsid db_machine

}

generate_prop_file ()
{

	non_platform_build=$1

	cat "${propFile}" | sed "s/<<DB_USER>>/${db_user}/g" | sed "s/<<DB_PASSWORD>>/${db_user}/g" | sed "s/<<DB_MACHINE>>/${db_machine}/g" | sed "s/<<DB_SID>>/${db_sid}/g" | sed "s/<<PLATFORM_BUILD>>/${non_platform_build}/g" > "${targetFile}"

}

main()
{

	CCM_PREFIX=$1
	makeMode=$2

	showDebugMessage "main: ------------- SECTION BREAK --------------"
	showDebugMessage "main: Processing for state=$state"
	showDebugMessage "main: Setting variables ..."
	
	CCM_ROOT="$BCE_ROOT/build/web/${project}-${CCM_PREFIX}${release}/${project}"
	showDebugMessage "main: CCM_ROOT=$CCM_ROOT"
	
	resolvedDir="$BCE_ROOT/build/web/resolved"
	showDebugMessage "main: resolvedDir=$resolvedDir"

	makeLog="${logPath}/make_${project}_${CCM_PREFIX}${release}_${makeMode}.log"
	showDebugMessage "main: makeLog=$makeLog"
	
	showDebugMessage "main: ... Done"

	export CCM_PREFIX makeMode CCM_ROOT resolvedDir makeLog

	if [ -z "${propFile}" ]
	then
		showDebugMessage "main: propFile=$propFile (which cannot be identified)"
		messString "ERROR: Cannot locate the properties file for ${project}-${release}"
		mailResults
		exit 1
	fi

	if [ -d "${resolvedDir}" ]
	then
		showDebugMessage "main: $resolvedDir exists and will be deleted"
		chmod -R 777 ${resolvedDir}
		echo "Removing resolved dir from build area."
		rm -rf ${resolvedDir}
	fi

	showDebugMessage "main: project=$project"
	showDebugMessage "main: release=$release"
	showDebugMessage "main: logPath=$logPath"
	showDebugMessage "main: projectStates=$projectStates"
	showDebugMessage "main: halfClean=$halfClean"
	showDebugMessage "main: propFile=$propFile"
	showDebugMessage "main: skipRTests=$skipRTests"
	showDebugMessage "main: flag_SkipReconfigure=$flag_SkipReconfigure"
	showDebugMessage "main: db_arg=$db_arg"
	showDebugMessage "main: build_type=$build_type"

	showDebugMessage "main: Calling preBuildCheck ${project} ${CCM_PREFIX} ${release} ..."
	preBuildCheck ${project} ${CCM_PREFIX} ${release}
	showDebugMessage "main: ... Returning from preBuildCheck"

	if [ "$buildSkip" = "no" ]
	then
		showDebugMessage "main: makeMode=$makeMode (prior to case statement)"
	
		case ${makeMode} in
		all)
			if [ "$db_arg" = "" ]
			then
				showDebugMessage "main: Calling create_database ${DATABASE} >> ${makeLog} 2>&1...";
				create_database ${DATABASE} >> ${makeLog} 2>&1;
				showDebugMessage "main: ... Returning from create_database";
			fi

			if [ "$release" = "3.0.3.c2" -o "$release" = "3.0.4" ]
			then
				showDebugMessage "main: Calling getBuildArgs ${project} ${majorRelease} ${CCM_PREFIX} ${release} >> ${makeLog} 2>&1 ...";
				getBuildArgs ${project} ${majorRelease} ${CCM_PREFIX} ${release} >> ${makeLog} 2>&1;
				showDebugMessage "main: ... Returning from getBuildArgs";
			else
				showDebugMessage "main: Calling getBuildArgs ${project} ${majorRelease} ${CCM_PREFIX} ..."
				getBuildArgs ${project} ${majorRelease} ${CCM_PREFIX} >> ${makeLog} 2>&1;
				showDebugMessage "main: ... Returning from getBuildArgs";
			fi
	
			showDebugMessage "main: Calling buildRelease >> ${makeLog} 2>&1...";
			buildRelease >> ${makeLog} 2>&1;
			showDebugMessage "main: ... Returning from buildRelease";
			
			if [ "${skipRTests}" = "F" ]
			then
				showDebugMessage "main: Calling checkBuild >> ${makeLog} 2>&1...";
				checkBuild >> ${makeLog} 2>&1;
				showDebugMessage "main: ... Returning from checkBuild";
			fi
			;;

		dbuser)
			skipRTests=T
			showDebugMessage "main: Calling create_database ${DATABASE} >> ${makeLog} 2>&1...";
			create_database ${DATABASE} >> ${makeLog} 2>&1;
			showDebugMessage "main: ... Returning from create_database";;
		
		env)
			messString "Changes for the env build mode has yet to be implemented...";;
	
		*)
			messString "Build type for this project cannot be found.";;
		
		esac

		if [ "${skipRTests}" = "F" ]
		then
			messString "INFO: Running unit tests for ${project}-${CCM_PREFIX}${release}"
			showDebugMessage "main: Calling eca_rtests ${project} ${CCM_PREFIX} ${release} ${DATABASE}..."
			${BCE_BUILD_SCRIPTS}/eca_rtests ${project} ${CCM_PREFIX} ${release} ${DATABASE}
			showDebugMessage "main: ... Returning from eca_rtests"
		else
			echo "Regression tests not running for this release."
		fi
	else
		messString "ERROR: BUILD FAILED: No workarea present for ${project}-${CCM_PREFIX}${release}."
		continue
	fi

	showDebugMessage "main: END"
}

move_logs ()
{

	build_run_type=$1

	if [ -f "$makeLog" ]
	then
		echo "Moving $makeLog to ${logPath}/make_${project}_${CCM_PREFIX}${release}_${makeMode}_${build_run_type}.log"
		mv $makeLog "${logPath}/make_${project}_${CCM_PREFIX}${release}_${makeMode}_${build_run_type}.log"
	fi

	makeLog="${logPath}/make_${project}_${CCM_PREFIX}${release}_${makeMode}_${build_run_type}.log"

	export makeLog

	if [ -f "${logPath}/${db_log_prefix}.log" ]
	then
		echo "Moving ${logPath}/${db_log_prefix}.log to ${logPath}/${db_log_prefix}_${build_run_type}.log"
		mv "${logPath}/${db_log_prefix}.log" "${logPath}/${db_log_prefix}_${build_run_type}.log"
	fi

}


setup_env()
{

	showDebugMessage "setup: ------------- SECTION BREAK --------------"
	showDebugMessage "setup: Setting variables for other build scripts ..."

	LOGDIR="$logPath"      #required for the reconfigureWait function call
	showDebugMessage "setup: LOGDIR=$LOGDIR"
		
	projectsm=`echo $project | tr '[A-Z]' '[a-z]'`
	showDebugMessage "setup: projectsm=$projectsm"

	#needs to be like this rather than tr '.' '_' because ant scripts expects it in this format
	relUnderscore=`echo $release | sed -e 's/\./_/' | sed -e 's/\./_/'`
	showDebugMessage "setup: relUnderscore=$relUnderscore"
		
	majorRelease=`echo $release | cut -d '.' -f1-2`
	showDebugMessage "setup: majorRelease=$majorRelease"

	#needs to be in lower case for setup_bc_env
	majorrelease=`echo $majorRelease`

	PLATFORM=`/usr/local/bin/platform`
	showDebugMessage "setup: PLATFORM=$PLATFORM"

	if [ "${project}" = "RBAPI" ]
	then
		case $majorRelease in
                	3.*|4.0|4.1|4.2)
				oracle="oracle10g"
				DATABASE_TYPE="10g"
			;;
			 8.0)
                                oracle="oracle12c"
				DATABASE_TYPE="12c"
                        ;;

                        *)
                        	oracle="oracle11g"
				DATABASE_TYPE="11g"
                        ;;
		esac
	else
		oracle="oracle9i2"
	fi

	showDebugMessage "setup: oracle=$oracle"

	case $majorRelease in
	                3.*|4.0|4.1)
                        if [ `hostname` != "snowbell" ]
                        then
                                showDebugMessage "setup: Not running on snowbell ... exiting"
                                messString "$project $majorRelease builds can only be ran on snowbell (exiting)"
                                return 1
                        fi
                        ;;

		4.2|4.3|4.4|5.0|5.1|5.2|5.3|6.0|6.1|7.0)
			if [ `hostname` != "alder" ]
			then
				showDebugMessage "setup: Not running on Alder ... exiting"
				messString "$project $majorRelease builds can only be ran on Alder (exiting)"
				return 1
			fi
			;;
			9.0|8.0)
				if [ `hostname` != "devapp697cn" ]
                        then
                                showDebugMessage "setup: Not running on devapp697cn....exiting"
                                messString "$project $majorRelease builds can only be ran on devapp697cn (exiting)"
                                return 1
                        fi
                        ;;

		*)
			if [ `hostname` != "kingfisher" ]
			then
				showDebugMessage "setup: Not running on Osprey ... exiting"
				messString "$project $majorRelease builds can only be ran on Osprey (exiting)"
				return 1
			fi
			propFile="/home/geneva/mercbuild_${relUnderscore}.properties"
			showDebugMessage "setup: propFile=$propFile"
	
			db_sid=`cat ${propFile} | grep build.OracleConnection | cut -d ':' -f6 | tr '[a-z]' '[A-Z]'`
			showDebugMessage "setup: dbsid=$db_sid"
	
			db_user=`cat ${propFile} | grep -i username | cut -d '=' -f2`
			showDebugMessage "setup: dbUser=$db_user"
	
			DATABASE="${db_user}/${db_user}@${db_sid}.world"
			showDebugMessage "setup: DATABASE=$DATABASE"
			;;
	esac

	showDebugMessage "setup: setmybce ${project} ${release} sdk ${oracle} ${PLATFORM}"
	setmybce "${project}" "${release}" sdk ${oracle} ${PLATFORM}
	error_status=$?
	if [ $error_status -ne 0 ]
	then
		echo "Error $error_status reported from setup_oracle_env:setmyoracle. Exiting"
		exit 1
	fi

	export LOGDIR logDir projectsm relUnderscore majorRelease project release projectStates halfClean flag_SkipReconfigure propFile targetFile db_arg skipRTests
	export oracle build_type db_sid db_user DATABASE majorrelease PLATFORM DATABASE_TYPE

	case ${build_type} in
		rtests)
			for state in `echo ${projectStates}`
			do
				CCM_PREFIX=`echo ${state} | cut -d'[' -f1`		
				makeMode=`echo ${state} | cut -d'[' -f2 | cut -d']' -f1`

				propFile="/home/geneva/mercbuild_${CCM_PREFIX}_${relUnderscore}.properties.template"
				targetFile="/home/geneva/mercbuild_${CCM_PREFIX}_${relUnderscore}.properties"
				
				if [ -f "${targetFile}" ]
				then
					rm "${targetFile}"
				fi

				skipRTests=F
				export skipRTests

				get_db ${CCM_PREFIX}
				generate_prop_file yes
				main ${CCM_PREFIX} ${makeMode}
				
				move_logs rtests

				mailResults
			done
			;;
		release)
			for state in `echo ${projectStates}`
			do
				CCM_PREFIX=`echo ${state} | cut -d'[' -f1`		
				makeMode=`echo ${state} | cut -d'[' -f2 | cut -d']' -f1`

				propFile="/home/geneva/mercbuild_${CCM_PREFIX}_${relUnderscore}.properties.template"
				targetFile="/home/geneva/mercbuild_${CCM_PREFIX}_${relUnderscore}.properties"
				
				if [ -f "${targetFile}" ]
				then
					rm "${targetFile}"
				fi
				
				skipRTests=T
				export skipRTests
				
				get_db ${CCM_PREFIX}
				generate_prop_file ""
				main ${CCM_PREFIX} ${makeMode}
			
				move_logs release

				mailResults
			done
			;;
		twin)
			for state in `echo ${projectStates}`
			do
				CCM_PREFIX=`echo ${state} | cut -d'[' -f1`		
				makeMode=`echo ${state} | cut -d'[' -f2 | cut -d']' -f1`

				propFile="/home/geneva/mercbuild_${CCM_PREFIX}_${relUnderscore}.properties.template"
				targetFile="/home/geneva/mercbuild_${CCM_PREFIX}_${relUnderscore}.properties"
				
				if [ -f "${targetFile}" ]
				then
					rm "${targetFile}"
				fi

				skipRTests=F
				export skipRTests

				get_db ${CCM_PREFIX}

				generate_prop_file yes
				main ${CCM_PREFIX} ${makeMode}

				move_logs rtests

				mailResults
			
				flag_SkipReconfigure=1
				skipRTests=T
				export skipRTests flag_SkipReconfigure
				generate_prop_file ""
				main ${CCM_PREFIX} ${makeMode}
				
				move_logs release

				mailResults
			done
			;;
		*)
			for state in `echo ${projectStates}`
			do
				CCM_PREFIX=`echo ${state} | cut -d'[' -f1`		
				makeMode=`echo ${state} | cut -d'[' -f2 | cut -d']' -f1`

				main ${CCM_PREFIX} ${makeMode}

				mailResults
			done
			;;
	esac

}


flag_SkipReconfigure=0
rem_lock=""

showDebugMessage "START"

showDebugMessage "Reading parameters ..."

while getopts p:r:l:s:d:c:u:t:qbh the_option
do
	case $the_option in
	p)
		project=${OPTARG}
		echo ""
		;;
	r)
		release=${OPTARG}
		;;
	l)
		logDir=${OPTARG}
		;;
	s)
		projectStates=`echo ${OPTARG} | tr "-" " "`
		;;
	b)
		skipRTests=T
		;;
	c)
		halfClean=${OPTARG}
		;;
	q)
		flag_SkipReconfigure=1
		;;
	u)
		db_arg=${OPTARG}
		;;
	o)
		rem_lock="-R"
		;;
	t)
		build_type=${OPTARG}
		;;
	h)
		usage
		exit 1
		;;
	*)
		echo "Found $the_option Not supported"
		usage
		exit 1
		;;
	esac
done

if [ -z "${project}" -o -z "${release}" -o -z "${logDir}" ]
then
	echo "Mandatory options are not provided"
	echo "	Project	= ${project}"
	echo "	Release = ${release}"
	echo "	LogDir = ${logDir}"
	usage
	exit 1
fi

if [ -z "${projectStates}" ]
then
	projectStates="sqa[all]"
	echo "Overriding projectStates, new value=$projectStates"
fi

if [ `dirname "${logDir}"` = "/irb/bce/admin/log" -o `dirname "${logDir}"` = "${BCE_BUILD_SCRIPTS}" ]
then
	logPath="${logDir}"
elif [ `dirname "${logDir}"` = '.' ]
then
	logPath="/irb/bce/admin/log/${logDir}"
else
	logPath="${logDir}"
fi

logDir=`basename ${logDir}`

. ${BCE_BUILD_SCRIPTS}/setup_bc_env ${release} ${project}
setup_env ${*}

#main ${*}

