#!/bin/sh
set -x
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh

release_tag=$1
if [ -z "$release_tag" ]
then
	echo "Usage: $0 <release tag>"
	exit 1
fi

TMPFILE=/tmp/crn.$$
TMPFILE2=/tmp/crn2.$$

#startCCM /ccm/pird

BUILDWEB_DATABASE=`buildweb_connection`

echo "Subject: APS: ${release_tag}: Release Notes " > $TMPFILE2
${BCE_BUILD_SCRIPTS}/check_patch_relnote_svn.sh -t $release_tag >> $TMPFILE2
cat $TMPFILE2
project_version=`discover_release_tag.sh -t $release_tag`
project=`echo $project_version | cut -d' ' -f1`
version=`echo $project_version | cut -d' ' -f2`
ccm_project=`cat $TMPFILE2 | grep "SVN Project =" | awk '{print $4}'`
wa_path=`cat $TMPFILE2 | grep "WA Path =" | awk '{print $5}'`
wa_path_no_proj=`echo $wa_path | sed -e 's/$ccmproject//g'`

cat $TMPFILE2 | grep "successfully processed" > /dev/null
success=$?
if [ $success -ne 0 ]
then
	echo "Subject: APS: ${release_tag}: Release Notes Error" > $TMPFILE
	echo "Summary" >> $TMPFILE
	echo "-------" >> $TMPFILE
	echo "" >> $TMPFILE
	cat $TMPFILE2 | grep ERROR >> $TMPFILE
	echo "" >> $TMPFILE
	echo "" >> $TMPFILE
	echo "Full Log" >> $TMPFILE
	echo "--------" >> $TMPFILE
	echo "" >> $TMPFILE
	cat $TMPFILE2 >> $TMPFILE
	cat $TMPFILE | /usr/lib/sendmail `cat /irb/bce/admin/email/patch_build_managers` 
#	cat $TMPFILE | /usr/lib/sendmail reshma.goud.ireni@netcracker.com Rajender.venkatapur@NetCracker.com 

	sql="update patch_summary set rnotes_ok='1' where project='$project' and version='$version'"
	sql_query $BUILDWEB_DATABASE "$sql"
	echo $sql
fi

if [ $success -ne 0 ]
then
	rm $TMPFILE $TMPFILE2
	#cleanUpCCM
	exit 1
else
	rel_project_version=`discover_release_tag.sh -t $release_tag -i`
	rel_project=`echo $rel_project_version | cut -d' ' -f1`
	rel_project_low=`echo $rel_project |tr '[A-Z]' '[a-z]'`
	rel_version=`echo $rel_project_version | cut -d' ' -f2`
	baserel=`echo $rel_version | cut -d'.' -f1-2`
	echo "Subject: APS: ${release_tag}: Release Notes Error (2)" >> $TMPFILE2
	echo "-------------------" >> $TMPFILE2
	echo "Add Release Notes Output" >> $TMPFILE2
	echo "Running Command: add_release_notes_svn.sh -t ${release_tag} -i \"${ccm_project}\" -y" >> $TMPFILE2
	add_release_notes_svn.sh -t ${release_tag} -i "${ccm_project}" -y >> $TMPFILE2
	echo "-------------------" >> $TMPFILE2
#	ccm_projects=`ccm query -s prep -t project -o genadmin "release='${release_tag}'" -f "%displayname" -u`
	num_proj=`echo $ccm_project | grep -v PATCH | wc -w`
#	echo "We are releasing ${num_proj}: $ccm_projects" >> $TMPFILE
	if [ $num_proj -eq 0 ]
	then

		echo "-------------------" >> $TMPFILE2
		echo "archive_geneva_svn -s sqa -r ${rel_version} -p ${rel_project} -t PATCH -v /irb/archive/$rel_project_low/$baserel-PATCH -u sdavulur -i" >> $TMPFILE2
		archive_geneva_svn -s sqa -r ${rel_version} -p ${rel_project} -t PATCH -v /irb/archive/$rel_project_low/$baserel-PATCH -u sdavulur -i >> $TMPFILE2
		echo "-------------------" >> $TMPFILE2
		echo "UPDATE patch_summary SET patch_status='Packaged' where project='$project' and version='$version'" >> $TMPFILE2
		echo "Patch is  ready for generating archive $rel_project $rel_version for release to our customer(s)" >> $TMPFILE2
		cat $TMPFILE2 | /usr/lib/sendmail `cat /irb/bce/admin/email/patch_build_managers`
		#cat $TMPFILE2 > /tmp/anurag
		#cat $TMPFILE2  | /usr/lib/sendmail reshma.goud.ireni@netcracker.com
	else
#		echo "There are more than 1($num_proj) projects to release"
#		echo "You will need to carefully reconfigure the projects to bring in the release notes"
#		echo add_folder_and_reconfigure.sh -s sqa -r ${rel_version} -p ${rel_project}PATCH >> $TMPFILE
#		echo archive_geneva -s sqa -r ${rel_version} -v ${wa_path_no_proj} -u drao9598 -p ${rel_project} -t PATCH -s sqa >> $TMPFILE
#		echo "UPDATE patch_summary SET patch_status='Packaged' where project='$rel_project' and version='$rel_version'" >> $TMPFILE
		echo "subject: Packaged - $rel_project $rel_version" > $TMPFILE2
		echo "Good Day,\n"  >> $TMPFILE2
		echo "    I am please to announce the availability of $rel_project $rel_version for release to our customer(s)\n\n" >> $TMPFILE2
		#cat $TMPFILE2 | /usr/lib/sendmail `cat /irb/bce/admin/email/patch_build_managers`
		cat $TMPFILE2 | /usr/lib/sendmail reshma.goud.ireni@netcracker.com
#		/irb/bce/admin/email/patch_release_managers
	fi

#	cat $TMPFILE | /usr/lib/sendmail `cat /irb/bce/admin/email/patch_build_managers` 

	rm $TMPFILE $TMPFILE2
#	cleanUpCCM
	exit 0
fi

