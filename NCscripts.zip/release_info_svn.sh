#!/bin/ksh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/svn_new.svn

#task1=$1
release_1=$1
log1=$2
root=$3
rc_num=$4
pf_num=$5
echo "variables from release_info.sh file $release_1 $log1 $root $rc_num $pf_num"
rel_num=`cat $root/configuration/infinys/release_information/release_info.xml|grep 'RB version'|awk '{print $2}'|cut -d '"' -f 2`
rc_num1=`cat $root/configuration/infinys/release_information/release_info.xml|grep rc|awk '{print $3}'|cut -d '"' -f 2`
pf_num1=`cat $root/configuration/infinys/release_information/release_info.xml|grep PF|awk '{print $2}'|cut -d '"' -f 2`
#cur_sch_let=`cat $root/SCHEMA/install/scripts/schema_VERSION.sh|grep TOLETTER|awk '{print $1}'|cut -d '"' -f 2`
#pre_sch_let=`cat $root/configuration/infinys/release_information/release_info.xml|grep letter|awk '{print $3}'|cut -d '"' -f 2`
echo $rc_num
echo $pf_num
echo $schema_let

#a=`echo $rc_num + 1 | bc`
cat $root/configuration/infinys/release_information/release_info.xml|sed -e "s/rc=\"$rc_num1\"/rc=\"$rc_num\"/g" >$root/configuration/infinys/release_information/release_info.xml1
cat $root/configuration/infinys/release_information/release_info.xml1|sed -e "s/PF version=\"$pf_num1\"/PF version=\"$pf_num\"/g" >$root/configuration/infinys/release_information/release_info.xml2
cat $root/configuration/infinys/release_information/release_info.xml2|sed -e "s/RB version=\"$rel_num\"/RB version=\"$release_1\"/g" >$root/configuration/infinys/release_information/release_info.xml3
#cat $root/configuration/infinys/release_information/release_info.xml3|sed -e "s/letter=\"$pre_sch_let\"/letter=\"$cur_sch_let\"/g" >$root/configuration/infinys/release_information/release_info.xml4

#ccm co -c "release_info.xml for $release_1" $root/configuration/infinys/release_information/release_info.xml 2>> ${log1}
#svn co -m "release_info.xml for $release_1" $root/configuration/infinys/release_information/release_info.xml 2>> ${log1}
#if [ $? -eq 0 ]
#then
	cd $root/configuration/infinys/release_information/	
	cp release_info.xml3 release_info.xml
#svn commit -m "release_info.xml for $release_1" $root/configuration/infinys/release_information/release_info.xml 2>> ${log1}
	cat release_info.xml 2>> ${log1}
	cd $root/mess/enu
#	ccm co -c "geneva_message for $release_1" geneva_messages.enu  2>> ${log1}
#	if [ $? -eq 0 ]
#	then
		cp ../dev/geneva_messages geneva_messages.enu
#svn commit -m "geneva_messages.enu for $release_1" >> ${log1}

	 	rm $root/configuration/infinys/release_information/release_info.xml1
	 	rm $root/configuration/infinys/release_information/release_info.xml2
	 	rm $root/configuration/infinys/release_information/release_info.xml3
#	 	rm $root/configuration/infinys/release_information/release_info.xml4
		exit 1	
	#else
	#echo "failed to checkout geneva_messages.enu file" 2>> ${log1}
	#fi	
#else
#	echo "failed to cehckout release_info.xml file" 2>> ${log1}
#fi	
