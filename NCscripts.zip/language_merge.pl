#!/usr/bin/perl -w
#
#  Script:              language_merge.pl
#  Subsystem:           1
#  Author:              %name: language_merge.pl %
#  Start date:          Wed Jan 15 09:03:18 2003
#  Version:             %full_filespec: language_merge.pl-11:perl:CB1#1 %
#
#  Description:
#
# (C) Convergys, 2001.
# Convergys refers to Convergys Corporation or any of its wholly
# owned subsidiaries.

use strict;
use Getopt::Std;
use File::Basename;

# Global Variables for parsing (Command Line or prompt) and (Script or Exe)
use vars qw($opt_v $opt_i $opt_p);

#
# Auxiliary Functions for the Merge Process.
#

# Function: Abort
# Description: Quit program with Error message
# In Params: String to print on exit
# Out Params: None
# Return: Integer 1, quit because of Error
sub Abort
{
	print "$_[0]\n";
	exit 1;
}



# Function: leave_script
# Description: General quit program routine
# In Params: Number to return from script
# Out Params: None
# Return: Integer 0 for success, anything else for error.
sub leave_script
{
	my $exit_status=$_[0];
	exit $exit_status;
}



# Function: usage
# Description: Print the programs usage, and calls leave_program with error 1
# In Params: None
# Out Params: None
# Return: None
sub usage
{
	print "Usage: language_merge.pl <orig> <new> <output_dir> [lang] [enu]\n";
	print "where:\n";
	print "\t<orig>\t\t: file at last release\n";
	print "\t<new>\t\t: file at this release\n";
	print "\t<output_dir>\t: directory to store merged file\n";
	print "\t[lang]\t\t: language file at last release\n";
	print "\t[enu]\t\t: enu at this release\n";
	print "\n";
	&leave_script (1);
}

# START OF ACTUAL PROGRAM
#

# Initialise Variables
my $file_lang="";
my $file_enu="";
my $type="";
my $lang;

# Read in arguments to file and check that they are valid.
if (@ARGV < 3 or @ARGV > 5 )
{
	&usage;
}

my $file_orig="$ARGV[0]";
my $file_new="$ARGV[1]";
my $output_directory="$ARGV[2]";
# Check that the arguments passed are valid
if ( ! -f $file_orig )
{
	print "Error: language_merge.pl: Argument 1: File does not exist\n";
	&leave_script (3);
}
if ( ! -f $file_new )
{
	print "Error: language_merge.pl: Argument 2: File does not exist\n";
	&leave_script (3);
}
if ( ! -d $output_directory )
{
	print "Error: language_merge.pl: Argument 3: Directory does not exist\n";
	&leave_script (3);
}
if (defined $ARGV[3])
{
	$file_lang="$ARGV[3]";
	if ( ! -f $file_lang )
	{
		print "Error: language_merge.pl: Argument 4: File does not exist\n";
		&leave_script (3);
	}
}
if (defined $ARGV[4])
{
	$file_enu="$ARGV[4]";
	if ( ! -f $file_enu )
	{
		print "Error: language_merge.pl: Argument 5: File does not exist\n";
		&leave_script (3);
	}
}

# Work out the type of file we are dealing with (drc, trn, txt, BLANK)
my $filename = basename($file_new);

$filename =~ /.*\.(.*)$/;
if (defined $1)
{
	$type = "$1";
}

# If the type of file is not recognised quit.
if ( "$type" ne "" and "$type" ne "drc" and "$type" ne "trn" and "$type" ne "txt")
{
	print "File not recognised: $filename, expecting a file of type:\n";
	print "\t\tdrc, trn, txt (API Error Message) or BLANK (VPA Messages)\n";
	exit 0;
}



# Work out the language we are to translate to by parsing language file at last release.
$file_lang =~ /.*\.(.*)$/;
$lang = $1;

# work out the name of the resulting merged file.
$filename =~ s/[\.]?$type$/\.$lang/g;

# Call the function to compare the files.
&compareFiles($file_new, $file_orig, $type, "$output_directory/$filename", $file_lang, $file_enu);

#
# Leave program with an error status of zero (no error)
#

# If we have got this far the script has fully ran successfully.
&leave_script (0);

#
# Main Functions for the Merge Process.
#

# Function: compareFiles
# Description: Takes in files to compare and merge, reads in the files to HASHES and
# 	       runs differences. Merges the differences.
# In Params: 
#	new: 		The newly created dev file for this release
#	old: 		The created dev file for the previous release
#	type: 		Type of the file in drc, trn, txt (API MEss) or <blank> (Batch Mess)
#	output_file:	The name and location of the resultant merged file
#	lang:		The language file to take as a baseline, to create new merged file.
#	enu:		ENU file created at this release to take new strings from
# Out Params: None
# Return: None
sub compareFiles
{
	# Read in arguments
	my $new = $_[0];
	my $old = $_[1];
	my $type = $_[2];
	my $output_file = $_[3];
	my $lang = $_[4];
	my $enu = $_[5];

	# Set up Hashes to read the strings into
	my $ref_hash_one;
	my $ref_hash_two;
	my $ref_hash_three;
	my $ref_hash_four;
	my $ref_new_not_old;
	my $ref_old_not_new;
	my $ref_diff_vals;

	# Populate the first hash
	$ref_hash_one = &loadTranslationFile($new, $type);

	# Populate the second hash
	$ref_hash_two = &loadTranslationFile($old, $type);
    
	if ( $lang ne "")
	{
		# Populate the enu hash
		$ref_hash_three = &loadTranslationFile($lang, $type);
	}
	if ( $enu ne "")
	{
		# Populate the enu hash
		$ref_hash_four = &loadTranslationFile($enu, $type);
	}

	# Find keys which exist in hash one but not hash two
	$ref_new_not_old = &diffKeys($ref_hash_one, $ref_hash_two);

	# Find keys which exist in hash two but not hash one
	$ref_old_not_new = &diffKeys($ref_hash_two, $ref_hash_one);

	# For each common key compare the values
	$ref_diff_vals = &compareValues($ref_hash_two, $ref_hash_one);

	# Output the result
	&outputResult($ref_hash_one,
		$ref_hash_two,
		$ref_hash_three,
		$ref_hash_four,
		$ref_new_not_old,
		$ref_old_not_new,
		$ref_diff_vals,
		$type,
		$output_file);
}


# Reads in the translation string resource file and
# stores the translations in a hash

# Function: loadTranslationFile
# Description: Reads in the translation strings and stores in a hash
# In Params: 
#	FileName:	Name of the file to read in
#	FileType:	Type of the file in drc,trn,txt or <blank>
# Out Params: None
# Return: The Hash
sub loadTranslationFile
{
	my $FileName = $_[0];
	my $FileType = $_[1];

	my $const;
	my $msg;
	my $current_domain;

	my %translations = ();

	open(DRC,"<$FileName") || &Abort ("Cannot open $FileName: $!\n");

	# This if statement works out the format of the file been read in
	# And parses as appropriate, storeing the file into a Hash
	if ($FileType eq "trn"
		|| $FileType eq "drc")
	{
		while(<DRC>)
		{
			/^(.*)\t(.*)$/;           # Any two tab seperated character fields
    
			$const = $1;
			$msg = $2;
	
			$translations{$const} = $msg;
		}
    
	}
	elsif ($FileType eq "txt")
	{
		LINE: while(<DRC>)
		{
			next LINE if /^\s*$/;     # Blank line or whitespace only
			next LINE if /^\/\/.*\s*$/;  # // Comment
			next LINE if /^-+\s*$/;      # One or more dashes (-)
			next LINE if /^\/+\s*$/;     # One or more /'s

			# Format of genevamessages (API) is <number>,<number>,<string>
			/^(\d+),(\d+),(.*)\s*$/;
			
			$const="$1,$2";
			$msg=$3;
	
			$msg=~s///g;

			$translations{$const} = $msg;
		}
	}
	else
	{
		LINE: while(<DRC>)
		{
			next LINE if /^\s*$/;     # Blank line or whitespace only
			next LINE if /^\/\/.*$/;  # // Comment
			next LINE if /^-+$/;      # One or more dashes (-)
			next LINE if /^\/+$/;     # One or more /'s

			if (/^domain\s+([\w_]+)/)
			{
				$current_domain="domain$1";
				next;
			}

			/^(\w+)\s+(\d+)\s+(\d+)\s+([\w_]+)\s+(.*)$/;        # (number) comma, single-digit, comma (string)

#			print "5.  $5\n";
			if (! defined $5 or $5 eq "")
			{
				/^(\w+)\s+(\d+)\s+([\w_]+)\s+(.*)$/;
				if (! defined $4)
				{
					print "$_\n";
				#	print "1. $1\n";
				#	print "2. $1\t$2\n";
				#	print "3. $1\t$2\t$3\n";
					next
				}
				$const="$current_domain $1 $2 $3";
				$msg=$4;
			}
			else
			{
				$const="$current_domain $1 $2 $3 $4";
				$msg=$5;
			}

			$translations{$const} = $msg;
		}
	}
    
	close(DRC);

	return \%translations;
}


#
# diffKeys
#
# Takes two hashes as arguments
# Populates an array with a list of keys and values which exist in the
# first hash but not in the second
#

sub diffKeys
{
    my $hash_one_ref = $_[0];
    my $hash_two_ref = $_[1];

    my %hash_one = %$hash_one_ref;
    my %hash_two = %$hash_two_ref;

    my @differences = ();

    my $key;
    my $value;

    while (($key,$value) = each %hash_one)
    {
	unless (exists $hash_two{$key})
	{
	    push(@differences, $key);
	    push(@differences, $value);
	}
    }

    return \@differences;
}


#
# compareValues
#
# Takes two hashes as arguments and compares values in all cases
# where a key exists in both. Populates an array with three elements
# for each case where the values are different. The array then has
# the form $key, $value1, $value2
#

sub compareValues
{
    my $hash_one_ref = $_[0];
    my $hash_two_ref = $_[1];

    my %hash_one = %$hash_one_ref;
    my %hash_two = %$hash_two_ref;

    my @resultarray;

    my $key;
    my $value;

    while (($key,$value) = each %hash_one)
    {
	if (exists $hash_two{$key})
	{
	    if ($value ne $hash_two{$key})
	    {
		print "key = $key\n";
		push(@resultarray, $key);
		print "value = $value\n";
		push(@resultarray, $value);
		print "hash_two{$key} = $hash_two{$key}\n";
		push(@resultarray, $hash_two{$key});
	    }
	}
    }


    # Return a reference to the array
    return \@resultarray;
}


sub change_context_to_output
{
	my $context_from = $_[0];
	my $fileType = $_[1];

	my $context_to;

	if ( $fileType eq "" )
	{
		# Geneva Messages (Batch)
		my $context = $context_from =~ /^(\S+)\s+(\S+)\s+(\S+)\s+(\S+)/;
		$context_to="$1\t$2\t$3\t$4";
	}
	elsif ( $fileType eq "txt" )
	{
		# Geneva Messages (Batch)
		my $context = $context_from =~ /^(\S+),(\S+)/;
		$context_to="$1\t$2";
	}
	else
	{
		$context_to = $context_from;
	}

	return $context_to;
}

sub get_lang_message
{
	my $context = $_[0];
	my $hash_lang_ref = $_[1];

	my %hash_lang = %$hash_lang_ref;
	my $message;

	$message=$hash_lang{$context};

	return $message;
}


sub outputResult
{
	my $ref_hash_one = $_[0];
	my $ref_hash_two = $_[1];
	my $ref_hash_three = $_[2];
	my $ref_hash_four = $_[3];
	my $ref_new_not_old = $_[4];
	my $ref_old_not_new = $_[5];
	my $ref_diff_vals = $_[6];
	my $fileType = $_[7];
	my $output_file_merge = $_[8];

	my @first_not_second = ();
	my @second_not_first = ();
	my @value_differences = ();
	my %new_file;

	my $count;
	my $usageString;
	my $enu_message;

	# Dereference all the references to populate the relevant structures

	@first_not_second = @$ref_new_not_old;
	@second_not_first = @$ref_old_not_new;
	@value_differences = @$ref_diff_vals;

	if ( defined $ref_hash_three )
	{
		# If a language file is given, should use this as the baseline
		%new_file = %$ref_hash_three;
	}
	else
	{
		# Else will have to use the original baseline file.
		%new_file = %$ref_hash_two;
	}

	# Setup the Output files

	unlink $output_file_merge;
	print "output_file_merge = $output_file_merge\n";
	open(MERGE_FILE, ">$output_file_merge") or die "Error: language_merge.pl: Can not write the file";

	# Print the results

	print("--------------- Adding ----------------------------------------\n");

	if (defined $first_not_second[0])
	{
		for($count = 0; 1; $count+=2)
		{
			if ( defined $ref_hash_four )
			{
				$first_not_second[$count+1]=&get_lang_message($first_not_second[$count],$ref_hash_four);
			}
			$new_file{$first_not_second[$count]}=$first_not_second[$count+1];

			$first_not_second[$count]=&change_context_to_output($first_not_second[$count],$fileType);
		
			my $output_context=$first_not_second[$count];
			$output_context=~s/^domain(.*)/domain $1/;
	
			print("addition\t$output_context\t$first_not_second[$count+1]\n");
	    
			last if !defined $first_not_second[$count+2];
		}
	}

	print("----------------- deleting ------------------------------------\n");
    
	if (defined $second_not_first[0])
	{
		for($count = 0; 1; $count+=2)
		{
			delete($new_file{$second_not_first[$count]});
		
			$second_not_first[$count]=&change_context_to_output($second_not_first[$count],$fileType);

			my $output_context=$second_not_first[$count];
			$output_context=~s/^domain(.*)/domain $1/;

			print("deletion\t$output_context\t$second_not_first[$count+1]\n");
    
			last if !defined $second_not_first[$count+2];
		}
	}

	print("----------------- changing ------------------------------------\n");
   
	if (defined $value_differences[0])
	{
		for($count = 0; 1; $count+=3)
		{
			print "here = $value_differences[$count+2]\n";
			if ( defined $ref_hash_four )
			{
				my $tmp_stringfor_lang=&get_lang_message($first_not_second[$count],$ref_hash_four);
				if ( defined $tmp_stringfor_lang )
				{
					$value_differences[$count+2]="$tmp_stringfor_lang";
				}
			}

			$new_file{$value_differences[$count]}=$value_differences[$count+2];
			$value_differences[$count]=&change_context_to_output($value_differences[$count],$fileType);
			
			my $output_context=$value_differences[$count];
			$output_context=~s/^domain(.*)/domain $1/;

			print("deletion\t$output_context\t$value_differences[$count+1]\n");

			print("addition\t$output_context\t$value_differences[$count+2]\n");
	    
			last if !defined $value_differences[$count+3];
	;	}
	}

	my $key;
	my $context_seperator;

	if ( $fileType eq "" )
	{
		$context_seperator=" ";
	}
	elsif ( $fileType eq "txt" )
	{
		$context_seperator=",";
	}
	else
	{
		$context_seperator="\t";
	}

	my $current_domain;
	my $last_domain="";
	my $key_output;

	foreach $key (sort keys %new_file)
	{
		if ($fileType eq "" )
		{
			$key =~ /^domain(\w*) (.*)$/;
			$current_domain=$1;
			$key_output=$2;
			if ( $current_domain ne $last_domain)
			{
				print MERGE_FILE "domain $current_domain\n";
				
			}
		}
		else
		{
			$key_output=$key;
		}
#		print "1. $key_output\n";
#		print "2. $context_seperator\n";
#		print "3. $new_file{$key}\n";
#		print "4. $key\n";
		print MERGE_FILE "$key_output$context_seperator$new_file{$key}\n";
		$last_domain=$current_domain;
	}
	close (MERGE_FILE);
}


################################################################
#
# END OF SCRIPT
