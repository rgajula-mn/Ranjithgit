#!/bin/sh
set -x

logdir=${BCE_LOG}

batch_dir=$logdir/batch_commands
batch_dir_pending=$batch_dir/pending.$$

tmp_file="/tmp/batch_command_run.$$"
preview="FALSE"

if [ "$1" = "-p" ]
then
	# Preview Mode
	preview="TRUE"
	echo "Will run the following commands:"
fi 

if [ "$1" = "-r" ]
then
	# Review Mode
	review="TRUE"
	echo "Currently Running the following commands:"
	ls -1 $batch_dir/pend*
	exit 0
fi 

if [ "$1" = "-d" ]
then
	# Done Mode
	done="TRUE"
	echo "Already ran the following commands:"
	ls -1 $batch_dir/done
	exit 0
fi 

if [ "$1" = "-b" ]
then
	# Done Mode
	done="TRUE"
	echo "The following commands failed:"
	ls -1 $batch_dir/broken
	exit 0
fi 

if [ "$1" = "-u" ]
then
	# Usage
	echo "$0 [-bdpr]"
	echo "	Runs the batch commands in $batch_dir"
	echo "		-b lists batch commands that failed"
	echo "		-d lists batch commands that worked"
	echo "		-p lists batch commands that are pending"
	echo "		-r lists batch commands that currently been executed"
	exit 0
fi 


mkdir $batch_dir_pending

if [ $? -ne 0 ]
then
	echo "ERROR $0: Cannot create $batch_dir_pending directory"
	exit 1
fi
#rsync /irb/bce/admin/releases_to_build_* genadmin@elm:/irb/bce/admin
#rsync /irb/bce/admin/buildweb_config/* genadmin@elm:/irb/bce/admin/buildweb_config
#mv $batch_dir/[A-Z]* $batch_dir_pending/. > /dev/null 2>&1
mv `find $batch_dir/[A-Z]* -type f|grep -v done|grep -v broken|grep -v /irb/bce/admin/log/batch_commands/pending.*` $batch_dir_pending/. > /dev/null 2>&1

for batch_command_file in `ls -1 $batch_dir_pending | grep -v done | grep -v pending | grep -v broken | sort`
do
	if [ "$preview" = "TRUE" ]
	then
		cat $batch_dir_pending/$batch_command_file
		mv $batch_dir_pending/$batch_command_file $batch_dir/.
		continue
	fi

	batch_command=`cat $batch_dir_pending/$batch_command_file`
	echo $batch_command

	cp ${batch_dir_pending}/${batch_command_file} ${batch_dir_pending}/${batch_command_file}_exec
	chmod 775 ${batch_dir_pending}/${batch_command_file}_exec
	
	echo "Subject: Batch Command Failed - $batch_command" > $tmp_file
	${batch_dir_pending}/${batch_command_file}_exec >> $tmp_file 2>&1
	if [ $? -eq 0 ]
	then
		mv $batch_dir_pending/$batch_command_file $batch_dir/done/.
		grep -v 'Subject:' $tmp_file >  $batch_dir/done/${batch_command_file}_output
	else
		mv $batch_dir_pending/$batch_command_file $batch_dir/broken/.
		cp $tmp_file $batch_dir/broken/${batch_command_file}_output
		echo "FAILED - $batch_command"
		cat $tmp_file | /usr/lib/sendmail sridhar.davuluru@netcracker.com 
		
	fi

	rm ${batch_dir_pending}/${batch_command_file}_exec
done

rmdir $batch_dir_pending
if [ -f "$tmp_file" ]
then
	rm $tmp_file
fi

exit 0
