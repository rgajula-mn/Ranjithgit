#set -x
R=`df -h|grep irb|egrep  'dev7|bce|archive|candidate'|egrep -v systems| grep M`
echo "$R" > ranjith0

if [ -z "$R" ]

then 

       df -h|grep irb|egrep  'dev7|bce|archive|candidate'|egrep -v systems > raga
       sed "s/G//g;s/M//g" raga > ranjith
       MAILTO=`cat /irb/bce/admin/email/head_build_managers`
       W=`cat ranjith|awk '$3 <= 10 && $3 != ""  {print "PATH="$5,"\nFREE="$3."G\n","Used%="$4,"\nTOTAL="$1."G\n"}'`
       if [ -z "$W" ]
        then 
           echo "every thing is fine now" > gaju;cat gaju|mail -s "Space ALERT !!" ranjith.kumar.gajula@netcracker.com
        else
           cat ranjith|awk '$3 <= 10 && $3 != ""  {print "PATH="$5,"\nFREE="$3."G\n","Used%="$4,"\nTOTAL="$1."G\n"}'|mail -s "Space ALERT !!" $MAILTO>> /dev/null 
      fi
else

       df -h|grep irb|egrep  'dev7|bce|archive|candidate'|egrep -v systems > raga
       sed "s/G//g" raga > ranjith
       MAILTO=`cat /irb/bce/admin/email/head_build_managers`
       df -h|grep irb|egrep  'dev7|bce|archive|candidate'|egrep -v systems| grep M > raga1
       sed "s/M//g" ranjith0 > ranjith1
      (cat ranjith|awk '$3 <= 10 && $3 != ""  {print "PATH="$5,"\nFREE="$3."G\n","Used%="$4,"\nTOTAL="$1."G\n"}';cat ranjith1|awk '$3 != ""  {print "PATH="$5,"\nFREE="$3."M\n","Used%="$4,"\nTOTAL="$1."G\n"}')|mail -s "Space ALERT !!" $MAILTO
fi
