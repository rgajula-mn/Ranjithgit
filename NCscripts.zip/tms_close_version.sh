#!/bin/ksh
set -x
BCE_BUILD_SCRIPTS=/irb/bce/admin/ccm_wa/PRD-bce/PRD/build_scripts
version=$1
project=$2
release_tag=`echo $project"_"$version`
version_id=`curl -k -H "Content-Type: application/json" -X GET -u ciber:8d#d56hg 'https://tms.netcracker.com/rest/api/2/project/RBM/versions?expand=id'|tr '},{' '},\n{'|grep "\"$release_tag\"" |awk '{print $1}'|cut -d',' -f2|cut -d ':' -f2|cut -d '"' -f2`
release_date=`date "+%Y-%m-%d"`
echo "version_id ..... $version_id .......... release_date is..........$release_date"
run_out=`curl -k -H "Content-Type: application/json" -X PUT -d "{\"releaseDate\": \"$release_date\",\"released\": \"true\"}" -u ciber:8d#d56hg https://tms.netcracker.com/rest/api/2/version/$version_id`
echo "run_out ........$run_out"
meta_data=`$BCE_BUILD_SCRIPTS/update_meta_prod.sh -d $release_tag`

MAILTO=`cat /irb/bce/admin/email/head_build_managers`
echo " TMS version $release_tag has been released .......... https://tms.netcracker.com/rest/api/2/version/$version_id  ......... $run_out ..... meta_data deleted for $release_tag .... $meta_data" | mailx -s " TMS Version $release_tag has been released" $MAILTO

