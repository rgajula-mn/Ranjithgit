#!/bin/sh

. $BCE_BUILD_SCRIPTS/buildweb_functions_svn.sh
. $BCE_BUILD_SCRIPTS/core_functions_svn.sh


ORACLE_HOME=/opt/oracle/9.2.0.SE
LD_LIBRARY_PATH=$ORACLE_HOME/lib
PATH=$ORACLE_HOME/bin:$PATH

main_dir="${BCE_ADMIN}"

export PATH ORACLE_HOME LD_LIBRARY_PATH

DATABASE=`buildweb_connection`

SWAP_TMP_FILE=$main_dir/reltobld_swap.$$
RELEASES_TMP_FILE=$main_dir/releases_to_build_autogen.$$
RELEASES_TMP_TMP_FILE=$main_dir/releases_to_build_autogen_tmp.$$
RELEASES_TMP_TMP_TMP_FILE=$main_dir/releases_to_build_autogen_tmp_tmp.$$

RTEST_TMP_FILE=$main_dir/releases_to_rtest_autogen.$$
RTEST_TMP_TMP_FILE=$main_dir/releases_to_rtest_autogen_tmp.$$

RELEASES_FILE=$main_dir/releases_to_build_autogen
RELEASES_FILE_AMERICA=$main_dir/releases_to_build_america_autogen
PREV_RELEASES_FILE=/tmp/releases_to_build_autogen.prev
PREV_RELEASES_FILE_AMERICA=/tmp/releases_to_build_america_autogen.prev

PREBUILD_RELEASES_FILE=$main_dir/releases_to_prebuild_autogen
PREBUILD_RELEASES_FILE_AMERICA=$main_dir/releases_to_prebuild_america_autogen
PREV_PREBUILD_RELEASES_FILE=/tmp/releases_to_prebuild_autogen.prev
PREV_PREBUILD_RELEASES_FILE_AMERICA=/tmp/releases_to_prebuild_america_autogen.prev

POSTBUILD_RELEASES_FILE=$main_dir/releases_to_postbuild_autogen
POSTBUILD_RELEASES_FILE_AMERICA=$main_dir/releases_to_postbuild_america_autogen
PREV_POSTBUILD_RELEASES_FILE=/tmp/releases_to_postbuild_autogen.prev
PREV_POSTBUILD_RELEASES_FILE_AMERICA=/tmp/releases_to_postbuild_america_autogen.prev

RTEST_FILE=$main_dir/test_scripts/overnight_rtests.sh
RTEST_FILE_AMERICA=$main_dir/test_scripts/overnight_rtests_america.sh
PREV_RTEST_FILE=/tmp/overnight_rtests.sh.prev
PREV_RTEST_FILE_AMERICA=/tmp/overnight_rtests_america.sh.prev

PLATTRAN_FILE=$main_dir/buildweb_config/platform_mapping
PLATTRAN_TMP_FILE=/tmp/platform_mapping.$$

BUILDPATH_FILE=$main_dir/buildweb_config/build_path
BUILDPATH_TMP_FILE=/tmp/build_path.$$

COPY_BUILDPATH_FILE=$main_dir/buildweb_config/copy_build_objects
COPY_BUILDPATH_TMP_FILE=/tmp/copy_build_objects.$$


RECONFIGURE_SERVER_FILE=$main_dir/buildweb_config/reconfigure_server

DEFAULTS_FOR_RELEASE_FILE=$main_dir/buildweb_config/defaults_for_release
OVERRIDES_FOR_RELEASE_FILE=$main_dir/buildweb_config/overrides_for_release
CURL_FOR_RELEASE_FILE=$main_dir/buildweb_config/curl_for_release

CCM_PLATFORM_DETAILS_FILE=$main_dir/buildweb_config/ccm_platform_details

CVG_PLATFORM_DETAILS_FILE=$main_dir/buildweb_config/platform_version
CVG_PLATFORM_DETAILS_FILE_PATCHES=$main_dir/buildweb_config/platform_version_patches

GATEKEEPER_FILE=$main_dir/buildweb_config/gatekeeper_releases

GENERIC_TMP_FILE=$main_dir/buildweb_config/tmp_file.$$
whatsChangedFile=/tmp/whatsChanged.$$
emailReport=/tmp/emailReport.$$

query_for_projects_and_buildstate ()
{
	build_state=$1
	if [ "$build_state" = "commented" ]
	then
		sqlplus -s $DATABASE << +END > ${RELEASES_TMP_TMP_FILE}
		set feed off
		set head off
		set scan on
		set lines 32767
		select a.project,',',a.version,',',b.depversion,',',c.buildtype||'['||c.target||']',',',c.commentrow,',',c.buildtime,',',c.mon,',',c.tue,',',c.wed,',',c.thu,',',c.fri,',',c.sat,',',c.sun
		from buildrel a, depversion b, reltobuildtype c
		where
			a.project=b.project(+) 
			and a.version=b.version(+) 
			and b.depproject(+)='GENEVA'
			and a.project=c.project(+)
			and a.version=c.version(+) 
			and commentrow is NOT NULL
			and buildtype is NOT NULL
		ORDER BY POSITION;
		exit;
+END
		status=$?
	else
		sqlplus -s $DATABASE << +END > ${RELEASES_TMP_TMP_FILE}
		set feed off
		set head off
		set scan on
		set lines 32767
		select a.project,',',a.version,',',b.depproject, ',',b.depversion,',',c.buildtype||'['||c.target||']',',',c.commentrow,',',c.buildtime,',',c.mon,',',c.tue,',',c.wed,',',c.thu,',',c.fri,',',c.sat,',',c.sun,',',a.position
		from buildrel a, depversion b, reltobuildtype c
		where a.BUILDSTATE='$build_state' 
			and a.project=b.project(+) 
			and a.version=b.version(+) 
			and b.depproject(+)='GENEVA'
			and a.project=c.project(+)
			and a.version=c.version(+) 
			and commentrow is NULL
			and buildtype is NOT NULL
		intersect
		select a.project,',',a.version,',',b.depproject, ',',b.depversion,',',c.buildtype||'['||c.target||']',',',c.commentrow,',',c.buildtime,',',c.mon,',',c.tue,',',c.wed,',',c.thu,',',c.fri,',',c.sat,',',c.sun,',',a.position
		from buildrel a, depversion b, reltobuildtype c
		where a.BUILDSTATE='$build_state'
			and a.project=b.project(+) 
			and a.version=b.version(+)
                        and b.depproject(+)='RB'
			and a.project=c.project(+)
			and a.version=c.version(+) 
			and commentrow is NULL
			and buildtype is NOT NULL
		union
		select a.project,',',a.version,',',b.depproject, ',',b.depversion,',',c.buildtype||'['||c.target||']',',',c.commentrow,',',c.buildtime,',',c.mon,',',c.tue,',',c.wed,',',c.thu,',',c.fri,',',c.sat,',',c.sun,',',a.position
		from buildrel a, depversion b, reltobuildtype c 
		where a.BUILDSTATE='$build_state'
			and a.project=b.project(+) 
			and a.version=b.version(+)
                        and b.depproject in ('GENEVA','RB')
			and a.project=c.project(+)
			and a.version=c.version(+) 
			and commentrow is NULL
			and buildtype is NOT NULL
		order by position;
		exit;
+END
		status=$?
	fi
	if [ $status -ne 0 ]
	then
		echo "ERROR: Cannot Connect to $DATABASE"
		echo "       Not creating new releases_to_build files."
		exit 1
	fi
}

query_for_projects_to_rtest ()
{
	sqlplus -s $DATABASE << +END > ${RTEST_TMP_TMP_FILE}
	set feed off
	set head off
	set scan on
	set lines 32767
	select a.ccmproject,',',a.host,',',a.sid,',',a.core,',',a.build_type,',',a.oracle_ver_name,',',a.filelist,',',a.filelist_type,',',a.wait,',',a.position,',',a.testtime,',',a.mon,',',a.tue,',',a.wed,',',a.thu,',',a.fri,',',a.sat,',',a.sun,',',a.threads
	from testrel a
	where  a.row_comment is NULL 
	ORDER BY HOST, POSITION;
	exit;
+END
	if [ $? -ne 0 ]
	then
		echo "ERROR: Cannot Connect to $DATABASE"
		echo "       Not creating new releases_to_test files."
		exit 1
	fi
}

create_releases_to_build_file ()
{
	region=$1
	release_file=$2
	if [ -z "$region" -o -z "$release_file" ]
	then
		return 1
	fi

	echo "#" > $release_file
	echo "# Please note, this is a auto-generated file, created by: $0" >> $release_file
	echo "#	Details can be viewd at: http://wbndbuildcdw/build_manager/releases_to_build/reltobuild.php" >> $release_file
	echo "# This file is created through the crontab on hobby - genadmin" >> $release_file
	echo "#" >> $release_file

	today=`date "+%a"`
	echo "echo \$$today" > /tmp/today.reltobuild
	chmod 744 /tmp/today.reltobuild
	
	while read build_string
	do
		run_today=""

		project=`echo $build_string | cut -d',' -f1`
		version=`echo $build_string | cut -d',' -f2`
		core=`echo $build_string | cut -d',' -f3-4 | sed -e "s/^,//g"  -e "s/,/-/g"`
		buildtype=`echo $build_string | cut -d',' -f5`
		comment=`echo $build_string | cut -d',' -f6`
		buildtime=`echo $build_string | cut -d',' -f7`
		Mon=`echo $build_string | cut -d',' -f8`
		Tue=`echo $build_string | cut -d',' -f9`
		Wed=`echo $build_string | cut -d',' -f10`
		Thu=`echo $build_string | cut -d',' -f11`
		Fri=`echo $build_string | cut -d',' -f12`
		Sat=`echo $build_string | cut -d',' -f13`
		Sun=`echo $build_string | cut -d',' -f14`

		export Mon Tue Wed Thu Fri Sat Sun

		run_today=`/tmp/today.reltobuild`

		if [ -z "$run_today" ]
		then
			continue
		fi

		if [ "$comment" != "" ]
		then
			continue
		fi
	
		if [ "$region" = "$buildtime" ]
		then
			if [ "$core" != "" ]
			then
				buildState=`echo ${build_string} | grep "^${project},${version}," | cut -d',' -f5 | sed -e 's/\[\]/\[all\]/g'`
				#buildState=`echo ${build_string} | grep "^${project},${version},${core}," | cut -d',' -f5 | sed -e 's/\[\]/\[all\]/g'`
				grep "^$project ${version}_$core:" $release_file > /dev/null
				if [ $? -ne 0 ]
				then
					if [ "${inDebug}" = "TRUE" ]
					then
						echo "Added $project ${version}_$core:${buildState} to $region"
					fi
					echo "$project ${version}_$core:${buildState}" >> $release_file
				else
					if [ "${inDebug}" = "TRUE" ]
					then
						echo "Added ${buildState} for $project ${version}_$core at $region"
					fi
					cat $release_file | sed "s/^\($project $version_$core:.*\)$/\1 ${buildState}/" > $RELEASES_TMP_TMP_TMP_FILE
					mv $RELEASES_TMP_TMP_TMP_FILE $release_file
				fi
			else
				buildState=`echo ${build_string} | grep "^${project},${version}," | cut -d',' -f5 | sed -e 's/\[\]/\[all\]/g'`
				grep "^$project ${version}:" $release_file > /dev/null
				if [ $? -ne 0 ]
				then
					if [ "${inDebug}" = "TRUE" ]
					then
						echo "Added $project ${version}:${buildState} to $region"
					fi
					echo "$project ${version}:${buildState}" >> $release_file
				else				
					if [ "${inDebug}" = "TRUE" ]
					then
						echo "Added ${buildState} for $project ${version} at $region"
					fi
					cat $release_file | sed "s/^\($project $version:.*\)$/\1 ${buildState}/" > $RELEASES_TMP_TMP_TMP_FILE
					mv $RELEASES_TMP_TMP_TMP_FILE $release_file
				fi
			fi
		fi

	done < ${RELEASES_TMP_FILE}
}

if_set_add_hyphen ()
{
	var=$1
	opt=$2

	if [ ! -z "$var" ]
	then
		if [ -z "$opt" ]
		then
			echo "-$var"
		else
			echo $opt $var
		fi
	fi

	return 0
}

create_releases_to_rtest_file ()
{
	region=$1
	rtest_file=$2
	if [ -z "$region" -o -z "$rtest_file" ]
	then
		return 1
	fi

	echo "#" > $rtest_file
	echo "# Please note, this is a auto-generated file, created by: $0" >> $rtest_file
	echo "#	Details can be viewd at: http://wbndbuildcdw/build_manager/releases_to_test/reltotest.php" >> $rtest_file
	echo "# This file is created through the crontab on hobby - genadmin" >> $rtest_file
	echo "#" >> $rtest_file
	echo ". /home/genadmin/.profile" >> $rtest_file
	echo ". BFGfunctions.sh" >> $rtest_file

	today=`date "+%a"`
	echo "echo \$$today" > /tmp/today.reltobuild
	chmod 744 /tmp/today.reltobuild
	last_host=""
	done_one=""

	echo "case \$HOST in" >> $rtest_file
	echo "	we_have_no_machine)" >> $rtest_file
	
	while read build_string
	do
		options=""
		run_today=""

		ccmproject=`echo $build_string | cut -d',' -f1`
		host=`echo $build_string | cut -d',' -f2`
		sid=`echo $build_string | cut -d',' -f3`
		core=`echo $build_string | cut -d',' -f4`
		build_type=`echo $build_string | cut -d',' -f5`
		oracle_ver_name=`echo $build_string | cut -d',' -f6`
		filelist=`echo $build_string | cut -d',' -f7`
		filelist_type=`echo $build_string | cut -d',' -f8`
		please_wait=`echo $build_string | cut -d',' -f9`
		position=`echo $build_string | cut -d',' -f10`
		testtime=`echo $build_string | cut -d',' -f11`
		Mon=`echo $build_string | cut -d',' -f12`
		Tue=`echo $build_string | cut -d',' -f13`
		Wed=`echo $build_string | cut -d',' -f14`
		Thu=`echo $build_string | cut -d',' -f15`
		Fri=`echo $build_string | cut -d',' -f16`
		Sat=`echo $build_string | cut -d',' -f17`
		Sun=`echo $build_string | cut -d',' -f18`
		Threads=`echo $build_string | cut -d',' -f19`

#		echo "sid            = $sid"
#		echo "core           = $core"
#		echo "please_wait    = $please_wait"
#		echo "build_type     = $build_type"
#		echo "filelist_type  = $filelist_type"
#		echo "filelist       = $filelist"

		if [ ! -z "$sid" ]
		then
			sid="${sid}.world"
		fi
		sid=`if_set_add_hyphen "${sid}" -d`
		core=`if_set_add_hyphen "$core" -g`
		if [ "$please_wait" = "Y" ]
		then
			please_wait='w'
		elif [ "$please_wait" = "N" ]
		then
			please_wait=''
		fi
		please_wait=`if_set_add_hyphen $please_wait`
		if [ -n "$filelist_type" -o -n "$filelist" ]
		then
			if [ $filelist_type != "a" ]
			then
				filelist_type=`if_set_add_hyphen $filelist_type`
				filelist=`if_set_add_hyphen "$filelist" "$filelist_type"`
			else
				filelist_type=""
				filelist=""
			fi
			
		fi

		threads=`if_set_add_hyphen "$Threads" -f`

		if [ "$build_type" != "n" ]
		then
			build_type=`if_set_add_hyphen $build_type`
		else
			build_type=""
		fi

		options="$sid $core $build_type $filelist $threads"

		export Mon Tue Wed Thu Fri Sat Sun

		run_today=`/tmp/today.reltobuild`

		if [ -z "$ccmproject" -o -z "$oracle_ver_name" ]
		then
			if [ "${inDebug}" = "TRUE" ]
			then
				echo "oracle_ver_name = $oracle_ver_name"
				echo "ccmproject      = $ccmproject"
			fi
			continue
		fi

		if [ "$oracle_ver_name" != "at" ]
		then
			oracle_ver_name="oracle$oracle_ver_name"
		fi

		if [ -z "$run_today" -o -z "$ccmproject" -o -z "$oracle_ver_name" ]
		then
			continue
		fi

		if [ "$last_host" != "$host" ]
		then
			echo "	;;" >> $rtest_file
			echo "	$host)" >> $rtest_file
			if [ "$host" = "parc" ]
			then
				echo "		# override LOGROOT for parc as it doesn't have enough diskspace!" >> $rtest_file
				echo "		LOGROOT=${BCE_ROOT}/rtest/aix/parc" >> $rtest_file
			fi
		fi

		if [ "$region" = "$testtime" ]
		then
			if [ "${inDebug}" = "TRUE" ]
			then
				echo "	Added $ccmproject to $host   $please_wait"
			fi
			echo "		run_test $please_wait -p $ccmproject -o $oracle_ver_name $options" >> $rtest_file
		fi
		last_host=$host
	done < ${RTEST_TMP_FILE}

	echo "	;;" >> $rtest_file

	echo "	*)" >> $rtest_file
	echo "	;;" >> $rtest_file
	echo "esac" >> $rtest_file

	chmod 755 $rtest_file
}

query_for_platforms_and_create ()
{
	sql="select platform,translated_platform || '[' from platform_mapping"
	BUILDWEB_DB=`buildweb_connection`
	plattyString=`sql_query ${BUILDWEB_DB} "$sql"`
	if [ $? -ne 0 ]
	then
		echo "[ERROR] Cannot Connect to $BUILDWEB_DB"
		echo "        Not creating new platform translation matrix file"
		echo
		return 99
	else
		
		# Process the SQL results thus ensures we dont overwrite with blank contents
		new_output=`echo ${plattyString} | sed -e 's/\[\ /\[/g;s/\[/\\\n/g' | sed -e '/^$/d'`
		echo $new_output | sed -e '/^$/d' > ${PLATTRAN_TMP_FILE}
		plattyKounter=`cat ${PLATTRAN_TMP_FILE} | wc -l`
		plattyKounter=`echo ${plattyKounter}`
		if [ ${plattyKounter} -gt 0 ]
		then
			mv ${PLATTRAN_FILE} ${PLATTRAN_FILE}.last
			cp ${PLATTRAN_TMP_FILE} ${PLATTRAN_FILE}
			echo "[INFO] The file [${PLATTRAN_FILE}] has been refreshed with ${plattyKounter} platforms"
			any_difference_between ${PLATTRAN_FILE}.last ${PLATTRAN_FILE}
		else
			echo "[INFO] The file [${PLATTRAN_FILE}] was not refreshed"
		fi
	fi
	echo
	return 0
}

query_for_buildpath_and_create ()
{
        sql="select project,version,BUILD_PATH,PLATFORM,ORACLE,STATE || '[' from build_projects"
        BUILDWEB_DB=`buildweb_connection`
        plattyString=`sql_query ${BUILDWEB_DB} "$sql"`
        if [ $? -ne 0 ]
        then
                echo "[ERROR] Cannot Connect to $BUILDWEB_DB"
                echo "        Not creating new Build path translation matrix file"
                echo
                return 99
        else

                # Process the SQL results thus ensures we dont overwrite with blank contents
                new_output=`echo ${plattyString} | sed -e 's/\[\ /\[/g;s/\[/\\\n/g' | sed -e '/^$/d'`
                echo $new_output | sed -e '/^$/d' > ${BUILDPATH_TMP_FILE}
                plattyKounter=`cat ${BUILDPATH_TMP_FILE} | wc -l`
                plattyKounter=`echo ${plattyKounter}`
                if [ ${plattyKounter} -gt 0 ]
                then
                        mv ${BUILDPATH_FILE} ${BUILDPATH_FILE}.last
                        cp ${BUILDPATH_TMP_FILE} ${BUILDPATH_FILE}
                        echo "[INFO] The file [${BUILDPATH_FILE}] has been refreshed with ${plattyKounter} build path details"
                        any_difference_between ${BUILDPATH_FILE}.last ${BUILDPATH_FILE}
                else
                        echo "[INFO] The file [${BUILDPATH_FILE}] was not refreshed"
                fi
        fi
        echo
        return 0
}

################adding for new entry for copy build objects list#########################################

query_for_copy_buildpath_and_create ()
{
        sql="select object,product || '[' from copy_build_objects"
        BUILDWEB_DB=`buildweb_connection`
        plattyString=`sql_query ${BUILDWEB_DB} "$sql"`
        if [ $? -ne 0 ]
        then
                echo "[ERROR] Cannot Connect to $BUILDWEB_DB"
                echo "        Not creating new Build path translation matrix file"
                echo
                return 99
        else

                # Process the SQL results thus ensures we dont overwrite with blank contents
                new_output=`echo ${plattyString} | sed -e 's/\[\ /\[/g;s/\[/\\\n/g' | sed -e '/^$/d'`
                echo $new_output | sed -e '/^$/d' > ${COPY_BUILDPATH_TMP_FILE}
                plattyKounter=`cat ${COPY_BUILDPATH_TMP_FILE} | wc -l`
                plattyKounter=`echo ${plattyKounter}`
                if [ ${plattyKounter} -gt 0 ]
                then
                        mv ${COPY_BUILDPATH_FILE} ${COPY_BUILDPATH_FILE}.last
                        cp ${COPY_BUILDPATH_TMP_FILE} ${COPY_BUILDPATH_FILE}
                        echo "[INFO] The file [${COPY_BUILDPATH_FILE}] has been refreshed with ${plattyKounter} copy_build_objects details"
                        any_difference_between ${COPY_BUILDPATH_FILE}.last ${COPY_BUILDPATH_FILE}
                else
                        echo "[INFO] The file [${COPY_BUILDPATH_FILE}] was not refreshed"
                fi
        fi
        echo
        return 0
}



create_csv_file_from_buildweb ()
{
	file_to_create=$1
	filename=`basename $file_to_create`
	sql="$2"
	seperator="$3"
	if [ -z "$seperator" ]
	then
		seperator=", "
	fi
	
	BUILDWEB_DB=`buildweb_connection`
	sql_query ${BUILDWEB_DB} "$sql" | sed -e "s/[ |	]//g;s/,/$seperator/g" | sed -e '/^$/d' > ${GENERIC_TMP_FILE}
	if [ $? -ne 0 ]
	then
		echo "[ERROR] Cannot Connect to $BUILDWEB_DB"
		echo "        Not creating new $filename matrix file"
		echo
		return 99
	else
		chmod 664 ${file_to_create}
		# Process the SQL results thus ensures we dont overwrite with blank contents
		line_count=`cat ${GENERIC_TMP_FILE} | wc -l`
		line_count=`echo ${line_count}`
		if [ ${line_count} -gt 0 ]
		then
			mv ${file_to_create} ${file_to_create}.last
			cat ${GENERIC_TMP_FILE} > ${file_to_create}
			echo "[INFO] The file [${file_to_create}] has been refreshed with ${line_count} platforms"
			any_difference_between ${file_to_create}.last ${file_to_create}
		else
			echo "[INFO] The file [${file_to_create}] was not refreshed"
		fi
	fi
	echo
	chmod 444 ${file_to_create}
	return 0
}

any_difference_between () {
	file1=$1
	file2=$2
	# 0 means no change
	# Any other value means changgatekeeper_releases
	theDiff=`diff -b -U0 ${file1} ${file2} | sed -e '/+++/d;/---/d;/@@/d'`
	if [ "${theDiff}" = "No differences encountered" ]
	then
		echo "[NO CHANGES] $file1"
		echo
		return 0
	else
		sendEmail="FALSE"
		echo "[UPDATED] $file1"
		echo
		if [ -z "${whatsChanged}" ]
		then
			whatsChanged="[$file1] updated<BR>"
			if [ "${inDebug}" = "TRUE" ]
			then
				whatsChanged="<BR>${whatsChanged}${theDiff}<BR>"
			fi
		else
			whatsChanged="${whatsChanged}[$file1] updated<BR>"
			if [ "${inDebug}" = "TRUE" ]
			then
				whatsChanged="<BR>${whatsChanged}${theDiff}<BR>"
			fi
		fi
		return 1
	fi	
}

##############################################################
# Build Query
##############################################################
if [ "$1" = "-z" ]
then
	inDebug="TRUE"
else
	echo
	echo "To view output to console and differences reported in the email use the -z switch"
	echo
fi

sendEmail="FALSE"
whatsChanged=""
query_for_projects_and_buildstate build
cat ${RELEASES_TMP_TMP_FILE} | sed -e 's/[	| ]//g' > ${RELEASES_TMP_FILE}

echo "Releases to Build: 20:00"
cp $RELEASES_FILE $PREV_RELEASES_FILE
create_releases_to_build_file 20:00 $SWAP_TMP_FILE
if [ $? -eq 0 ]
then
	mv $SWAP_TMP_FILE $RELEASES_FILE
	any_difference_between $PREV_RELEASES_FILE $RELEASES_FILE
fi

echo "Releases to Build: 05:00"
cp $RELEASES_FILE_AMERICA $PREV_RELEASES_FILE_AMERICA
create_releases_to_build_file 5:00 $SWAP_TMP_FILE
if [ $? -eq 0 ]
then
	mv $SWAP_TMP_FILE $RELEASES_FILE_AMERICA
	any_difference_between $PREV_RELEASES_FILE_AMERICA $RELEASES_FILE_AMERICA
fi

rm $RELEASES_TMP_FILE ${RELEASES_TMP_TMP_FILE} $PREV_RELEASES_FILE $PREV_RELEASES_FILE_AMERICA

##############################################################
# PreBuild Query
##############################################################
query_for_projects_and_buildstate prebuild
cat ${RELEASES_TMP_TMP_FILE} | sed -e 's/[	| ]//g' > ${RELEASES_TMP_FILE}

echo "Releases to Pre-Build: 20:00"
cp $PREBUILD_RELEASES_FILE $PREV_PREBUILD_RELEASES_FILE
create_releases_to_build_file 20:00 $SWAP_TMP_FILE
if [ $? -eq 0 ]
then
	mv $SWAP_TMP_FILE $PREBUILD_RELEASES_FILE
	cat $RELEASES_FILE | grep -v '^#' >> $PREBUILD_RELEASES_FILE
	any_difference_between $PREV_PREBUILD_RELEASES_FILE $PREBUILD_RELEASES_FILE
fi

echo "Releases to Pre-Build: 05:00"
cp $PREBUILD_RELEASES_FILE_AMERICA $PREV_PREBUILD_RELEASES_FILE_AMERICA
create_releases_to_build_file 5:00 $SWAP_TMP_FILE
if [ $? -eq 0 ]
then
	mv $SWAP_TMP_FILE $PREBUILD_RELEASES_FILE_AMERICA
	cat $RELEASES_FILE_AMERICA | grep -v '^#' >> $PREBUILD_RELEASES_FILE_AMERICA
	any_difference_between $PREV_PREBUILD_RELEASES_FILE_AMERICA $PREBUILD_RELEASES_FILE_AMERICA
fi

rm $RELEASES_TMP_FILE ${RELEASES_TMP_TMP_FILE} $PREV_PREBUILD_RELEASES_FILE $PREV_PREBUILD_RELEASES_FILE_AMERICA

##############################################################
# PostBuild Query
##############################################################
query_for_projects_and_buildstate postbuild
cat ${RELEASES_TMP_TMP_FILE} | sed -e 's/[	| ]//g' > ${RELEASES_TMP_FILE}

echo "Releases to Post-Build: 20:00"
cp $POSTBUILD_RELEASES_FILE $PREV_POSTBUILD_RELEASES_FILE
create_releases_to_build_file 20:00 $SWAP_TMP_FILE
if [ $? -eq 0 ]
then
	mv $SWAP_TMP_FILE $POSTBUILD_RELEASES_FILE
	any_difference_between $PREV_POSTBUILD_RELEASES_FILE $POSTBUILD_RELEASES_FILE
fi

echo "Releases to Post-Build: 05:00"
cp $POSTBUILD_RELEASES_FILE_AMERICA $PREV_POSTBUILD_RELEASES_FILE_AMERICA
create_releases_to_build_file 5:00 $SWAP_TMP_FILE
if [ $? -eq 0 ]
then
	mv $SWAP_TMP_FILE $POSTBUILD_RELEASES_FILE_AMERICA
	any_difference_between $PREV_POSTBUILD_RELEASES_FILE_AMERICA $POSTBUILD_RELEASES_FILE_AMERICA
fi

rm $RELEASES_TMP_FILE ${RELEASES_TMP_TMP_FILE} $PREV_POSTBUILD_RELEASES_FILE $PREV_POSTBUILD_RELEASES_FILE_AMERICA

##############################################################
# Commented Out Query
##############################################################
echo "Releases Commented out"
echo
query_for_projects_and_buildstate commented
cat ${RELEASES_TMP_TMP_FILE} | sed -e 's/[	| ]//g' > ${RELEASES_TMP_FILE}
cat ${RELEASES_TMP_FILE} | cut -d, -f1-4 | tr ',' '  ' | sed -e 's/^/	/g' > ${RELEASES_TMP_TMP_FILE}
if [ -s ${RELEASES_TMP_TMP_FILE} ]
then
	echo "Releases Commented out"
	cat ${RELEASES_TMP_TMP_FILE}
	echo
fi

rm $RELEASES_TMP_FILE ${RELEASES_TMP_TMP_FILE}

##############################################################
# Rtest Query
##############################################################
query_for_projects_to_rtest
cat ${RTEST_TMP_TMP_FILE} | sed -e 's/[	| ]//g' | sed -e '/^$/d' > ${RTEST_TMP_FILE}

echo "Projects to Rtest: 22:00"
cp $RTEST_FILE $PREV_RTEST_FILE
create_releases_to_rtest_file 22:00 $SWAP_TMP_FILE
if [ $? -eq 0 ]
then
	mv $SWAP_TMP_FILE $RTEST_FILE
	any_difference_between $PREV_RTEST_FILE $RTEST_FILE
fi

echo "Projects to Rtest: 06:00"
cp $RTEST_FILE_AMERICA $PREV_RTEST_FILE_AMERICA
create_releases_to_rtest_file 06:00 $SWAP_TMP_FILE
if [ $? -eq 0 ]
then
	mv $SWAP_TMP_FILE $RTEST_FILE_AMERICA
	any_difference_between $PREV_RTEST_FILE_AMERICA $RTEST_FILE_AMERICA
fi

rm $RTEST_TMP_FILE ${RTEST_TMP_TMP_FILE} $PREV_RTEST_FILE $PREV_RTEST_FILE_AMERICA

echo
echo "[INFO] Addtional file refreshes"

##############################################################
# Platform Translations
##############################################################
echo
echo "[INFO] Attempting to refresh [${PLATTRAN_FILE}]"
query_for_platforms_and_create

##############################################################
# BUILD path Translations
##############################################################
echo
echo "[INFO] Attempting to refresh [${BUILDPATH_FILE}]"
query_for_buildpath_and_create

##############################################################
#COPY BUILD OBJECTS Translations
##############################################################
echo
echo "[INFO] Attempting to refresh [${COPY_BUILDPATH_FILE}]"
query_for_copy_buildpath_and_create

##############################################################
# Reconfigure_Server
##############################################################
echo
echo "[INFO] Attempting to refresh [${RECONFIGURE_SERVER_FILE}]"
sql="select host,',',ccm_platform from reconfigure_server"
create_csv_file_from_buildweb "${RECONFIGURE_SERVER_FILE}" "${sql}" ",	"

##############################################################
# Defaults_for_release
##############################################################
echo
echo "[INFO] Attempting to refresh [${DEFAULTS_FOR_RELEASE_FILE}]"
sql="select PROJECT,',',MAJOR_RELEASE,',',PLATFORM,',',ORACLE_PLATFORM,',',MACHINE,',',decode(SID,'(AUTO)','auto',SID) from defaults_for_release"
create_csv_file_from_buildweb "${DEFAULTS_FOR_RELEASE_FILE}" "${sql}"

##############################################################
# Overrides_for_release
##############################################################
echo
echo "[INFO] Attempting to refresh [${OVERRIDES_FOR_RELEASE_FILE}]"
sql="select PROJECT,',',VERSION,',',STATE,',',PLATFORM,',',ORACLE_PLATFORM,',',MACHINE,',',decode(SID,'(AUTO)','auto',SID) from overrides_for_release"
create_csv_file_from_buildweb "${OVERRIDES_FOR_RELEASE_FILE}" "${sql}"

##############################################################
# Curl_for_release
##############################################################
echo
echo "[INFO] Attempting to refresh [${CURL_FOR_RELEASE_FILE}]"
sql="select PROJECT,',',VERSION,',',DEPPROJECT,',',DEPVERSION,',',IN_PROJECT from depversion where depproject='CURL'"
create_csv_file_from_buildweb "${CURL_FOR_RELEASE_FILE}" "${sql}"

##############################################################
# Ccm_platform_details
##############################################################
echo
echo "[INFO] Attempting to refresh [${CCM_PLATFORM_DETAILS_FILE}]"
sql="select PLATFORM_ID,',',PLATFORM_CCM,',',PLATFORM_NAME from ccm_platform_details"
create_csv_file_from_buildweb "${CCM_PLATFORM_DETAILS_FILE}" "${sql}" "	"

##############################################################
# Gatekeeper
##############################################################
echo
echo "[INFO] Attempting to refresh [${GATEKEEPER_FILE}]"
sql="select release,',',folder_number,',',oracle_version from taskgate_release"
create_csv_file_from_buildweb "${GATEKEEPER_FILE}" "${sql}" "-"

##############################################################
# cvg_platform_details
##############################################################
echo
echo "[INFO] Attempting to refresh [${CVG_PLATFORM_DETAILS_FILE}]"

sql="select d.project,',',m.translated_platform,',',p.oracle,',',d.version,',',d.depversion,',',p.sdk,',',p.prd from platform_details p, depversion d, platform_mapping m where d.depproject='PLATFORM' and d.depversion=p.platform_version and p.os = m.platform and m.platform = p.os"

create_csv_file_from_buildweb "${CVG_PLATFORM_DETAILS_FILE}" "${sql}" ", "

###added below lines for adding patche version in platform_version file

sql="select d.project,',',m.translated_platform,',',p.oracle,',',d.PATCH_VERSION,',',d.PLATFORM_VERSION,',',p.sdk,',',p.prd from platform_details p,  PATCH_COMPANY_PF d, platform_mapping m where d.PLATFORM_VERSION=p.platform_version and p.os = m.platform and m.platform = p.os"

create_csv_file_from_buildweb "${CVG_PLATFORM_DETAILS_FILE_PATCHES}" "${sql}" ", "
chmod 644 "${CVG_PLATFORM_DETAILS_FILE_PATCHES}" ${CVG_PLATFORM_DETAILS_FILE}

cat ${CVG_PLATFORM_DETAILS_FILE_PATCHES} >> ${CVG_PLATFORM_DETAILS_FILE}

chmod 444 "${CVG_PLATFORM_DETAILS_FILE_PATCHES}" ${CVG_PLATFORM_DETAILS_FILE}

###added above lines for adding patche version in platform_version file

rm $GENERIC_TMP_FILE

# If changes detected notify the team
if [ "${sendEmail}" = "TRUE" ]
then
	echo "${whatsChanged}" > ${whatsChangedFile}
	${BCE_BUILD_SCRIPTS}/html_email.sh -F 'Build Config Reporter' -s "Build Config Files have been updated" -m ${whatsChangedFile} > ${emailReport}
	send_email ${emailReport} `cat $main_dir/email/build_managers`
	rm ${emailReport} ${whatsChangedFile}
	echo "[INFO] Updates have been detected - sending the email"
else
	echo "[INFO] No updates have been detected - not sending the email"
fi
