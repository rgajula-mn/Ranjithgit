#!/bin/sh
#
#  Script:              create_autogen_schema.sh
#  Instance:            CB1_1
#  Author:              vantony1
#  Start date:          Tue May 23 14:47:17 2006
#  Version:             %full_filespec: create_autogen_schema.sh-20:shsrc:CB1#1 %
#
#  Description:
#			The script creates the autogen schemas and checks if the
#			autogen files needs to be modified and checks-in the files
#			to CM Synergy if necessary
#
#
# (C) Convergys, 2002.
# Convergys refers to Convergys Corporation or any of its wholly owned
# subsidiaries.

# General initialization section
# Set script paths and data files

if [ -z "$autogen_schema" ]
then
	autogen_schema=$BCE_ADMIN/ccm_wa/PRD-bce/PRD/tools/schema
fi

###########################################################################################
#
#     #######
#     #        #    #  #    #   ####    #####     #     ####   #    #   ####
#     #        #    #  ##   #  #    #     #       #    #    #  ##   #  #
#     #####    #    #  # #  #  #          #       #    #    #  # #  #   ####
#     #        #    #  #  # #  #          #       #    #    #  #  # #       #
#     #        #    #  #   ##  #    #     #       #    #    #  #   ##  #    #
#     #         ####   #    #   ####      #       #     ####   #    #   ####
#
###########################################################################################

# Utilize common functions
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/web_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/svn_new.svn

# Constants
build_logs=$BCE_LOG

# Document all switches
usage() {
	echo
	echo "create_autogen_schema.sh usage"
	echo "----------------------"
	echo
	echo "Usage: `basename $0` -p <project> -l <log directory> -r <rc number> -f <pf release number>"
	echo
	echo "[MANDATORY] Setting -p specifies the project, e.g., GENEVA-sqa5.4.11.solaris.oracle9i2"
	echo "[MANDATORY] Setting -l specifies the build log directory in which to look for env files"
	echo
	echo "Example usage: `basename $0` -p GENEVA-sqa5.4.11.solaris.oracle9i2 -l 20060504i -r 5 -f 4.0.23.2"
	echo
	exit_program 1
}

################################################################
# Parse the arguments
################################################################
# The getopts function parses the command line arguments. It is
# supported on all platforms on which this program will be run:
################################################################

parseArguments() {

	ccm_proj_name=""
  
	while getopts p:l:r:f: the_option 2>/dev/null
	do

		case ${the_option} in

		p)
			ccm_proj_name="${OPTARG}"
			;;
		l)
			build_log_dir="${OPTARG}"
			;;
		r)
			rc_num="${OPTARG}"
			;;
		f)
			pf_num="${OPTARG}"
			;;
		[?])
			usage
			;;
		esac

	done

	return 0

}

# Validate stuff
sanity_check() {

	if [ -z "${ccm_proj_name}" ]
	then	
		echo
		echo "=----------------------------------="
		echo "      Project name not specified    "
		echo "=----------------------------------="
		usage
	fi
	
	#Check if the project is a valid project in CCM
#	ccm query -t project -n ${proj_name} -version ${proj_version} > /dev/null
	if [ $? -ne 0 ]
	then
		echo
		echo "=------------------------------------------="
		echo "Cannot locate ${ccm_proj_name} in CM Synergy"
		echo "=------------------------------------------="		
		usage
	fi

	if [ -z "${build_log_dir}" ]
	then
		echo
		echo "=-------------------------="
		echo "Log directory not specified"
		echo "=-------------------------="
		usage
	fi
	if [ -z "${rc_num}" ]
	then
		echo
		echo "=-------------------------="
		echo "RC number not specified"
		echo "=-------------------------="
		usage
	fi
	if [ -z "${pf_num}" ]
	then
		echo
		echo "=-------------------------="
		echo "PF release number not specified"
		echo "=-------------------------="
		usage
	fi
	
	#Create the build logs directory if it does not already exist
	if [ ! -d "${build_logs}/${build_log_dir}" ]
	then

		mkdir ${build_logs}/${build_log_dir}
	
	fi
	
}

# Install packages...
install_packages()
{
        procs_dir=$2
	for f in `ls "${procs_dir}" | egrep "${1}"`
            do
                if [ -f "${procs_dir}/${f}" ]
                then
                    echo "${f}" | tee -a ${log}
                    db_load ${DATABASE} "${procs_dir}/${f}" ${log}

                    if [ $? -ne 0 ]
                    then
                        messString "ERROR: Cannot load file ${procs_dir}/${f}. Check logs ${log}"
                        exit_program 8
                    fi
                else
                    messString "ERROR: Cannot find file ${procs_dir}/${f}"
                    exit_program 8
                fi
            done
}

################################################################
# Check the machine on which the script is being executed
################################################################
# We are using the build_project_svn script to generate the schema
# build_project_svn needs to be executed on the machine dedicated for
# a project version and the oracle version. Script terminates if
# are on a wrong machine.
################################################################

check_build_machine() {

	ccm_proj_name=$1
	machine_name=""

	if [ ! -z "${ccm_proj_name}" ]
	then
	    result_from_machine_for_proj=`machine_for_projects.pl -p $ccm_proj_name`

	    echo $result_from_machine_for_proj | grep "This project should be built on" > /dev/null
	    if [ $? -eq 0 ]
	    then
		machine_name=`echo $result_from_machine_for_proj | cut -d: -f2 | sed -e 's/ //g'`
	    else
		echo $result_from_machine_for_proj | grep "world" > /dev/null
		if [ $? -eq 0 ]
		then
		    return 0
		else
		    echo
		    messString "ERROR: Defaults and overrides configuration do not have this platform ${ccm_proj_name}. Aborting."
	            return 1				
		fi
	    fi
		
	    if [ ! -z "${machine_name}" ]
	    then
	        echo
	        messString "ERROR: This project should be built on: ${machine_name}, we are now on `hostname`. Aborting."
	        return 1
	    fi
	fi

}

messString() {
    echo "${*}" 2>>${log} | tee -a ${log}
    echo "" 2>>${log} | tee -a ${log}
}

################################################################
# Create the normal and the event schemas
################################################################
# Use the build_project_svn script to create the schemas. The
# environment file which contains the database connection information,
# created during this process is backed up to be sourced later. 
################################################################

createDB() {
 
    echo
    messString "Creating NORMAL schema using build_project_svn: build_project_svn -p $1 -o $2 -r $3 -m $4 -d $5 -t dbuser_no_packages -s $6 -L -l 0.2"
    messString "Detailed log can be found at ${build_logs}/${5}/make_${1}_${6}${3}_dbuser.log"

    build_project_svn -p $1 -o $2 -r $3 -m $4 -d $5 -t dbuser_no_packages -s $6 -L -l 0.2 | tee -a ${log}

    if [ $? -eq 0 ]
    then
	    if [ -d "${build_logs}/$5" ]
	    then
		if [ -s "${build_logs}/$5/env-$1_${6}${3}_dbuser_no_packages.sh" ]
		then			
			cp "${build_logs}/$5/env-$1_${6}${3}_dbuser_no_packages.sh" "${logDir}/env-$1-${6}${3}-dbuser_no_packages-normal.$$.sh"
			messString ""
			messString "Copied ${build_logs}/$5/env-$1_${6}${3}_dbuser_no_packages.sh to ${logDir}/env-$1-${6}${3}-dbuser_no_packages-normal.$$.sh"
		else
			messString "ERROR: ${build_logs}/$5/env-$1_${6}${3}_dbuser_no_packages.sh file not found or found zero byte file"
			exit_program 6
		fi
		if [ -s "${build_logs}/$5/make_${1}_${6}${3}_dbuser.log" ]
		then
			cp "${build_logs}/$5/make_${1}_${6}${3}_dbuser.log" "${logDir}/make_${1}_${6}${3}_dbuser-normal.$$.log"
			messString ""
			messString "Detailed logs for NORMAL schema creation now copied to ${logDir}/make_${1}_${6}${3}_dbuser-normal.$$.log"
		else
			messString "ERROR: ${build_logs}/$5/make_${1}_${6}${3}_dbuser.log file not found or found zero byte file"
			exit_program 6
		fi
	    else
		messString "ERROR: Log directory ${build_logs}/$5 not found"
		exit_program 6
            fi
    else
	messString "ERROR: An error was encountered when creating the schema, please check and try again"
	messString "Detailed log can be found at ${build_logs}/${5}/make_${1}_${6}${3}_dbuser.log"
	exit_program 6
    fi

    messString ""
    messString "Creating EVENT schema using build_project_svn: build_project_svn -p $1 -o $2 -r $3 -m $4 -d $5 -t dbuser_no_packages -s $6 -L -l 0.2"
    messString "Detailed log can be found at ${build_logs}/${5}/make_${1}_${6}${3}_dbuser.log"

    build_project_svn -p $1 -o $2 -r $3 -m $4 -d $5 -t dbuser_no_packages -s $6 -L -l 0.2 | tee -a ${log}

    if [ $? -eq 0 ]
    then
	    if [ -d "${build_logs}/$5" ]
	    then
		if [ -s "${build_logs}/$5/env-$1_${6}${3}_dbuser_no_packages.sh" ]
		then
			cp "${build_logs}/$5/env-$1_${6}${3}_dbuser_no_packages.sh" "${logDir}/env-$1-${6}${3}-dbuser_no_packages-event.$$.sh"
			messString ""
			messString "Copied ${build_logs}/$5/env-$1_${6}${3}_dbuser_no_packages.sh to ${logDir}/env-$1-${6}${3}-dbuser_no_packages-event.$$.sh"
		else
			messString "ERROR: ${build_logs}/$5/env-$1_${6}${3}_dbuser_no_packages.sh file not found or found zero byte file"
			exit_program 7
		fi
		if [ -s "${build_logs}/$5/make_${1}_${6}${3}_dbuser.log" ]
		then
			messString ""
			cp "${build_logs}/$5/make_${1}_${6}${3}_dbuser.log" "${logDir}/make_${1}_${6}${3}_dbuser-event.$$.log"
			messString "Detailed logs for EVENT schema creation now copied to ${logDir}/make_${1}_${6}${3}_dbuser-event.$$.log"
		else
			messString "ERROR: ${build_logs}/$5/make_${1}_${6}${3}_dbuser.log file not found or found zero byte file"
			exit_program 7
		fi
	    else
		messString "ERROR: Log directory ${build_logs}/$5 not found"
		exit_program 7
	    fi
    else
	messString "ERROR: An error was encountered when creating the schema, please check and try again"
	messString "Detailed log can be found at ${build_logs}/${5}/make_${1}_${6}${3}_dbuser.log"
	exit_program 7
    fi

}

################################################################
# Calls SQL/Plus to execute a specified script
################################################################
# Connects to a specified database and executes a specified sql script
# Exits on an Oracle/SQL failure.
################################################################

db_load() {

    DATABASE=$1
    TARGETFILE=$2
    LOGFILE=$3
    export DATABASE TARGETFILE LOGFILE

    sqlplus -s "${DATABASE}" >> ${LOGFILE} 2>&1 << +ENDSQL
    whenever sqlerror exit 1
    @${TARGETFILE}
    commit;
    exit 0
+ENDSQL
	
    return $?

}

################################################################
# Loads the normal procedures to the normal schema and the event
# procedures to the event schema
################################################################
# Sources the environment file generated during schema creation 
# to connect to the correct database schema and loads the specified
# procedures
################################################################
################################################################
# History

# 7-May-08	Dave B		Modified to install olc packages

################################################################

load_db_files () {

    major_release=$3
    name_proj_ccm=$1
    name_proj=$2
    rel_platform=$4

    name_projlc=`echo $name_proj | tr '[A-Z]' '[a-z]'`

    if [ "$name_proj" = "GENEVA" ]
    then
        build_home=$BCE_ROOT/build/geneva/${major_release}
    else
        build_home=$BCE_ROOT/build/${name_projlc}/${major_release}
    fi
####### Loading normal packages if environment exists ######## 

    . ${logDir}/env-${name_proj_ccm}-dbuser_no_packages-normal.$$.sh
 
    if [ $? -eq 0 ]
    then
	
	normal_procs_dir="${build_home}/${name_proj_ccm}/${name_proj}/sql"
	#if [ "$major_release" = "5.3" ]
	#then
	#	eca_procs_dir="$BCE_ROOT/build/web/${name_proj}API-${rel_platform}/${name_proj}API/build_release_eca/distrib/external/schema/eca/procedures"
	#else
		if [ "$major_release" = "3.0" -o "$major_release" = "3.1" -o "$major_release" = "3.2" ]
        	then
                eca_procs_dir="$BCE_ROOT/build/web/${name_proj}API-${rel_platform}/${name_proj}API/build_output/distrib/external/schema/eca/procedures"
		else
			eca_procs_dir="$BCE_ROOT/build/web/${name_proj}API-${rel_platform}/${name_proj}API/build_release_all/distrib/external/schema/eca/procedures"
		fi
	#fi
	
	event_procs_dir="${build_home}/${name_proj_ccm}/${name_proj}/sql"

	messString ""
	messString "Loading procedures in normal schema..."	

	if [ -d "${normal_procs_dir}" ]
	then
	    install_packages "all_private_package_spc.plb|all_public_package_spc.sql" ${normal_procs_dir}
	    install_packages "all_private_package_bdy.plb|all_public_package_bdy.sql" ${normal_procs_dir}
	    install_packages "all_private_standalone_procs.plb|all_public_standalone_procs.sql" ${normal_procs_dir}
	else
	    messString "ERROR: Cannot find directory ${normal_procs_dir}"
	    exit_program 8
	fi

	if [ -d "${eca_procs_dir}" ]
	then
	    install_packages all_ECA_prmake_RB_sqa4.0.1.solaris.oracle10g_dbuser-normal.9273.logivate_package_spc.plb ${eca_procs_dir}
            install_packages all_ECA_private_package_bdy.plb ${eca_procs_dir}
	else
	    messString "ERROR: Cannot find directory ${eca_procs_dir}"
	    exit_program 8
	fi

    else
	messString "ERROR: An error was encountered when sourcing environment variables from ${logDir}/env-${name_proj_ccm}-dbuser_no_packages-normal.$$.sh"
	exit_program 8
    fi

########  Loading event packages if environment exists ########
    
. ${logDir}/env-${name_proj_ccm}-dbuser_no_packages-event.$$.sh
    
    if [ $? -eq 0 ]
    then
	messString ""
	messString "Loading procedures in event schema..."
	if [ -d "${event_procs_dir}" ]
	then
	    install_packages "all_private_package_spc_event.plb|all_public_package_spc_event.sql" ${event_procs_dir}
       	    install_packages "all_private_package_bdy_event.plb|all_public_package_bdy_event.sql" ${event_procs_dir}
       	    install_packages "all_private_standalone_procs_event.plb|all_public_standalone_procs_event.sql" ${event_procs_dir}
	else
    	    messString "ERROR: Cannot find directory ${event_procs_dir}"
    	    exit_program 9
	fi
	

    else
	messString "ERROR: An error was encountered when sourcing environment variables from ${logDir}/env-${name_proj_ccm}-dbuser_no_packages-event.$$.sh"
	exit_program 9
    fi

	###### This section is only for RB pojects 4.0 and later ########

	if [ ${is_RB_4_and_higher} = 1 ]; then

	########  Loading cache packages if environment exsists ########

		cache_procs_dir="${build_home}/${name_proj_ccm}/${name_proj}/sql"
	# Find the olc database name
		name_proj_ccm1=`echo ${name_proj_ccm} | sed -e "s/-/_/g"`
		sys_olc_db_name=`cat ${logDir}/make_${name_proj_ccm1}_dbuser-normal.$$.log | grep DATABASE_OLC_CACHE= | cut -d"=" -f2`
		olc_db_name=`echo ${sys_olc_db_name} | sed -e "s/\(sys\/sys@\)\([0-9a-zA-Z]*\.world\)\(.*\)/\2/g"`
		echo "#*** THIS FILE HAS BEEN GENERATED BY create_autogen_schema.sh***" > ${logDir}/env-${name_proj_ccm}-dbuser_no_packages-cache.$$.sh
		echo "#*** Based on ${logDir}/make-${name_proj_ccm}-dbuser-normal.$$.sh ***" >> ${logDir}/env-${name_proj_ccm}-dbuser_no_packages-cache.$$.sh

	# Create cache environment file

		cat ${logDir}/env-${name_proj_ccm}-dbuser_no_packages-normal.$$.sh | sed -e "s/^\(DATABASE=.*@\)\([0-9a-zA-Z]*\.world\)/\1${olc_db_name}/g" >> ${logDir}/env-${name_proj_ccm}-dbuser_no_packages-cache.$$.sh

	#	Source the newly created environment

	    . ${logDir}/env-${name_proj_ccm}-dbuser_no_packages-cache.$$.sh

	    if [ $? -eq 0 ]
	    then
		messString ""
		messString "Loading procedures in cache schema..."
		if [ -d "${cache_procs_dir}" ]
		then
		    install_packages "all_private_package_spc_cache.plb|all_public_package_spc_cache.sql" ${cache_procs_dir}
		    install_packages "all_private_package_bdy_cache.plb|all_public_package_bdy_cache.sql" ${cache_procs_dir}
		    install_packages "all_private_standalone_procs_cache.plb|all_public_standalone_procs_cache.sql" ${cache_procs_dir}
		else
		    messString "ERROR: Cannot find directory ${cache_procs_dir}"
		    exit_program 9
		fi
		

	    else
		messString "ERROR: An error was encountered when sourcing environment variables from ${logDir}/env-${name_proj_ccm}-dbuser_no_packages-cache.$$.sh"
		exit_program 9
	    fi
	fi

}

################################################################
# Uses the autogen scripts to generate the autogen files from 
# normal and event schemas
################################################################
# Sources the environment file generated during schema creation 
# to connect to the correct database schema and creates the autogen
# files using autogen scripts
################################################################
################################################################
# History

# 7-May-08	Dave B		Modified to generate olc schema files

################################################################

generate_autogen_files () {

    if [ ! -d "$CCM_ROOT/autogen" ]
    then
	mkdir "$CCM_ROOT/autogen"
    fi

    . ${logDir}/env-$1-dbuser_no_packages-normal.$$.sh
    
    if [ $? -eq 0 ]
    then
	messString ""
	messString "Generating autogen files from normal schema...  \c"
	${autogen_schema}/make_procsyn.sh > $CCM_ROOT/autogen/procsyn.sql
	${autogen_schema}/make_dropprocsyn.sh > $CCM_ROOT/autogen/dropprocsyn.sql
	${autogen_schema}/make_adminrole_proc.sh > $CCM_ROOT/autogen/adminrole_proc.sql
	${autogen_schema}/make_dropproc.sh > $CCM_ROOT/autogen/dropproc_geneva.sql
	messString "done."
    else
	messString "ERROR: An error was encountered when sourcing environment variables from ${logDir}/env-$1-dbuser_no_packages-normal.$$.sh"
	exit_program 10
    fi

    . ${logDir}/env-$1-dbuser_no_packages-event.$$.sh
    
    if [ $? -eq 0 ]
    then
	messString ""
	messString "Generating autogen files from event schema...  \c"
	${autogen_schema}/make_procsyn.sh > $CCM_ROOT/autogen/procsyn_event.sql
	${autogen_schema}/make_dropprocsyn.sh > $CCM_ROOT/autogen/dropprocsyn_event.sql
	${autogen_schema}/make_adminrole_proc.sh > $CCM_ROOT/autogen/adminrole_proc_event_1.sql
	cat $CCM_ROOT/autogen/adminrole_proc_event_1.sql |grep -v "PVSYSTEMDATE" > $CCM_ROOT/autogen/adminrole_proc_event.sql	
	${autogen_schema}/make_dropproc.sh > $CCM_ROOT/autogen/dropproc_event_1.sql
	cat $CCM_ROOT/autogen/dropproc_event_1.sql |grep -v "PVSYSTEMDATE" > $CCM_ROOT/autogen/dropproc_event.sql
	messString "done."
    else
	messString "ERROR: An error was encountered when sourcing environment variables from ${logDir}/env-$1-dbuser_no_packages-event.$$.sh"
	exit_program 10
    fi

	###### This section is only for RB pojects 4.0 and later ########

	if [ ${is_RB_4_and_higher} = 1 ]; then

	    . ${logDir}/env-$1-dbuser_no_packages-cache.$$.sh
	    
	    if [ $? -eq 0 ]
	    then
		messString ""
		messString "Generating autogen files from event schema...  \c"
		${autogen_schema}/make_procsyn.sh > $CCM_ROOT/autogen/olc_procsyn.sql
		${autogen_schema}/make_dropprocsyn.sh > $CCM_ROOT/autogen/olc_drop_procsyn.sql
		${autogen_schema}/make_adminrole_proc.sh > $CCM_ROOT/autogen/olc_adminrole_proc_1.sql
		cat $CCM_ROOT/autogen/olc_adminrole_proc_1.sql |grep -v "PVSYSTEMDATE" | grep -v "BIDPLSQL"|grep -v "GNVCEP" |grep -v "GNVCEPARTITIONMANAGER" |grep -v "GNVCEPARTITIONUTILS" |grep -v "GNVDELETECPDUCPIDU"|grep -v "GNVDUPCHECKPARTITION" > $CCM_ROOT/autogen/olc_adminrole_proc.sql
		${autogen_schema}/make_dropproc.sh > $CCM_ROOT/autogen/olc_drop_procedures_1.sql
		cat $CCM_ROOT/autogen/olc_drop_procedures_1.sql |grep -v "PVSYSTEMDATE" > $CCM_ROOT/autogen/olc_drop_procedures.sql
		messString "done."
	    else
		messString "ERROR: An error was encountered when sourcing environment variables from ${logDir}/env-$1-dbuser_no_packages-cache.$$.sh"
		exit_program 10
	    fi
	fi



}

################################################################
# Determine if differences exist between the generated autogen files
# and those that in CM Synergy and if so, checkin the modified files
################################################################
# Checks in the autogen files to CM Synergy and does a DCM transfer to CB2
################################################################
# History

# 8-May-08	Dave B		Modified to find olc files in:  
#				$CCM_ROOT/SCHEMA/synonyms $CCM_ROOT/SCHEMA/olc scripts and $CCM_ROOT/SCHEMA/olc/roles
################################################################

check_autogen_file_changes () {

    touch ${logDir}/check_autogen_build_objs.sh_results.$$
    diff=`${BCE_BUILD_SCRIPTS}/check_auto_gen_build_objs.sh $CCM_ROOT ${logDir}/check_autogen_build_objs.sh_results.$$`

    if [ ${diff} -ne 0 ]
    then
	messString ""
	messString "Differences detected for autogen files - creating task to checkin files"

	release_tag=`discover_release_tag.sh -p $proj_name -r $release`

	#task=`ccm task -create -synopsis "\"Reconcile autogen files for $release\"" -resolver genadmin -release "$release_tag" -subsystem 'Build' -default -q`

	#######################here we are creating PR, target and subtask ##########################################################
	
	#if [ $? -ne 0 ]
	#then
	 #   messString "ERROR: Sub Task not created successfully"
	  #  exit_program 11
	#else
	 #   task=`echo $task | awk '{print $1}' | awk -F\# '{print $2}'`
	  #  messString "Task $task created successfully"

	    org_dir=`pwd`

	    if [ -d "$CCM_ROOT/SCHEMA/synonyms" ]
	    then
		cd "$CCM_ROOT/SCHEMA/synonyms"
	        for file in `ls -1 $CCM_ROOT/SCHEMA/synonyms`
	        do
		    echo $file | egrep "procsyn.sql|procsyn_event.sql|dropprocsyn.sql|dropprocsyn_event.sql" > /dev/null
		    if [ $? -eq 0 ]
		    then
			#messString "Checking out file ${file}"
		        #ccm co -c "Reconcile autogen files for $release" $file 2>> ${log}
		        #if [ $? -eq 0 ]
		        #then
			    cp $CCM_ROOT/autogen/$file $CCM_ROOT/SCHEMA/synonyms/
			    #ccm checkin -nc @
		           # #svn commit -m "committing files in synonyms for $file" 2>> ${log}
		        #else
			#    messString "ERROR: Checkout of $file failed"
		        #fi
		    fi
	        done
				 #svn commit -m "committing files in source for" 2>> ${log}


	    else
		messString "ERROR: Directory $CCM_ROOT/SCHEMA/synonyms do not exist"
		exit_program 11
	    fi

	    if [ -d "$CCM_ROOT/SCHEMA/source" ]
	    then
	        cd "$CCM_ROOT/SCHEMA/source"
	        for file in `ls -1 $CCM_ROOT/SCHEMA/source`
	        do
		    echo $file | egrep "dropproc_geneva.sql|dropproc_event.sql" > /dev/null
		    if [ $? -eq 0 ]
		    then
		       # messString "Checking out file ${file}"
		        #ccm co -c "Reconcile autogen files for $release" $file 2>> ${log}
		        #if [ $? -eq 0 ]
		        #then
			    cp $CCM_ROOT/autogen/$file $CCM_ROOT/SCHEMA/source/
			 #   ccm checkin -nc @
		        #else
			 #   messString "ERROR: Checkout of $file failed"
		        #fi
		    fi
	        done
			 #svn commit -m "committing files in source for" 2>> ${log}

	    else
		messString "ERROR: Directory $CCM_ROOT/SCHEMA/source do not exist"
		exit_program 11
	    fi

	    if [ -d "$CCM_ROOT/SCHEMA/roles" ]
	    then
		cd "$CCM_ROOT/SCHEMA/roles"
	        for file in `ls -1 $CCM_ROOT/SCHEMA/roles`
	        do
		    echo $file | egrep "adminrole_proc.sql|adminrole_proc_event.sql" > /dev/null
		    if [ $? -eq 0 ]
		    then
		        #messString "Checking out file ${file}"
		        #ccm co -c "Reconcile autogen files for $release" $file 2>> ${log}
		        #if [ $? -eq 0 ]
		        #then
			    cp $CCM_ROOT/autogen/$file $CCM_ROOT/SCHEMA/roles/
			 #   ccm checkin -nc @
		        #else
			 #   messString "ERROR: Checkout of $file failed"
		        #fi
		    fi
	        done
			 #svn commit -m "committing files in source for" 2>> ${log}

	    else
		messString "ERROR: Directory $CCM_ROOT/SCHEMA/roles do not exist"
		exit_program 11
	    fi

	###### This section is only for RB pojects 4.0 and later ########

	if [ ${is_RB_4_and_higher} = 1 ]; then
	# Added to capture files in $CCM_ROOT/SCHEMA/olc/synonyms  directory - Dave B 8-May-08

	    if [ -d "$CCM_ROOT/SCHEMA/olc/synonyms" ]
	    then
		cd "$CCM_ROOT/SCHEMA/olc/synonyms"
	        for file in `ls -1 $CCM_ROOT/SCHEMA/olc/synonyms`
	        do
		    echo $file | egrep "olc_drop_procsyn.sql|olc_procsyn.sql" > /dev/null
		    if [ $? -eq 0 ]
		    then
			    cp $CCM_ROOT/autogen/$file $CCM_ROOT/SCHEMA/olc/synonyms/
		    fi
	        done
	 		#svn commit -m "committing files in source for" 2>> ${log}


	    else
		messString "ERROR: Directory $CCM_ROOT/SCHEMA/olc/synonyms does not exist"
		exit_program 11
	    fi


	    # Added to capture files in $CCM_ROOT/SCHEMA/olc/scripts directory - Dave B 8-May-08

	    if [ -d "$CCM_ROOT/SCHEMA/olc/scripts" ]
	    then
		cd "$CCM_ROOT/SCHEMA/olc/scripts"
	        for file in `ls -1 $CCM_ROOT/SCHEMA/olc/scripts`
	        do
		    echo $file | egrep "olc_drop_procedures.sql" > /dev/null
		    if [ $? -eq 0 ]
		    then
			    cp $CCM_ROOT/autogen/$file $CCM_ROOT/SCHEMA/olc/scripts/
		    fi
	        done
			 #svn commit -m "committing files in source for" 2>> ${log}


	    else
		messString "ERROR: Directory $CCM_ROOT/SCHEMA/olc/scripts does not exist"
		exit_program 11
	    fi

	    # Added to capture files in $CCM_ROOT/SCHEMA/olc/roles directory - Dave B 8-May-08

	    if [ -d "$CCM_ROOT/SCHEMA/olc/roles" ]
	    then
		cd "$CCM_ROOT/SCHEMA/olc/roles"
	        for file in `ls -1 $CCM_ROOT/SCHEMA/olc/roles`
	        do
		    echo $file | egrep "olc_adminrole_proc.sql" > /dev/null
		    if [ $? -eq 0 ]
		    then
		     #   messString "Checking out file ${file}"
		        #ccm co -c "Reconcile autogen files for $release" $file 2>> ${log}
		        #if [ $? -eq 0 ]
		        #then
			    cp $CCM_ROOT/autogen/$file $CCM_ROOT/SCHEMA/olc/roles/
			    #ccm checkin -nc @
		        #else
			 #   messString "ERROR: Checkout of $file failed"
		        #fi
		    fi
	        done
				#svn commit -m "committing files in source for" 2>> ${log}

	    else
		messString "ERROR: Directory $CCM_ROOT/SCHEMA/olc/roles does not exist"
		exit_program 11
	    fi
	fi


	    cd $org_dir

	
	    #objs_in_task=`ccm task -show objects $task | wc -l`

	  #  if [ "${objs_in_task}" -gt 0 ]
	  #  then
		echo "calling release_info.sh for updating rc number and updating geneva_messages.enu" 2>> ${log}
		#release_info.sh $task $release $log $CCM_ROOT $rc_num $pf_num
		release_info_svn.sh $release $log $CCM_ROOT $rc_num $pf_num
		#ccm task -checkin default
	#	if [ $? -eq 0 ]
	#	then
		    #messString "Task ${task} checked in successfully"
		    #messString "Initiating DCM Transfer for release ${majorRelease}"

		    #do_dcm_transfer "${majorRelease}"
	
		    #if [ $? -eq 0 ]
		    #then
		#	messString "DCM Transfer for release ${majorRelease} successful."
		#	exit_program 0
		 #   else
		#	messString "ERROR: Errors during DCM Transfer - Check logs ${log}"
		#	exit_program 12
		 #   fi
		#else
		 #   messString "ERROR: Could not checkin task $task"
		  #  exit_program 11
		#fi
	    #else
	#	messString "ERROR: No file associated with task $task. Task $task not checked in."
	#	exit_program 11
	 #   fi

    else
	messString "No differences detected for autogen files"
	exit_program 0
    fi

}

exit_program ()
{

        messString "Exiting Program with status $1:"
        case $1 in
                0)
                        messString "  SUCCESS: Exiting happy."
                        ;;
                1)
                        messString "  ERROR: Incorrect Usage."
                        ;;
                2)
                        messString "  ERROR: Ctrl-C caught."
                        ;;
                3)
                        messString "  ERROR: CM Session could not be started."
                        ;;
                4)
                        messString "  ERROR: Incorrect parameters. Please check."
                        ;;
                5)
                        messString "  ERROR: SQL Plus not found. Aborting."
                        ;;
                6)
                        messString "  ERROR: Errors occured during creation of normal schema. Investigate. Logs available at ${log}"
			messString "  ERROR: Detailed schema creation logs available at ${build_logs}/${5}/make_${1}_${6}${3}_dbuser.log"
                        ;;
                7)
                        messString "  ERROR: Errors occured during creation of event schema. Investigate. Logs available at ${log}"
			messString "  ERROR: Detailed schema creation logs available at ${build_logs}/${5}/make_${1}_${6}${3}_dbuser.log"
                        ;;
                8)
                        messString "  ERROR: Errors occured while loading procedures to normal schema. Investigate. Logs available at ${log}"
                        ;;
                9)
                        messString "  ERROR: Errors occured while loading procedures to event schema. Investigate. Logs available at ${log}"
                        ;;
                10)
                        messString "  ERROR: Errors occured while generating autogen files from schema. Investigate. Logs available at ${log}"
                        ;;
                11)
                        messString "  ERROR: Errors occured while trying to checkin autogen file changes to CM Synergy. Investigate. Logs available at ${log}"
			echo

			#if [ ! -z "${task}" ]
			#then
		         #   if [ `ccm task -query -custom "name='task${task}'" -u -f "%status"` = 'task_assigned' ]
			  #  then
			#	task_working_objs=""
			#	task_working_objs=`ccm query "status='working' and is_associated_object_of('task${task}-1:task:CB1')" -u -f "%objectname"`
			#	if [ ! -z "${task_working_objs}" ]
			#	then
			#	    messString "Task $task still found in assigned state with the following objects in working state:-"
			#	    messString "$task_working_objs"
			#	    for object in `echo $task_working_objects`
			#	    do
			#	       messString "Deleting object ${object}"
			#	       ccm delete -replace ${object}
			#	    done
			#	    messString "Trying to complete task $task"
			#	    ccm task -complete default -y
			#	else
			#	    messString "Task $task still found in assigned state"
			#	    messString "Trying to complete task $task"
			#	    ccm task -complete default -y
			#	fi
			 #   fi
			#fi
                        ;;
                12)
                        messString "  ERROR: Errors occured during DCM transfer. Investigate. Logs available at ${log}"
                        ;;
                *)
                        messString "  Unknown Error"
                        ;;
        esac
	cleanUpCCM >/dev/null 2>&1
        exit $1
}

###########################################################################################
#
#     #    #    ##       #    #    #
#     ##  ##   #  #      #    ##   #
#     # ## #  #    #     #    # #  #
#     #    #  ######     #    #  # #
#     #    #  #    #     #    #   ##
#     #    #  #    #     #    #    #
#
###########################################################################################

ccm_proj_name=""

# Define traps - you never know what a user presses
# Exit with a non-zero number if CTRL+C pressed for example
#trap 'trap_exit' 1 2 3 15
trap 'exit_program 2'  2

if [ $# -lt 4 ]
then
	usage
fi

parseArguments $@

proj_name=`echo $ccm_proj_name | awk -F\- '{print $1}'`
proj_version=`echo $ccm_proj_name | awk -F\- '{print $2}'`

echo
#echo "Starting CCM on PRD... \c"
#startCCM "/ccm/prd" >/dev/null 2>&1
#if [ -z "${CCM_ADDR}" ]
#then
#	echo
#	exit_program 3
#fi
echo "done."

sanity_check ${proj_name} ${proj_version}
if [ $? -ne 0 ]
then
	exit_program 4
fi

echo
echo "Verifying if we are on the right build machine...  \c"
check_build_machine ${ccm_proj_name}
if [ $? -ne 0 ]
then
	echo
	exit 1
fi
echo "done."

logDir=${build_logs}/${build_log_dir}

if [ ! -d $logDir ]
then
	mkdir $logDir
	chmod 777 $logDir
fi

log="${logDir}/${ccm_proj_name}_create_autogen_schema_$$.log"

echo
echo "CCM Project Name: ${ccm_proj_name}" | tee -a ${log}
echo "Build Logs Dir: ${build_log_dir}" | tee -a ${log}
echo

proj_version=`echo $ccm_proj_name | awk -F\- '{print $2}'`
proj_purpose=`echo $proj_version | cut -b1-3`

oracle_version=`echo $ccm_proj_name | sed 's/\(.*\)oracle\(.*\)/\2/'`
if [ "${oracle_version}" = "${ccm_proj_name}" ]
then
	oracle_version="at"
else
	oracle_version=`echo oracle${oracle_version}`
fi

release_platform=`echo $ccm_proj_name | sed "s/${proj_name}-${proj_purpose}\(.*\)\.${oracle_version}/\1/"`
release=`echo $release_platform | sed 's/\(.*\)\.\(.*\)/\1/'`
majorRelease=`echo $release | cut -d '.' -f1-2`

platform=`echo $release_platform | sed 's/\(.*\)\.\(.*\)/\2/'`

major_release_1=`echo ${majorRelease} | cut -d'.' -f1`
major_release_2=`echo ${majorRelease} | cut -d'.' -f2`

# Check if it's an RB project higher than 4.0
is_RB_4_and_higher=0

if [ "${proj_name}" = "RB" -a "${major_release_1}" -ge '4' -a "${major_release_2}" -ge '0' ]; then
	is_RB_4_and_higher=1
fi


echo "Project Name: ${proj_name}" | tee -a ${log}
echo "Major Release: ${majorRelease}" | tee -a ${log}/
echo
echo "Project Purpose: ${proj_purpose}" | tee -a ${log}
echo "Full Release: ${release}" | tee -a ${log}
echo "Platform: ${platform}" | tee -a ${log}
echo "Oracle Version: ${oracle_version}" | tee -a ${log}

proj_namelc=`echo $proj_name | tr '[A-Z]' '[a-z]'`

if [ "${proj_name}" = "GENEVA" ]
then
    CCM_ROOT="${BCE_ROOT}/build/geneva/${majorRelease}/${ccm_proj_name}/${proj_name}"
else
    CCM_ROOT="${BCE_ROOT}/build/$proj_namelc/${majorRelease}/${ccm_proj_name}/${proj_name}"
fi

find_sqlhome 9.2.0.SE

if [ $? -ne 0 ]
then
    messString "`basename $0`: ERROR: Cannot find valid SQLPLUS"
    exit_program 5
fi

echo
echo "Logs available in ${log}"
echo | tee -a ${log}

createDB ${proj_name} ${oracle_version} "$release_platform.$oracle_version" ${majorRelease} ${build_log_dir} ${proj_purpose}

load_db_files ${ccm_proj_name} ${proj_name} ${majorRelease} "${proj_purpose}${release}"

generate_autogen_files ${ccm_proj_name}

check_autogen_file_changes



