#!/bin/sh

while getopts ":b:d:z:" o
do
	case "${o}" in 
		b)
			BACKUP_DIR=${OPTARG}
			;;
		d)
			DATABASE=${OPTARG}
			;;
		z)
			build_zip=${OPTARG}
			;;
	esac
done

if ! [ -d $BACKUP_DIR ]
then
	mkdir $BACKUP_DIR
fi
echo "Backup directory is $BACKUP_DIR"

unpack_dir=`echo $build_zip | perl -pe 's/(.*)\..*/\1/'`

if ! [ -d $unpack_dir ]
then
	mkdir $unpack_dir
fi
unzip -q $build_zip -d $unpack_dir
pack_files=`find $unpack_dir \( -name "*.spc" -o -name "*.plb" \)`

echo "Getting package names"
packages=""
for pack_file in $pack_files
do
	package=`perl -0777 -pe 's{/\*.*?\*/}{}gs' $pack_file | \
		 perl -n -e 'print unless m{^\s*--.*$}' | \
		 perl -e '$str = do { local $/; <> }; while ($str =~ /create\s+(?:or\s+replace)?\s+package\s+(?:body\s+)?(\S*?)\s+\S+/sgi) { $a= uc $1; print "$a"} '`
	packages="$packages $package"
done

packages=$(echo "$packages" | tr " " "\n" | sort -u | tr "\n" " ")

sql=`find $unpack_dir -name "*changes.sql"`
if ! [ -z "$packages" ] || ! [ -z "$sql" ]
then
	echo "Testing database connection"
	sqlplus -s "${DATABASE}" > /dev/null << +ENDSQL
		WHENEVER OSERROR EXIT 9;
		WHENEVER SQLERROR EXIT SQL.SQLCODE;
		select 1 from dual;
+ENDSQL
	if [ $? -ne 0 ]
	then
		rm -rf $unpack_dir
		echo "Cannot access to DATABASE schema"
		exit 1
	fi
fi
if [ -z "$packages" ]
then
	echo "Nothing to backup"
	exit 0
fi

for package in $packages
do
	echo "Creating backup for $package package"
	sqlplus -s "${DATABASE}"> /dev/null << +ENDSQL
		set termout off echo off;
		set escape off;
		set trimout on trimspool on;
		set feedback off;
		set long 200000 pages 0 lines 151;
		column txt format a141 word_wrapped;
		spool $BACKUP_DIR/$package-BACKUP.sql
		select DBMS_METADATA.GET_DDL('PACKAGE_SPEC','$package') txt from dual;
		select '/' txt from dual;
		select DBMS_METADATA.GET_DDL('PACKAGE_BODY','$package') txt from dual;
		select '/' txt from dual;
		spool off;
+ENDSQL
	perl -pi -e 's/(?<!\\)\\(?!\\)/\\\\/g' "$BACKUP_DIR/$package-BACKUP.sql"
done

rm -rf $unpack_dir
cd $BACKUP_DIR
zip -qr backup_packages-`basename $unpack_dir`.zip *.sql
rm -f *.sql
