--Need to replace variables with actual values (on build stage): componentId, componentType, VersionNum, packageType, integrationName, integrationVersion        
DELETE FROM components_versions WHERE component_id = 'componentId';
INSERT INTO COMPONENTS_VERSIONS (COMPONENT_ID, COMPONENT_TYPE, INSTALL_DATE, VERSION, PACKAGE_TYPE, INTEGRATION_NAME, INTEGRATION_VERSION, COMMENTS) VALUES ('componentId', componentType, sysdate, 'VersionNum', 'packageType', 'integrationName', 'integrationVersion', 'patchContent');
INSERT INTO COMPONENTS_VERSIONS_HISTORY (COMPONENT_ID, COMPONENT_TYPE, INSTALL_DATE, VERSION, PACKAGE_TYPE, INTEGRATION_NAME, INTEGRATION_VERSION, COMMENTS) VALUES ('componentId', componentType, sysdate, 'VersionNum', 'packageType', 'integrationName', 'integrationVersion', 'patchContent');
	
