#!/usr/bin/perl -w

#
#   Script:        check_overnight_builds.pl
#
#   Version:       %version: 112 %
#
#   File spec:     %full_filespec: check_overnight_builds.pl-112:perl:CB1#1 %
#
#   Last altered:  %derived_by: pavu0613 % %date_modified: Wed Jun 05 09:59:32 2002 %
#
#   Usage:         check_overnight_builds <log_file_name> [yyyymmdd] [NOSNIP]
#
#   Description:   Reads a given build log (and its associated reconfigure
#                  log) and finds any errors. It then sends an HTML report
#                  to the appropriate people.
#
#                  If log_file_name has a path, it will look for the
#                  make and reconfigure logs there. Otherwise, it will look
#                  in /prdbuild/admin/log/<yyyymmdd>
#
#                  If the optional parameter NOSNIP is specified, the report
#                  will be sent in its entirety.
#                 
##############################################################################

use strict;
use File::Path;
use File::Copy;

# Constants
my $logFileRootDirectory = "/irb/bce/admin/log";
my $batch_update_web_dir = "$logFileRootDirectory/batch_job_data";
my $sambaPath = "\\\\pelican.emea.convergys.com\\bce\\admin\\log";
my $httpPath = "log";
my $mime_boundary = "----=_NextPart_000_0019_01BEA766.A2582120";
my $targetEmail = "Pavan.Vuppala\@netcracker.com,sridhar.davuluru\@netcracker.com,arun.kumar.kulkarni\@netcracker.com,ranjith.kumar.gajula\@netcracker.com,reshma.goud.ireni\@netcracker.com,ravi.katepally\@netcracker.com,tulasi.jagabandu\@netcracker.com";
my $index_php_location="/irb/bce/admin/ccm_wa/BUILDWEB-bce/BUILDWEB/build_logs";

# Snipping maximums
my $maxLogEntry = 10; # should be an even number
my $maxSQLEntry = 30;

# Rule types
my $reportLines = 0;
my $reportRange = 1;
my $doNothing = 2;
my $executePerl = 3;
my $head = 4;
my $body = 5;
my $ignoreOraErr = 6;

# File names elements and locations
my $workDir; 
my $logDate;
my $makeFilename;
my $makeLogFileName;
my $reconfigureLogFileName;
my $platform;
my $platformOther;
my $oracleVersion;
my $genevaDir;
my $majorVersion;
my @dates;
my $ccmProjectName;
my $ccmProject;
my $fullPlatform;
my $fullVersion;
my $projectState;

# Working data for log file
my $textLine;
my $lastCompilerCall = 0;
my $lastSqlplusCall = 0;
my $lastShowErrors = 0;
my $lastWrapperError = 0;
my $lastLinkerError = 0;
my @lineList;

# The log file(s)
my @logList;

# The build and reconfigure reports. The number of errors/warnings found is
# in the first element of the array.
my @buildReport = (0);
my @warningReport = (0);
my @reconfigureReport = (0);

# Time stamps
my $buildStartTime = "unknown";
my $buildFinishTime = "unknown";

# Sequence Numbers
my $manifest_seq_number = "";

# Disk space
my $diskAvailableMB = 0;
my $diskTotalMB = 0;
my $diskAvailablePct = 0;
my $diskAvailablePctThreshold = 10;

# Root Directory to Dump HTML pages to
my $html_directory="$logFileRootDirectory/build_logs_html";


# Rules

# The rules consist of:
# (1) a regular expression without the / / delimiters;
# (2) a brief description of what the rule is testing for;
# (3) a value of $reportLines, $reportRange, $doNothing, $executePerl,
#     $head, $body or $ignoreOraErr saying what type of action is required;
# (4) appropriate arguments given (3).
# Note that $lineNum is the current line in the log, and the regular
# expressions are tested in the order given. If a particular pattern
# is likely to occur very regularly, it should go near the top
# of the list.

my @reconfigureRules =
    ( ['^WARNING: No candidates found', 'No candidates',
              $reportLines, '$lineNum'],

      ['Parallel versions', 'Parallel versions', $reportRange, '$lineNum', '$lineNum+2'],

      ['Reconfigure failed', 'Reconfigure failed',
              $reportLines, '$lineNum'],

      ['No selection available for directory entry', 'No selection',
              $reportLines, '$lineNum'],

      ['Failed to unuse selected object', 'Failed unuse',
              $reportLines, '$lineNum'],

      ['Failed to use selected object', 'Failed use',
              $reportLines, '$lineNum'],

      ['^Warning:', 'General warning',
              $reportLines, '$lineNum'],

      ['manifest_seq_number=(.*)',
              'Manifest Number', $executePerl,
	       '$manifest_seq_number = &seqNumber;']
    );

my @warningRules =
    ( [': warning: ', 'warning', $reportLines, '$lineNum'],

      [' \(W\) ', 'warning', $reportLines, '$lineNum']
    );

my @buildRules =
    ( ['^gcc -c', 'CC call', $executePerl, '$lastCompilerCall = $lineNum;'],

      ['TRACE_', 'Error ignored', $doNothing],

      ['^gcc -shared', 'CC call', $executePerl, '$lastCompilerCall = $lineNum;'],

      ['^cc ', 'CC call', $executePerl, '$lastCompilerCall = $lineNum;'],

      ['^sqlplus(.*)show_errors.sql',
              'Show errors call', $executePerl, '$lastShowErrors = $lineNum;'],

      # Note that this line is incomplete, as the rule needs to be platform
      # specific. It is completed in code below. If any rules are inserted
      # above this one, the code needs to be changed.
      ['^g?make(.*): \*\*\* \[(.*)\.o\] Error', 'Problem producing .o'],

      ['^Error \d*: ', 'C Error', $reportLines, '$lineNum'],

      [': undefined reference to ', 'C Error', $reportLines, '$lineNum'],

      ['Duplicate message', 'Message Error', $reportLines, '$lineNum'],
      
      ['\d* \(S\) ', 'C Error', $reportLines, '$lineNum'],

      ['Out of memory', 'Machine Error', $reportRange, '$lineNum', '$lineNum+1'],

      ['cannot find symbol', 'Symbol Error', $reportRange, '$lineNum', '$lineNum+1'],

      ['line \d*: [Ee]rror', 'C Error', $reportLines, '$lineNum'],
      
      ['^g?make(.*): \*\*\* \[(.*)\.(ALLEXE|LIB|EXE)\] Error',
              'Problem producing lib/exe', $reportLines, '$lineNum'],

      ['^g?make\[1\]: \*\*\* \[(.*)\.(PLSQL|INC)\] Error',
              'Problem producing db code', $reportLines, '$lineNum'],

      ['^g?make(.*): \*\*\* \[(.*)\.c\] Error',
              'Problem producing C from ProC', $reportLines,
              '$lineNum-1', '$lineNum'],

      ['^g?make(.*): \*\*\* \[(.*)/bin/(\w)*\] Error',
              'Problem linking binary', $reportLines, '$lineNum'],
 
      ['^g?make\[\d*\]: \*\*\* \[(\w)*\] Error',
              'Problem linking binary', $reportLines, '$lineNum'],

      ['^g?make(.*): \*\*\* \[(.*)\.(.*)\] Error',
              'Miscellaneous make error', $reportRange,
              '$lineNum-2', '$lineNum'],

      ['[Ee]rror(.*)ignored', 'Error ignored', $doNothing],

      ['Error Test Driver', 'Error ignored', $doNothing],

      ['Error Messages raised by this package', 'Ignore', $doNothing],

      ['[Ee]rror(.*)in file (.*)\.pc$', 'ProC error', $reportLines,
              '$lineNum', '$lineNum+3'],

      ['^sqlplus', 'Sqlplus call',
              $executePerl, '$lastSqlplusCall = $lineNum;'],

      ['^create', 'Sqlplus call',
              $executePerl, '$lastSqlplusCall = $lineNum;'],

      ['ERROR at line ', 'Oracle error', $head, '$lastSqlplusCall'],

      ['^ORA-01917', 'Oracle error', $ignoreOraErr],

      ['^ORA-01918', 'Oracle error', $ignoreOraErr],

      ['^ORA-01919', 'Oracle error', $ignoreOraErr],

      ['^ORA-04020', 'Oracle error', $ignoreOraErr],

      ['^ORA-\d{5}', 'Oracle error', $body],

      ['cserr\s.*Error\s', 'Error ignored', $doNothing],
 
      ['Tout', 'Error ignored', $doNothing],

      ['\sError\s', 'Error', $reportLines, '$lineNum'],

      ['cc: (Error|Severe):', 'CC error', $reportLines, '$lineNum'],

      ['[Nn]o rule', 'No rule', $reportLines, '$lineNum'],

      ['Package Body created with compilation errors',
              'Package compilation errors', $reportLines,
	       '$lineNum-2', '$lineNum'],

      ['NAME(.*)TEXT',
              'Start of show_errors.sql log',
	       $executePerl, '&showErrorsLog($lineNum);'],

      ['Wrapper error',
              'Wrapper error', $executePerl,
	       '$lastWrapperError = $lineNum;'],

      ['Outputting source and continuing',
              'End of wrapper error', $reportRange,
	       '$lastWrapperError', '$lineNum-1'],

      ['because of errors', 'Errors found', $reportLines, '$lineNum'],

      ['ld: Unsatisfied symbols:', 'Linker error 1', $head],

      ['ld: 0711-224 WARNING:' , 'Duplicate symbol:', $doNothing ],

      ['ld: fatal:', 'Linker error 1', $reportRange, '$lineNum-3', '$lineNum'],

      ['^   (\w)* \(code\)$', 'Linker error 1', $body],

      ['^Fatal:', 'Fatal Error', $reportLines, '$lineNum'],

      ['No Databases Available', 'Database Errors', $reportLines, '$lineNum'],

      ['ld: [^ ]* [^(WARNING: Duplicate symbol:)|(\(Warning\) Unsatisfied symbol \"static time_it::operator new\(unsigned long\)\")|(See the loadmap file make_log for more information)]', 'Linker error 2', $reportLines, '$lineNum', '$lineNum+1'],

#      ['^Error running script', 'Schema installation error', $reportRange, '$lineNum', '$lineNum+3'],

      ['^Build of (.*) aborted because there is a failed Reconfigure flag in the log directory', 'Reconfigure Failed',
             $reportLines, '$lineNum' ],

      ['^Build of (.*) aborted because a time out occured whilst waiting for reconfigure', 'Reconfigure Failed', $reportLines, '$lineNum'],

      ['check_auto_gen_build_objs', 'AUTOGEN Errors', $reportLines, '$lineNum'],

      ['error at line', 'java Error', $reportLines, '$lineNum'],

      ['[Ee]rror:', 'java Error', $reportLines, '$lineNum'],

      ['BUILD FAILED', 'java Error', $reportLines, '$lineNum'],

      ['had error', 'java Error', $reportLines, '$lineNum'],
      
      ['[Ee]rror: file', 'java Error', $reportLines, '$lineNum'],

      ['^ERROR: No compiled jar files could be found for testing.', 'java Error', $reportLines, '$lineNum'],

      ['Build started: (.*)',
               'Build started', $executePerl,
	       '$buildStartTime = &logTime if $buildStartTime eq "unknown";'],

      ['Build finished: (.*)',
              'Build finished', $executePerl,
	       '$buildFinishTime = &logTime;']
    );


# Start
{
    $makeLogFileName = $ARGV[0]
	or die "Usage: perl check_overnight_builds.pl " .
	    "<make_log_file_name> [yyyymmdd] [NOSNIP]\n";

    # Determine whether there is a NOSNIP flag
    if ($ARGV[$#ARGV] eq 'NOSNIP')
    {
	print "Will not snip entries.\n";
	$maxLogEntry = 9_999_999_998; # a large even number
	$maxSQLEntry = 9_999_999_999; # a large number
    }

    # Determing working directory
    if ( $makeLogFileName =~ /(.*)(20\d{6})(.*)\/([^\/]*)/ )
    {
	$workDir = "$1$2$3";
	$logDate = $2;
	$makeLogFileName = $4;
    }
    else
    {
	chdir($logFileRootDirectory)
	    or die "Cannot cd to /irb/bce/admin/log ($!)";

	# Determine the log date to use
	if (defined $ARGV[1])
	{
	    $logDate = $ARGV[1];
	    print ("Using given log date: $logDate\n");
	}
	else
	{
	    @dates = <20*>;
	    $logDate = (sort { $a <=> $b } @dates)[-1];
	    print ("Most recent log date is $logDate\n");
	}
	
	$workDir = "$logFileRootDirectory/$logDate";
    }

    chdir("$workDir") or die "Cannot cd to $workDir ($!)";
    print("Looking in directory $workDir\n");
    my $lognameFormat;
    my $lognameFormat_for_GENEVAAPI;

    $lognameFormat_for_GENEVAAPI="^make_" .  
                            "([A-Z]*)_" .
	                    "(sqa|rsqa|test|int|dev|cov|mul|conts|contd|lint|mem)" .
	                    "(\\d+ \\. \\d+[INTS]*)" .
	                    "( (\\. \\w+)*| )" .
	                    "_(all|clean|dbuser|dbcrtlog) \\. log \$";

	$lognameFormat_for_GENEVAAPI="^make_" .  
						"([A-Z]*)_" .
					"(sqa|rsqa|test|int|dev|cov|mul|conts|contd|lint|mem)" .
					"(\\d+ \\. \\d+[INTS]*)" .
					"( (\\. \\w+)*| )" .
					"_(all|clean|dbuser|dbcrtlog)(_)*(rtests|release)* \\. log \$";

    $lognameFormat="^make_" .
                            "([A-Z]*)_" .
	                    "(sqa|rsqa|test|int|dev|cov|mul|conts|contd|lint|mem)" .
	                    "(\\d+ \\. \\d+[INTS]*)" .
	                    "( (\\. \\w+)* )" .
	                    "( \\. )" .
	                    "(solaris|solaris32|sol|aix|hp|hp64|tru64|linux|suselinux|linux32|itanium)" .
	                    "( \\. )" .
	                    "(oracle| )" .
	                    "(7|8|8i|9i|9i2|10g|11g|12c|at)" .
	                    "_(all|clean|2dbuser|dbcrtlog) \\. log \$";
	                    
    if ($makeLogFileName =~ m/$lognameFormat/x)
    {
	($ccmProject, $platform, $oracleVersion, $majorVersion,
	 $genevaDir, $reconfigureLogFileName, $fullPlatform, $fullVersion, $projectState, $platformOther)
	    = ($1, $7, $10, $3, "$1-$2$3$4$6$7$8$9$10",
	       "reconfigure-$1-$2$3$4$6$7$8$9$10", "$7$8$9$10", "$3$4", "$2", "$9$10");

	$ccmProjectName="$1-$2$3$4$6$7$8$9$10";
    }
    elsif ($makeLogFileName =~ m/$lognameFormat_for_GENEVAAPI/x)
    {
		if ( "$1" eq "GENEVAAPI" ) {
			($ccmProject, $platform, $oracleVersion, $majorVersion, $genevaDir, $reconfigureLogFileName, $fullPlatform, $fullVersion, $projectState, $platformOther)
			= ($1, "web", "9i2", $3, "$1-$2$3$4", "reconfigure-$1-$2$3$4", "web", "$3$4", "$2", "");

		} elsif ( "$1" eq "RBAPI" ) {
			if ( "$8" eq "rtests" ) {
				($ccmProject, $platform, $oracleVersion, $majorVersion, $genevaDir, $reconfigureLogFileName, $fullPlatform, $fullVersion, $projectState, $platformOther)
				= ($1, "web(rtests)", "10g", $3, "$1-$2$3$4", "reconfigure-$1-$2$3$4", "web", "$3$4", "$2", "oracle10g");
			} elsif ( "$8" eq "release" ) {
				($ccmProject, $platform, $oracleVersion, $majorVersion, $genevaDir, $reconfigureLogFileName, $fullPlatform, $fullVersion, $projectState, $platformOther)
				= ($1, "web(release)", "10g", $3, "$1-$2$3$4", "reconfigure-$1-$2$3$4", "web", "$3$4", "$2", "oracle10g");
			} else {
				($ccmProject, $platform, $oracleVersion, $majorVersion, $genevaDir, $reconfigureLogFileName, $fullPlatform, $fullVersion, $projectState, $platformOther)
				= ($1, "web", "10g", $3, "$1-$2$3$4", "reconfigure-$1-$2$3$4", "web", "$3$4", "$2", "oracle10g");
			}
		}

		$ccmProjectName="$1-$2$3$4";
    }
    else
    {
	($platform, $oracleVersion, $majorVersion,
	 $genevaDir, $reconfigureLogFileName)
	    = ('', '', '', '', '');

	print "Warning: make log file $makeLogFileName is not of ".
	    "the expected form.\n";
	print "The reconfigure report will not be created.\n";
    }

    # Platform specific code - changes the "problem making an .o file" rule
    if ($platform eq 'tru64')
    {
	push @{ $buildRules[3] }, $reportLines, '$lineNum';
    }
    else
    {
	push @{ $buildRules[3] }, $reportRange,
	'$lastCompilerCall+1', '$lineNum';
    }

    print "Checking $makeLogFileName for build problems\n";

    $" = "";

    open (MAKEFILELOG, "$makeLogFileName")
	or die "Cannot open input file $makeLogFileName ($!)";
    @logList = <MAKEFILELOG>;
    close (MAKEFILELOG) or die "Cannot close input file $makeLogFileName ($!)";

    $lastCompilerCall = 0;
    $lastShowErrors = 0;

    produceReport (\@buildReport, @buildRules);
    produceReport (\@warningReport, @warningRules);

    if (open (RECONFIGFILELOG, "$reconfigureLogFileName"))
    {

	@logList = <RECONFIGFILELOG>;
	close (RECONFIGFILELOG)
	    or die "Cannot close input file $reconfigureLogFileName ($!)";

	printf("Checking $reconfigureLogFileName for reconfigure problems\n");

	produceReport (\@reconfigureReport, @reconfigureRules);

    }
    else
    {
	print "Warning: could not open reconfigure log file " .
	    "$reconfigureLogFileName\n";
	$reconfigureLogFileName = '';
    }

    # Find disk usage for /irb/bce directory
    if (open DISKINFO, "df -k /irb/bce |")
    {
	while (<DISKINFO>)
	{
	    if ( m{(\d+)\s+(\d+)\s+(\d+)\s+(\d+)%\s+/irb/bce} )
	    {
		($diskTotalMB, $diskAvailableMB, $diskAvailablePct) =
		    (int($1/1024), int($3/1024), 100-$4);
#		last;
	    }
	}
	close DISKINFO;
    }
    else
    {
        print "Warning: could not run df\n";
    }

    my $hostname;
    my $dbsid;
    $hostname=`hostname`;
    chomp($hostname);

    if (defined ($ENV{"dbsid"}))
    {
        $dbsid="$ENV{'dbsid'}";
    }
    else
    {
        $dbsid=" ";
    }
    chomp($dbsid);

    # Open an File connection
   
    my $log_sub_dir="$ccmProject/$fullVersion/$projectState/$fullPlatform";
    my $log_directory="$html_directory/$log_sub_dir";
    my @dirs_created=mkpath ("$log_directory",1, 0777);
    my $dir_created;
    foreach $dir_created (@dirs_created)
    {
    	copy ("$index_php_location/index.php","$dir_created")
    }

    my $buildErrors=$buildReport[0];
    my $warningErrors=$warningReport[0];
    my $reconfigureErrors=$reconfigureReport[0];

    my $finishTime=$buildFinishTime;
    my $month="";
    if ($finishTime =~ /unknown/ )
    {
	$finishTime="${logDate}000000";
    }
    else
    {
	#$finishTime=~s/.* (\d+):(\d+):(\d+) .*/$1$2$3/;
	if ($finishTime =~ m/\w+ (\w+) (\d+) (\d+):(\d+):(\d+) +[a-zA-Z0-9+:]+ (\d+)/)
	{
		$month=$1;
		SWITCH: {
			$month eq "Jan" && do { $month = "01"; last SWITCH; };
			$month eq "Feb" && do { $month = "02"; last SWITCH; };
			$month eq "Mar" && do { $month = "03"; last SWITCH; };
			$month eq "Apr" && do { $month = "04"; last SWITCH; };
			$month eq "May" && do { $month = "05"; last SWITCH; };
			$month eq "Jun" && do { $month = "06"; last SWITCH; };
			$month eq "Jul" && do { $month = "07"; last SWITCH; };
			$month eq "Aug" && do { $month = "08"; last SWITCH; };
			$month eq "Sep" && do { $month = "09"; last SWITCH; };
			$month eq "Oct" && do { $month = "10"; last SWITCH; };
			$month eq "Nov" && do { $month = "11"; last SWITCH; };
			$month eq "Dec" && do { $month = "12"; last SWITCH; };
		}
		my $time="$3$4$5";
		my $year="$6";
		my $day=$2;
		$day =~ s/^(\d)$/0$1/;
		$finishTime="${year}${month}${day}${time}";
	}
	else
	{
		print "Error: Error Parsing finishTime: $finishTime\n";
	}
    }
    $month="";

    my $startTime=$buildStartTime;
    if ($startTime =~ /unknown/ )
    {
	$startTime="${logDate}000000";
    }
    else
    {
	#$startTime=~s/.* (\d+):(\d+):(\d+) .*/$1$2$3/;
	if ($startTime =~ m/\w+ +(\w+) +(\d+) +(\d+):(\d+):(\d+) +[a-zA-Z0-9+:]+ +(\d+)/)
	{
		$month=$1;
		SWITCH: {
			$month eq "Jan" && do { $month = "01"; last SWITCH; };
			$month eq "Feb" && do { $month = "02"; last SWITCH; };
			$month eq "Mar" && do { $month = "03"; last SWITCH; };
			$month eq "Apr" && do { $month = "04"; last SWITCH; };
			$month eq "May" && do { $month = "05"; last SWITCH; };
			$month eq "Jun" && do { $month = "06"; last SWITCH; };
			$month eq "Jul" && do { $month = "07"; last SWITCH; };
			$month eq "Aug" && do { $month = "08"; last SWITCH; };
			$month eq "Sep" && do { $month = "09"; last SWITCH; };
			$month eq "Oct" && do { $month = "10"; last SWITCH; };
			$month eq "Nov" && do { $month = "11"; last SWITCH; };
			$month eq "Dec" && do { $month = "12"; last SWITCH; };
		}
		my $time="$3$4$5";
		my $year="$6";
		my $day=$2;
		$day =~ s/^(\d)$/0$1/;
		$startTime="${year}${month}${day}${time}";
	}
	else
	{
		print "Error: Error Parsing startTime: -$startTime-\n";
		exit 1;
	}
    }
    

    my $htmlFile="${logDate}${finishTime}_${buildErrors}_${reconfigureErrors}.html";

    print "build_results;$ccmProject;$fullVersion;$startTime;$finishTime;$projectState;$platform;$reconfigureErrors;$buildErrors;$warningErrors;../build_logs/logs/$log_sub_dir/$htmlFile;$platformOther;;;$hostname;$dbsid;$manifest_seq_number\n";
    open (WEBUPDATE, ">$batch_update_web_dir/$ccmProject$projectState$platform$platformOther$fullVersion$startTime");
    select WEBUPDATE;

	if ( $ccmProject =~ /API/ ) {
		print "build_results;$ccmProject;$fullVersion;$startTime;$finishTime;$projectState;$platform;$reconfigureErrors;$buildErrors;$warningErrors;../build_logs/logs/$log_sub_dir/$htmlFile;$platformOther;12;0;$hostname;$dbsid;$manifest_seq_number\n";
	} else {
		print "build_results;$ccmProject;$fullVersion;$startTime;$finishTime;$projectState;$platform;$reconfigureErrors;$buildErrors;$warningErrors;../build_logs/logs/$log_sub_dir/$htmlFile;$platformOther;;;$hostname;$dbsid;$manifest_seq_number\n";
	}

    close WEBUPDATE;
 
    open (MAIL, ">$log_directory/${htmlFile}");
    select MAIL;

    
    # HTML header
    print "<HTML>\n<HEAD>\n";
    print "<link rel=  \"stylesheet\" type=  \"text/css\" " .
	"href=  \"http://intranet/stylesheets/housestyle.css\">\n";
    print "<link rel=  \"stylesheet\" type=  \"text/css\" " .
	"href=  \"http://intranet/stylesheets/pr.css\">\n";
    print "</HEAD>\n";
    
    # HTML body
    print "<BODY>\n";
    $logDate =~ /(\d{4})(\d{2})(\d{2})/;
    print "<P><H1>Reports for $3/$2/$1</H1></P>\n";

    print "<P><A HREF=\"#Build\">Build report</A> - " .
	     "<A HREF=\"#Reconfigure\">Reconfigure report</A> - " .
    	     "<A HREF=\"#Warning\">Build Warnings report</A> - " .
	     "<A HREF=\"#Deliverables\">Deliverables report</A></P>\n";

    print "<P>Build start time: $buildStartTime<BR>\n";
    print "Build finish time: $buildFinishTime\n";
    if ($diskTotalMB > 0)
    {
	my $openTag = "";
	my $closeTag = "";

	print "<BR>Disk space available in /irb/bce: ";

	# If disk space is short, alert by rendering in bold
	if ($diskAvailablePct <= $diskAvailablePctThreshold)
	{
	    $openTag = "<B>";
	    $closeTag = "</B>";
	}

	print "$openTag $diskAvailableMB MB out of $diskTotalMB MB " .
	    "($diskAvailablePct\%) $closeTag";

    }
    print "</P>\n";

    # Build report
    print "<P><H2><A NAME=\"Build\">Build report " .
	"($makeLogFileName)</A></H2></P>\n";
    print "<P><A HREF=\"http:\\$httpPath\\$logDate\\$makeLogFileName\">";
    print "Original make log file</A></P>\n";
    print "<P>Number of build errors found: $buildReport[0]</P>\n";
    shift @buildReport;
    print "<P><UL>\n@buildReport\n</UL></P>\n";

    # Reconfigure report
    print "<P><H2><A NAME=\"Reconfigure\">Reconfigure report";
	
    if ($reconfigureLogFileName eq '')
    {
	print "</A></H2></P>\n";
	print "<P>Could not open a reconfigure report. ($reconfigureLogFileName)</P>\n";
    }
    else
    {
	print " ($reconfigureLogFileName)</A></H2></P>\n";
	print "<P><A HREF=\"file://$sambaPath\\$logDate\\" .
	    "$reconfigureLogFileName\">";
	print "Original reconfigure log file</A></P>\n";
	print "<P>Number of reconfigure warnings found: " .
	    "$reconfigureReport[0]</P>\n";
	shift @reconfigureReport ;
	print "<P><UL>\n@reconfigureReport\n</UL></P>\n";
    }

    # Warning report
    print "<P><H2><A NAME=\"Warning\">Build Warnings report " .
	"($makeLogFileName)</A></H2></P>\n";
    print "<P><A HREF=\"file://$sambaPath\\$logDate\\$makeLogFileName\">";
    print "Original make log file</A></P>\n";
    print "<P>Number of build warnings found: $warningReport[0]</P>\n";
    shift @warningReport;
    print "<P><UL>\n@warningReport\n</UL></P>\n";

    # Deliverables report
    print "<P><H2><A NAME=\"Deliverables\">Deliverables report" .
        "</A></H2></P>\n";

    my $ccmPath;
    my $bin_loc="";
    my $smallCcmProject=$ccmProject;
    $smallCcmProject = lc($smallCcmProject);

    if ( "$ccmProject" eq "GENEVA" )
    {
	$ccmPath="/irb/bce/build/geneva/$majorVersion/$genevaDir/GENEVA";
    }
    elsif ( "$ccmProject" eq "RB" )
    {
	$ccmPath="/irb/bce/build/$smallCcmProject/$majorVersion/$genevaDir/$ccmProject";
    }
    elsif ( "$ccmProject" eq "GENEVAAPI" )
    {
	$ccmPath="/irb/bce/build/web/$genevaDir/$ccmProject";
	$bin_loc=`. web_functions.sh; getBuildArgs $ccmProject $projectState; echo \$jarloc"`;
	$bin_loc=$bin_loc . "/*";
	$bin_loc=~s/\s//g;
    }
    else
    {
	$ccmPath="/irb/bce/build/$smallCcmProject/$majorVersion/$genevaDir/$ccmProject";
    }

    print "Listing deliverables from: $ccmPath\n";

    if (chdir("$ccmPath") &&
        open BINDIR, "ls -al bin/* lib/* ALLBATCH/bin/* ALLBATCH/lib/*.so ALLBATCH/lib/*.sl ALLBATCH/java/* sql/all* mess/*/* prod/lib/* prod/bin/* build_release_all/distrib/external/jar $bin_loc |")
    {
        print "<PRE>\n";
        while (<BINDIR>)
        {
            print;
        }
        close BINDIR;
        print "</PRE>\n";
    }
    else
    {
        print "<P>Could not list Deliverables.</P>\n";
    }

    # Footer
    print "</BODY></HTML>\n";

    close MAIL;

    # Open an email connection and make it default output
    open (MAIL, "| /usr/lib/sendmail $targetEmail");
    open (MYFILE, "<$log_directory/$htmlFile");
    select MAIL;
    # Sendmail header

    print "From: \"Geneva Admin\" <pdm.geneva.bce.admin\@convergys.com>\n";
    print "To: ravi.katepally\@netcracker.com,sridhar.davuluru\@netcracker.com;arun.kumar.kulkarni\@netcracker.com;ranjith.kumar.gajula\@netcracker.com;reshma.goud.ireni\@netcracker.com;tulasi.jagabandu\@netcracker.com;ravi.katepally\@netcracker.com;\n";
    print "Subject: $logDate: Build: $ccmProjectName <$buildErrors/$reconfigureErrors> [$hostname - $dbsid]\n";
    print "MIME-Version: 1.0\n";
    print "Content-Type: multipart/alternative;\n";
    print "        boundary=\"$mime_boundary\"\n";
    print "\n";

    # MIME header
    print "This is a multi-part message in MIME format.\n";
    print "\n";
    print "--$mime_boundary\n";
    print "Content-Type: text/html;\n";
    print "        charset=\"iso-8859-1\"\n";
    print "Content-Transfer-Encoding: quoted-printable\n";
    print "\n";

    # Body
    my @file = <MYFILE>;
    print MAIL "@file";

    # Footer
    print "\n--$mime_boundary--\n\n";

    close MYFILE;
    close MAIL;
 

    exit 0;
}


#############################################################################
#
# Function name:   produceReport
#
# Description:     This subroutine analyses @logList using the rules given
#                  in the list passed to it, and adds them to the report
#                  passed.
#
# Returns:         none
#
sub produceReport
{
    my $reportRef;
    my @rules;

    my @currentList = ();
    my $currentRuleName = "none"; 

    my @regExps;
    my $regExpFunction;
    my @regExpResult;
    my $regExpNum;
    my $regExpRef;

    my $lineNum = 0;

    ($reportRef, @rules) = @_;

    @regExps = ();
    foreach $regExpRef (@rules)
    {
	push @regExps, $$regExpRef[0];
    }
    $regExpFunction = buildRegExp(@regExps);

    foreach $_ (@logList)
    {
	@regExpResult = &$regExpFunction;

	for ($regExpNum = 0; $regExpNum<=$#regExpResult; $regExpNum++)
	{
	    if ($regExpResult[$regExpNum])
	    {
		my @ruleArgs = @{$rules[$regExpNum]};
		shift @ruleArgs;

		my $ruleDescription = shift @ruleArgs;
		my $ruleType = shift @ruleArgs;

		if ($#currentList > 0 &&
		    ($currentRuleName ne $ruleDescription || $ruleType != $body))
		{
			if ( $ruleType == 6 ) {
				if ( $#currentList > 1 ) {
					&errorReport($reportRef, @currentList);
					@currentList = ();
					$ruleDescription = 'none';				
				}
			}
			else
			{
				&errorReport($reportRef, @currentList);
				@currentList = ();
				$ruleDescription = 'none';	
			}
		}

		if ($ruleType == $reportLines)
		{
		    my $rangeLineNum;
		    my @rangeLineList = ();

		    foreach $rangeLineNum (@ruleArgs)
		    {
			push @rangeLineList, eval($rangeLineNum);
		    }
		    &errorReport($reportRef, @rangeLineList);
		}
		elsif ($ruleType == $reportRange)
		{
		    my $rangeTop = eval (shift @ruleArgs);
		    my $rangeBottom = eval (shift @ruleArgs);

		    if ($rangeBottom - $rangeTop + 1 > $maxLogEntry)
		    {
			my $linesSnipped;

			$linesSnipped = $rangeBottom - $rangeTop
			    - $maxLogEntry + 1;

			&errorReport($reportRef,
				     ($rangeTop ..
				      $rangeTop + $maxLogEntry/2 - 1),
				     "... $linesSnipped lines snipped ...<BR>",
				     ($rangeBottom - $maxLogEntry/2 + 1 ..
				      $rangeBottom));
		    }
		    else

		    {
			&errorReport($reportRef, ($rangeTop .. $rangeBottom));
		    }
		}
		elsif ($ruleType == $executePerl)
		{
		    eval ( shift @ruleArgs );
		}
		elsif ($ruleType == $head)
		{
		    my $rangeLineNum;

		    @currentList = ();
		    foreach $rangeLineNum (@ruleArgs)
		    {
			push @currentList, eval $rangeLineNum;
		    }
		    push @currentList, $lineNum;
		    $currentRuleName = $ruleDescription;
		}
		elsif ($ruleType == $body)
		{
		    push @currentList, $lineNum;
		    $currentRuleName = $ruleDescription;
		}
		elsif ($ruleType == $ignoreOraErr) {
		    # (ajh)
		    # Ignore an Oracle error
		    #
		    # Oracle errors are of the form:
		    #   ERROR at line n:
		    #   ORA-xxxxxx: error text
		    #
		    # By the time the error code has been matched as one that
		    # should be ignored, the original ERROR line would have
		    # already made it into the report. Pop off lines from the
		    # report until a list item start element is found, and then
		    # decrement the error total (first element of the report
		    # arrayref)

			if ( $$reportRef[0] > 1 ) {
				my $element = "";

			    do { $element = pop @$reportRef; }
			    until ($element =~ /^<LI>$/ || @$reportRef == 1);

	 		    $$reportRef[0]--;					
			}

		    @currentList = ();
		    $currentRuleName = 'none';

		}

		last;
	    }
	}

	$lineNum++;
    }
}

#############################################################################
#
# Function name:   errorReport
#
# Description:     Given a reference to a report and a list of instructions
#                  describing an error, this function adds the error to the
#                  report. The instructions are either line numbers
#                  (e.g. the instruction '6' will add line 6 of the
#                  log to the report) or HTML markup strings (e.g. the
#                  instruction '<PRE>' inserts a <PRE> tag into the report).
#
# Returns:         none
#
sub errorReport
{
    my $lineInstruction;
    my $textLine;
    my ($reportRef, @lineInstructionList) = @_;

    push @$reportRef, "<LI>";

    foreach $lineInstruction (@lineInstructionList)
    {
	# Is the instruction an integer?
	if ($lineInstruction =~ /^\d+$/)
	{
	    # Convert '<', '>' and '"' to the corresponding HTML codes
	    $textLine = $logList[$lineInstruction];
	    $textLine =~ s#\<#\&lt\;#g;
	    $textLine =~ s#\>#\&gt\;#g;
	    $textLine =~ s#\"#\&quot\;#g;
	    $textLine =~ s#^  #\&nbsp\;\&nbsp\;\&nbsp\;#; 

	    push @$reportRef, "$textLine<BR>";
	}
	else
	{
	    push @$reportRef, $lineInstruction;
	}
    }
    
    push @$reportRef, "</LI>";
    $$reportRef[0]++;
    
    return;
}

#############################################################################
#
# Function name:   buildRegExp
#
# Description:     Given a list of regular expressions, constructs a
#                  function which executes each regular expression
#                  and returns a list of booleans giving the result
#                  of each one.
#
#                  See the Perl FAQ on regular expressions.
#
# Returns:         A reference to the function constructed
#
sub buildRegExp {
    my @regExp = @_;
    my $expression = join '*1, ' => map { "m/\$regExp[$_]/o" } (0..$#regExp);
    my $matchFunction = eval "sub { ($expression*1) }";
    die if $@; # propagate $@; this shouldn't happen!
    return $matchFunction;
}

#############################################################################
#
# Function name:   showErrorsLog
#
# Description:     Given the start of some show_errors.sql output, this
#                  function inserts appropriate HTML markup into the report.
#
# Returns:         None
#
sub showErrorsLog
{
    my $rangeLineNum;
    my $linesSnipped;
    my @lineList = ($lastShowErrors, '<PRE>');

    my ($lineNum) = @_;

    $linesSnipped = 0;

    for ($rangeLineNum = $lineNum; ; $rangeLineNum++)
    {
	if ($logList[$rangeLineNum] =~ /^[A-Z\s\-]/)
	{
	    if ($rangeLineNum >= $lineNum + $maxSQLEntry)
	    {
		$linesSnipped++;
	    }
	    else
	    {
		push @lineList, $rangeLineNum;
	    }
	}
	else
	{
	    last;
	}
    }

    push @lineList, '</PRE>';

    if ($linesSnipped > 0)
    {
	push @lineList, "... $linesSnipped lines snipped ...<BR>";
    }

    &errorReport(\@buildReport, @lineList);

    return;
}


#############################################################################
#
# Function name:   logTime
#
# Description:     Extracts the date and time from the current line
#
# Returns:         String containing the date and time found
#
sub logTime
{
    if (/^Build (start|finish)ed: (.*?)(Local time zone.*)?$/)
    {
	return $2;
    }
    else
    {
	return "Could not determine time";
    }
}

#############################################################################
#
# Function name:   logTime
#
# Description:     Extracts the date and time from the current line
#
# Returns:         String containing the date and time found
#
sub seqNumber
{
    if (/^manifest_seq_number=(.*?)$/)
    {
	return $1;
    }
    else
    {
	return "Could not determine sequence";
    }
}
