#/bin/sh
#set -x

die () {
    echo >&2 "$@"
    exit 1
}
usage=$"This script will update svn external properties for given SVN URL of project,\n\
$0 svn_uri\n\,
eg: https://svnca.netcracker.com/RB/branches/Patches/O2/O2_6.0.5.x/ (upto project name and including '/') \n\
"
[ "$#" -ge 1 ] || die "SVN URI is not provided. $usage"

SVNURL=$1
		cd /irb/bce/svn_nagidi
        . /home/geneva/pavu0613
		rm -rf .svn
svn co --depth=empty $SVNURL /irb/bce/svn_nagidi
projects=$(svn ls $SVNURL)
	echo "Project Directories are :"
	echo $projects | tr " " "\n"
		for i in $projects
		do
                        if [ "$i" = "RBAPI/" ] 
				then
				rm -rf .svn
                svn co --depth=empty ${SVNURL}${i} /irb/bce/svn_nagidi 
				svn propget svn:externals /irb/bce/svn_nagidi > rbapi_repo
cat > rbapi << EOF
${SVNURL}RB/SCHEMA SCHEMA
${SVNURL}RB/GNVUA GNVUA
${SVNURL}RB/APICAT APICAT
${SVNURL}RB/APICORE APICORE
${SVNURL}RB/APICUSTACC APICUSTACC
${SVNURL}RB/APISYSCONFIG APISYSCONFIG
${SVNURL}RB/CORE/BUILD CORE/BUILD
${SVNURL}RB/CORE/TOOL CORE/TOOL
EOF
				diff -B rbapi_repo rbapi > /dev/null
				if [ $? -eq 1 ]; then
  				  echo "RBAPI properties are different,So update is required"
					svn propdel svn:externals /irb/bce/svn_nagidi
					svn propset svn:externals -F rbapi /irb/bce/svn_nagidi
					svn ci -m "updating properties for RBAPI RBM-78794"			
				else
				    echo "update is not required since RBPAI properties are same"
				fi				
				rm -rf rbapi_repo rbapi .svn
				
                        fi

			if [ "$i" = "WIN/" ]
                                  then
					rm -rf .svn
                                        svn co --depth=empty ${SVNURL}${i} /irb/bce/svn_nagidi
					svn propget svn:externals /irb/bce/svn_nagidi > win_repo
cat > win << EOF
${SVNURL}RB/REPORTS REPORTS
EOF
				#cat win_repo
				#cat win
				diff -B win_repo win > /dev/null
                                if [ $? -eq 1 ]; then
                                  echo "WIN Properties are different ,So update is required"
                                        svn propdel svn:externals /irb/bce/svn_nagidi
                                        svn propset svn:externals -F win /irb/bce/svn_nagidi
                                        svn ci -m "updating properties for WIN  RBM-78794"
                                else
                                    echo "update is not required since WIN Properties are same"
                                fi
                                rm -rf win_repo win .svn

					svn co --depth=empty ${SVNURL}${i}PC/REPOSITORY/SRC /irb/bce/svn_nagidi
					svn up genevamessages.txt
						if [ -f genevamessages.txt ]
	                                        then
						echo "Found genevamessages.txt files in SRC..removing it"
        	                                svn rm genevamessages.txt
                	                        fi

					svn propget svn:externals /irb/bce/svn_nagidi > src_repo
cat > src << EOF
${SVNURL}RB/APICORE/genevamessages.txt genevamessages.txt
EOF
				diff -B src_repo src > /dev/null
                                if [ $? -eq 1 ]; then
                                  echo "SRC properties are different,So update is required"
                                        svn propdel svn:externals /irb/bce/svn_nagidi
                                        svn propset svn:externals -F src /irb/bce/svn_nagidi
					svn ci -m "updating properties for WIN/PC/REPOSITORY/SRC/geneavemessages.txt  RBM-78794"
                                else
                                    echo "update is not required since SRC Properties are same"
                                fi
                                rm -rf src_repo src .svn

                                fi

done

