#! /usr/bin/ksh

###########################################################################################
#
#     Set up Constants
#
###########################################################################################

. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh
#. ${BCE_BUILD_SCRIPTS}/ccm_functions.sh
#. ${BCE_BUILD_SCRIPTS}/core_functions.sh
#. ${BCE_BUILD_SCRIPTS}/buildweb_functions.sh

BUILDWEB_DB=`buildweb_connection`
default_time=19990101010101
input_end_time=$default_time
input_export_time=$default_time
input_archive_time=$default_time
input_iso_time=$default_time
input_release_time=$default_time
input_prep_co_time=$default_time
BCE_LOG="/irb/bce/admin/log"

email() 
{
	log="$BCE_LOG/das_threshold_log.txt"
	SUBJ="DAS - Database Allocation about to Expire = $3"
	TO=$1
	CC=$4
	db=$3
	word="$1"" $2"
	grep "$word" $log
	S=$?
	if [ $S -eq  0 ]; then
		echo "quittinggggg"
	
	else
		ext=`sqlplus -s $BUILDWEB_DB << +EOF
		SET FEED OFF
		SET HEAD OFF
		select e.EXTENSIONS from das_extra_data e where e.SID='$3';
		exit
		+END`


		param=`sqlplus -s $BUILDWEB_DB << +EOF
		SET FEED OFF
		SET HEAD OFF
		select PARAM_VALUE from das_params where PARAM_NAME='max number of extensions';
		exit
		+END`

		if [ $ext -lt $param ]; then
			
			contents="$2""  If you  need use of this DB beyond the set expiry  date you have the option to extend this booking by up to 30 days. This extension must happen before the expiry date else the booking will end and the DB will be reclaimed."

		else
			
			contents="$2""   You have already exercised the option to extend this booking hence it will expire on the said date. If you need use of this DB beyond the set expiry date please log a BCE request, explaining your need."


		fi
		#echo $contents
				
		echo "you will get a mail now"
		echo $1 $2 >> $log
 
(
cat << !
To : ${TO}
Subject : ${SUBJ}
Cc : ${CC}
!

cat << !
$contents
!
) | /usr/lib/sendmail  ${TO} ${CC}

	fi
}


usage()
{
	echo " "
	echo "You entered $0 $* "
	echo " "
	echo "Usage: $0"
	echo "  e.g. $0"
	echo " "
	exit_program 1
}

find_sqlhome 9.2.0.SE
if [ $? -ne 0 ]
then
	echo "$0: Error: Cannot find valid SQLPLUS"
	exit 1
fi


results=`sqlplus -s $BUILDWEB_DB << +EOF
SET FEED OFF
SET HEAD OFF
select d.LOCATION LOCATION,d.ORACLE_VERSION ORCALE_VERSION,l.FREE FREE,d.THRESHOLD THRESHOLD from lock_dbs_available l,das_allocate_threshold d where l.ORACLE_VERSION=d.ORACLE_VERSION AND l.FREE <= d.THRESHOLD;
exit
+END`
 
if [[ -n "$results" ]] ; then
	
SUBJ="DAS Thresholds Exceeded, can we have more of these databases???"
TO=vpulimam,rkok3587,shav0415
CC=vpulimam
(
cat << !
To : ${TO}
Subject : ${SUBJ}
Cc : ${CC}
!

cat << !
----------------------------------------------------------------------------------------------
LOCATION	         ORACLE_VERSION         	  FREE       THRESHOLD
----------------------------------------------------------------------------------------------
$results
!
) | /usr/lib/sendmail ${TO},${CC}

fi

file="/tmp/locks.txt"
#log="/tmp/logdb.txt"
id="/tmp/id.txt"
msg="/tmp/msg.txt"

dblocks=`sqlplus -s $BUILDWEB_DB << +EOF
SET FEED OFF
SET HEAD OFF
SELECT l.SID SID,l.EXPIRE_TIME EXPIRY,e.UNIX_ID UNIX_ID  FROM build_database_locks l,das_extra_data e WHERE l.SID=e.SID;
exit
+END`
(cat << !
$dblocks
!
) > $file

export day_21=$(date --date='-21 days ago' +%d-%b-%y)
export day_10=$(date --date='-10 days ago' +%d-%b-%y)
export day_5=$(date --date='-5 days ago' +%d-%b-%y)
export day_3=$(date --date='-3 days ago' +%d-%b-%y)
export day_1=$(date  --date='-1 day ago' +%d-%b-%y)

export day_21=`echo $day_21 | tr -s '[:lower:]' '[:upper:]'`
export day_10=`echo $day_10 | tr -s '[:lower:]' '[:upper:]'`
export day_5=`echo $day_5 | tr -s '[:lower:]' '[:upper:]'`
export day_3=`echo $day_3 | tr -s '[:lower:]' '[:upper:]'`
export day_1=`echo $day_1 | tr -s '[:lower:]' '[:upper:]'`


awk '{ ; if ($2==ENVIRON["day_1"]) print $1 " " $2 " " $3 }' $file > $id
if [[ -s $id ]] ; then
	{

	while IFS="    " read line
	do
		ln="/tmp/line.txt"
		echo $line > $ln
		msg=`awk < $ln ' { print $1 " is allocated to your id " $3 ". The expiry date is " $2 ". Expires Tomorrow" }' `
		
		db=`awk < $ln ' { ; print $1 }' `

		uid=`awk < $ln ' { ; print $3 }' `

		cc="vpulimam,rkok3587";
		
		if [[ -n "$uid" ]] ; then
		     	email $uid "$msg" $db $cc
		fi
	
	done 
	} < $id
fi

rm $id

awk '{ ; if ($2==ENVIRON["day_3"]) print $1 " " $2 " " $3 }' $file > $id
if [[ -s $id ]]; then
	{
	while IFS="    " read line
	do
		ln="/tmp/line.txt"
		echo $line > $ln
		msg=`awk < $ln ' { print $1 " is allocated to your id " $3 ". The expiry date is " $2 ". 3 Days to expire"}' `
		
		db=`awk < $ln ' { ; print $1 }' `

		uid=`awk < $ln ' { ; print $3 }' `
		
		cc="vpulimam,rkok3587";
		if [[ -n "$uid" ]] ; then
			echo $uid
			echo $msg
		
			email $uid "$msg" $db $cc
		fi
	
	done 
	} < $id
fi


rm $id

awk '{ ; if ($2==ENVIRON["day_5"]) print $1 " " $2 " " $3 }' $file > $id
if [[ -s $id ]]; then
	{
	while IFS="    " read line
	do
		ln="/tmp/line.txt"
		echo $line > $ln
		msg=`awk < $ln ' { print $1 " is allocated to your id " $3 ". The expiry date is " $2 ". 5 Days to expire"}' `
		
		db=`awk < $ln ' { ; print $1 }' `

		uid=`awk < $ln ' { ; print $3 }' `

		cc="vpulimam,rkok3587"
			
		if [[ -n "$uid" ]] ; then
			email $uid "$msg" $db $cc
		fi
	done 
	} < $id
fi

rm $id

awk '{ ; if ($2==ENVIRON["day_10"]) print $1 " " $2 " " $3 }' $file > $id
if [[ -s $id ]]; then
	{
	while IFS="    " read line
	do
		ln="/tmp/line.txt"
		echo $line > $ln
		msg=`awk < $ln ' { print $1 " is allocated to your id " $3 ". The expiry date is " $2 ". 10 Days to expire" }' `
		
		db=`awk < $ln ' { ; print $1 }' `

		uid=`awk < $ln ' { ; print $3 }' `

		cc="vpulimam,rkok3587"
		
		if [[ -n "$uid" ]] ; then
		email $uid "$msg" $db $cc
		fi
	done 
	} < $id
fi

rm $id

awk '{ ; if ($2==ENVIRON["day_21"]) print $1 " " $2 " " $3 }' $file > $id
if [[ -s $id ]]; then
	{
	while IFS="    " read line
	do
		ln="/tmp/line.txt"
		echo $line > $ln
		msg=`awk < $ln ' { print $1 " is allocated to your id " $3 ". The expiry date is " $2 ". 21 Days to expire" }' `
		
		db=`awk < $ln ' { ; print $1 }' `

		uid=`awk < $ln ' { ; print $3 }' `

		cc="vpulimam,rkok3587"
		
		if [[ -n "$uid" ]] ; then
			email $uid "$msg" $db $cc
		fi
	
	done 
	} < $id
fi

rm $id
