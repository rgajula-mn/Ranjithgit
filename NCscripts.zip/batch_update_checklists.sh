#!/bin/sh

. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh

batch_path=${BCE_LOG}/batch_job_data
tmp_loc_file=/tmp/batch_update_buildweb.$$

get_column ()
{
	line=$1
	column=$2
	option=$3
	
	value=`echo $line | cut -d';' -f$column`
	if [ ! -z "$value" ]
	then
		if [ ! -z "$option" ]
		then
			echo "-$option $value"
		else
			echo "$value"
		fi
	fi

	return 0
}

if [ ! -d /$batch_path/done ]
then
	mkdir /$batch_path/done
fi
if [ ! -d /$batch_path/failed ]
then
	mkdir /$batch_path/failed
fi

for i in `ls $batch_path | grep -v done | grep -v failed`
do
	echo Running for file : $i >> $tmp_loc_file
	while read tmp_line
	do
		if [ -z "$tmp_line" ]
		then
			continue
		fi
		line=`echo $tmp_line | sed -e 's/ //g'`
		table_update=`get_column $line 1`
		if [ "$table_update" = "baseline_build_folder" ]
		then
			update_string=""
			update_string="$update_string `get_column $line 2 p`"
			update_string="$update_string `get_column $line 3 v`"
			update_string="$update_string `get_column $line 4 I`"
			update_string="$update_string `get_column $line 5 l`"
			update_string="$update_string `get_column $line 6 J`"
			update_string="$update_string `get_column $line 7 i`"

			echo $line
			echo Adding to build_results "$update_string" -T >> $tmp_loc_file 2>&1
			${BCE_BUILD_SCRIPTS}/update_build_information.sh $update_string -Y >> $tmp_loc_file 2>&1
			broken=$?
		fi
		if [ "$table_update" = "test_cand_summary" ]
		then
			update_string=""
			update_string="$update_string `get_column $line 2 p`"
			update_string="$update_string `get_column $line 3 v`"
			update_string="$update_string `get_column $line 4 j`"
			update_string="$update_string `get_column $line 5 i`"
			update_string="$update_string `get_column $line 6 s`"
			update_string="$update_string `get_column $line 7 P`"
			update_string="$update_string `get_column $line 8 L`"
			update_string="$update_string `get_column $line 9 u`"

			echo $line
			echo Adding to build_results "$update_string" -T >> $tmp_loc_file 2>&1
			${BCE_BUILD_SCRIPTS}/update_build_information.sh $update_string -T >> $tmp_loc_file 2>&1
			broken=$?
		fi
		if [ "$table_update" = "build_results" ]
		then
			update_string=""
			update_string="$update_string `get_column $line 2 p`"
			update_string="$update_string `get_column $line 3 v`"
			update_string="$update_string `get_column $line 4 l`"
			update_string="$update_string `get_column $line 5 m`"
			update_string="$update_string `get_column $line 6 s`"
			update_string="$update_string `get_column $line 7 o`"
			update_string="$update_string `get_column $line 8 d`"
			update_string="$update_string `get_column $line 9 e`"
			update_string="$update_string `get_column $line 10 w`"
			update_string="$update_string `get_column $line 11 b`"
			update_string="$update_string `get_column $line 12 r`"
			update_string="$update_string `get_column $line 13 f`"
			update_string="$update_string `get_column $line 14 g`"
			update_string="$update_string `get_column $line 15 U`"
			update_string="$update_string `get_column $line 16 W`"
			update_string="$update_string `get_column $line 17 K`"
			update_string="$update_string `get_column $line 18 H`"
			update_string="$update_string `get_column $line 19 A`"

			echo $line
			echo Adding to build_results "$update_string" -B >> $tmp_loc_file 2>&1
			${BCE_BUILD_SCRIPTS}/update_build_information.sh $update_string -B >> $tmp_loc_file 2>&1
			broken=$?
		fi
		if [ "$table_update" = "release_summary" ]
		then
			project=`get_column $line 2`
			rel_type=`get_column $line 3`
			version=`get_column $line 4`
			rel_time=`get_column $line 5`
			release_mgr=`get_column $line 6`

			echo Adding to release_summary - $project $version $rel_type $rel_time $release_mgr >> $tmp_loc_file 2>&1
			${BCE_BUILD_SCRIPTS}/update_build_information.sh -p $project -v $version -y $rel_time -R -j $rel_type -M $release_mgr >> $tmp_loc_file 2>&1
			broken=$?
		fi
		if [ "$table_update" = "bas_summary" ]
		then
			script=`get_column $line 2`
			summary=`get_column $line 3`
			description=`get_column $line 4`
			owner=`get_column $line 5`
			severity=`get_column $line 6`
			category=`get_column $line 7`
			time=`get_column $line 8`

			echo Adding to bas_summary - $script $summary $description $owner $severity $category $time >> $tmp_loc_file 2>&1
			${BCE_BUILD_SCRIPTS}/update_build_information.sh -c "$category" -d "$description" -o "$owner" -p "$severity" -s "$script" -r "$summary" -t "$time" >> $tmp_loc_file 2>&1
			broken=$?
		fi


	done < /$batch_path/$i

	if [ "$broken" != "0" ]
	then
		mv /$batch_path/$i /$batch_path/failed/.
	else
		mv /$batch_path/$i /$batch_path/done/.
	fi

done

if [ -f $tmp_loc_file ]
then
	rm $tmp_loc_file
fi

