#!/bin/bash

project=$1
version=$2
stat=$3
platform=$4
oracle=$5
machine=$6
sid=$7
action=$8

if [ $# -ne 8 ]
then
echo "[INFO] Invalid number of inputs"
exit
fi

if [ $action == "i" ]
then
echo "[INFO] inserting"

sql="insert into overrides_for_release values('$project','$version','$stat','$platform','$oracle','$machine','$sid')"

elif [ $action == "d" ]
then
echo "[INFO] deleting"
sql="delete from  overrides_for_release  where PROJECT='$project' and VERSION='$version' and STATE='$stat' and PLATFORM='$platform' and ORACLE_PLATFORM='$oracle' and MACHINE='$machine'"
else


echo "[INFO] invalid action"
exit
fi


echo $sql
        result=`sqlplus -s buildweb/georgespass@web.world << +END
                set feedback off
                set head off
                $sql;
                exit
+END`


