set serveroutput on;
set linesize 255;
declare
  cursor c_CheckTable is
    select table_name
    from user_tables
    where table_name like 'OLD_VERSION_GENEVA%' or table_name like 'OLD_VERSION_RB%';
  v_TableName varchar2(255);
begin
  dbms_output.put_line('create_ac_db_tidygenevaversion.sql: Checking for OLD_VERSION%');
  open c_CheckTable;
  fetch c_CheckTable into v_TableName;
  close c_CheckTable;
  if v_TableName is not null then
    dbms_output.put_line('create_ac_db_tidygenevaversion.sql: Fixing ' || v_TableName);
    execute immediate
      'rename ' || v_TableName || ' to ' || replace(v_TableName, 'OLD_', '');
  end if;
  dbms_output.put_line('create_ac_db_tidygenevaversion.sql: Done');
end;
/
exit
