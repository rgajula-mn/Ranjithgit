#!/bin/bash
#set -x
function getTaskFileList()
{
cpt_database=cpt/cpt@webca.world
task=$1
list=`sqlplus -s $cpt_database << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
               select OBJECT_NAMe from CM_ADMIN.CMOBJECT a,CPT.TASKHASCCMOBJECT b where a.OBJECT_ID=b.CCM_OBJECT_ID and b.TASK_NUMBER='$task';
                exit
EOF`

for i in ${list[*]};do echo $i;done


}

function getTaskObjects()
{
cpt_database=cpt/cpt@webca.world

taskObjects=`sqlplus -s $cpt_database << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
               select OBJECT_NAMe from CM_ADMIN.CMOBJECT a,CPT.TASKHASCCMOBJECT b where a.OBJECT_ID=b.CCM_OBJECT_ID and b.TASK_NUMBER='$task';
                exit
EOF`

echo ${taskObjects[*]}

}


function usage(){
        printf "\t[INFO] Usage: <sript name> <release tag> <platform> <oracle> <state> <unix_userid>\n"
        printf "\t[INFO] Eg: script.sh RB_3.0.30.5 aix oracle10g sqa skan3092\n"
        exit 1
}

function isMachineValid(){
        uname -a | grep SunOS > /dev/null 2>&1
        if [ $? -ne 0 ]
        then
                printf "\t[INFO] You have to run this script in a Solaris machine. E.g. devapp759cn or devapp760cn etc.\n"
                 exit 1
        fi
}

function displayEnteredValues(){
        printf "\t[INFO] You have entered \n"
        printf "\t[INFO] Relese: $releaseTag \n"
        printf "\t[INFO] Platform: $platform;$synergyPlatform \n"
        printf "\t[INFO] Oracle: $oracle\n"
        printf "\t[INFO] Project type: $projectType\n"
	printf "\t[INFO] User: $userid\n"
        printf "\t[INFO] Your project: $project-$projectType$releaseNum.$platform.$oracle\n"
}

function areParametersValid(){
        result=`sqlplus -s $DATABASE << EOF
                        whenever sqlerror exit failure
                        set feed off
                        set head off
                        select decode((select unique(version) from patch_summary where project='$project' and version='$releaseNum'),null,0,1) from dual;
                        select decode((select unique(OPER_SYS) from patch_platforms where OPER_SYS='$platform'),null,0,1) from dual;
                        select decode((select unique(ORACLE_NAME) from patch_platforms where ORACLE_NAME='$oracle'),null,0,1) from dual;
                        select decode((select unique(project) from patch_platforms where project='$project' and version='$releaseNum' and oper_sys='$platform' and oracle_name='$oracle'),null,0,1) from dual;
                        exit
EOF`
        result=(`echo $result`)
        if [ "${result[0]}" = "0" ]
        then
                printf "\t[ERROR] Release tag entered is invalid. Exiting program.\n"
                exit 1
        fi
        if [ "${result[1]}" = "0" ]
        then
                printf "\t[ERROR] Platform entered is invalid. Exiting program.\n"
                exit 1
        fi
        if [ "${result[2]}" = "0" ]
        then
                printf "\t[ERROR] Oracle entered is invalid. Exiting program.\n"
                exit 1
        fi
        if [ "${result[3]}" = "0" ]
        then
                printf "\t[ERROR] Patch with these inputs doesn't exist. Exiting program.\n"
                exit 1
        fi
        if [ "${result[0]}" = "1" -a "${result[2]}" = "1" -a "${result[2]}" = "1"  -a "${result[3]}" = "1" ]
        then
                if [ "$4" = "sqa" ]
                then
			if [ "$5" = "arku1015" -o "$5" = "sdavulur" -o "$5" = "krna0316" -o "$5" = "raga1015" -o "$5" = "reir1015" -o "$5" = "pavu0613" -o "$5" = "anar0913" ]
			then
                        	printf "\t[INFO] Input values given are correct.\n"
				userid=$5
			else
				printf "\t[ERROR] User id is wrong.\n"
				exit 1
			fi

                else
                        printf "\t[ERROR] Project type $4 is not valid. Exiting program.\n"
                        exit 1
                fi
        else
                exit 1
        fi
}


function findExpectedRC(){
	if [ "$project" = "GENEVA" -a "$majorRelease" = "2.2" ]
	then
        	patchType="RBPATCH"
	        majorRelease="2.2"
        	tmp=`echo $releaseTag | sed -e "s/.*_//g" | cut -d'.' -f3-4`
	        releaseNum=`echo $majorRelease.$tmp`
	fi

        expectedRC=`sqlplus -s $DATABASE << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                select cand_name from test_cand_summary where rowid=(select max(rowid) from test_cand_summary where project='${project}' and version='${releaseNum}');
                exit
EOF`
        tmp=`echo $expectedRC | cut -c3`
if [ "${tmp}" = "" ]
then
        tmp=0
fi
        tmp=`expr $tmp + 1`
	if [ $tmp -gt 1  ]
	then
		previousRC=`expr $tmp - 1`
	fi
        expectedRC="RC$tmp"
	printf "\t[INFO] Next RC to be given: $expectedRC\n"
}

function startSynergy(){
        startCCM "$CCM_DATABASE_CB1"
        if [ -z "${CCM_ADDR}" ]
        then
                printf "\t[ERROR] CCM Failed to start. Exiting program.\n"
                cleanUpCCM
                exit 1
        else
                printf "\t[INFO] CCM Started\n"
        fi
}

function findWorkArea(){
        #ccm query "name='$patchType' and version='$projectType$releaseNum.$platform.$oracle'"
	if [ "$project" = "TAP3" ]
        then
                workArea="/irb/bce/release/tap3/$majorRelease/TAP3PATCH-$projectType$releaseNum.$platform.$oracle"
	elif [ "$project" = "VI" ]
	then
		workArea_VI_X="/irb/bce/release/vi_x/$majorRelease/VI_XPATCH-$projectType$releaseNum.$platform.$oracle"
		workArea_VI_STQ="/irb/bce/release/vi_stq/$majorRelease/VI_STQPATCH-$projectType$releaseNum.$platform.$oracle"
		workArea_VI_CTL="/irb/bce/release/vi_ctl/$majorRelease/VI_CTLPATCH-$projectType$releaseNum.$platform.$oracle"
        else
                workArea="/irb/bce/release/rb/$majorRelease/RBPATCH-$projectType$releaseNum.$platform.$oracle"
        fi
    	#workArea=`ccm attr -s wa_path @`
        if [ "$project" = "GENEVA" -a "$majorRelease" = "5.3" ]
        then
                patchWorkArea=`echo $workArea/GENEVAPATCH`
        elif [ "$project" = "RB" -o "$majorRelease" = "2.2" ]
        then
                patchWorkArea=`echo $workArea/RBPATCH/RB/RB`
	elif [ "$project" = "TAP3" ]
        then
                patchWorkArea=`echo $workArea/TAP3PATCH/TAP3/TAP3`
	elif [ "$project" = "VI" ]
        then
                patchWorkArea_VI_X=`echo $workArea_VI_X/VI_XPATCH/VI_X/VI_X`
		patchWorkArea_VI_STQ=`echo $workArea_VI_STQ/VI_STQPATCH/VI_STQ/VI_STQ`
		patchWorkArea_VI_CTL=`echo $workArea_VI_CTL/VI_CTLPATCH/VI_CTL/VI_CTL`
        fi
     #   ccm attr -c platform -t string @
     #   ccm attr -m platform -v $synergyPlatform
	printf "\t[INFO] Workarea for the patch: $patchWorkArea\n"
}

function checkoutProject(){
	projectLowerCase=`echo $project|tr '[A-Z]' '[a-z]'`
	echo "projectLowerCase = $projectLowerCase"
	if [ "$project" = "GENEVA" -a "$majorRelease" = "2.2" ]
	then
        	patchType="RBPATCH"
	        majorRelease="2.2"
        	tmp=`echo $releaseTag | sed -e "s/.*_//g" | cut -d'.' -f3-4`
	        releaseNum=`echo $majorRelease.$tmp`
	fi
	if [ "$project" = "TAP3" ]
        then
                ls -ld //irb/bce/release/$projectLowerCase/$majorRelease/TAP3PATCH-$projectType$releaseNum.$platform.$oracle
	elif [ "$project" = "VI" ]
	then
		ls -ld //irb/bce/release/${projectLowerCase}_x/$majorRelease/VI_XPATCH-$projectType$releaseNum.$platform.$oracle
        else
                ls -ld //irb/bce/release/${projectLowerCase}/$majorRelease/RBPATCH-$projectType$releaseNum.$platform.$oracle
        fi
	#ccm query "name='$patchType' and version='$projectType$releaseNum.$platform.$oracle'"
	if [ $? -eq 0 ]
	then
		printf "\t[INFO] Project already exists. No need to checkout\n"
	else
		printf "\t[INFO] Checking out project...\n"
		#ccm co -purpose 'Release Candidate' -path //irb/bce/release/$projectLowerCase/$majorRelease -release $releaseTag -ncb -wa -p $patchType-template -to $projectType$releaseNum.$platform.$oracle
		if [ "$project" = "TAP3" ]
               	then
                       	mkdir -p /irb/bce/release/$projectLowerCase/$majorRelease/TAP3PATCH-$projectType$releaseNum.$platform.$oracle/TAP3PATCH/TAP3/TAP3
                        cd /irb/bce/release/$projectLowerCase/$majorRelease/TAP3PATCH-$projectType$releaseNum.$platform.$oracle/TAP3PATCH/TAP3/TAP3
                        mkdir bin doc lib
		elif [ "$project" = "VI" ]
		then
			mkdir -p /irb/bce/release/${projectLowerCase}_x/$majorRelease/VI_XPATCH-$projectType$releaseNum.$platform.$oracle/VI_XPATCH/VI_X/VI_X
			#mkdir -p /irb/bce/release/$projectLowerCase_stq/$majorRelease/VI_STQPATCH-$projectType$releaseNum.$platform.$oracle/VI_STQPATCH/VI_STQ/VI_STQ
			#mkdir -p /irb/bce/release/$projectLowerCase_ctl/$majorRelease/VI_CTLPATCH-$projectType$releaseNum.$platform.$oracle/VI_CTLPATCH/VI_CTL/VI_CTL
		
			echo "Creating VI_X Directory Structure"
			cd /irb/bce/release/${projectLowerCase}_x/$majorRelease/VI_XPATCH-$projectType$releaseNum.$platform.$oracle/VI_XPATCH/VI_X/VI_X
			#mkdir -p bin doc exe include java lib META_INF sample schema validation
			mkdir -p doc

			#echo "Creating VI_STQ Directory Structure"
			#cd /irb/bce/release/$projectLowerCase_stq/$majorRelease/VI_STQPATCH-$projectType$releaseNum.$platform.$oracle/VI_STQPATCH/VI_STQ/VI_STQ
			#mkdir -p bin  doc  exe  include  java  lib  META_INF  sample  schema  validation
				
			#echo "Creating VI_CTL Directory Structure"
			#cd /irb/bce/release/$projectLowerCase_ctl/$majorRelease/VI_CTLPATCH-$projectType$releaseNum.$platform.$oracle/VI_CTLPATCH/VI_CTL/VI_CTL
			#mkdir -p bin  doc  exe  include  java  lib  META_INF  sample  schema  validation  vertex vertex/commtax21/bin
                else
                        mkdir -p /irb/bce/release/$projectLowerCase/$majorRelease/RBPATCH-$projectType$releaseNum.$platform.$oracle/RBPATCH/RB/RB
                        cd /irb/bce/release/$projectLowerCase/$majorRelease/RBPATCH-$projectType$releaseNum.$platform.$oracle/RBPATCH/RB/RB
                        mkdir bin doc lib
                fi

	fi
	findWorkArea
}

function setupPatch(){
	if [ "$expectedRC" = "RC1" ]
	then
		checkoutProject
	else
		findWorkArea
	fi
}

function createTask(){
existingTasksArray=`ccm query -t task "release='$releaseTag' and owner='genadmin' and status='task_assigned'" | awk '{print $2}' | head -1`
if [ "$expectedRC" = "RC1" -a "$existingTasksArray" = "" ] || [ "$expectedRC" != "RC1" -a  "$existingTasksArray" = "" ]
then
                newTaskCreated=`ccm task -create -default -synopsis "Create $releaseTag Patch Project Structure" -resolver genadmin -release $releaseTag -subsystem "Build"`
                newTaskCreated=`echo $newTaskCreated | grep "Task CB[1-2]\#[0-9]"`
                newTaskCreated=`echo $newTaskCreated | awk '{print $2}'`
		if [ "$newTaskCreated" != "" ]
		then
                	printf "\t[INFO] Created task $newTaskCreated and set to default...\n"
		else
			printf "\t[ERROR] Failed to create task.\n"
		fi
elif [ "$existingTasksArray" != "" ] 
then
                        ccm task -def $existingTasksArray
                        newTaskCreated=`ccm task -def | awk "{print $1}" | sed "s/://"`
                        printf "\t[INFO] Task $newTaskCreated already exists for this patch with owner 'genadmin' and status 'task_assigned'.\n"
			printf "\t[INFO] Using $newTaskCreated as default.\n"
fi

isNewTaskCreated="true"
}

function anyNewDeliverablesAsked(){
printf "\n\n"
printf "\t[INFO] Delieverables existing in the patch\n"
printf "\t===========================================\n"
cat /dev/null > /tmp/deliverables_in_synergy
cat /dev/null > /tmp/deliverables_in_task

#ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and type!='dir'" | awk '{print $2}' | cut -d"-" -f1 >> /tmp/deliverables_in_synergy
#patchTasks=`ccm query -t task "release='$releaseTag' and status='completed' and owner!='genadmin'" -f %task_number | awk '{print $2}'`
patchTasks=`sqlplus -s $DATABASE << EOF
                        whenever sqlerror exit failure
                        set feed off
                        set head off
                       select TASK_NUMBER from TASK where RELEASE='$releaseTag';
                        exit
EOF`

printf "\n\n"
for task in $patchTasks
do
	printf "\t[INFO] Querying task: $task.\n"
        result=`sqlplus -s cpt/cpt@webca.world << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                select unique(deliverable_name) from submittedtaskdeliverable where task_number in ($task);
                exit
EOF`
        for deliverable in $result
        do

		query_output=`echo $deliverable | grep -v "\." | egrep  "Messages_VPA|Messages_API|Schema|APIs|None_-_Rtest_only"`
		if [ $? -eq 1 ]
		then

		printf "\t[INFO] Found $deliverable in the task $task\n"
		query_output=`echo $deliverable | grep "\.egg\$"`
		if [ $? -eq 0 ]
		then
		echo "[INFO]$deliverable deliverable found in task $task"
		echo "[INFO] Adding it to bin"
		addDeliverable "binary" "$deliverable" "$pathToAllDeliverables/bin"
		fi
                                                            
		query_output=`echo $deliverable | egrep "\.xml\$|\.mess\$"`
		if [ $? -eq 0 ]
		then
		echo "[INFO]$deliverable deliverable found in task $task"
		echo "[INFO] Adding it to schema/mess"
		find_workarea=`echo $pathToAllDeliverables|sed 's/ALLBATCH//'`
		addDeliverable "mess" "$deliverable" "$find_workarea"
		fi

			query_output=`echo $deliverable | egrep "\.h\$|\.hh\$|\.sh\$|\.ksh\$|\.pl\$|\.pm\$"`

			if [ $? -eq 0 ]
			then	
				headerFile=$deliverable
				#headerFile=`ccm task CB1#$task -sh obj | egrep "\.h|\.hh|\.sh|\.ksh|\.pl|\.pm" | awk '{print $2}' | cut -d":" -f1 | cut -d "-" -f1 | uniq`
				if [ "$headerFile" = "" ]
				then
					printf "\t[ERROR] $deliverable version was not found in the task CB1#$task.\n"
					headerFile=$deliverable
				fi
				for header in $headerFile
				do
					#headerFileFourPart=`ccm query "recursive_is_member_of('$project-$projectType$releaseNum.$platform.$oracle',none) and name='$header'" -f "%name-%version:%type:%subsystem" | awk '{print $2}'`
					headerName=`echo $headerFileFourPart | cut -d ":" -f1 | cut -d"-" -f1`
					headerVersion=`echo $headerFileFourPart | cut -d ":" -f1 | cut -d"-" -f2`
					#header=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='$headerName' and version='$headerVersion'" -f "%name-%version:%type:%subsystem"`
					header=
					headerName=$headerFile
					if [ "$header" = "" ]
					then
						echo $headerName | egrep "\.h\$|\.hh\$"
						if [ $? -eq 0 ]
						then
							find_workarea=`echo $pathToAllDeliverables|sed 's/ALLBATCH//'`
							#addDeliverable "include" "$headerFileFourPart" ""
							
							addDeliverable "include" "$headerFile" "$find_workarea"
						fi
						echo $headerName | egrep "\.sh\$|\.ksh\$|\.pl\$|\.pm\$"
						if [ $? -eq 0 ]
						then
							find_workarea=`echo $pathToAllDeliverables|sed 's/ALLBATCH//'`
							addDeliverable "bin_header" "$headerFile" "$find_workarea"
						fi
					else
						printf "\t[INFO] $header already existis in the patch.\n"
					fi
					echo $headerName >> /tmp/deliverables_in_task
				done
			fi
			query_output=`echo $deliverable | grep "\.exe\$"`
			if [ $? -eq 0 ]
			then
				#query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='$deliverable'"`
				if [ $? -eq 0 ]
				then
					printf "\t[INFO] $deliverable already exists in the patch.\n"
				else
					addDeliverable "executable" "$deliverable" ""
				fi
				echo $deliverable >> /tmp/deliverables_in_task
			fi
			query_output=`echo $deliverable | egrep "\.plb\$|\.bdy"`
			if [ $? -eq 0 ]
			then
				
					printf "\t[INFO] $deliverable Adding to the Patch.\n"
				
					addDeliverable "plb" "$deliverable" "$pathToAllDeliverables/sqlbdy"
				
				echo $deliverable >> /tmp/deliverables_in_task
			fi
			query_output=`echo $deliverable | grep "\.spc\$"`
			if [ $? -eq 0 ]
			then
			#	spcs=`ccm task CB1#$task -sh obj | grep "\.spc" | awk '{print $2}' | cut -d":" -f1 | cut -d"-" -f1 | uniq`
			spcs=$deliverable
				if [ "$spcs" = "" ]
				then
					printf "\t[ERROR] $deliverable version was not mentioned in the task CB1#$task"
					spcs=$deliverable
				fi
        	                for spc in $spcs
                	        do
                        	       # spcFileFourPart=`ccm query "recursive_is_member_of('$project-$projectType$releaseNum.$platform.$oracle',none) and name='$spc'" -f "%name-%version:%type:%subsystem" | awk '{print $2}'`
                                	spcName=`echo $spcFileFourPart | cut -d":" -f1 | cut -d"-" -f1`
	                                spcVersion=`echo $spcFileFourPart | cut -d":" -f1 | cut -d"-" -f2`
        	                       # spc=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='$spcName' and version='$spcVersion'" -f "%name-%version:%type:%subsystem"`
                	                if [ "$spc" != "" ]
                        	        then
						addDeliverable "spc" "$deliverable" "$pathToAllDeliverables/sqlspc/"	
                                	        #addDeliverable "spc" "$spcFileFourPart" "$pathToAllDeliverables/sqlspc/"
	                                else
        	                                printf "\t[INFO] $spc already exists in the patch.\n"
                	                fi
					echo $spcName >> /tmp/deliverables_in_task
	                        done
			fi
			query_output=`echo $deliverable | egrep "\.mess\$|\.txt\$"`
			if [ $? -eq 0 ]
			then
				#messageFile=`ccm task CB1#$task -sh obj | egrep "\.mess|\.txt" | awk '{print $2}' | cut -d":" -f1 | cut -d"-" -f1 | uniq`
                                if [ "$messageFile" = "" ]
                                then
                                        printf "\t[ERROR] $deliverable version was not mentioned in the task CB1#$task"
                                        messageFile=$deliverable
                                fi
        	                for mess in $messageFile
                	        do
                        	        #messFileFourPart=`ccm query "recursive_is_member_of('$project-$projectType$releaseNum.$platform.$oracle',none) and name='$mess'" -f "%name-%version:%type:%subsystem" | awk '{print $2}'`
                                	messName=`echo $messFileFourPart | cut -d":" -f1 | cut -d"-" -f1`
	                                messVersion=`echo $messFileFourPart | cut -d":" -f1 | cut -d"-" -f2`
        	                       # mess=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='$messName' and version='$messVersion'" -f "%name-%version:%type:%subsystem"`
                	                if [ "$mess" = "" ]
                        	        then
                                	        addDeliverable "mess" "$messFileFourPart" ""
	                                else
        	                                printf "\t[INFO] $mess already existis in the patch.\n"
                	                fi
					echo $messName >> /tmp/deliverables_in_task
                        	done
			fi

			query_output=`echo $deliverable | grep "\.so\$"`
			if [ $? -eq 0 ]
			then
				if [ "$platform" = "itanium" -o "$platform" = "hp64" ]
				then
					ls -ltr $pathToAllDeliverables/lib/$deliverable > /dev/null 2>&1
					if [ $? -ne 0 ]
					then
						deliverable=`echo $deliverable | sed 's/.so/.sl/'`
					fi
				fi
				#query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='$deliverable'"`
				if [ $? -ne 0 ]
				then
					printf "\t[INFO] $deliverable already exists in the patch.\n"
				else
					addDeliverable "library" "$deliverable" "$pathToAllDeliverables/lib"
				fi
				echo $deliverable >> /tmp/deliverables_in_task
			fi
			query_output=`echo $deliverable | grep -v "\." | egrep -v "Messages_VPA|Messages_API|Schema|APIs|None_-_Rtest_only"`
			if [ $? -eq 0 ]
			then
				#query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='$deliverable'"`
				if [ $? -ne 0 ]
				then
					printf "\t[INFO] $deliverable already exists in the patch.\n"
				else
					addDeliverable "binary" "$deliverable" "$pathToAllDeliverables/bin"
				fi
				echo $deliverable >> /tmp/deliverables_in_task
			fi
			query_output=`echo $deliverable |egrep "ALL_BINARIES|ALL_LIBRARIES"`
                        if [ $? -eq 0 ]
                        then
                                if [ "$deliverable" = "ALL_BINARIES" ]
                                then
                                        addDeliverable "all_binary" "$deliverable" "$pathToAllDeliverables/bin"
                                else
                                        addDeliverable "all_library" "$deliverable" "$pathToAllDeliverables/lib"
                                fi
                        fi
		else
		if [ "$deliverable" = "APIs" ]
		then
		#	bdys=`ccm task CB1#$task -sh obj | awk '{print $2}' | grep "\.bdy"`


			bdys=`getTaskFileList $task | grep "\.bdy\$"`
			for plb in $bdys
			do
				#plb=`echo $plb | sed 's/:.*//' | sed 's/.bdy/.plb/' | cut -d '-' -f1`
				#query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='$plb'"`
				if [ $? -ne 0 ]
				then
					printf "\t[INFO] $plb is already exists in the patch.\n"
				else
					plb=`echo $plb|sed 's/.bdy/.plb/g'`
					addDeliverable "plb" "$plb" "$pathToAllDeliverables/sqlbdy"
				fi
				echo $plb >> /tmp/deliverables_in_task
			done
			spcs=`getTaskFileList $task | grep "\.spc"\$`
			for spc in $spcs
			do
				
				if [ "$spc" != "" ]
				then
					addDeliverable "spc" "$spc" "$pathToAllDeliverables/sqlspc"
				else
					printf "\t[INFO] $spc already exists in the patch.\n"
				fi
				echo $spcName >> /tmp/deliverables_in_task
			 done
		fi


		if [ "$deliverable" = "Messages_VPA" -o "$deliverable" = "Messages_API" ]
		then
		#	messageFile=`ccm task CB1#$task -sh obj | egrep "\.mess|\.txt" | awk '{print $2}' | cut -d":" -f1 | cut -d"-" -f1 | uniq`
		messageFile=`getTaskFileList $task|egrep "\.mess\$|\.xml\$|\.txt\$"`


			for mess in $messageFile
			do
			#	messFileFourPart=`ccm query "recursive_is_member_of('$project-$projectType$releaseNum.$platform.$oracle',none) and name='$mess'" -f "%name-%version:%type:%subsystem" | awk '{print $2}'`
			#	messName=`echo $messFileFourPart | cut -d":" -f1 | cut -d"-" -f1`
			#	messVersion=`echo $messFileFourPart | cut -d":" -f1 | cut -d"-" -f2`
			#	mess=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='$messName' and version='$messVersion'" -f "%name-%version:%type:%subsystem"`
		
				if [ "$mess" != "" ]
				then

				echo "[INFO] Adding it to schema/mess"
		find_workarea=`echo $pathToAllDeliverables|sed 's/ALLBATCH//'`
		addDeliverable "mess" "$mess" "$find_workarea"
					#addDeliverable "mess" "$messFileFourPart" ""
					#addDeliverable "mess" "$messName" ""
				else
					printf "\t[INFO] $mess already existis in the patch.\n"
				fi
				echo $messName >> /tmp/deliverables_in_task
			done
		fi
		if [ "$deliverable" = "Schema" ]
		then
#			sqlFile=`ccm task CB1#$task -sh obj | grep "\.sql" | awk '{print $2}' | cut -d":" -f1 | cut -d"-" -f1 | uniq`


		sqllist=`getTaskFileList $task|egrep "\.sql\$"`
		sqlFile=`echo $sqllist|tr ' ' '\n'|grep sql`


			for sql in $sqlFile
			do
				#sqlFileFourPart=`ccm query "recursive_is_member_of('$project-$projectType$releaseNum.$platform.$oracle',none) and name='$sql'" -f "%name-%version:%type:%subsystem" | awk '{print $2}'`
				#sqlName=`echo $sqlFileFourPart | cut -d ":" -f1 | cut -d"-" -f1`
			#	sqlVersion=`echo $sqlFileFourPart | cut -d ":" -f1| cut -d"-" -f2`
			#	sql=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='$sqlName' and version='$sqlVersion'" -f "%name-%version:%type:%subsystem"`
sqlName=$sql
sql=
				if [ "$sql" = "" ]
				then
find_workarea=`echo $pathToAllDeliverables|sed 's/ALLBATCH//'`


					addDeliverable "sql" "$sqlName" "$find_workarea/SCHEMA/SRC"
				else
					printf "\t[INFO] $sql already existis in the patch.\n"
				fi
				echo $sqlName >> /tmp/deliverables_in_task
			done
		fi
		fi
        done
done
}
function anyNewTAP3DeliverablesAsked(){
	printf "\n\n"
        printf "\t[INFO] Delieverables existing in the patch\n"
        printf "\t===========================================\n"
        cat /dev/null > /tmp/deliverables_in_synergy
        cat /dev/null > /tmp/deliverables_in_task
#	if [ $project = "TAP3" ]
#	then
		releaseTag1=$releaseTag
                t1=`echo $releaseTag1|cut -d'_' -f1|cut -d'3' -f1`
                t2=`echo $releaseTag1|cut -d'_' -f2`
                releaseTag=`echo $t1"_"$t2`
        patchTasks=`sqlplus -s $DATABASE << EOF
                        whenever sqlerror exit failure
                        set feed off
                        set head off
                       select TASK_NUMBER from TASK where RELEASE='$releaseTag';
                        exit
EOF`
	printf "\n\n"
	        for task in $patchTasks
        	do
			printf "\t[INFO] Querying task: $task.\n"
        	        result=`sqlplus -s cpt/cpt@webca.world << EOF
                	whenever sqlerror exit failure
	                set feed off
        	        set head off
                	select unique(deliverable_name) from submittedtaskdeliverable where task_number in ($task);
	                exit
EOF`
			for deliverable in $result
	                do
				query_output=`echo $deliverable | grep -v "\." | egrep  "Messages_VPA|Messages_API|Schema|APIs|None_-_Rtest_only"`
	                        if [ $? -eq 1 ]
        	                then
					query_output=`echo $deliverable | egrep "\.template\$"`
	                                if [ $? -eq 0 ]
        	                        then
						if [ $deliverable = "TFEt3create.template" ]
                                                then
                                                     find_workarea=`echo $pathToAllDeliverables`
                                                     addDeliverable "binary" "$deliverable" "$find_workarea"
                                                fi
					fi
					query_output=`echo $deliverable | egrep "\.h\$|\.hh\$|\.sh\$|\.ksh\$|\.pl\$|\.pm\$"`
                                	if [ $? -eq 0 ]
	                                then
        	                                headerFile=$deliverable
                                        	if [ "$headerFile" = "" ]
	                                        then
        	                                        printf "\t[ERROR] $deliverable version was not found in the task CB1#$task.\n"
                	                                headerFile=$deliverable
                        	                fi
                                	        for header in $headerFile
                                        	do
                                                	headerName=`echo $headerFileFourPart | cut -d ":" -f1 | cut -d"-" -f1`
	                                                headerVersion=`echo $headerFileFourPart | cut -d ":" -f1 | cut -d"-" -f2`
                                                	header=
	                                                headerName=$headerFile
        	                                        if [ "$header" = "" ]
                	                                then
                        	                                echo $headerName | egrep "\.h\$|\.hh\$"
                                	                        if [ $? -eq 0 ]
                                        	                then
                                                	                find_workarea=`echo $pathToAllDeliverables|sed 's/ALLBATCH//'`
                                                                	addDeliverable "include" "$headerFile" "$find_workarea"
	                                                        fi
        	                                                echo $headerName | egrep "\.sh\$|\.ksh\$|\.pl\$|\.pm\$"
                	                                        if [ $? -eq 0 ]
                        	                                then
                                	                                #################################################TAP3CHANGES#################################################
                                        	                        if [ $project = "TAP3" ]
                                                	                then
                                                        	                if [ $headerName = "HURGfindPid.sh" -o $headerName = "SISfindPid.sh" -o $headerName = "TFEfindPid.sh" -o $headerName = "TFIfindPid.sh" ]
                                                                                then
                                                                                        find_workarea=`echo $pathToAllDeliverables`
                                                                                        addDeliverable "binary" "$headerFile" "$find_workarea"
                                                                                elif [ $headerName = "common_functions.ksh" -o $headerName = "TAP3_pre_install.sh" -o $headerName = "TAP3_post_install.sh" -o "TAP3_pre_install.sql" ]
                                                                                then
                                                                                        find_workarea=`echo $pathToAllDeliverables/configuration/infinys/validation/`
                                                                                        addDeliverable "validation" "$headerFile" "$find_workarea"
                                                                                else
                                                                                        echo "No Files found in the Task"
                                                                                fi
                                                    			else
                                                                                find_workarea=`echo $pathToAllDeliverables|sed 's/ALLBATCH//'`
                                                                                addDeliverable "bin_header" "$headerFile" "$find_workarea"
	                                                                fi
								fi
							else
								printf "\t[INFO] $header already existis in the patch.\n"
                                            		fi
	                                                echo $headerName >> /tmp/deliverables_in_task
        	                                done
					fi
					query_output=`echo $deliverable | grep "\.so\$"`
	                                if [ $? -eq 0 ]
        	                        then
                	                        if [ "$platform" = "itanium" -o "$platform" = "hp64" ]
                        	                then
                                	                ls -ltr $pathToAllDeliverables/lib/$deliverable > /dev/null 2>&1
                                        	        if [ $? -ne 0 ]
                                                	then
                                                        	deliverable=`echo $deliverable | sed 's/.so/.sl/'`
	                                                fi
        	                                fi
                	                        #query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='$deliverable'"`
                        	                if [ $? -ne 0 ]
                                	        then
                                        	        printf "\t[INFO] $deliverable already exists in the patch.\n"
	                                        else
                        	                                if [ $deliverable = "TAP3RPI.so" -o $deliverable = "TAP3RUP.so" ]
                                	                        then
                                        	                        addDeliverable "binary" "$deliverable" "$pathToAllDeliverables/lib/"
                                                	        else
                                                        	        addDeliverable "library" "$deliverable" "$pathToAllDeliverables/lib/"
	                                                        fi
                                	        fi
                                        	echo $deliverable >> /tmp/deliverables_in_task
	                                fi
					#################################FOR_TAP3_MESSAGES#################################
		                        query_output=`echo $deliverable | grep -v "\." | egrep  "Messages_VPA|Messages_API|Schema|SCHEMA|APIs|messages|None_-_Rtest_only"`
                		        if [ $? -eq 0 ]
		                        then
                		                if [ $project = "TAP3" ]
                                		then
		                                        if [ "$deliverable" = "HURGmessages" -o "$deliverable" = "RFTmessages" -o "$deliverable" = "RUImessages" -o "$deliverable" = "SISmessages" -o "$deliverable" = "TDAmessages" -o "$deliverable" = "TDCmessages" -o "$deliverable" = "TDDmessages" -o "$deliverable" = "TFEGTRmessages" -o "$deliverable" = "TFEmessages" -o "$deliverable" = "TFImessages" -o "$deliverable" = "TGMmessages" -o "$deliverable" = "TGMNYmessages" -o "$deliverable" = "THKmessages" -o "$deliverable" = "TUTmessages" -o "$deliverable" = "TAP3RPImessages" ]
                		                        then
                                		                messageFile=`getTaskFileList $task|egrep "\.mess\$|\.xml\$"`
                                                		for mess in $messageFile
		                                                do
                		                                        if [ "$mess" != "" ]
                                		                        then
                                                		                echo "[INFO] Adding it to schema/mess/eng"
                                                                		find_workarea=`echo $pathToAllDeliverables`
		                                                                addDeliverable "mess" "$mess" "$find_workarea"
                		                                        else
                                		                                printf "\t[INFO] $mess already existis in the patch.\n"
                                                		        fi
                                                                		echo $messName >> /tmp/deliverables_in_task
		                                                done
                		                        fi
                                		fi
		                        fi
					#################################FOR_TAP3_MESSAGES#################################
					query_output=`echo $deliverable | grep -v "\." | egrep -v "Messages_VPA|Messages_API|Schema|SCHEMA|APIs|None_-_Rtest_only|API"`
					if [ $? -eq 0 ]
		                        then
                                		if [ $? -ne 0 ]
		                                then
                		                        printf "\t[INFO] $deliverable already exists in the patch.\n"
                                		else
		                                        addDeliverable "binary" "$deliverable" "$pathToAllDeliverables/bin"
                		                fi
                                			echo $deliverable >> /tmp/deliverables_in_task
		                        fi	
					query_output=`echo $deliverable | grep "\.API\$"`
		                        if [ $? -eq 0 ]
                		        then
                                		bdys=`getTaskFileList $task | egrep "\.bdy\$|\.API\$"`
		                                for plb in $bdys
                		                do
                                		        if [ $? -ne 0 ]
		                                        then
                		                                printf "\t[INFO] $plb is already exists in the patch.\n"
                               			        else
		                                                plb=`echo $plb|sed 's/.bdy/.plb/g'`
								#plb=`echo $plb|sed 's/ .API/.plb/g'`
                		                                addDeliverable "plb" "$plb" "$pathToAllDeliverables/sqlbdy"
                                		        fi
		                                        echo $plb >> /tmp/deliverables_in_task
                		                done
                                		spcs=`getTaskFileList $task | grep "\.spc"\$`
		                                for spc in $spcs
                		                do
	
        		                                if [ "$spc" != "" ]
                        		                then
		                                                addDeliverable "spc" "$spc" "$pathToAllDeliverables/sqlspc"
                		                        else
                                		                printf "\t[INFO] $spc already exists in the patch.\n"
		                                        fi
                	                        echo $spcName >> /tmp/deliverables_in_task
                        		         done
		                        fi
					if [ "$deliverable" = "HURGmessages" -o "$deliverable" = "RFTmessages" -o "$deliverable" = "RUImessages" -o "$deliverable" = "SISmessages" -o "$deliverable" = "TDAmessages" -o "$deliverable" = "TDCmessages" -o "$deliverable" = "TDDmessages" -o "$deliverable" = "TFEGTRmessages" -o "$deliverable" = "TFEmessages" -o "$deliverable" = "TFImessages" -o "$deliverable" = "TGMmessages" -o "$deliverable" = "TGMNYmessages" -o "$deliverable" = "THKmessages" -o "$deliverable" = "TUTmessages" ]
			                then
                        			messageFile=`getTaskFileList $task|egrep "\.mess\$|\.xml\$"`
			                        for mess in $messageFile
                        			do
			                                if [ "$mess" != "" ]
                        			        then
			                                        echo "[INFO] Adding it to schema/mess/eng"
                        			                find_workarea=`echo $pathToAllDeliverables`
			                                        addDeliverable "mess" "$mess" "$find_workarea"
                        			        else
			                                        printf "\t[INFO] $mess already existis in the patch.\n"
                        			        fi
			                                        echo $messName >> /tmp/deliverables_in_task
                        			done
			                fi
					if [ "$deliverable" = "Schema" -o "$deliverable" = "SCHEMA" ]
		                        then
                                		sqllist=`getTaskFileList $task|egrep "\.sql\$"`
		                                sqlFile=`echo $sqllist|tr ' ' '\n'|grep sql`
                                		for sql in $sqlFile
		                                do
                                			sqlName=$sql
			                                sql=
                        		                if [ "$sql" = "" ]
                                        		then
                                                        	find_workarea=`echo $pathToAllDeliverables`
	                                                        addDeliverable "sql" "$sqlName" "$find_workarea/SCHEMA/SRC"
                                        		else
		                                                printf "\t[INFO] $sql already existis in the patch.\n"
                		                        fi
                                		        echo $sqlName >> /tmp/deliverables_in_task
		                                done
                		        fi
				fi
			done
		done
#	fi
}

function anyNewVIDeliverablesAsked(){
	printf "\n\n"
        printf "\t[INFO] Delieverables existing in the patch\n"
        printf "\t===========================================\n"
        cat /dev/null > /tmp/deliverables_in_synergy
        cat /dev/null > /tmp/deliverables_in_task

	patchTasks=`sqlplus -s $DATABASE << EOF
                        whenever sqlerror exit failure
                        set feed off
                        set head off
                       select TASK_NUMBER from TASK where RELEASE='$releaseTag';
                        exit
EOF`

	printf "\n\n"
	for task in $patchTasks
	do
		printf "\t[INFO] Querying task: $task.\n"
        	result=`sqlplus -s cpt/cpt@webca.world << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                select unique(deliverable_name) from submittedtaskdeliverable where task_number in ($task);
                exit
EOF`
	        for deliverable in $result
        	do
			query_output=`echo $deliverable | grep "\.so\$"`	
			if [ $? -eq 0 ]
                        then
                                if [ "$platform" = "itanium" -o "$platform" = "hp64" ]
                                then
                                        ls -ltr $pathToAllDeliverables/lib/$deliverable > /dev/null 2>&1
                                        if [ $? -ne 0 ]
                                        then
                                                deliverable=`echo $deliverable | sed 's/.so/.sl/'`
                                        fi
                                fi
                                if [ $? -ne 0 ]
                                then
                                        printf "\t[INFO] $deliverable already exists in the patch.\n"
                                else
                                        addVIDeliverable "library" "$deliverable" "$pathToAllDeliverables/VERTEX/lib/"
                                fi
                                echo $deliverable >> /tmp/deliverables_in_task
                        fi
			query_output=`echo $deliverable | grep -v "\." | egrep -v "Messages_VPA|Messages_API|Schema|SCHEMA|APIs|None_-_Rtest_only|VPA|messages|VPA_messages"|grep -v "VPA messages"`
                        if [ $? -eq 0 ]
                        then
                                addVIDeliverable "binary" "$deliverable" "$pathToAllDeliverables/VERTEX/bin"
                       		echo $deliverable >> /tmp/deliverables_in_task
                        fi
                           query_output=`echo $deliverable | egrep "\.plb\$|\.spc\$|\.bdy\$"`
                            if [ $? -eq 0 ]
                             then
                                addDeliverable "procedures" "$deliverable" "$find_workarea"
                            echo $deliverable >> /tmp/deliverables_in_task
                              fi

			if [ "$deliverable" = "beautify_link_area_log.pl" ]
                        then
                                addVIDeliverable "binary" "$deliverable" "$pathToAllDeliverables/VERTEX/bin"
                                echo $deliverable >> /tmp/deliverables_in_task
                        fi
			if [ "$deliverable" = "Installer_scripts" ]
			then
				sqllist=`getTaskFileList $task|egrep "\.sql\$|\.xml\$|\.pl\$|\.sh\$|\.ctl\$"`
                                sqlFile=`echo $sqllist|tr ' ' '\n'|egrep 'sql|xml|pl|sh|ctl'`
                                for sql in $sqlFile
                                do
                                	sqlName=$sql
                                        sql=
                                        if [ "$sql" = "" ]
                                        then
                                        	find_workarea=`echo $pathToAllDeliverables/SCHEMA`
                                                addVIDeliverable "sql" "$sqlName" "$find_workarea"
                                        else
                                                printf "\t[INFO] $sql already existis in the patch.\n"
                                        fi
                                        echo $sqlName >> /tmp/deliverables_in_task
                                done	
			fi
			if [ "$deliverable" = "VPA_messages" -o "$deliverable" = "VPA messages" -o "$deliverable" = "VPA" -o "$deliverable" = "messages" ]
	                then
                		messageFile=`getTaskFileList $task|egrep "\.mess\$|\.xml\$|\.txt\$"`
	                        for mess in $messageFile
        	                do
                                	if [ "$mess" != "" ]
	                                then
		                                echo "[INFO] Adding it to schema/mess"
                				find_workarea=`echo $pathToAllDeliverables/SCHEMA/mess`
				                addVIDeliverable "mess" "$mess" "$find_workarea"
                                	else
                                        	printf "\t[INFO] $mess already existis in the patch.\n"
	                                fi
        	                        echo $messName >> /tmp/deliverables_in_task
                	        done
	                fi
                             query_output=`echo $deliverable|grep -v "\.plb\$\.bdy\$\.spc\$"`
                        if [ $? -eq 0 ]
                        then
 
            		find_workarea=`echo $pathToAllDeliverables/API`
				echo "deliverables from VI:" $deliverable
				echo "find work-area for:" $find_workarea
				addVIDeliverable "plb/spc" "$deliverable" "$find_workarea"
                    		fi 
			if [ "$deliverable" = "Vertex" -o "$deliverable" = "Commtax" -o "$deliverable" = "executables" -o "$deliverable" = "Vertex_Commtax_executables" ]
			then
				addVIDeliverable "binary" "$deliverable" "$pathToAllDeliverables/VERTEX/bin"
			fi	
		done

	done
}
function addVIDeliverable()
{
	if [ "$1" = "mess" ]
        then
                ls -ld $patchWorkArea_VI_X/schema/mess

                if [ $? -eq 2 ]
                then
                        ls -ld $patchWorkArea_VI_X/schema
                        if [ $? -eq 2 ]
                        then
                                printf "\t[INFO] Creating directory schema...\n"
                                mkdir -p $patchWorkArea_VI_X/schema
                        fi
                        printf "\t[INFO] Creating directory schema/mess...\n"
                        mkdir -p $patchWorkArea_VI_X/schema/mess
                fi
                printf "\t[INFO] Adding $2 to schema/mess directory...\n "
                cd $patchWorkArea_VI_X/schema/mess
                found_path=`find $3 -name  "$2" -print`
                if [ "$found_path" = "" ]
                then
                	echo "[INFO] $2 Not found in build work area"
                else
        	        echo "[INFO] $2 Found in Work area...Copying"
	                cp -p $found_path $patchWorkArea_VI_X/schema/mess
                fi
	elif [ "$1" = "plb/spc" ]
	then
		cd $find_workarea
		found_spc_bdy=`find . -name "$deliverable"`
		echo "vlue of found_spc_bdy is:" $found_spc_bdy
                mkdir -p $patchWorkArea_VI_X/schema/procedures
	        cp -p $find_workarea/$found_spc_bdy /irb/bce/release/${projectLowerCase}_x/$majorRelease/VI_XPATCH-$projectType$releaseNum.$platform.$oracle/VI_XPATCH/VI_X/VI_X/schema/procedures
		
	elif [ "$1" = "library" ]
        then
		patchWorkArea_VI_X=`echo $workArea_VI_X/VI_XPATCH/VI_X/VI_X`
		patchWorkArea_VI_STQ=`echo $workArea_VI_STQ/VI_STQPATCH/VI_STQ/VI_STQ`
		patchWorkArea_VI_CTL=`echo $workArea_VI_CTL/VI_CTLPATCH/VI_CTL/VI_CTL`
                if [ "$platform" = "itanium" -o "$platform" = "hp64" ]
                then
                        ls -ltr $3/$2 > /dev/null 2>&1
                        if [ $? -ne 0 ]
                        then
                                deliverable=`echo $2 | sed 's/.so/.sl/'`
                                ls -ltr $3/$deliverable > /dev/null 2>&1
                                if [ $? -ne 0 ]
                                then
                                        printf "\t[ERROR] $deliverable not found in the build work area. Not added to patch.\n"
                                else
                                        printf "\t[INFO] $deliverable found in the build work area. Adding it to lib directory...\n"
					if [ "$deliverable" = "libVI.sl" -o "$deliverable" = "libVICOMMON.sl" ]
					then
						ls -ld ${patchWorkArea_VI_X}/lib
						if [ $? -eq 2 ]
						then
							printf "\t[INFO] Creating directory lib...\n"
							mkdir -p ${patchWorkArea_VI_X}/lib
						fi
		                                cp -p $3/$deliverable ${patchWorkArea_VI_X}/lib/
					elif [ "$deliverable" = "libVISTQ.sl" ]
					then
						ls -ld ${patchWorkArea_VI_STQ}/lib
                                                if [ $? -eq 2 ]
                                                then
                                                        printf "\t[INFO] Creating directory lib...\n"
                                                        mkdir -p ${patchWorkArea_VI_STQ}/lib
                                                fi
                                                cp -p $3/$deliverable ${patchWorkArea_VI_STQ}/lib/
					elif [ "$deliverable" = "libVICTL.sl" ]
					then
						ls -ld ${patchWorkArea_VI_CTL}/lib
                                                if [ $? -eq 2 ]
                                                then
                                                        printf "\t[INFO] Creating directory lib...\n"
                                                        mkdir -p ${patchWorkArea_VI_CTL}/lib
                                                fi
                                                cp -p $3/$deliverable ${patchWorkArea_VI_CTL}/lib/
					fi
					
                                fi
                        fi
                else
                        ls -ltr $3/$2 > /dev/null 2>&1
			if [ $? -eq 0 ]
			then
				if [ "$deliverable" = "libVI.so" -o "$deliverable" = "libVICOMMON.so" ]
                                then
                                	ls -ld ${patchWorkArea_VI_X}/lib
                                        if [ $? -eq 2 ]
                                        then
                                        	printf "\t[INFO] Creating directory lib...\n"
                                                mkdir -p ${patchWorkArea_VI_X}/lib
                                        fi
                                        cp -p $3/$deliverable ${patchWorkArea_VI_X}/lib/
                                elif [ "$deliverable" = "libVISTQ.so" ]
                                then
                                	ls -ld ${patchWorkArea_VI_STQ}/lib
                                        if [ $? -eq 2 ]
                                        then
                                        	printf "\t[INFO] Creating directory lib...\n"
                                                mkdir -p ${patchWorkArea_VI_STQ}/lib
                                        fi
                                        cp -p $3/$deliverable ${patchWorkArea_VI_STQ}/lib/
                                elif [ "$deliverable" = "libVICTL.so" ]
                                then
                                	ls -ld ${patchWorkArea_VI_CTL}/lib
                                        if [ $? -eq 2 ]
                                        then
                                        	printf "\t[INFO] Creating directory lib...\n"
                                                mkdir -p ${patchWorkArea_VI_CTL}/lib
                                        fi
                                        cp -p $3/$deliverable ${patchWorkArea_VI_CTL}/lib/
                               fi
			fi
                fi
	elif [ "$1" = "binary" ]
        then
                ls -ltr $3/$2 > /dev/null 2>&1
                if [ $? -eq 0 ]
                then
			if [ "$2" = "STWS" ]
			then
				ls -ld $patchWorkArea_VI_STQ/bin/
				if [ $? -eq 2 ]
                                then
					printf "\t[INFO] Creating directory bin ...\n"
					mkdir -p $patchWorkArea_VI_STQ/bin/
				fi
	                        printf "\t[INFO] $2 found in the build work area. Adding it to VI_STQ - bin directory...\n"
	                        cp -p $3/$2 $patchWorkArea_VI_STQ/bin/$2
			elif [ "$2" = "beautify_link_area_log.pl" ]
			then
				printf "\t[INFO] $2 found in the build work area. Adding it to VI_CTL - vertex/commtax21/bin directory...\n"
				ls -ld $patchWorkArea_VI_CTL/vertex
				if [ $? -eq 2 ]
				then
					printf "\t[INFO] Creating directory vertex and vertex/commtax21/bin...\n"
					mkdir -p $patchWorkArea_VI_CTL/vertex
					mkdir -p $patchWorkArea_VI_CTL/vertex/commtax21
					mkdir -p $patchWorkArea_VI_CTL/vertex/commtax21/bin
				else
					ls -ld $patchWorkArea_VI_CTL/vertex/commtax21
					if [ $? -eq 2 ]
                                        then
                                                printf "\t[INFO] Creating directory vertex and vertex/commtax21...\n"
                                                mkdir -p $patchWorkArea_VI_CTL/vertex
                                                mkdir -p $patchWorkArea_VI_CTL/vertex/commtax21
                                        fi
				fi
				printf "\t[INFO] Adding $2 to vertex/commtax21/bin directory...\n "
				cp -p $3/beautify_link_area_log.pl $patchWorkArea_VI_CTL/vertex/commtax21/bin/
			fi
		elif [ "$2" = "executables" -o "$2" = "Vertex_Commtax_executables" ]
                then
                                printf "\t[INFO] $2 found in the build work area. Adding it to VI_CTL - vertex/commtax21/bin directory...\n"
                                ls -ld $patchWorkArea_VI_CTL/vertex/commtax21/bin
                                if [ $? -eq 2 ]
                                then
                                        ls -ld $patchWorkArea_VI_CTL/vertex/commtax21
                                        if [ $? -eq 2 ]
                                        then
                                                printf "\t[INFO] Creating directory vertex and vertex/commtax21...\n"
                                                mkdir -p $patchWorkArea_VI_CTL/vertex
                                                mkdir -p $patchWorkArea_VI_CTL/vertex/commtax21
                                        fi
                                fi
                                printf "\t[INFO] Creating directory vertex/commtax21/bin...\n"
                                mkdir -p $patchWorkArea_VI_CTL/vertex/commtax21/bin
                                printf "\t[INFO] Adding $2 to vertex/commtax21/bin directory...\n "
                                cp -p $3/CT* $patchWorkArea_VI_CTL/vertex/commtax21/bin/
                else
                        printf "\t[ERROR] $2 not found in the build work area. Not added to patch\n"
                fi
	elif [ "$1" = "sql" ]
	then
		found_path=`find $pathToAllDeliverables -name $2 -print`
		path_val=0
		a=1
		touch /irb/bce/arun_exe/temp_vi_auto_patch.txt
		echo $found_path|cut -d'/' -f10-|tr '/' "\n" > /irb/bce/arun_exe/temp_vi_auto_patch.txt
		no_val=`cat /irb/bce/arun_exe/temp_vi_auto_patch.txt|wc -l`

		dir_path=
		while [ $a -ne $no_val ]
                do
			ls -ld $patchWorkArea_VI_X/schema
			if [ $? -eq 2 ]
        	        then
				printf "\t[INFO] Creating directory schema...\n"
				mkdir -p $patchWorkArea_VI_X/schema
			else
				val_b=`sed -n ${a}p /irb/bce/arun_exe/temp_vi_auto_patch.txt`
			       #if [ "$val_b" = "SCHEMA" ]
		        	#then
                		#	val_b=`echo $val_b| tr '[A-Z]' '[a-z]'`
				#	ls -ld $patchWorkArea_VI_X/$val_b
			        #fi
				cd $patchWorkArea_VI_X/schema
				if [ -z $dir_path ]
                                then
					dir_path=${val_b}
				else
                                	dir_path=`echo "$dir_path/${val_b}"`
                                fi
				ls -ld $dir_path
				if [ $? -eq 2 ]
				then
					echo "Creating directory $dir_path"
					mkdir -p $dir_path
				fi
				a=`expr $a + 1`
				fin_path=$patchWorkArea_VI_X/schema/$dir_path
			fi
		done
		cp -p $found_path $fin_path
		rm -rf /irb/bce/arun_exe/temp_vi_auto_patch.txt
		
        else
                printf "\n"
	fi
	
	

}
function addDeliverable(){

		isNewTaskCreated="DUMMY"
	if [ "$isNewTaskCreated" = "" ]
	then
		createTask
	fi
	if [ "$1" = "plb" ]
	then
		ls -ld $patchWorkArea/schema/procedures
#		query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='procedures' and type='dir'"`
		if [ $? -eq 2 ]
		then
		#	query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='schema' and type='dir'"`
		ls -ld $patchWorkArea/schema/
			if [ $? -eq 2 ]
			then
				printf "\t[INFO] Creating directory schema...\n"
		mkdir -p $patchWorkArea/schema/procedures
				mkdir -p $patchWorkArea/schema
			#	ccm create -type dir $patchWorkArea/schema
			fi
			printf "\t[INFO] Creating directory schema/procedures...\n"
			mkdir -p $patchWorkArea/schema/procedures
#			ccm create -type dir $patchWorkArea/schema/procedures
		fi
		ls -ltr $3/$2 > /dev/null 2>&1
		if [ $? -eq 0 ]
		then
			printf "\t[INFO] $2 found in the build work area. Adding it to the patch...\n"
		#	ccm create -type $1 $patchWorkArea/schema/procedures/$2
			cp -p $3/$2 $patchWorkArea/schema/procedures/$2
		else
			printf "\t[ERROR] $2 not created in the build work area. Not added to patch.\n"
		fi
	elif [ "$1" = "spc" ]
	then
		ls -ld $patchWorkArea/schema/procedures
		#query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='procedures' and type='dir'"`
		if [ $? -eq 2 ]
		then
			#query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='schema' and type='dir'"`
		ls -ld $patchWorkArea/schema/
			if [ $? -eq 2 ]
			then
				printf "\t[INFO] Creating directory schema...\n"
				mkdir -p $patchWorkArea/schema
				#ccm create -type dir $patchWorkArea/schema
			fi
			printf "\t[INFO] Creating directory schema/procedures...\n"
	#		ccm create -type dir $patchWorkArea/schema/procedures
		mkdir -p $patchWorkArea/schema/procedures

		fi
		printf "\t[INFO] Adding $2 to schema/procedures directory...\n"
		cd $patchWorkArea/schema/procedures
		cp -p $3/$2 $patchWorkArea/schema/procedures/$2
	#	ccm use $2
	elif [ "$1" = "mess" ]
	then
#		query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='mess' and type='dir'"`
		ls -ld $patchWorkArea/schema/mess

		if [ $? -eq 2 ]
		then
		#	query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='schema' and type='dir'"`
			ls -ld $patchWorkArea/schema
			if [ $? -eq 2 ]
			then
				printf "\t[INFO] Creating directory schema...\n"
			#	ccm create -type dir $patchWorkArea/schema
				mkdir -p $patchWorkArea/schema
			fi
			printf "\t[INFO] Creating directory schema/mess...\n"
			mkdir -p $patchWorkArea/schema/mess
		#	ccm create -type dir $patchWorkArea/schema/mess
		fi
		printf "\t[INFO] Adding $2 to schema/mess directory...\n "
		#tmp=`echo $releaseNum | tr -d "."`
		#printf "\t[INFO] Finding work area of $2..."
		#messFileWorkArea=`find $buildPath/$projectLowerCase/$majorRelease/$project-$projectType$releaseNum.$platform.$oracle/$project -name "$2"`
		#if [ "$messFileWorkArea" != "" ]
		#then	
			cd $patchWorkArea/schema/mess

			found_path=`find $3 -type d \( -name ALLBATCH -o -name all_plugin_include \) -prune -o -name  "$2" -print`
			if [ "$found_path" = "" ]
			then
			echo "[INFO] $2 Not found in build work area"
			else
			echo "[INFO] $2 Found in Work area...Copying"
			cp -p $found_path $patchWorkArea/schema/mess
			fi
			#ccm use $2		
			#if [ "$tmp"  -ge 6121 ]
			#then
			#	ccm create -type message_file $2
			#		ccm attr -m release -v $releaseTag @
			#		ccm attr -c platform -t string @
			#		ccm attr -m platform -v $synergyPlatform @
			#	else 
			#		ccm create -type message_file $2
                	#               ccm attr -m release -v $releaseTag @
                	#               ccm attr -c platform -t string @
                	#              ccm attr -m platform -v $synergyPlatform @
			#		fi
			
		#else	
		#	echo "\t[INFO] $2 is not found in $buildPath/$projectLowerCase/$majorRelease/$project-$projectType$releaseNum.$platform.$oracle/$project"
		#	echo "\t[INFO] Skipping $2..."
		#fi
	elif [ "$1" = "sql" ]
	then
	#	query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='schema' and type='dir'"`
	ls -ld $patchWorkArea/schema
		if [ $? -eq 2 ]
		then
			printf "\t[INFO] Creating directory schema...\n"
			mkdir -p $patchWorkArea/schema
#			ccm create -type dir $patchWorkArea/schema
		fi
		printf "\t[INFO] Adding $2 to schema directory...\n"
		cd $patchWorkArea/schema
	#	ccm use $2
cp -p $3/$2 $patchWorkArea/schema
	elif [ "$1" = "executable" ]
	then
	#	query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='exe' and type='dir'"`
		ls -ld $patchWorkArea/exe
		if [ $? -eq 2 ]
		then
			printf "\t[INFO] Creating directory exe...\n"
		mkdir -p $patchWorkArea/exe
		#	ccm create -type dir $patchWorkArea/exe
		fi
		printf "\t[INFO] Creating $2 in exe directory...\n"
		cd $patchWorkArea/exe
		touch $patchWorkArea/exe/$2
	#	ccm create -type $1 $patchWorkArea/exe/$2
	elif [ "$1" = "include" ]
	then
		ls -ld $patchWorkArea/include
	#	query_output=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name='include' and type='dir'"`
		if [ $? -eq 2 ]
		then
			printf "\t[INFO] Creating directory include...\n"
		#	ccm create -type dir $patchWorkArea/include
			mkdir -p $patchWorkArea/include
		fi
		printf "\t[INFO] Adding $2 to include directory...\n"
		cd $patchWorkArea/include
#		found_path=`find $3 -type d \( -name ALLBATCH -o -name all_plugin_include \) -prune -o -name  "$2" -print`
		found_path=`find $3/CORE/all_plugin_include -name $2`
		cp -p $found_path $patchWorkArea/include/	
	#	ccm use $2
	elif [ "$1" = "bin_header" ]
	then
		cd $patchWorkArea/bin
		#ccm use $2
		found_path=`find $3 -type d \( -name ALLBATCH -o -name all_plugin_include \) -prune -o -name  "$2" -print`
		cp -p $found_path $patchWorkArea/bin

	elif [ "$1" = "library" ]
	then
		if [ "$platform" = "itanium" -o "$platform" = "hp64" ]
		then
			ls -ltr $3/$2 > /dev/null 2>&1
			if [ $? -ne 0 ]
			then
				deliverable=`echo $2 | sed 's/.so/.sl/'`
				ls -ltr $3/$deliverable > /dev/null 2>&1
				if [ $? -ne 0 ]
				then
					printf "\t[ERROR] $deliverable not found in the build work area. Not added to patch.\n"
				else
					printf "\t[INFO] $deliverable found in the build work area. Adding it to lib directory...\n"

				cp -p $3/$deliverable $patchWorkArea/lib/$deliverable
				#	ccm create -type $1  $patchWorkArea/lib/$deliverable
				fi
			else
				printf "\t[INFO] $2 found in the build work area. Adding it to lib directory...\n"
				cp -p $3/$deliverable $patchWorkArea/lib/$2
				#ccm create -type $1  $patchWorkArea/lib/$2
			fi
		else
			ls -ltr $3/$2 > /dev/null 2>&1
			if [ $? -eq 0 ]
			then
				printf "\t[INFO] $2 found in the build work area. Adding it to lib directory...\n"
				cp -p $3/$2 $patchWorkArea/lib/$2
			#	ccm create -type $1  $patchWorkArea/lib/$2
			else
				printf "\t[ERROR] $2 not found in the build work area. Not added to patch.\n"
			fi
		fi
	elif [ "$1" = "binary" ]
	then
		ls -ltr $3/$2 > /dev/null 2>&1
		if [ $? -eq 0 ]
		then
			printf "\t[INFO] $2 found in the build work area. Adding it to bin directory...\n"
			cp -p $3/$2 $patchWorkArea/bin/$2
			#ccm create -type $1 $patchWorkArea/bin/$2
		else
			printf "\t[ERROR] $2 not found in the build work area. Not added to patch\n"
		fi
	elif [ "$1" = "all_binary" ]
        then
                ls -ltr $3/bin.zip > /dev/null 2>&1
                if [ $? -eq 0 ]
                then
                        printf "\t[INFO] bin.zip found in the build work area. Adding it to bin directory...\n"
                        cp -p $3/bin.zip $patchWorkArea/bin/
                else
                        printf "\t[ERROR] bin.zip not found in the build work area. Not added to patch\n"
                fi
        elif [ "$1" = "all_library" ]
        then
                ls -ltr $3/lib.zip > /dev/null 2>&1
                if [ $? -eq 0 ]
                then
                        printf "\t[INFO] lib.zip found in the build work area. Adding it to lib directory...\n"
                        cp -p $3/lib.zip $patchWorkArea/lib/
                else
                        printf "\t[ERROR] lib.zip not found in the build work area. Not added to patch.\n"
                fi	
	else
		printf "\n"
	fi
	
}

############NEWLY_ADDED-2016/09/01 ###################
findPatchCompany()
{
project=$1
version=$2

BUILDWEB_DB="buildweb/georgespass@webca.world"
 sqlquery="select COMPANY from buildweb.patch_company where PROJECT='$project' and VERSION='$version'"

                Company=`sqlplus -s $BUILDWEB_DB << +END
                set feed off;
                set head off;
                set lines 32767;
                $sqlquery;
                exit;
+END`
echo "$Company"
}
function findParentRelease(){
	project=$1
	Company=$2
	BUILDWEB_DB="buildweb/georgespass@webca.world"
	sqlquery="select max(a.VERSION) from patch_company a,PATCH_SUMMARY b where a.VERSION = (select max(a.VERSION) from patch_company where a.COMPANY='${Company}' and a.PROJECT='$project') and b.PATCH_STATUS = 'Released' and a.VERSION=b.VERSION"
        parent_version=`sqlplus -s $BUILDWEB_DB << +END
                set feed off;
                set head off;
		set lines 32767;
		$sqlquery;
                exit;
+END`
echo "$parent_version"

}
function findParentRelease_RCno(){
	project=$1
	parent_version=$2

	BUILDWEB_DB="buildweb/georgespass@webca.world"
	sqlquery="select max(CAND_NAME) from test_cand_summary where project='$project' and version='${parent_version}'"
	parent_version_rc_no=`sqlplus -s $BUILDWEB_DB << +END
                set feed off;
                set head off;
		set lines 32767;
		$sqlquery;
                exit;
+END`
	echo "${parent_version_rc_no}"	

}

add_release_info_xml()
{
	project=$1
	version=$2
	#company=`findPatchCompany $project $version`
	#Parent_Version=`findParentRelease $project $company`
	Parent_Version=$3
	#Parent_Patch_RCno=`findParentRelease_RCno $project $Parent_Version`
	Parent_Patch_RCno=$4
	echo "**********ADDING RELEASE_INFO.XML***********"
	find_workarea=`echo $pathToAllDeliverables|sed 's/ALLBATCH//'`
	cp -p $find_workarea/configuration/infinys/release_information/release_info.xml $patchWorkArea/bin/
	if [ -f $patchWorkArea/bin/release_info.xml ]
	then
		echo "\n#############################################################################################\n"	
		cat $patchWorkArea/bin/release_info.xml
		echo "\n#############################################################################################\n"
		rel_proj=`cat $patchWorkArea/bin/release_info.xml|grep RB|grep -v encoding|head -1|cut -d" " -f1|cut -d"<" -f2`
		rel_version=`cat $patchWorkArea/bin/release_info.xml|grep version|grep -v encoding|head -1|cut -d" " -f2|cut -d"=" -f2|cut -d'"' -f2`
		r_rcno=`cat $patchWorkArea/bin/release_info.xml|grep version|grep -v encoding|head -1|cut -d" " -f3|cut -d"=" -f2|cut -d'"' -f2`
		rel_rcno=RC${r_rcno}
		rel_type=`cat $patchWorkArea/bin/release_info.xml|grep version|grep -v encoding|head -1|cut -d" " -f4|cut -d"=" -f2|cut -d'"' -f2`
		ret_parent_version=`cat $patchWorkArea/bin/release_info.xml|grep parent|cut -d"<" -f2|cut -d" " -f2|cut -d"=" -f2|cut -d '"' -f2`
		ret_parent_rcno=`cat $patchWorkArea/bin/release_info.xml|grep parent|cut -d"<" -f2|cut -d" " -f3|cut -d"=" -f2|cut -d '"' -f2`
		rel_schema_letter=`cat $patchWorkArea/bin/release_info.xml|grep letter|cut -d"<" -f2|cut -d" " -f3|cut -d"=" -f2|cut -d'"' -f2`
		find_workarea=`echo $pathToAllDeliverables|sed 's/ALLBATCH//'`
		build_schema_letter=`cat $find_workarea/SCHEMA/install/scripts/schema_VERSION.sh|grep "TOLETTER"|cut -d"=" -f2|cut -d '"' -f2`
		echo "rel_proj = $rel_proj"
		echo "rel_version = $rel_version"
		echo "r_rcno = $r_rcno"
		echo "rel_rcno = $rel_rcno"
		echo "rel_type = $rel_type"
		echo "ret_parent_version = $ret_parent_version"
		echo "ret_parent_rcno = $ret_parent_rcno"
		echo "parent_version = ${Parent_Version}"
		echo "parent_version_rc_no = ${Parent_Patch_RCno}"
		if [ ${project} = ${rel_proj} -a ${version} = ${rel_version} -a ${expectedRC} = ${rel_rcno} -a ${rel_type} = "incremental" -a ${Parent_Version} = ${ret_parent_version} -a ${Parent_Patch_RCno} = "RC${ret_parent_rcno}" -a ${build_schema_letter} = ${rel_schema_letter} ]
		then
			echo "Release_info.xml is correct"	
		else
			echo "Release_info.xml is incorrect, please correct it and run again"
			exit
		fi
	else
		echo "Relesae_info.xml is not present, please check and add"
		exit
	fi
}

############NEWLY_ADDED-2016/09/01 ###################

function compareCurrentAndPreviousRC(){
	printf "\t[INFO] Comparing previous RC(RC$previousRC) with current RC($expectedRC)...\n"
	cat /dev/null > /tmp/deliverables_in_synergy.tmp
	cat /dev/null > /tmp/deliverables_in_task.tmp
	sort /tmp/deliverables_in_synergy | sed '/^$/d' >> /tmp/deliverables_in_synergy.tmp
	mv /tmp/deliverables_in_synergy.tmp /tmp/deliverables_in_synergy
	sort /tmp/deliverables_in_task | sed '/^$/d' >> /tmp/deliverables_in_task.tmp
	mv /tmp/deliverables_in_task.tmp /tmp/deliverables_in_task
	tmp=`comm -23 /tmp/deliverables_in_synergy /tmp/deliverables_in_task`
	if [ "$tmp" = "" ]
	then
		printf "\t[INFO] No extra deliverables found in Synergy.\n"
	else
	for extraDeliverables in $tmp
	do
		#extra=`ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and name match '$extraDeliverables'" -f "%name:%version:%type:%subsystem"`
		printf "\t[INFO] Found deliverable $extra extra in Synergy. This is removed from the task."
		printf "\t[INFO] Unusing $extra..."
		if [ "$extra" != "" ]
		then
			cd $patchWorkArea
		        if [ "$isNewTaskCreated" = "" ]
		        then
                		createTask
		        fi
			#ccm unuse $extra
		fi
	done
	fi
}

function deliverablesToPrepState(){
		printf "\t[INFO] Putting deliverables into prep state...\n"
                #ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and status='working' and type!='dir'"
             #   ccm attr -m release -v $releaseTag @
             #   ccm attr -c platform -t string @
               # ccm attr -m platform -v $synergyPlatform @
             #   ccm attr -c is_product -v TRUE -t boolean -f @
              #  ccm checkin -nc @
}

function runCopyBuildObjects(){
if [ "$project" = "GENEVA" -a "$majorRelease" = "2.2" ]
then
        patchType="RBPATCH"
        majorRelease="5.4"
        tmp=`echo $releaseTag | sed -e "s/.*_//g" | cut -d'.' -f3-4`
        releaseNum=`echo $majorRelease.$tmp`
fi
                printf "\t[INFO] Copying deliverables to patch (copy_build_objects.sh -p $project-$projectType$releaseNum.$platform.$oracle  -u $userid -c $expectedRC)...\n"
		copy_build_objects_svn.sh -p $project-$projectType$releaseNum.$platform.$oracle  -u $userid -c $expectedRC
		
}
function checkinDefaultTask(){
	if [ "$isNewTaskCreated" = "true" ]
        then
		printf "\t[INFO] Finding if any working state objects are there or not in the patch...\n"
		#ccm query "is_member_of('$patchType-$projectType$releaseNum.$platform.$oracle') and status='working' and type!='dir'"
		if [ $? -eq 0 ]
		then
			printf "\t[INFO] Working state objects are found in the patch. Not checking in the default task: $newTaskCreated\n"
		else
			printf "\t[INFO] No working state objects found in the patch...\n"
			printf "\t[INFO] Checking in default task $newTaskCreated...\n"
			#ccm task -checkin default
		fi
        fi
}
