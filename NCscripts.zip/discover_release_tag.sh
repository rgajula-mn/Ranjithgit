#!/bin/ksh
#
# PLEASE NOTE! THIS SCRIPT IS KORN SHELL AND NOT BOURNE SCHELL BECAUSE
# GETOPTS DOES NOT WORK ON TRU64 IN BOURNE SHELL - DO NOT CHANGE!
#
#  Script:		discover_release_tag.sh
#  Instance:		1
#  Author:		sg
#  Start date:		Fri Mar 22 09:31:11 2002
#  Version:		%full_filespec: discover_release_tag.sh-21:shsrc:CB1#1 %
#
#  Description:		
#
#
# (C) Convergys, 2001.                                          
# Convergys refers to Convergys Corporation or any of its wholly owned
# subsidiaries.

usage()
{
    echo " "
    echo "Usage: $0 <-r Release> <-p Project> [-h]"
    echo "  e.g. $0 -r 4.0.17 -p GENEVA"
    echo " "
    echo "  This will work out the release tag for the GENEVA 4.0.17"
    echo " "
    echo "  Setting -h will display this usage page."
    echo "  Setting -i will display the release project."
    echo " "
    exit 1
}

while getopts ir:p:t:h the_option
do
        case $the_option in
        r)
                release="$OPTARG"
                ;;
        h)
                usage
                ;;
	i)
		release_proj=1
		;;
        p)
                project="$OPTARG"
                ;;
	t)
		release_tag="$OPTARG"
		;;
        [?])
                usage
                ;;
        esac
done

if [ ! -z "${release_tag}" ]
then
	short_proj=`echo $release_tag | cut -d'_' -f1`
	version=`echo $release_tag | cut -d'_' -f2`
	major_release=`echo $version | cut -d'.' -f1-2`

	case $short_proj in
		GEN)
			if [ "$release_proj" = "1" ]
			then
				if [ "$major_release" = "5.4" -o "$major_release" = "2.2" ]
				then
					echo "RB $version"
				else
					echo "GENEVA $version"
				fi
			else
				echo "GENEVA $version"
			fi
			;;
		TAP)
			echo "TAP3 $version"
			;;
		*)
			echo "$short_proj $version"
			;;
	esac
	exit 0
			
fi

if [ -z "$release" -o -z "$project" ]
then
	echo "You passed in the command: $0 $*"
        usage
fi

case $project in
        GENEVA)
                case $release in
                # No Prefix
                        3.2.30)
                                echo "$release"
                                ;;
                        4.0.22)
                                echo "$release"
                                ;;
                        4.0.22.*)
                                echo "$release"
                                ;;
                        4.1.19)
                                echo "$release"
                                ;;
                        4.1.19.*)
                                echo "$release"
                                ;;
                        4.1.20)
                                echo "$release"
                                ;;
                        4.1.20.*)
                                echo "$release"
                                ;;
                        4.2.13.*)
                                echo "$release"
                                ;;
                        4.2.14.*)
                                echo "$release"
                                ;;
                        4.2.14)
                                echo "$release"
                                ;;
                # CORE_ prefix
                        5.0.3)
                                echo "CORE_$release"
                                ;;
                        5.0.4)
                                echo "CORE_$release"
                                ;;
                        5.0.4.*)
                                echo "CORE_$release"
                                ;;
                        5.0.5)
                                echo "CORE_$release"
                                ;;
                        5.0.5.*)
                                echo "CORE_$release"
                                ;;
                        5.1.0)
                                echo "CORE_$release"
                                ;;
                        5.1.0.*)
                                echo "CORE_$release"
                                ;;
                        5.1.1)
                                echo "CORE_$release"
                                ;;
                        5.1.1.*)
                                echo "CORE_$release"
                                ;;
                        5.1.1_MB)
                                echo "CORE_$release"
                                ;;
		# IRB_ prefix
			2.3.*)
				echo "IRB_$release"
				;;
                # GEN_ prefix
                        *)
                                echo "GEN_$release"
                                ;;
                esac
                ;;
        TAP3)
                echo "TAP_$release"
                ;;
	CSA)
		echo "CSA_$release"
		;;
	WSC)
		echo "WSC_$release"
		;;
	UCMS)
		echo "UCMS_$release"
		;;
	GASL)
		echo "GASL_$release"
		;;
	ECA)
                case $release in
                        5.1.*|5.2.*)
                                echo "ECA_$release"
                                ;;
                        5.4.*|2.2.*)
                                rb_release=`echo $release | sed -e 's/^2.2/5.4/'`
                                echo "GEN_$rb_release"
                                ;;
			*)
                                echo "RB_$release"
                                ;;
		esac
		;;
	JAVACORE)
		echo "WEBCORE_$release"
		;;
	GNVMERCAPI)
		echo "ECA_$release"
		;;
	GENEVAAPI)
		echo "GEN_$release"
		;;
	CORE)
		echo "GEN_$release"
		;;
	PFCORE)
		echo "PFCORE_$release"
		;;
	RB)
		case $release in
			5.4.*|2.2.*)
                                rb_release=`echo $release | sed -e 's/^2.2/5.4/'`
				echo "GEN_$rb_release"
				;;
			*)
				echo "RB_$release"
				;;
		esac
	
		;;
	RBAPI)
		echo "RB_$release"
		;;
	*)
        # Any other Solution project
                echo "${project}_${release}"
                ;;
esac
















