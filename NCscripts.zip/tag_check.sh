#!/bin/bash
set -x

tag_url=$1

#checkTagStatus()
#{
if curl -u genadmin:Fr0sties --output /dev/null --silent --head --fail "$tag_url"
then
	val="true"
else
	val="false"
fi
#}

echo "$val"
