#!/bin/sh
# 
# ccm_functions

check_env() {
        if [ -z "$LOGNAME" ]
        then
            echo "Error: LOGNAME not set "
            exit 1
        fi

        if [ -z "$CCM_HOME" ]
        then
            echo "Error: CCM_HOME not set "
            exit 1
        fi

	if [ -z "$BCE_ROOT" -o -z "$BCE_ADMIN" -o -z "$BCE_LOG" -o -z "$BCE_BUILD_SCRIPTS" -o -z "$BCE_TEST_SCRIPTS" ]
	then
		echo "Error: .bce.ini not ran"
		echo "Need to have all the following vars set:"
		echo "	BCE_ROOT=$BCE_ROOT"
		echo "	BCE_LOG=$BCE_LOG"
		echo "	BCE_ADMIN=$BCE_ADMIN"
		echo "	BCE_BUILD_SCRIPTS=$BCE_BUILD_SCRIPTS"
		echo "	BCE_TEST_SCRIPTS=$BCE_TEST_SCRIPTS"
		exit 1
	fi
		
}

sol_to_geneva_conv() {
	case $THE_PROJECT in
		AMI*)
			BASERELEASE="oneoff"
			BASEPROJECT="RB" ;;
		 DQC*)
                        BASERELEASE="oneoff"
                        BASEPROJECT="RB" ;;

		BCMPLUS*)
			BASERELEASE="4.1"
			BASEPROJECT="GENEVA" ;;
		APR*)
			BASERELEASE="oneoff"
			BASEPROJECT="RB" ;;
		PCMI*|ECAPCMI*)
			case $BASERELEASE in
			1.0)
				BASERELEASE="5.0"
				BASEPROJECT="RB" ;;
			1.1)
				BASERELEASE="5.1"
				BASEPROJECT="RB" ;;
			1.2)
				BASERELEASE="5.2"
				BASEPROJECT="RB" ;;
			1.3)
				BASERELEASE="5.3"
				BASEPROJECT="RB" ;;
			1.4)
				BASERELEASE="6.0"
				BASEPROJECT="RB" ;;
			1.5)
				BASERELEASE="6.1"
				BASEPROJECT="RB" ;;
			1.6)
				BASERELEASE="7.0"
				BASEPROJECT="RB" ;;
			1.7)
				BASERELEASE="8.0"
				BASEPROJECT="RB" ;;
			 1.8)
                                BASERELEASE="9.0"
                                BASEPROJECT="RB" ;;
			esac ;;
		TAP*|RMS*|GII*)
			case $BASERELEASE in
				6.1)
					BASERELEASE="5.0"
					BASEPROJECT="GENEVA" ;;
				6.2)
					BASERELEASE="5.1"
					BASEPROJECT="GENEVA" ;;
				7.1)
					BASERELEASE="5.1"
					BASEPROJECT="GENEVA" ;;
				7.2)
					BASERELEASE="5.2"
					BASEPROJECT="GENEVA" ;;
				7.3)
					BASERELEASE="5.3"
					BASEPROJECT="GENEVA" ;;
				7.4|8.3)
					BASERELEASE="5.4"
					BASEPROJECT="GENEVA" ;;
				8.4)
					BASERELEASE="3.0"
					BASEPROJECT="RB" ;;
				8.5)
					BASERELEASE="4.0"
					BASEPROJECT="RB" ;;
				8.6)
					BASERELEASE="4.1"
					BASEPROJECT="RB" ;;
				8.7)
					BASERELEASE="4.2"
					BASEPROJECT="RB" ;;
				8.8)
					BASERELEASE="4.3"
					BASEPROJECT="RB" ;;
				8.9)
					BASERELEASE="4.4"
					BASEPROJECT="RB" ;;
				8.10)
					BASERELEASE="5.0"
					BASEPROJECT="RB" ;;
				8.11)
					BASERELEASE="5.1"
					BASEPROJECT="RB" ;;
				8.12)
                                        BASERELEASE="5.2"
                                        BASEPROJECT="RB" ;;
				8.13)
                                        BASERELEASE="5.3"
                                        BASEPROJECT="RB" ;;
				8.14)
                                        BASERELEASE="6.0"
                                        BASEPROJECT="RB" ;;
				8.15)
                                        BASERELEASE="6.1"
                                        BASEPROJECT="RB" ;;
				8.16)
                                        BASERELEASE="7.0"
                                        BASEPROJECT="RB" ;;
				8.17)
                                        BASERELEASE="8.0"
                                        BASEPROJECT="RB" ;;
				8.18)
                                        BASERELEASE="9.0"
                                        BASEPROJECT="RB" ;;

				*0)
					BASERELEASE="4.1"
					BASEPROJECT="GENEVA" ;;
				*1)
					BASERELEASE="4.2"
					BASEPROJECT="GENEVA" ;;
				*2)
					BASERELEASE="5.0"
					BASEPROJECT="GENEVA" ;;
				*3)
					BASERELEASE="5.1"
					BASEPROJECT="GENEVA" ;;
				*4)
					BASERELEASE="5.2"
					BASEPROJECT="GENEVA" ;;
				*)
					echo ERROR $BASERELEASE - unrecognised $THE_PROJECT version;
					return 2 ;;
			esac ;;
		GNI*)
			case $BASERELEASE in
				*0)
					BASERELEASE="5.1"
					BASEPROJECT="GENEVA" ;;
				*1)
                                        BASERELEASE="5.2"
					BASEPROJECT="GENEVA" ;;
				*2)
                                        BASERELEASE="5.3"
					BASEPROJECT="GENEVA" ;;
				*)
					echo ERROR $BASERELEASE - unrecognised $THE_PROJECT version;
					return 2 ;;
			esac ;;
		ALU*)
			BASEPROJECT="RB" ;;
		NML*)
			case $BASERELEASE in
				1.0)
					BASERELEASE="4.1"
					BASEPROJECT="GENEVA" ;;
				1.1)
					BASERELEASE="4.2"
					BASEPROJECT="GENEVA" ;;
				1.2)
					BASERELEASE="5.0"
					BASEPROJECT="GENEVA" ;;
				1.3)
					BASERELEASE="5.1"
					BASEPROJECT="GENEVA" ;;
				1.4)
					BASERELEASE="5.2"
					BASEPROJECT="GENEVA" ;;
				2.2)
					BASERELEASE="5.4"
					BASEPROJECT="GENEVA" ;;
				*)
					echo ERROR $BASERELEASE - unrecognised $THE_PROJECT version;
					return 2 ;;
			esac ;;
		SPD*)
			case $BASERELEASE in
				3.1)
					BASERELEASE="5.1"
					BASEPROJECT="GENEVA" ;;
				3.3)
					BASERELEASE="5.3"
					BASEPROJECT="GENEVA" ;;
				*0)
					BASERELEASE="4.1"
					BASEPROJECT="GENEVA" ;;
				*1)
					BASERELEASE="4.2"
					BASEPROJECT="GENEVA" ;;
				*2)
					BASERELEASE="5.0"
					BASEPROJECT="GENEVA" ;;
				*)
					echo ERROR $BASERELEASE - unrecognised $THE_PROJECT version;
					return 2 ;;
			esac ;;
		PI*)
			case $BASERELEASE in
				3.0)
					BASERELEASE="3.0"
					BASEPROJECT="RB" ;;
				  *)
					echo ERROR $BASERELEASE = unrecognised $THE_PROJECT version;
					return 2 ;;
		        esac ;;
		GPI*)
			case $BASERELEASE in
				4.1)
					BASERELEASE="5.2"
					BASEPROJECT="GENEVA" ;;
				4.2)
					BASERELEASE="5.3"
					BASEPROJECT="GENEVA" ;;
				4.3)
					BASERELEASE="5.4"
					BASEPROJECT="GENEVA" ;;
				*)
					echo ERROR $BASERELEASE - unrecognised $THE_PROJECT version;
					return 2 ;;
			esac ;;		
		VIT*)
			case $BASERELEASE in
				3.1)
					BASERELEASE="oneoff" ;;
				2.4)
					BASERELEASE="5.1"
					BASEPROJECT="GENEVA" ;;
				2.1)
					BASERELEASE="4.1"
					BASEPROJECT="GENEVA" ;;
				2.2)
					BASERELEASE="4.2"
					BASEPROJECT="GENEVA" ;;
				2.3)
					BASERELEASE="5.0"
					BASEPROJECT="GENEVA" ;;
				*)
					BASERELEASE="oneoff" ;;
			esac ;;

                VI_X*|VI_STQ*|VI_CTL*)
			BASEPROJECT="RB" ;;
 
		VI*)
			BASEPROJECT="RB" ;;
		GVI*)
			case $BASERELEASE in
				2.1)
					BASERELEASE="4.2"
					BASEPROJECT="GENEVA" ;;
				2.2)
					BASERELEASE="5.0"
					BASEPROJECT="GENEVA" ;;
				2.3)
					BASERELEASE="5.1"
					BASEPROJECT="GENEVA" ;;
				3.1)
					BASERELEASE="5.2"
					BASEPROJECT="GENEVA" ;;
				3.2)
					BASERELEASE="5.3"
					BASEPROJECT="GENEVA" ;;
				4.1)
					BASERELEASE="5.4"
					BASEPROJECT="GENEVA" ;;
				  *)
					echo ERROR $BASERELEASE = unrecognised $THE_PROJECT version;
					return 2 ;;
		        esac ;;
		PFCORE*)
			case $BASERELEASE in
				2.2)
					BASERELEASE="5.4"
					BASEPROJECT="GENEVA" ;;
				  *)
					echo ERROR $BASERELEASE = unrecognised $THE_PROJECT version;
					return 2 ;;
			esac ;;
		WSC*)
			case $BASERELEASE in
				*)
					BASERELEASE="oneoff"
					BASEPROJECT=$THE_PROJECT ;;
			esac ;;
		#commented the below lines for RB_5.1 release onwards (13/05/2010)
		#ECA*)
		#	case $BASERELEASE in
		#		5.1|5.2|5.3|5.3IN)
		#			BASERELEASE="oneoff" 
		#			BASEPROJECT=$THE_PROJECT ;;
		#	esac ;;
                CSA*)
			case $BASERELEASE in
				*)
					BASERELEASE="oneoff" 
					BASEPROJECT=$THE_PROJECT ;;
			esac ;;
                CPG*)
			case $BASERELEASE in
				*)
					BASERELEASE="oneoff" 
					BASEPROJECT=$THE_PROJECT ;;
			esac ;;
		GENEVAWEB*)
			case $BASERELEASE in
				*)
					BASERELEASE="oneoff" 
					BASEPROJECT=$THE_PROJECT ;;
			esac ;;
		GENEVAAPI*)
			case $BASERELEASE in
				*)
					BASERELEASE="web" 
					BASEPROJECT=$THE_PROJECT ;;
			esac ;;
		JAVACORE*)
			case $BASERELEASE in
				*)
					BASERELEASE="web" 
					BASEPROJECT=$THE_PROJECT ;;
			esac ;;
		WEBCORE*)
			case $BASERELEASE in
				*)
					BASERELEASE="web" 
					BASEPROJECT=$THE_PROJECT ;;
			esac ;;
		UCMS*)
			case $BASERELEASE in
				*)
					BASERELEASE="oneoff" 
					BASEPROJECT=$THE_PROJECT ;;
			esac ;;
                CSDSYSTEST*)
			case $BASERELEASE in
				*)
					BASERELEASE="oneoff" 
					BASEPROJECT=$THE_PROJECT ;;
			esac ;;
		GENEVA*|RB*|RTCA*|PF*)
			BASERELEASE=$BASERELEASE
			BASEPROJECT=$THE_PROJECT
			;;
		*)
			echo ERROR -$THE_PROJECT- not a solution recognised by sol_to_geneva_conv;
			return 1 ;;
	esac
	return 0;
}

what_is_project()
{
	case $THE_PROJECT in
		AMI*)
			PROJECT_ARENA="WEB" ;;
		DQC*)
                        PROJECT_ARENA="WEB" ;;
		APR*)
			PROJECT_ARENA="WEB" ;;
		BCMPLUS*)
			PROJECT_ARENA="AC" ;;
		TAP3*)
			PROJECT_ARENA="AC" ;;
		PCMI*|ECAPCMI*)
			PROJECT_ARENA="WEB" ;;
		PI*|GPI*)
			PROJECT_ARENA="AC" ;;
		SPD*)
			PROJECT_ARENA="AC" ;;
		VIT*)
			PROJECT_ARENA="SOL" ;;
		VI*|GVI*|VI_X|VI_STQ|VI_CTL)
			PROJECT_ARENA="AC" ;;
		RMS*)
			PROJECT_ARENA="AC" ;;
		ALU*)
			PROJECT_ARENA="AC" ;;
		NML*)
			PROJECT_ARENA="AC" ;;
		GII*)
			PROJECT_ARENA="AC" ;;
		WSC*)
			PROJECT_ARENA="WEB" ;;
		CPG*)
			PROJECT_ARENA="SOL" ;;
		GENEVAWEB*)
			PROJECT_ARENA="WEB" ;;
		GENEVAAPI*) 
			PROJECT_ARENA="WEB" ;;
		GENEVA*)
			PROJECT_ARENA="GEN" ;;
		RBAPI*)
			PROJECT_ARENA="WEB" ;;
		RB*)
			PROJECT_ARENA="GEN" ;;
		PF*)
			PROJECT_ARENA="GEN" ;;
		RTCA*)
			PROJECT_ARENA="GEN" ;;
		PHT*)
			PROJECT_ARENA="GEN" ;;
		GNI*)
			PROJECT_ARENA="AC" ;;
		GNICSA*)
			PROJECT_ARENA="WEB" ;;
		UCMS*)
			PROJECT_ARENA="WEB" ;;
		CSA*) 
			PROJECT_ARENA="WEB" ;;
		ECA*) 
			PROJECT_ARENA="WEB" ;;
		WSC*) 
			PROJECT_ARENA="WEB" ;;
		GASL*) 
			PROJECT_ARENA="WEB" ;;
		GNVMERCAPI*)
			PROJECT_ARENA="WEB" ;;
		PFCORE*)
			PROJECT_ARENA="PFCORE" ;;
		*)
			echo WARNING: what_is_project: $THE_PROJECT - unrecognised project ;
			echo default PROJECT_ARENA=DEF set ;
			PROJECT_ARENA="DEF" ;;
	esac
}
			
is_project_a_solution() {
	case $THE_PROJECT in
		AMI*)
			SOLUTION="yes" ;;
		DQC*)
                        SOLUTION="yes" ;;

		APR*)
			SOLUTION="yes" ;;
		PCMI*|ECAPCMI*)
			SOLUTION="yes" ;;
		BCMPLUS*)
			SOLUTION="yes" ;;
		TAP3*)
			SOLUTION="yes" ;;
		CPG*|PI*|GPI*)
			SOLUTION="yes" ;;
		CSA*)
			SOLUTION="yes" ;;
		SPD*)
			SOLUTION="yes" ;;
		VI*|GVI*)
			SOLUTION="yes" ;;
		VIT*)
			SOLUTION="yes" ;;
		RMS*)
			SOLUTION="yes" ;;
		ALU*)
			SOLUTION="yes" ;;
		NML*)
			SOLUTION="yes" ;;
		GII*)
			SOLUTION="yes" ;;
		WSC*)
			SOLUTION="yes" ;;
	        ECA*)
			SOLUTION="yes" ;;
		CSA*)
			SOLUTION="yes" ;;
		GENEVAWEB*)
			SOLUTION="yes" ;;
		GENEVA*)
			SOLUTION="no" ;;
		RB*)
			SOLUTION="no" ;;
		PF*)
			SOLUTION="no" ;;
		RTCA*)
			SOLUTION="no" ;;
		PHT*)
			SOLUTION="no" ;;
		GNI*)
			SOLUTION="yes" ;;
		UCMS*)
			SOLUTION="yes" ;;
		PFCORE*)
			SOLUTION="no" ;;
		*)
			echo WARNING $THE_PROJECT - unrecognised project ;
			echo default PROJECT NOT SOLUTION set ;
			SOLUTION="no" ;;
	esac
}
		
		

get_platform_list() {
	just_internal=$1

# Any platforms that you wish to release please enter here:
	case $BASEPROJECT in
		GENEVA*)
			case $BASERELEASE in
				4.0)
					PLATFORM_LIST="a8" ;;
				4.1)
					PLATFORM_LIST="t8i" ;;
				4.2)
					PLATFORM_LIST="a8i s8i" ;;
				5.0)
					PLATFORM_LIST="a8i s8i" ;;
				5.1)
					PLATFORM_LIST="64h8i t8i a9i2 s9i2" ;;
				5.2)
					PLATFORM_LIST="a9i2 h9i2 i9i2 s9i2 t9i2" ;;
				5.3)
					PLATFORM_LIST="a9i2 h9i2 s9i2 t9i2 l10g";;
				5.3IN)
					PLATFORM_LIST="s9i2 s32at";;
				5.4)
					PLATFORM_LIST="s9i2 s32at s10g a9i2 a10g h9i2 h10g i9i2 i10g t9i2 t10g l10g l9i2" ;;
				5.4TS)
					PLATFORM_LIST="a9i2 a10g h9i2 h10g i9i2 i10g s32at s9i2 s10g t9i2 t10g l10g" ;;
				oneoff)
					PLATFORM_LIST="oneoff" ;;
				web)
					PLATFORM_LIST="web" ;;
				gii*)
					PLATFORM_LIST="a9i 64h9i s9i t9i" ;;
				GENEVALANG*)
					PLATFORM_LIST="DEU ESN FRA ITA" ;;
				*)
					echo ERROR - $BASEPROJECT $BASERELEASE- - unrecognised release ;
					exit 1 ;;
			esac
			;;
		RB*|RTCA*|PF*)
			case $BASERELEASE in
			        2.2)
					PLATFORM_LIST="a9i2 a10g h9i2 h10g i9i2 i10g s9i2 s10g t9i2 t10g l10g l9i2 s32at" ;;
				3.0)
					PLATFORM_LIST="a10g i10g s10g l10g s32at" ;;
				3.1)
					PLATFORM_LIST="a10g i10g s10g l10g wl10g jb10g ws10g s32at" ;;
				3.2)
                                        PLATFORM_LIST="a10g i10g s10g l10g s32at" ;;
				4.0)
					PLATFORM_LIST="a10g i10g s10g l10g" ;;
				4.1)
					PLATFORM_LIST="a10g i10g s10g l10g wl10g jb10g" ;;
				4.2)
					PLATFORM_LIST="a10g i10g s10g l10g" ;;
				4.3)
					PLATFORM_LIST="a10g i10g s10g l10g a11g i11g s11g l11g" ;;
				4.4)
					PLATFORM_LIST="a10g i10g s10g l10g a11g i11g s11g l11g" ;;
				5.0)
					PLATFORM_LIST="a10g i10g s10g l10g a11g i11g s11g l11g" ;;
				5.1)
					PLATFORM_LIST="a11g i11g s11g l11g" ;;
				5.2)
					PLATFORM_LIST="a11g i11g s11g l11g" ;;
				5.3)
					PLATFORM_LIST="a11g i11g s11g l11g" ;;
				6.0)
					PLATFORM_LIST="a11g i11g s11g l11g" ;;
				6.1)
					PLATFORM_LIST="a11g i11g s11g l11g" ;;
				7.0)
					PLATFORM_LIST="a11g i11g s11g l11g sl11g" ;;
				8.0)
					PLATFORM_LIST="a11g i11g s11g l11g sl11g a12c i12c s12c l12c" ;;
			        9.0)
                                        PLATFORM_LIST="a12c i12c s12c l12c a11g i11g s11g l11g" ;;

				oneoff)
					PLATFORM_LIST="oneoff" ;;
				web)
					PLATFORM_LIST="web" ;;
				*)
					echo ERROR - $BASEPROJECT $BASERELEASE - unrecognised release ;
					exit 1 ;;
			esac
			;;
		ECA*)
			case $BASERELEASE in
			        2.2)
					PLATFORM_LIST="j9i2 j10g" ;;
				3.0)
					PLATFORM_LIST="wl10g jb10g ws10g" ;;
				3.1)
					PLATFORM_LIST="wl10g jb10g ws10g" ;;
				3.2)
                                        PLATFORM_LIST="wl10g jb10g ws10g" ;;
				4.0)
					PLATFORM_LIST="wl10g jb10g" ;;
				4.1)
					PLATFORM_LIST="wl10g jb10g" ;;
				4.2)
					PLATFORM_LIST="wl10g jb10g" ;;
				4.3)
					PLATFORM_LIST="wl10g jb10g" ;;
				4.4)
					PLATFORM_LIST="wl10g jb10g" ;;
				5.0)
					PLATFORM_LIST="wl10g jb10g" ;;
				5.1)
					PLATFORM_LIST="wl11g jb11g" ;;
				5.2)
					PLATFORM_LIST="wl11g jb11g" ;;
				5.3)
					PLATFORM_LIST="wl11g jb11g" ;;
				6.0)
					PLATFORM_LIST="wl11g jb11g" ;;
				6.1)
					PLATFORM_LIST="wl11g jb11g" ;;
				7.0)
					PLATFORM_LIST="wl11g jb11g" ;;
				8.0)
					PLATFORM_LIST="wl11g jb11g" ;;
				9.0)
                                        PLATFORM_LIST="wl12c jb12c" ;;

				*)
					echo ERROR - $BASEPROJECT $BASERELEASE - unrecognised release ;
					exit 1 ;;
			esac				
			;;	
		*)
			echo ERROR - $BASEPROJECT - unrecognised project ;
			exit 1 ;;
	esac

# Any platforms that should not be released only enter here:

	if [ ! -z "$just_internal" ]
	then
		case $BASEPROJECT in
			GENEVA*)
				case $BASERELEASE in
					3.1)
						PLATFORM_LIST="$PLATFORM_LIST" ;;
					4.0)
						PLATFORM_LIST="$PLATFORM_LIST" ;;
					4.1)
						PLATFORM_LIST="$PLATFORM_LIST" ;;
					4.2)
						PLATFORM_LIST="$PLATFORM_LIST" ;;
					5.0)
						PLATFORM_LIST="$PLATFORM_LIST 64h8i" ;;
					5.1)
						PLATFORM_LIST="$PLATFORM_LIST" ;;
					5.2)
						PLATFORM_LIST="$PLATFORM_LIST l9i2" ;;
					5.3)
						PLATFORM_LIST="$PLATFORM_LIST l9i2";;
					5.3IN)
						PLATFORM_LIST="$PLATFORM_LIST";;
					5.4)
						PLATFORM_LIST="$PLATFORM_LIST";;
					5.4TS)
						PLATFORM_LIST="$PLATFORM_LIST l9i2";;
					oneoff)
						PLATFORM_LIST="$PLATFORM_LIST" ;;
					web)
						PLATFORM_LIST="$PLATFORM_LIST" ;;
					gii*)
						PLATFORM_LIST="$PLATFORM_LIST" ;;
					GENEVALANG*)
						PLATFORM_LIST="$PLATFORM_LIST" ;;
					*)
						echo ERROR $BASERELEASE - unrecognised release ;
						exit 1 ;;
				esac
				;;
			RB*|RTCA*|PF*)
				case $BASERELEASE in
					2.2)
						PLATFORM_LIST="$PLATFORM_LIST";;
					3.0|3.2)
						PLATFORM_LIST="$PLATFORM_LIST";;
					3.1)
						PLATFORM_LIST="$PLATFORM_LIST";;
					4.0|4.1|4.2|4.3|4.4|5.0|5.1|5.2|5.3|6.0|6.1|7.0|8.0|9.0)
						PLATFORM_LIST="$PLATFORM_LIST";;
					oneoff)
						PLATFORM_LIST="$PLATFORM_LIST" ;;
					web)
						PLATFORM_LIST="$PLATFORM_LIST" ;;
					*)
						echo ERROR $BASERELEASE - unrecognised release ;
						exit 1 ;;
				esac
				;;
			*)
				echo ERROR - $BASEPROJECT - unrecognised project ;
				;;
		esac
	fi
	
}

get_platform () {
	get_platform_from_platform_id
}

get_platform_from_platform_name() 
{
	check_env

	if [ -z "$PLATFORM_NAME" ]
	then
		echo "Error: PLATFORM_NAME is blank"
		return 1
	fi
	full_line=`grep "$PLATFORM_NAME" ${BCE_ADMIN}/config/ccm_platform_details`
	if [ $? -ne  0 ]
	then
		echo "Error: Cannot find $PLATFORM_NAME"
		return 1
	fi
	PLATFORM_ID=`echo $full_line | awk '{print $1}'`
	PLATFORM_CCM=`echo $full_line | awk '{print $2}'`
	PLATFORM_INF_ID=`echo $full_line | awk '{print $4}'`
	return 0
}

get_platform_from_platform_ccm() 
{
	check_env

	if [ -z "$PLATFORM_CCM" ]
	then
		echo "Error: PLATFORM_CCM is blank"
		return 1
	fi
	full_line=`grep "$PLATFORM_CCM" ${BCE_ADMIN}/config/ccm_platform_details`
	if [ $? -ne  0 ]
	then
		echo "Error: Cannot find $PLATFORM_CCM"
		return 1
	fi
	PLATFORM_ID=`echo $full_line | awk '{print $1}'`
	PLATFORM_NAME=`echo $full_line | awk '{print $3}'`
	PLATFORM_INF_ID=`echo $full_line | awk '{print $4}'`
	return 0
}

get_platform_from_platform_id() 
{
	check_env

	if [ -z "$PLATFORM_ID" ]
	then
		echo "Error: PLATFORM_ID is blank"
		return 1
	fi
	full_line=`grep "^$PLATFORM_ID" ${BCE_ADMIN}/config/ccm_platform_details`
	if [ $? -ne  0 ]
	then
		echo "Error: Cannot find $PLATFORM_ID"
		return 1
	fi
	PLATFORM_CCM=`echo $full_line | awk '{print $2}'`
	PLATFORM_NAME=`echo $full_line | awk '{print $3}'`
	PLATFORM_INF_ID=`echo $full_line | awk '{print $4}'`
	return 0
}

get_platform_from_platform_inf_id() 
{
	check_env

	if [ -z "$PLATFORM_INF_ID" ]
	then
		echo "Error: PLATFORM_INF_ID is blank"
		return 1
	fi
	full_line=`grep "	$PLATFORM_INF_ID$" ${BCE_ADMIN}/config/ccm_platform_details`
	if [ $? -ne  0 ]
	then
		echo "Error: Cannot find $PLATFORM_INF_ID"
		return 1
	fi
	PLATFORM_ID=`echo $full_line | awk '{print $1}'`
	PLATFORM_CCM=`echo $full_line | awk '{print $2}'`
	PLATFORM_NAME=`echo $full_line | awk '{print $3}'`
	return 0
}

# 0 = old geneva
# 1 = new infinys
am_i_old_geneva()
{
	am_i_old_geneva_project=$1
	am_i_old_geneva_release=$2

	am_i_old_major_release=`echo $am_i_old_geneva_release | cut -d'.' -f1-2`

	case $am_i_old_geneva_project in
		GENEVA)
			return 0
			;;
		RB|VI*|PI|AMI|ALU|APR|PCMI|ECAPCMI|RTCA|DQC|PF)
			return 1
			;;
		TAP3|TAP)
			case $am_i_old_major_release in
				2.1|3.1|6.1|6.2|7.1|7.2|7.3)
					return 0
					;;
				*)
					return 1
					;;
			esac
			;;
		ECA)
		#Commented the below lines for RB_5.1 release onwards (13/05/2010)
		#	case $am_i_old_major_release in
		#		5.1|5.2|5.3|5.3IN)
		#			return 0
		#			;;
		#		*)
					return 1
					;;
		#	esac
		#	;;
		GVI)
			if [ "$am_i_old_major_release" = "4.1" ]
			then
				return 1
			else
				return 0
			fi
			;;
		NML)
			int_release=`echo $am_i_old_major_release | cut -d. -f1`
			if [ $int_release -eq 1 ]
			then
				return 0
			else
				return 1
			fi
			;;
		GPI)
			case $am_i_old_major_release in
				4.1|4.2)
					return 0
			        	;;
				*)
					return 1
					;;
			esac
			;;
		*)
			return 0
			;;
	esac
}
