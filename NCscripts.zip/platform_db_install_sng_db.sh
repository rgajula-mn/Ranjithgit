#!/bin/sh
#set -x
if [ -z "${BCE_BUILD_SCRIPTS}" ]
then
	BCE_BUILD_SCRIPTS=/irb/bce/admin/build_scripts
fi

. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh

BUILDWEB_DB=`buildweb_connection`

platform_root=$1
db_sid=$2
JAVA_HOME=$3
schema_base_name=$4
pf_tmp_dir=$5
#dbspec=`echo $schema_base_name|cut -d '_' -f2-10|sed -e 's/sqa//g'|sed -e 's/_//g'`
dbspec=`echo $schema_base_name`

usage()
{
	echo "Usage: $0 <PF Location> <DB SID> <JAVA HOME> <BASE_NAME> [TMP Work Area]"
	echo "Where"
	echo "   <PF Location>   = The location where all the platforms OSs for this release reside for example"
	echo "      /irb/infinys/release/platform/IPF4.0/IPF4.0.4.2"
	echo "   <BASE NAME>     = The prefix to all the schemas that are created for example (Max 6 characters):"
	echo "      	sg_40F"
	echo "   [TMP Work Area] = An area for the script to write working files while the installation runs, the script will completed delete the directory once it completes... required when running on non-UK systems"
	echo "Currently you have"
	echo "   <PF Location>   = $platform_root"
	echo "   <DB SID>        = $db_sid"
	echo "   <JAVA HOME>     = $JAVA_HOME"
	echo "   <BASE NAME>     = $schema_base_name"
	echo "   <TMP Work Area> = $pf_tmp_dir"
	echo ""
	echo "You must also have the following environments set (correctly)"
	echo "   ORACLE_HOME i.e. /opt/oracle/10.2.0.3.SE"
	echo "   LD_LIBRARY_PATH=\$ORACLE_HOME/lib"
	echo "   PATH=\$ORACLE_HOME/bin:\$PATH"
	exit 1
}

export JAVA_HOME

get_db_machine_from_sid ()
{
	sid_uc=`echo $db_sid | tr '[a-z]' '[A-Z]'`
	sql="select host from bce_databases where sid='$sid_uc'"
	
	sql_query $BUILDWEB_DB "$sql" "n"
	
}

db_machine1=`get_db_machine_from_sid`
db_machine=`echo $db_machine1`


if [ $# -lt 4 ]
then
	usage
fi

orig_pwd=`pwd`
# Create a working copy for the schema Installation
#
if [ ! -z "$pf_tmp_dir" ]
then
	pf_tmp_dir_plus=$pf_tmp_dir/tmp$$
fi

# Section added by Dave B to copy platform dir to local disk for byron and dickens 21-Oct-08
HOSTNAME=`uname -n`
if [ "${HOSTNAME}" = "dickens" -o "${HOSTNAME}" = "byron" ];then
	tmp_platform_location=/rtests/${LOGNAME}/$schema_base_name.$$
else
	tmp_platform_location=${pf_tmp_dir_plus:-/irb/archive/archive3/platform_installs/${LOGNAME}/$schema_base_name.$$}
fi
# End of added section.

echo "Using $tmp_platform_location to store the platform installation scripts"
mkdir -p $tmp_platform_location
if [ $? -ne 0 ]
then
	echo "ERROR: Failed to create TMP platform location : $tmp_platform_location"
	echo "ERROR: Please raise a BCE request to help fix this issue"
	echo "ERROR: Installation Aborting"
	exit 1
fi

# -Dave B 14-Oct-08... redirected stderr to stdout and added status checking
cp -pR $platform_root/SCHEMA_INSTALL $tmp_platform_location 2>&1

if [ $? -ne 0 ]
then
	echo "ERROR: Failed to copy \"$platform_root/SCHEMA_INSTALL\" to \"$tmp_platform_location\""
	echo "ERROR: Installation Aborting"
	exit 1
fi
# -End of change

cd $platform_root/SCHEMA_INSTALL/PF/platform/bin
tmp_car=`pwd | sed -e 's/\/PF\/platform\/bin//g'`
platform_ver=`echo $tmp_car |  sed -e "s|.*IPF\([0-9]\.[0-9]\.[0-9\.]*\).*|\1|g" | sed -e 's/\.$//g'`
cd ${tmp_platform_location}/SCHEMA_INSTALL/PF/platform/bin

if [ ! -f ut.env ]
then
	echo "Subject: Platform auto creation error `pwd`/ut.env missing. \nHave Fun!" | /usr/lib/sendmail sgraham1
	echo "Error: $0: no ut.env found in `pwd`/bin"
	exit 1
fi

new_platform_stage_root=`pwd | sed -e 's/\/PF\/platform\/bin//g'`

echo "Installing $platform_ver of Platform"

mkdir -p /irb/bce/misc/external_db_dirs/$db_machine/$db_sid
chmod 777 /irb/bce/misc/external_db_dirs/$db_machine/$db_sid

sqlplus -s "sys/sys@$db_sid.world as sysdba" << +END
    set feed off
    set scan on
    grant execute on sys.dbms_lock to system with grant option;
    grant execute on dbms_fga to system with grant option;
    grant SELECT on sys.v_\$session to system with grant option;
    create directory CVG_INFINYS_PF as '/irb/bce/misc/external_db_dirs/$db_machine/$db_sid';
    grant read,write on directory CVG_INFINYS_PF to PUBLIC;
    GRANT ALL ON AQ\$_UNFLUSHED_DEQUEUES TO system WITH GRANT OPTION;
    drop user ${dbspec}_UT cascade;
    drop user ${dbspec}_AUDIT cascade;
    drop user ${dbspec}_PF cascade;
    drop user ${dbspec}_SEC cascade;
    commit;
    exit
+END

echo PF_HOME=$PF_HOME
PF_HOME=""
export PF_HOME
#env
unset PF_HOME
echo PF_HOME=$PF_HOME
PATH=${tmp_platform_location}/SCHEMA_INSTALL/PF/platform/bin:${JAVA_HOME}/bin:$PATH
echo $PATH
export PATH

pf_control_area="${new_platform_stage_root}/pf_control_area"
mkdir $pf_control_area

############adding PF_LOG_PATH in db_migrate.skh file ###############
perl -i -slpe 'print $s if $. == $n; $. = 0 if eof' -- -n=164 -s="PF_LOG_FILE=/tmp/PF_LOG.$$" db_migrate.ksh*
#cat db_migrate.ksh
#echo system >> out$$
############adding PF_LOG_PATH in db_migrate.skh file ###############

mv ut.env ut.env.orig
cat ut.env.orig | sed -e "s|Directory where platform software is staged (i.e. dir above PF)|$new_platform_stage_root|" | sed -e "s|UNIX username of developer/tester|${schema_base_name}|" | sed -e "s/database hostname/$db_machine/" | sed -e "s/listener port number/1521/g" | sed -e "s/Oracle TWO_TASK (usually the same as the Oracle SID)/${db_sid}.world/" | sed -e "s/Oracle SID/$db_sid/g" | sed -e "s/Platform version being installed/$platform_ver/" | sed -e "s|tmp|${pf_control_area}|g" | sed -e "s|Oracle software directory|$ORACLE_HOME|" | sed -e 's/users/data/g' > ut.env
echo "PF_MESSAGEBUS_TABLESPACE=data" >> ut.env

cat ut.env
 
echo system > out$$
echo ${db_sid}.world >> out$$

cat out$$
	#./dropUsers.sh < out$$
	
	echo "Drop PR users and roles" >> out$$ 2>&1
	
sqlplus -s "sys/sys@$db_sid.world as sysdba" << +END
        set feed off
        set scan on
		drop role ${PF_READ_ONLY_ROLE};
		drop role ${PF_UPDATE_ROLE};
		drop role ${PF_AUDIT_ADMIN_ROLE};
		drop role ${PF_AUDIT_READ_ROLE};
		drop role ${PF_AUDIT_ROLE};
		drop role AUDIT_AD_ROLE_${dbspec}_ut;
		drop role AUDIT_AD_ROLE_${dbspec}_ut;
		drop role AUDIT_ROLE_${dbspec}_ut;
		drop user ${PF_SCHEMA} cascade;
		drop user ${PF_USER} cascade;
		drop user ${PF_SEC_SCHEMA} cascade;
		drop user ${PF_AUDIT} cascade;
        commit;
        exit
+END

echo "./createUsers.sh"
./createUsers.sh < out$$ 
status=$?
echo return code = $status

if [ $status -ne 0 ]
then
	echo return from createUser.sh $status - exiting
fi

pwd
echo $PATH
plt=`platform`
if [ $plt = 'aix' ]
then
        plt_dir=${tmp_platform_location}/SCHEMA_INSTALL/PF/platform/bin
        echo "\nplatform directory............$plt_dir"
        cd ${tmp_platform_location}/SCHEMA_INSTALL/PF/platform/bin
        chmod -R 755 *
else
        chmod -R 755 *
fi

chmod -R 755 *
echo "Running ./installDB.sh (from `pwd`)"

if [ -f /tmp/cvginstallingBootstrap ]
then
	echo "Bootstrap crap already going on, why oh why is Platform soooo rubbish, and does not allow multiple users do multiple installs on the same server at the same time, trying to delete"
	rm /tmp/cvginstallingBootstrap 2>&1
fi

./installDB.sh 2>&1
STATUS=$?
echo return code = $?

DATABASE=${schema_base_name}_pf/${schema_base_name}_pf@$db_sid.world

if [ -f ../lib/pf-storedproc1.4.jar ]
then
loadjava -user $DATABASE ../lib/pf-storedproc1.4.jar
elif [ -f ../lib/pf-storedproc1.5.jar ]
then
loadjava -user $DATABASE ../lib/pf-storedproc1.5.jar
elif [ -f ../lib/pf-storedproc.jar ]
then
loadjava -user $DATABASE ../lib/pf-storedproc.jar
fi
loadjava -user $DATABASE ../lib/pf-dbinstallutil.jar

cd $orig_pwd
rm -rf $tmp_platform_location

exit 0
