#!/bin/bash
set -x

project=$1
rel_tag=$2


os=`uname -s`
platform_name=`platform`
echo " platform_name==========$platform_name"
if [ $os = "SunOS" ]
then
         SVN_HOME=/tools/svn_client/subversion-1.7.13
         PATH=$SVN_HOME/bin:$PATH
         LD_LIBRARY_PATH=$SVN_HOME/lib:$LD_LIBRARY_PATH
         export PATH LD_LIBRARY_PATH SVN_HOME
elif [ $os = "HP-UX" ]
then
         SVN_HOME=/tools/svn_client/subversion-1.7.13
         PATH=$SVN_HOME/bin:$PATH
         LD_LIBRARY_PATH=$SVN_HOME/lib:$LD_LIBRARY_PATH
         export PATH LD_LIBRARY_PATH SVN_HOME
elif [ $os = "Linux" ]
then
        if [ $platform_name = "RHEL5-EM64T" ]
        then
                SVN_HOME=/tools/svn_client/subversion-1.7.13
                PATH=$SVN_HOME/bin:$PATH
                LD_LIBRARY_PATH=$SVN_HOME/lib:$LD_LIBRARY_PATH
                export PATH LD_LIBRARY_PATH SVN_HOME
        fi
        if [  $platform_name = "RHEL4-EM64T" ]
        then
                SVN_HOME=/tools/svn_client_rhel4
                PATH=$SVN_HOME/bin:$PATH
                LD_LIBRARY_PATH=$SVN_HOME/lib:$LD_LIBRARY_PATH
                export PATH LD_LIBRARY_PATH SVN_HOME
        fi
        if [  $platform_name = "SLE11-EM64T" ]
        then
                SVN_HOME=/tools/svn_client_suse
                PATH=$SVN_HOME/bin:$PATH
                LD_LIBRARY_PATH=$SVN_HOME/lib:$LD_LIBRARY_PATH
                export PATH LD_LIBRARY_PATH SVN_HOME
        fi


        if [ $platform_name = "RHEL6-EM64T" -o $platform_name = "RHEL7-EM64T" ]
        then
                export PATH=/tools/svn_client_rhel6/bin:$PATH
                export LD_LIBRARY_PATH=/tools/svn_client_rhel6/lib:$LD_LIBRARY_PATH
                export LD_LIBRARY_PATH=/tools/svn_client_rhel6/serf/lib:$LD_LIBRARY_PATH
                export LD_LIBRARY_PATH=/tools/svn_client_rhel6/apr-util/lib:$LD_LIBRARY_PATH
                export LD_LIBRARY_PATH=/tools/svn_client_rhel6/apr/lib:$LD_LIBRARY_PATH
                export PATH LD_LIBRARY_PATH SVN_HOME
        fi


elif [ $os = "aix" ]
then
         SVN_HOME=/tools/svn_client/subversion-1.7.13
         PATH=$SVN_HOME/bin:$PATH
         LD_LIBRARY_PATH=$SVN_HOME/lib:$LD_LIBRARY_PATH
         export PATH LD_LIBRARY_PATH SVN_HOME
else
 echo "Subversion not yet installed for $os operating system!"
fi


function usage()
(
 echo "For RB"
 echo "./tag_creation.sh RB 6.1.5.223 RBM-78794"
 echo "For TAP"
 echo "./tag_creation.sh TAP3 8.18.1.1 RBM-76403"
 echo "For VI"
 echo "./tag_creation.sh VI 9.0.1.1 RBM-76409"
 echo " For PF"
 echo "./tag_creation.sh PF 6.0.1.9 RBM-94422"
 exit
)

if [ "$#" -lt "2" ]
then
        usage
else

Client_GP_CODE=`sqlplus -s buildweb/georgespass@webca.world << EOF
                        whenever sqlerror exit failure
                        set pagesize 0 feedback off verify off heading off echo off
                        select GP_CODE from COMPANY_GPCODE where COMPANY_NAME=(select COMPANY from patch_company where version='$rel_tag' and project='$project');
                        exit
EOF`

GP_CODE_SVN=`sqlplus -s buildweb/georgespass@webca.world << EOF
                        whenever sqlerror exit failure
                        set pagesize 0 feedback off verify off heading off echo off
                        select GPCODE_SVN from COMPANY_GPCODE where COMPANY_NAME=(select COMPANY from patch_company where version='$rel_tag' and project='$project');
			exit             
EOF`

	rel_tag_branch=`echo $rel_tag|awk -F'.' '{print $1"."$2"."$3"."}'`
	#branch_url=https://svnca.netcracker.com/$project/branches/Patches/$Client_GP_CODE/${Client_GP_CODE}_${rel_tag_branch}x
	if [ $project = 'PF' ]
	then
		branch_url=https://svnhd.netcracker.com/$project/branches/Patches/$GP_CODE_SVN/${Client_GP_CODE}_${rel_tag_branch}x
		tag_url=https://svnhd.netcracker.com/$project/tags/Patches/$GP_CODE_SVN/${Client_GP_CODE}_${rel_tag}
	else
		branch_url=https://svncn.netcracker.com/$project/branches/Patches/$GP_CODE_SVN/${Client_GP_CODE}_${rel_tag_branch}x
		#echo $branch_url
		tag_url=https://svncn.netcracker.com/$project/tags/Patches/$GP_CODE_SVN/${Client_GP_CODE}_${rel_tag}
	fi
	#echo $tag_url

	svn ls $tag_url
	if [ $? = 0 ]
	then
		echo "TAG $tag_url Exists"
	else

		if [ $project = 'RB' ]
		then
			svn copy $branch_url -m "RBM-78794" $tag_url
			echo "RB"
		elif [ $project = 'TAP3' ]
		then
			svn copy $branch_url -m "RBM-76403" $tag_url
			echo "TAP3"
		elif [ $project = 'VI' ]
		then	
			svn copy $branch_url -m "RBM-76409" $tag_url
			echo "VI"
		elif [ $project = 'PF' ]
		then
			svn copy $branch_url -m "RBM-94422" $tag_url
			echo "PF"
		else
			echo "Please specify correct project"
		fi
		#echo $Client_GP_CODE
	fi
fi

#/irb/bce/admin/ccm_wa/PRD-bce/PRD/build_scripts/tag_mail.sh $project $rel_tag $tag_url

export PATH=/tools/curl/curl-7.18.2/bin/:$PATH
export LD_LIBRARY_PATH=/tools/curl/curl-7.18.2/lib:$LD_LIBRARY_PATH

echo "[INFO] CHECKING FOR TAG EXISTANCE"
echo "#########################################"
value=`ssh devapp655cn /irb/bce/admin/ccm_wa/PRD-bce/PRD/build_scripts/tag_check.sh $tag_url`

temp_html=/tmp/temp_RC_html.html
echo "To: arun.kumar.kulkarni@netcracker.com,sridhar.davuluru@NetCracker.com,ranjith.kumar.gajula@netcracker.com,reshma.goud.ireni@netcracker.com,ravi.katepally@netcracker.com,tulasi.jagabandu@netcracker.com" > ${temp_html}
#echo "To: arun.kumar.kulkarni@netcracker.com" > ${temp_html}
echo "MIME-Version: 1.0" >> ${temp_html}
echo "Content-Type: text/html; charset="us-ascii"" >> ${temp_html}
#if curl -u genadmin:Fr0sties --output /dev/null --silent --head --fail "$tag_url"
if [ "$value" == "true" ]
then
        echo "This URL Exist"
        echo "Subject: $project"_"$rel_tag TAG is Created" >> ${temp_html}
        echo "<html>" >> ${temp_html}
        echo "<body>" >> ${temp_html}
        echo "<p>" >> ${temp_html}
        echo "Hi Team,<br/></br>" >> ${temp_html}
        echo "<b>$tag_url</b> is Created<br/></br> <font size="5" color="green"><b> $cand_loc </b></font>" >> ${temp_html}
        echo "</p>" >> ${temp_html}
        echo "$define_warning" >> ${temp_html}
        echo "</body>" >> ${temp_html}
        echo "</html>" >> ${temp_html}
else
        echo "This URL Doesnt Exists,please check and create"
        echo "Subject: $project"_"$rel_tag TAG IS NOT CREATED!! PLEASE CHECK" >> ${temp_html}
        echo "<html>" >> ${temp_html}
        echo "<body>" >> ${temp_html}
        echo "<p>" >> ${temp_html}
        echo "Hi Team,<br/></br>" >> ${temp_html}
        echo "<b>$tag_url</b> is NOT CREATED, PLEASE CHECK<br/></br> <font size="5" color="red"><b> $cand_loc </b></font>" >> ${temp_html}
        echo "</p>" >> ${temp_html}
        echo "$define_warning" >> ${temp_html}
        echo "</body>" >> ${temp_html}
        echo "</html>" >> ${temp_html}
fi
/usr/sbin/sendmail arun.kumar.kulkarni@netcracker.com,sridhar.davuluru@NetCracker.com,ranjith.kumar.gajula@netcracker.com,reshma.goud.ireni@netcracker.com,ravi.katepally@netcracker.com,tulasi.jagabandu@netcracker.com < ${temp_html}
#/usr/sbin/sendmail arun.kumar.kulkarni@netcracker.com < ${temp_html}
echo "Email Sent Sucessfully"
echo "#########################################"

