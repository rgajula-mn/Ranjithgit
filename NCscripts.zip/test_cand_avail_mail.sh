#|/bin/ksh
set -x
. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh

BUILDWEB_DB="buildweb/georgespass@webca.world"
cand_loc=$1
if [ -d $cand_loc ]
then
        sqlquery="select CAND_NAME from TEST_CAND_SUMMARY where EXPORT_LOCATION='$cand_loc'"
        RCNAME=`sqlplus -s $BUILDWEB_DB << +END
                set feed off;
                set head off;
                set lines 32767;
                $sqlquery;
                exit;
+END`
	echo "Candidate Location = $cand_loc"
	echo "RC.No=$RCNAME"
	CAND_FULL_NAME=`echo $cand_loc|cut -d'/' -f7`
	proj=`echo $CAND_FULL_NAME|cut -d'_' -f1`
	rel=`echo $CAND_FULL_NAME|cut -d'_' -f2|cut -d'.' -f1-4`
	p=`echo $RCNAME`
	if [ -n $RCNAME ]
	then
                echo "#########################################"
                echo "Release Candidate is generated sucessfully, Sending Mail..."
                temp_html=/tmp/temp_RC_html.html
                echo "To: arun.kumar.kulkarni@netcracker.com,sridhar.davuluru@NetCracker.com,ranjith.kumar.gajula@netcracker.com,reshma.goud.ireni@netcracker.com,ravi.katepally@netcracker.com" > ${temp_html}
#		echo "To: arun.kumar.kulkarni@netcracker.com" > ${temp_html}
                echo "Subject: $proj"_"$rel"."${p} is available for testing" >> ${temp_html}
                echo "MIME-Version: 1.0" >> ${temp_html}
                echo "Content-Type: text/html; charset="us-ascii"" >> ${temp_html}
                echo "<html>" >> ${temp_html}
                echo "<body>" >> ${temp_html}
                echo "<p>" >> ${temp_html}
                echo "Hi Team,<br/></br>" >> ${temp_html}
                echo "<b>$CAND_FULL_NAME</b> is available for Testing in below location <br/></br> <font size="5" color="green"><b> $cand_loc </b></font>" >> ${temp_html}
                echo "</p>" >> ${temp_html}
                echo "$define_warning" >> ${temp_html}
                echo "</body>" >> ${temp_html}
                echo "</html>" >> ${temp_html}
                /usr/sbin/sendmail arun.kumar.kulkarni@netcracker.com,sridhar.davuluru@NetCracker.com,ranjith.kumar.gajula@netcracker.com,reshma.goud.ireni@netcracker.com,ravi.katepally@netcracker.com < ${temp_html}
#		/usr/sbin/sendmail arun.kumar.kulkarni@netcracker.com < ${temp_html}
        #       echo "Release Candidate is = $RC_NAME"
                echo "Email Sent Sucessfully"
                echo "#########################################"
        fi

else
        echo "Candidate is not present, please check"
        echo "#########################################"
        echo "Release Candidate is Not Generated, Sending Mail..."
        temp_html=/tmp/temp_RC_html.html
        echo "To: arun.kumar.kulkarni@netcracker.com,sridhar.davuluru@NetCracker.com,ranjith.kumar.gajula@netcracker.com,reshma.goud.ireni@netcracker.com,ravi.katepally@netcracker.com" > ${temp_html}
#       echo "To: arun.kumar.kulkarni@netcracker.com" > ${temp_html}
        echo "Subject: $proj"_"$rel"."${p} Candidate Generation Failed" >> ${temp_html}
        echo "MIME-Version: 1.0" >> ${temp_html}
        echo "Content-Type: text/html; charset="us-ascii"" >> ${temp_html}
        echo "<html>" >> ${temp_html}
        echo "<body>" >> ${temp_html}
        echo "<p>" >> ${temp_html}
        echo "Hi Team,<br/></br>" >> ${temp_html}
        echo "<b>$CAND_FULL_NAME</b> Candidate is not Generated, please check. <br/></br> <font size="5" color="red"><b> $cand_loc </b></font>" >> ${temp_html}
        echo "</p>" >> ${temp_html}
        echo "$define_warning" >> ${temp_html}
        echo "</body>" >> ${temp_html}
        echo "</html>" >> ${temp_html}
        /usr/sbin/sendmail arun.kumar.kulkarni@netcracker.com,sridhar.davuluru@NetCracker.com,ranjith.kumar.gajula@netcracker.com,reshma.goud.ireni@netcracker.com,ravi.katepally@netcracker.com < ${temp_html}
#       /usr/sbin/sendmail arun.kumar.kulkarni@netcracker.com < ${temp_html}
        #echo "Release Candidate is = $RC_NAME"
        echo "Failed Email Sent Sucessfully"
        echo "#########################################"

        exit
fi
