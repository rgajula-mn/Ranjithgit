#!/bin/ksh
# 21/11/2006 tcahill /prdservice moved to /irb/ice quick fix
#set -x
# Utilize common functions
. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh

# Document all switches
usage() {
	echo
	echo "Patch Release Note verifier"
	echo "[MANDATORY] Setting -t specifies the ccm tag, e.g., GEN_5.2.14.1"
	# echo "[OPTIONAL]  Setting -l specifies the location of the release note, e.g., /prdservices/patches/release_note_gni_2.0.0.3.txt"
        echo "[OPTIONAL]  Setting -l specifies the location of the release note, e.g., /irb/ice/patches/release_note_gni_2.0.0.3.txt"
	echo "            -l should be used when checking Additional Components"
	echo "            However, if -l is ommitted then specific to Geneva and default path is used"
	echo
	echo "[ERROR]xample usage for GENEVA: $0 -t 5.2.14.1"
        #echo "[ERROR]xample usage for GNI: $0 -t 2.0.0.3 -l /prdservices/patches/release_notes_gni_2.0.0.3.txt"
	echo "[ERROR]xample usage for GNI: $0 -t 2.0.0.3 -l /irb/ice/patches/release_notes_gni_2.0.0.3.txt"
	echo
	exit 1
}

# Capture user intervention and exit gracefully
trap_exit() {
	echo  "\n[INFO] User intervention caught"
	echo "\n[INFO] Exiting on a trapped signal..."
	exit 1
}

# Get the problems out of CPT
problems_at_release () {
	rt=$1
	sqlplus -s $DATABASE >> ${problems_path} 2>&1 << +ENDSQL
	set heading off;
	set feedback off;
	set PAGESIZE 5000;
	select problem_number from releases where target='${rt}';
	exit
+ENDSQL
}

# Get the tasks out of CPT
tasks_for_problems_at_release () {
	rt=$1
	while read probs
	do
		if [ ! -z "${probs}" ]
		then
			echo "\n[INFO] Problem ${probs} is targetted at ${rt}"
			sqlplus -s $DATABASE >> ${tasks_path} 2>&1 << +ENDSQL
			set heading off;
			set feedback off;
			set PAGESIZE 5000;
			select task_number || ' ' || assigner || ' ' || status from task where problem_number='${probs}' and release='${rt}';
			exit
+ENDSQL
		fi
	done < ${problems_path}
}

# Get the deliverables for a task
deliverables_for_task () {
	while read tasks assigner status
	do
		if [ ! -z "${tasks}" ]
		then
			echo "\n[INFO] Task $tasks is ${status} by ${assigner}"
			sqlplus -s $DATABASE >> ${deliverables_path} 2>&1 << +ENDSQL
			set heading off;
			set feedback off;
			set PAGESIZE 5000;
			select deliverable_name from submittedtaskdeliverable where task_number='${tasks}';
			exit
+ENDSQL
		fi
	done < ${tasks1_path}
}

# Minimal checking required
if [ "$#" -lt "1" ]
then
	usage
fi

# General initialization section
DATABASE=cpt/cpt@webca.world
noProblems=0
problems_path="/tmp/problems"
tasks_path="/tmp/tasks"
tasks1_path="/tmp/tasks1"
deliverables_path="/tmp/deliverables"
deliverables1_path="/tmp/deliverables1"
summary_path="/tmp/summary"
UAs="accountsreceivable.exe batchpaymententry.exe billingcatmaintenance.exe billrenderer.exe ConfigurationDataTransfer.exe custaccmaintenance.exe launchrendering.exe productconfiguration.exe productpricingeditstransfer.exe ratingcatmaintenance.exe rejectedeventmaintenance.exe systemconfiguration.exe systemmonitor.exe setup.exe UAs"
APIs="_bdy.plb _spc.plb .spc .bdy .plb APIs"
Messages_VPA=".xml Messages_VPA"
Messages_API=".txt Messages_API"
Schema=".sql Schema"
# Blank out the working files
>${problems_path}
>${tasks_path}
>${tasks1_path}
>${deliverables_path}
>${deliverables1_path}
>${summary_path}

# Process the doobreys
while getopts t:l: the_option 2>/dev/null
do
	case ${the_option} in
	t)
		release_tag=${OPTARG}
		release=`echo "${release_tag}" | cut -d'_' -f2`
		# Presume GENEVA at this stage if not the -l option will override this setting
	;;
	l)
		if [ ! -z ${OPTARG} ]
		then
			if [ -f ${OPTARG} ]
			then
				release_note="${OPTARG}"
				echo "\n[DEBUG] -l was set to ${release_note}"
			else
				echo "\n[DEBUG] detected with -l switch. Aborting... No Such File ${OPTARG}..."
				exit 1
			fi
		fi
	;;
	*)
		echo "\n[DEBUG] Incorrect switches have been passed"
		echo "\n[DEBUG] Refer to usage below for mandatory switches"
		echo
		usage
	;;
	esac
done

if [ -z "$release_tag" ]
then
	echo "No Release Tag entered"
	usage
fi

if [ -z "$release_note" ]
then
	project_version=`discover_release_tag.sh -t $release_tag`
	project=`echo $project_version | cut -d' ' -f1`
	version=`echo $project_version | cut -d' ' -f2`
	major_release=`echo $release | cut -d'.' -f1-2`
	rel_release=$release
	rel_project=$project
	if [ "$project" = "GENEVA" -o "$project" = "RB" ]
	then
		if [ "$project" = "GENEVA" -a "$major_release" = "5.4" ]
		then
			rel_release=`echo $release | sed -e 's/5\.4\./2.2./g'`
			rel_project=RB
		fi
                #release_note="/prdservices/patches/release_notes_${rel_release}.txt"
		release_note="/irb/ice/patches/release_notes_${rel_release}.txt"
	else
                #release_note="/prdservices/patches/`ls /prdservices/patches | grep "release_notes_" | grep -i "${project}" | grep -i "${version}" | egrep "txt$"`"
		release_note="/irb/ice/patches/`ls /irb/ice/patches | grep "release_notes_" | grep -i "${project}" | grep -i "${version}" | egrep "txt$"`"
		
	fi
fi

# Define traps - you never know what a user presses
# Exit with a non-zero number if CTRL+C pressed for example
trap 'trap_exit' 1 2 3 15

# Verify there is a release note mainly for GENEVA
if [ ! -f ${release_note} ]
then
	echo "\n[ERROR] ${release_note} does not exist"
	exit 1
fi

# Get all problems for the release tag from CPT
problems_at_release ${release_tag}

# Get the tasks
echo "\n[INFO] Processing problems..."
tasks_for_problems_at_release ${release_tag}
echo

# Filter out blank tasks
cat ${tasks_path} | egrep -v "no rows selected" > ${tasks1_path}

# Get the deliverables
echo "\n[INFO] Processing tasks..."
deliverables_for_task
echo

cat ${deliverables_path} | sort -u | egrep -v "no rows selected|^$" > ${deliverables1_path}
if [ ! -s ${deliverables1_path} ]
then
	echo "\n[ERROR] No deliverables have been posted by the developer"
	exit 1
fi
cat ${problems_path} ${deliverables1_path} > ${summary_path}
# Proces1s the release note with problems/tasks/deliverables
echo "\n[INFO] Processing ${release_note}"
#ccmproject=`ccm query -s prep -n ${rel_project}PATCH "release='${release_tag}'" -u -f "%displayname" | head -1`
pf_ora=`sqlplus -s buildweb/georgespass@webca.world  << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                select OPER_SYS||'.'||ORACLE_NAME from PATCH_PLATFORMS where PROJECT='$project' and version='$version';
                exit
        EOF`
pf_ora=`echo $pf_ora| tr -d '\r'`
small_project=`echo  $rel_project | tr '[A-Z]' '[a-z]'`
ccmproject=${rel_project}PATCH-sqa$version.$pf_ora
#wa_path=`ccm query -s prep -n ${rel_project}PATCH "release='${release_tag}'" -u -f "%wa_path" | head -1`
wa_path=/irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/
#echo "[INFO] SVN Project = $ccmproject"
echo "\n[INFO]SVN Project = $ccmproject"
echo "\n[INFO] WA Path = $wa_path"
while read a_line
do
	if [ ! -z "$a_line" ]
	then
		if [ "${a_line}" = "APIs" ]
		then
			echo
			echo "\n[INFO] APIs were detected...processing variations"
			Kounter=0
			processedAPIs=""
			for api in ${APIs}
			do
		#		searchResult=`grep -i "${api}" ${release_note}`
		#		if [ $? -eq 0 ]
		#		then
					searchResult=`grep -i "${api}" ${release_note} | cut -d' ' -f1|grep "${api}"`
					echo ${processedAPIs} | grep ${searchResult} > /dev/null
					if [ $? -ne 0 ]
					then
						processedAPIs="${processedAPIs} ${searchResult}"
						for text in ${searchResult}
						do
							echo "[INFO] Found ${text}"
							#ccmAPIS=`ccm query -s prep "type!='project' and release='${release_tag}' and member_status='sqa'" -u -f "%name"`
							#cd /irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}/${rel_project}/schema/procedures/
							ccmAPIS=`ls -ltRL /irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}PATCH/${rel_project}/${rel_project}/|awk '{ print $9}'|tr ' ' '\n'` 

							echo "${ccmAPIS}" | grep ${text} > /dev/null
							if [ $? -eq 0 ]
							then
								echo "\n[INFO] ${text} was found in the SVN Patch project"
							else
								echo "\n[ERROR] ${text} was NOT found in the SVN Patch project"
								noProblems=1
							fi
						done
						Kounter=$((Kounter+`grep -c "${api}" ${release_note}`))
					fi
		#		fi
			done
			if  [ ${Kounter} -gt 0 ]
			then
				allOK=0
			fi
			echo "\n[INFO] ${Kounter} APIs were detected"
			echo
		elif [ "${a_line}" = "Messages_VPA" ]
                then
                        echo
                        echo "\n[INFO] Messages_VPA were detected...processing variations"
                        Kounter=0
                        processedVPAs=""
                        for mess in ${Messages_VPA}
                        do
                              #  searchResult=`grep -i "${mess}" ${release_note}`
                              #  if [ $? -eq 0 ]
                              #  then
                                        searchResult=`grep -i "${mess}" ${release_note} | cut -d' ' -f1|grep ".xml"`
                                        echo ${processedVPAs} | grep ${searchResult} > /dev/null
                                        if [ $? -ne 0 ]
                                        then
                                                processedVPAs="${processedVPAs} ${searchResult}"
                                                for text in ${searchResult}
                                                do
                                                        echo "[INFO] Found ${text}"
                                                        #ccmAPIS=`ccm query -s prep "type!='project' and release='${release_tag}' and member_status='sqa'" -u -f "%name"`
                                                        #cd /irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}/${rel_project}/schema/procedures/
                                                        ccmMESS=`ls -ltRL /irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}PATCH/${rel_project}/${rel_project}/|awk '{ print $9}'|tr ' ' '\n'`

                                                        echo "${ccmMESS}" | grep ${text} > /dev/null
                                                        if [ $? -eq 0 ]
                                                        then
                                                                echo "\n[INFO] ${text} was found in the SVN Patch project"
                                                        else
                                                                echo "\n[ERROR] ${text} was NOT found in the SVN Patch project"
                                                                noProblems=1
                                                        fi
                                                done
                                                Kounter=$((Kounter+1))
                                        fi
                               # fi
                        done
                        if  [ ${Kounter} -gt 0 ]
                        then
                                allOK=0
                        fi
                        echo "\n[INFO] ${Kounter} Meassages_VPA were detected"
                        echo
		elif [ "${a_line}" = "Messages_API" ]
                then
                        echo
                        echo "\n[INFO] Messages_API were detected...processing variations"
                        Kounter=0
                        processedAPIs=""
                        for mess in ${Messages_API}
                        do
                              #  searchResult=`grep -i "${mess}" ${release_note}`
                               # if [ $? -eq 0 ]
                               # then
                                        searchResult=`grep -i "${mess}" ${release_note} | cut -d' ' -f1|grep ".txt"`
                                        echo ${processedAPIs} | grep ${searchResult} > /dev/null
                                        if [ $? -ne 0 ]
                                        then
                                                processedAPIs="${processedAPIs} ${searchResult}"
                                                for text in ${searchResult}
                                                do
                                                        echo "[INFO] Found ${text}"
                                                        #ccmAPIS=`ccm query -s prep "type!='project' and release='${release_tag}' and member_status='sqa'" -u -f "%name"`
                                                        #cd /irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}/${rel_project}/schema/procedures/
                                                        ccmMESS=`ls -ltRL /irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}PATCH/${rel_project}/${rel_project}/|awk '{ print $9}'|tr ' ' '\n'`

                                                        echo "${ccmMESS}" | grep ${text} > /dev/null
                                                        if [ $? -eq 0 ]
                                                        then
                                                                echo "\n[INFO] ${text} was found in the SVN Patch project"
                                                        else
                                                                echo "\n[ERROR] ${text} was NOT found in the SVN Patch project"
                                                                noProblems=1
                                                        fi
                                                done
                                                Kounter=$((Kounter+1))
                                        fi
                                #fi
                        done
                        if  [ ${Kounter} -gt 0 ]
                        then
                                allOK=0
                        fi
                        echo "\n[INFO] ${Kounter} Meassages_API were detected"
                        echo

		elif [ "${a_line}" = "Schema" ]
                then
                        echo
                        echo "\n[INFO] Schema were detected...processing variations"
                        Kounter=0
                        processedSQLs=""
                        for sql in ${Schema}
                        do
                                #searchResult=`grep -i "${sql}" ${release_note}`
                                #if [ $? -eq 0 ]
                                 #then
                                        searchResult=`grep "${sql}" ${release_note}| cut -d' ' -f1|grep ".sql"`
                                        echo ${processedSQLs} | grep ${searchResult} > /dev/null
                                        if [ $? -ne 0 ]
                                        then
                                                processedSQLs="${processedSQLs} ${searchResult}"
                                                for text in ${searchResult}
                                                do
                                                        echo  "\n[INFO] Found ${text}"
                                                        #ccmAPIS=`ccm query -s prep "type!='project' and release='${release_tag}' and member_status='sqa'" -u -f "%name"`
                                                        #cd /irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}/${rel_project}/schema/procedures/
                                                        ccmSQLS=`ls -ltRL /irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}PATCH/${rel_project}/${rel_project}/|awk '{ print $9}'|tr ' ' '\n'`

                                                        echo "${ccmSQLS}" | grep ${text} > /dev/null
                                                        if [ $? -eq 0 ]
                                                        then
                                                                echo  "\n[INFO] ${text} was found in the SVN Patch project"
                                                        else
                                                                echo "\n[ERROR] ${text} was NOT found in the SVN Patch project"
                                                                noProblems=1
                                                        fi
                                                done
                                                Kounter=$((Kounter+1))
                                        fi
                               # fi
                        done
                        if  [ ${Kounter} -gt 0 ]
                        then
                                allOK=0
                        fi
                        echo "\n[INFO] ${Kounter} Schema were detected"
                        echo

		elif [ "${a_line}" = "User apps" ]
		then
			echo
			echo "\n[INFO] User Apps were detected...processing variations"
			Kounter=0
			for userApp in ${UAs}
			do
				searchResult=`grep -iw "${userApp}" ${release_note}`
				if [ $? -eq 0 ]
				then
					echo "\n[INFO] Found ${userApp}"
			#		cd /irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}/${rel_project}/exe/
		ccmUAS=`ls -ltRL /irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}PATCH/${rel_project}/${rel_project}/|awk '{ print $9}'|tr ' ' '\n'`			
					ccmUAS=`ls -l *.exe *.msi|awk '{ print $9}'`
					echo "${ccmUAS}" | grep ${userApp} > /dev/null
					if [ $? -eq 0 ]
					then
						echo "\n[INFO] ${userApp} was found in the SVN Patch project"
					else
						echo "\n[ERROR] ${userApp} was NOT found in the SVN Patch project"
						noProblems=1
					fi
					Kounter=$((Kounter+1))
				fi
			done
			if  [ ${Kounter} -gt 0 ]
			then
				allOK=0
			fi
			echo "\n[INFO] ${Kounter} User Apps were detected"
			echo
		else
			searchResult=`grep "${a_line}" ${release_note}`
			allOK=$?
			echo "$a_line" | grep "\.so" > /dev/null 
			if [ $? -eq 0 -a $allOK -ne 0 ]
			then
				ali=`echo $a_line | sed -e 's/\.so/\.sl/g'`
				searchResult=`grep "${ali}" ${release_note}`
				allOK=$?
			fi
		fi
		if [ allOK -eq 0 ]
		then
			alreadyProcessed="${UAs} ${APIs} ${Messages_VPA} ${Schema} ${Messages_API}"
			echo ${alreadyProcessed} | grep ${a_line} > /dev/null
			if [ $? -ne 0 ]
			then
				echo "\n[INFO] ${a_line} was found in the  release note"
				echo "${a_line}" | grep '[0-9][0-9]*' > /dev/null
				if [ $? -ne 0 ]
				then
					if [ -z "${ccmVPAS}" ]
					then
						#ccmVPAS=`ccm query "is_member_of('${ccmproject}')" -u -f "%name"`
						#cd /irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}/${rel_project}/bin
						ccmVPAS=`ls -ltRL /irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}PATCH/${rel_project}/${rel_project}/|awk '{ print $9}'|tr ' ' '\n'`

#echo "/irb/bce/release/$small_project/$major_release/${rel_project}PATCH-sqa$version.$pf_ora/${rel_project}/${rel_project}/bin/" 

					fi
					ccmVPAS=`echo $ccmVPAS | sed -e 's/\.sl/\.so/g'`
					echo "${ccmVPAS}" | grep ${a_line} > /dev/null
					if [ $? -eq 0 ]
					then
						echo "\n[INFO] ${a_line} was found in the SVN Patch project (svnVPAS)"
					else
						echo "\n[ERROR] ${a_line} was NOT found in the SVN Patch project (svnVPAS)"
						noProblems=1
					fi
				fi
			fi
		else
			#echo "\n[ERROR] ${a_line} was NOT found in the release note"
			noProblems=1
		fi
	fi
done < ${summary_path}

echo
echo "\n[INFO] Performing final sanity check..."
grep '[0-9]*\.[0-9]*[A-Z]*\.[0-9|a-z]*\.[0-9]' ${release_note} | grep ${release} > /dev/null
if [ $? -eq 1 ]
then
	echo "[WARNING] Questionable patch number was detected within release"
	grep '[0-9]*\.[0-9]*[A-Z]*\.[0-9|a-z]*\.[0-9]' ${release_note}
	echo
	noProblems=1
else
	echo "[INFO] No unusal patch numbers detected"
	echo
fi
	
if [ ${noProblems} -eq 0 ]
then
	echo "[INFO] ${release_note}\n\n\n ******successfully processed******\n"
	echo "############################################################################\\n"
	echo "############################################################################\\n"
else
		echo "[WARNING] ${release_note}\n\n\n ******requires investigation******\n"
		echo "############################################################################\n"
	echo "############################################################################\n"
fi
