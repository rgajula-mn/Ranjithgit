#!/bin/bash
set -x
rel_tag=$1
platform=$2
#server=$3
source_path=$3
dest_path=$4
release_num=`echo $source_path|cut -d '/' -f6|sed 's/RBAPI-sqa//g'`
dots_in_release=`echo $release_num|tr -d -c '.'|wc -c`
head=`echo $release_num|cut -d '.' -f1,2`
function usage()
(
 echo "Sample : ECA-8.0.4jJ11g.64.WebLogic.zip"
 echo "./eca_zip_generate.sh 8.0.4 jJ11g.64 /irb/bce/build/web/RBAPI-sqa8.0.4/RBAPI /irb/candidate/rc/rb/8.0/RB_8.0.4.RC1/"
 exit 
)
check_xml()
{
touch /irb/bce/admin/log/temp_manifest.xml
if [ "$platform" = "jJ11g.64" ]
then
                if [ -f $source_path/build/weblogic_10_3/packaging/jJ*/manifest.xml ]
                then
                                searchResult=`grep -i "${release_num}" $source_path/build/weblogic_*_*/packaging/jJ*/manifest.xml`
                                if [ $? -eq 0 ]
                                then
                                                echo "zip can be created"
                                                cp $source_path/build/weblogic_10_3/packaging/jJ*/manifest.xml $dest_path/ECA/manifest/manifest.xml
						echo "Manifest.xml copied sucessfully"
                                else
					sed "4s/\(^.*version.*=.*\"\)\(.*\)\(\".*$\)/\1${release_num}\3/" $source_path/build/weblogic_10_3/packaging/jJ*/manifest.xml >> /irb/bce/admin/log/temp_manifest.xml
					cat /irb/bce/admin/log/temp_manifest.xml > $source_path/build/weblogic_10_3/packaging/jJ*/manifest.xml
                                        cp $source_path/build/weblogic_10_3/packaging/jJ*/manifest.xml $dest_path/ECA/manifest/manifest.xml
                                        echo "Manifest.xml copied sucessfully"
                                fi
                fi
                if [ -f  /irb/bce/build/rb/$head/RB-sqa$release_num.linux.oracle11g/RB/configuration/infinys/release_information/release_info.xml ]
                then
			cp /irb/bce/build/rb/$head/RB-sqa$release_num.linux.oracle11g/RB/configuration/infinys/release_information/release_info.xml $dest_path/ECA/ECA/bin/release_info.xml
                else
                                exit
                fi
else
                if [ -f $source_path/build/weblogic_12_*/packaging/jJ*/manifest.xml ]
                then
                                searchResult=`grep -i "${release_num}" $source_path/build/weblogic_12_1/packaging/jJ*/manifest.xml`
                                if [ $? -eq 0 ]
                                then
                        	        echo "zip can be created"
                                        cp $source_path/build/weblogic_12_1/packaging/jJ*/manifest.xml $dest_path/ECA/manifest/manifest.xml
					echo "Manifest.xml copied sucessfully"
                                else
					sed "4s/\(^.*version.*=.*\"\)\(.*\)\(\".*$\)/\1${release_num}\3/" $source_path/build/weblogic_12_*/packaging/jJ*/manifest.xml >> /irb/bce/admin/log/temp_manifest.xml
                                        cat /irb/bce/admin/log/temp_manifest.xml > $source_path/build/weblogic_12_*/packaging/jJ*/manifest.xml
                                        cp $source_path/build/weblogic_12_*/packaging/jJ*/manifest.xml $dest_path/ECA/manifest/manifest.xml
                                        rm -rf $source_path/build/weblogic_12_*/packaging/jJ*/manifest_org.xml
                                        echo "Manifest.xml copied sucessfully"
                                fi
                fi
                if [ -f /irb/bce/build/rb/$head/RB-sqa$release_num.linux.oracle12c/RB/configuration/infinys/release_information/release_info.xml ]
                then
                        cp /irb/bce/build/rb/$head/RB-sqa$release_num.linux.oracle12c/RB/configuration/infinys/release_information/release_info.xml $dest_path/ECA/ECA/bin/release_info.xml
                else
                                exit
                fi
fi
rm -rf /irb/bce/admin/log/temp_manifest.xml
}

if [ "$#" -lt "4" ]
then
        usage
else
#if [ $server = 'WebLogic' ]
#then
if [ -d $dest_path/ECA ]
then
	rm -rf $dest_path/ECA
	echo "Removed the Directory Structure"
fi
echo "creating directory structure"
mkdir -p $dest_path/ECA/manifest/
mkdir -p $dest_path/ECA/ECA/
mkdir -p $dest_path/ECA/ECA/bin/
mkdir -p $dest_path/ECA/ECA/doc/eca/
mkdir -p $dest_path/ECA/ECA/java/ECA.ear/META-INF/
mkdir -p $dest_path/ECA/ECA/java/ECA.ear/APP-INF/lib/
mkdir -p $dest_path/ECA/ECA/java/EKM.ear/META-INF/
mkdir -p $dest_path/ECA/ECA/java/EKM.ear/APP-INF/lib/
mkdir -p $dest_path/ECA/ECA/java/PF.ear/META-INF/
mkdir -p $dest_path/ECA/ECA/java/PF.ear/APP-INF/lib/
mkdir -p $dest_path/ECA/ECA/lib/webservices/client/schema/ECA/
mkdir -p $dest_path/ECA/ECA/lib/webservices/client/schema/CommonIML/
mkdir -p $dest_path/ECA/ECA/lib/webservices/client/schema/Base/
mkdir -p $dest_path/ECA/ECA/lib/webservices/client/wsdl/ECA/
mkdir -p $dest_path/ECA/ECA/META_INF/
mkdir -p $dest_path/ECA/ECA/schema/install/
mkdir -p $dest_path/ECA/ECA/java/EKM.ear/APP-INF/lib/config.jar/
mkdir -p $dest_path/ECA/ECA/java/PF.ear/APP-INF/lib/config.jar/
mkdir -p $dest_path/ECA/ECA/java/ECA.ear/APP-INF/lib/config.jar/

echo "copying the deliverables from source to destination"
#release_num=`echo $source_path|cut -d '/' -f6|sed 's/RBAPI-sqa//g'`
#head=`echo $release_num|cut -d '.' -f1,2`
check_xml
##########Changing directory to webservices directory to generate the javadoc zip######
cd ${source_path}/build_output/webservices/javadoc
zip -r $source_path/build_release_all/distrib/external/webservices_javadoc.zip  *
ls -ltr $source_path/build_release_all/distrib/external/webservices_javadoc.zip
chmod 755 -R $dest_path/ECA/ECA/doc/eca/
cp $source_path/build_release_all/distrib/external/javadoc.zip $dest_path/ECA/ECA/doc/eca/javadoc.zip
cp $source_path/build_release_all/distrib/external/webservices_javadoc.zip $dest_path/ECA/ECA/doc/eca/webservices_javadoc.zip
cp $source_path/build_output/bws/deliverables/weblogic_*_*/bws.jar $dest_path/ECA/ECA/java/ECA.ear/APP-INF/lib/bws.jar
cp $source_path/build_output/cews/deliverables/weblogic_*_*/cews.jar $dest_path/ECA/ECA/java/ECA.ear/APP-INF/lib/cews.jar
cp $source_path/build_output/stws/deliverables/weblogic_*_*/stws.jar $dest_path/ECA/ECA/java/ECA.ear/APP-INF/lib/stws.jar
cp $source_path/build_output/vatws/deliverables/weblogic_*_*/vatws.jar $dest_path/ECA/ECA/java/ECA.ear/APP-INF/lib/vatws.jar
cp $source_path/build_output/webservices/deliverables/eca-webservices.war $dest_path/ECA/ECA/java/ECA.ear/eca-webservices.war
cp $source_path/build_output/eca.tca/deliverables/weblogic_*_*/RBServer.jar $dest_path/ECA/ECA/java/ECA.ear/RBServer.jar
cp $source_path/build_output/ekm/deliverables/weblogic_*_*/ECA-asyncPlugins.jar $dest_path/ECA/ECA/java/EKM.ear/APP-INF/lib/ECA-asyncPlugins.jar
cp $source_path/build_output/ekm/deliverables/weblogic_*_*/ECA-mapi.jar $dest_path/ECA/ECA/java/EKM.ear/APP-INF/lib/ECA-mapi.jar
cp $source_path/build_output/ekm/deliverables/weblogic_*_*/eca_cii.war $dest_path/ECA/ECA/java/EKM.ear/eca_cii.war
cp $source_path/build_output/ekm/deliverables/weblogic_*_*/eca_cii_ejb.jar $dest_path/ECA/ECA/java/EKM.ear/eca_cii_ejb.jar
cp $source_path/build_output/eci/deliverables/weblogic_*_*/ECI-syncPlugins.jar $dest_path/ECA/ECA/java/PF.ear/APP-INF/lib/ECI-syncPlugins.jar
cp -R $source_path/build_output/webservices/deliverables/schema $dest_path/ECA/ECA/lib/webservices/client/
cp -R $source_path/build_output/webservices/deliverables/wsdl $dest_path/ECA/ECA/lib/webservices/client/
cp $source_path/build_output/eca.tca/deliverables/weblogic_*_*/RBClient.jar $dest_path/ECA/ECA/lib/RBClient.jar
cp $source_path/build/geneva_packaging/static.properties $dest_path/ECA/static.properties
cp $source_path/build/geneva_packaging/ECA/ECA/META_INF/build.xml $dest_path/ECA/ECA/META_INF/build.xml
#cp $source_path/SCHEMA/install/build.xml $dest_path/ECA/ECA/schema/install/build.xml
cp $source_path/build/geneva_packaging/ECA/ECA/schema/install/build.xml $dest_path/ECA/ECA/schema/install/build.xml
cp $source_path/build/geneva_packaging/ECA/ECA/schema/install/ecaOracleSetup.sql $dest_path/ECA/ECA/schema/install/ecaOracleSetup.sql
#cp $source_path/build/geneva_packaging/release_info.xml $dest_path/ECA/ECA/bin/release_info.xml
#cp $source_path/build/weblogic_*_*/packaging/jJ*/manifest.xml $dest_path/ECA/manifest/manifest.xml

echo "zipping the file"
searchresult=`echo "$dest_path" | grep "candidate"`
if [ $? -eq 0 ]
then
	file_name=ECA-$rel_tag$platform.WebLogic
	cd $dest_path
	zip -r $file_name.zip ECA
else
	if [ "$dots_in_release" -eq 2 ]
	then
		cp -pr /irb/bce/build/doc/rb/$head/$release_num/* $dest_path/ECA/ECA/doc/
	elif [ -f /irb/ice/patches/release_notes_$release_num.txt ]
	then
		cp /irb/ice/patches/release_notes_$release_num.txt $dest_path/ECA/ECA/doc/release_notes_$release_num.txt
	else
		exit
	fi
	file_name=ECA-$rel_tag$platform.WebLogic
	cd $dest_path
	zip -r $file_name.zip ECA
fi
#zip -r $dest_path/$file_name.zip $dest_path/ECA
#else
#echo "Jboss"
if [ -d $dest_path/ECA ]
then
        rm -rf $dest_path/ECA
        echo "Removed the Directory Structure"
fi
mkdir -p $dest_path/ECA/manifest/
mkdir -p $dest_path/ECA/ECA/
mkdir -p $dest_path/ECA/ECA/bin/
mkdir -p $dest_path/ECA/ECA/doc/eca/
mkdir -p $dest_path/ECA/ECA/java/ECA.ear/META-INF/
mkdir -p $dest_path/ECA/ECA/java/ECA.ear/APP-INF/lib/
mkdir -p $dest_path/ECA/ECA/java/EKM.ear/META-INF/
mkdir -p $dest_path/ECA/ECA/java/EKM.ear/APP-INF/lib/
mkdir -p $dest_path/ECA/ECA/java/PF.ear/META-INF/
mkdir -p $dest_path/ECA/ECA/java/PF.ear/APP-INF/lib/
mkdir -p $dest_path/ECA/ECA/lib/webservices/client/schema/ECA/
mkdir -p $dest_path/ECA/ECA/lib/webservices/client/schema/CommonIML/
mkdir -p $dest_path/ECA/ECA/lib/webservices/client/schema/Base/
mkdir -p $dest_path/ECA/ECA/lib/webservices/client/wsdl/ECA/
mkdir -p $dest_path/ECA/ECA/META_INF/
mkdir -p $dest_path/ECA/ECA/schema/install
mkdir -p $dest_path/ECA/ECA/java/EKM.ear/APP-INF/lib/config.jar/
mkdir -p $dest_path/ECA/ECA/java/PF.ear/APP-INF/lib/config.jar/
mkdir -p $dest_path/ECA/ECA/java/ECA.ear/APP-INF/lib/config.jar/

echo "copying the deliverables from source to destination"
release_num=`echo $source_path|cut -d '/' -f6|sed 's/RBAPI-sqa//g'`
head=`echo $release_num|cut -d '.' -f1,2`
check_xml
##########Changing directory to webservices directory to generate the javadoc zip######
#cd $source_path/build_output/webservices/javadoc
#zip -r $source_path/build_release_all/distrib/external/webservices_javadoc.zip  *
#ls -ltr $source_path/build_release_all/distrib/external/webservices_javadoc.zip
#chmod 755 -R $dest_path/ECA/ECA/doc/eca/
cp $source_path/build_release_all/distrib/external/javadoc.zip $dest_path/ECA/ECA/doc/eca/javadoc.zip
cp $source_path/build_release_all/distrib/external/webservices_javadoc.zip $dest_path/ECA/ECA/doc/eca/webservices_javadoc.zip
cp $source_path/build_output/bws/deliverables/jboss_*_*/bws.jar $dest_path/ECA/ECA/java/ECA.ear/APP-INF/lib/bws.jar
cp $source_path/build_output/cews/deliverables/jboss_*_*/cews.jar $dest_path/ECA/ECA/java/ECA.ear/APP-INF/lib/cews.jar
cp $source_path/build_output/stws/deliverables/jboss_*_*/stws.jar $dest_path/ECA/ECA/java/ECA.ear/APP-INF/lib/stws.jar
cp $source_path/build_output/vatws/deliverables/jboss_*_*/vatws.jar $dest_path/ECA/ECA/java/ECA.ear/APP-INF/lib/vatws.jar
cp $source_path/build_output/webservices/deliverables/eca-webservices.war $dest_path/ECA/ECA/java/ECA.ear/eca-webservices.war
cp $source_path/build_output/eca.tca/deliverables/jboss_*_*/RBServer.jar $dest_path/ECA/ECA/java/ECA.ear/RBServer.jar
cp $source_path/build_output/ekm/deliverables/jboss_*_*/ECA-asyncPlugins.jar $dest_path/ECA/ECA/java/EKM.ear/APP-INF/lib/ECA-asyncPlugins.jar
cp $source_path/build_output/ekm/deliverables/jboss_*_*/ECA-mapi.jar $dest_path/ECA/ECA/java/EKM.ear/APP-INF/lib/ECA-mapi.jar
cp $source_path/build_output/ekm/deliverables/jboss_*_*/eca_cii.war $dest_path/ECA/ECA/java/EKM.ear/eca_cii.war
cp $source_path/build_output/ekm/deliverables/jboss_*_*/eca_cii_ejb.jar $dest_path/ECA/ECA/java/EKM.ear/eca_cii_ejb.jar
cp $source_path/build_output/eci/deliverables/jboss_*_*/ECI-syncPlugins.jar $dest_path/ECA/ECA/java/PF.ear/APP-INF/lib/ECI-syncPlugins.jar
cp -R $source_path/build_output/webservices/deliverables/schema $dest_path/ECA/ECA/lib/webservices/client/
cp -R $source_path/build_output/webservices/deliverables/wsdl $dest_path/ECA/ECA/lib/webservices/client/
cp $source_path/build_output/eca.tca/deliverables/jboss_*_*/RBClient.jar $dest_path/ECA/ECA/lib/RBClient.jar
cp $source_path/build/geneva_packaging/static.properties $dest_path/ECA/static.properties
cp $source_path/build/geneva_packaging/ECA/ECA/META_INF/build.xml $dest_path/ECA/ECA/META_INF/build.xml
#cp $source_path/SCHEMA/install/build.xml $dest_path/ECA/ECA/schema/install/build.xml
cp $source_path/build/geneva_packaging/ECA/ECA/schema/install/build.xml $dest_path/ECA/ECA/schema/install/build.xml
cp $source_path/build/jboss_*_*/ECA_jndi.xml $dest_path/ECA/ECA/bin/ECA-jndi.xml
cp $source_path/build/geneva_packaging/ECA/ECA/schema/install/ecaOracleSetup.sql $dest_path/ECA/ECA/schema/install/ecaOracleSetup.sql
#cp $source_path/build/geneva_packaging/release_info.xml $dest_path/ECA/ECA/bin/release_info.xml
#cp $source_path/build/weblogic_*_*/packaging/jJ*/manifest.xml $dest_path/ECA/manifest/manifest.xml

echo "zipping the file"
searchresult=`echo "$dest_path" | grep "candidate"`
if [ $? -eq 0 ]
then
	file_name=ECA-$rel_tag$platform.JBoss
	cd $dest_path
	zip -r $file_name.zip ECA
else
	if [ "$dots_in_release" -eq 2 ]
	then
		cp -pr  /irb/bce/build/doc/rb/$head/$release_num/* $dest_path/ECA/ECA/doc/
        elif [ -f /irb/ice/patches/release_notes_$release_num.txt ]
        then
                cp /irb/ice/patches/release_notes_$release_num.txt $dest_path/ECA/ECA/doc/release_notes_$release_num.txt
        else
                exit
        fi
	file_name=ECA-$rel_tag$platform.JBoss
        cd $dest_path
        zip -r $file_name.zip ECA

fi
fi
nodes=`echo $release_num|awk -F'.' '{print NF}'`
type="INSTALL"
releaseTime=`date "+%Y%m%d%H%M%S"`
state="sqa"
if [ "$type" = "PATCH" -o "$type" = "INSTALL" -a $nodes = 4 ]
then
        USER_ENTERED_PROJECT="RB"
        project="RB"
        Username="arku1015"
        echo "$dest_path" | grep "/irb/archive"
        if [ $? -eq 0 ]
        then
                        $BCE_BUILD_SCRIPTS/tag_creation.sh $USER_ENTERED_PROJECT $release_num
                        ssh devapp655cn "bash .bce.ini;$BCE_BUILD_SCRIPTS/tms_close_version.sh $release_num $USER_ENTERED_PROJECT > ${BCE_LOG}/tms_version/tms_version_close_$USER_ENTERED_PROJECT_$release_num.log" 2>&1
        else
                RCName=`echo ${dest_path} | sed -e 's/.*\([RID][CB][0-9][0-9]*\).*/\1/'`
                echo "we archiving to candidate location so tags are not required"
                echo "update_build_information_svn.sh -T -p $project -v i $release_num -u $Username -j ${type} -s $state -y $releaseTime -i $RCName -L ${dest_path}"
                ${BCE_BUILD_SCRIPTS}/update_build_information.sh -T -p "$project" -v "$releasei_num" -u "$Username" -j "${type}" -s "$state" -y "$releaseTime" -i "$RCName" -L "${dest_path}"
        fi
else
        echo "Tags creation script is not running because it is not a patch"
fi
