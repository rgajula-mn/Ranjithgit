#!/bin/ksh

# This file take an instance and a filelocation as its arguments, deletes the instance thats passed and creates
# a new db instance using the file supplied
#set -x
instance=$1
filename=$2
oracle_short_id=$3
oracle_data_location=$4
charset=$5
geneva_major=$6
db_edition=$7

if [ "${db_edition}" = "EE" ]
then
	setup_ext="_ee"
else
	setup_ext=""
fi
export setup_ext

tmp_file=/tmp/build_drop_and_create_db.$$
touch $tmp_file

. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh

###########################################################################################
#
#     #######
#     #        #    #  #    #   ####    #####     #     ####   #    #   ####
#     #        #    #  ##   #  #    #     #       #    #    #  ##   #  #
#     #####    #    #  # #  #  #          #       #    #    #  # #  #   ####
#     #        #    #  #  # #  #          #       #    #    #  #  # #       #
#     #        #    #  #   ##  #    #     #       #    #    #  #   ##  #    #
#     #         ####   #    #   ####      #       #     ####   #    #   ####
#
###########################################################################################

find_real_sqlhome ()
{
	if [ -r /var/opt/oracle/oratab ]
	then
		ORATAB=/var/opt/oracle/oratab
	elif [ -r /etc/oratab ]
	then
		ORATAB=/etc/oratab
	else
		echo "ERROR: ORATAB not in standard location."
		return 1
	fi

	oracle_home=`egrep "$instance:" $ORATAB | awk -F: '{print $2}'`
	if [ $? -ne 0 -o -z "$oracle_home" ]
	then
		echo "Cannot find the instance $instance in $ORATAB"
		return 2
	fi

	ORACLE_HOME=$oracle_home
	export ORACLE_HOME
	
	return 0	
}

error_sid_not_match ()
{
	echo "Error: new_sid does not match expected sid"
	echo "	new_sid  = $new_sid"
	echo "	instance = $instance"
	exit_program 1
}

check_result ()
{
	err_type=$2
	if [ -z "$err_type" ]
	then
		err_type="Warning"
	fi

	$1
	if [ $? -ne 0 ]
	then
		echo $err_type: $0: Running command $1
		echo $res
		if [ "$err_type" = "Error" ]
		then
			exit 1
		fi
	fi
}

exit_program ()
{
	echo ""
	rm $tmp_file
	if [ $1 -ne 0 ]
	then
		echo "Exiting $0 with status $1"
	fi
	exit $1
}

###########################################################################################
#
#     #    #    ##       #    #    #
#     ##  ##   #  #      #    ##   #
#     # ## #  #    #     #    # #  #
#     #    #  ######     #    #  # #
#     #    #  #    #     #    #   ##
#     #    #  #    #     #    #    #
#
###########################################################################################

if [ -z "$filename" -o -z "$instance" -o -z "$oracle_short_id" -o -z "$oracle_data_location" -o -z "$charset" -o -z "$geneva_major" ]
then
	echo "Usage: $0 <instance> <absolute file location> <oracle version> <ora data location> <charset>"
	echo "eg: $0 OSP3 /bceadmin/oracle_pak/solaris_64_jvm_9204_EE_WE8ISO8859P15.tar.Z 9.2.0.SE /Disk1/oradata/OSP3 WE8ISO8859P15"
	echo "instance             = $instance"
	echo "filename             = $filename"
	echo "oracle_short_id      = $oracle_short_id"
	echo "oracle_data_location = $oracle_data_location"
	echo "charset              = $charset"
	echo "geneva_major         = $geneva_major"
	exit_program 1
fi

hostname=`hostname`

if [ ! -f "$filename" ]
then
	echo "$0: Error: There is no $filename on $hostname"
	exit_program 1
fi

find_real_sqlhome
if [ $? -ne 0 ]
then
	echo "$0: Error: Cannot find valid SQLPLUS"
	echo "$ORACLE_HOME"
	exit_program 1
fi
DATABASE="sys/sys@${instance}.world as sysdba"
SYSDATABASE=" / as sysdba"

ORACLE_SID=$instance
export ORACLE_SID

if [ ! -d "$oracle_data_location" ]
then
	echo "$0: Error: No oracle data location: $oracle_data_location"
	exit_program 1
fi

PATH=$PATH:$ORACLE_HOME/bin
export PATH

echo "Enter Oracle and shutdown $SYSDATABASE"
$ORACLE_HOME/bin/sqlplus -s "$SYSDATABASE" << +END
	set feed off
	set head off
	set scan on
	set pages 1000
	set lines 32767
	shutdown abort;
	exit
+END

check_result "cd $oracle_data_location" Error

rm *.ctl *.sql *.dbf *.rdo *.log > /dev/null 2>&1

# Run extraction of new DB:
cat $filename |  tar xzvf -

# Enter Oracle and setup for builds
users_file=""
testfile=`echo $filename | grep "SE" | grep -v "92" | grep -v "10203"`
if [ ! -z "$testfile" ]
then
	users_file="_users"
fi
cat $BCE_BUILD_SCRIPTS/setup_build_db_${oracle_short_id}${setup_ext}${users_file}.sql | sed -e "s|SET_DISK|$oracle_data_location|g;s/SET_CHARACTERSET/$charset/g;s|ORACLE_SID|$ORACLE_SID|g" > $tmp_file

$ORACLE_HOME/bin/sqlplus -s "${SYSDATABASE}" << +ENDSQL
	@$tmp_file
	shutdown immediate
	exit
+ENDSQL

$ORACLE_HOME/bin/sqlplus -s "${SYSDATABASE}" << +ENDSQL
	startup
	exit
+ENDSQL

# Need to allow a couple of seconds for the TNS Service Handler to come up, sleep for 2 mins to be safe.
sleep 120

$ORACLE_HOME/bin/sqlplus -s "${SYSDATABASE}" << +ENDSQL
        @${BCE_BUILD_SCRIPTS}/create_GENEVAADMIN_role.sql
        exit
+ENDSQL

if [ "$oracle_short_id" = "9i2" ]
then
	$ORACLE_HOME/bin/sqlplus -s "${SYSDATABASE}" << +ENDSQL
		alter database datafile '$oracle_data_location/rbs01.dbf' resize 700m;
		commit;
	exit
+ENDSQL
fi

$ORACLE_HOME/bin/sqlplus -s "${SYSDATABASE}" << +ENDSQL
	alter database datafile '$oracle_data_location/system01.dbf' resize 1400m;
	commit;
	exit
+ENDSQL

# Enter Oracle and setup for builds and put results into variable
new_sid=`sql_query "sys/sys@${instance}.world as sysdba" 'select NAME from V$DATABASE' | sed -e 's/	| //g'`
if [ -z "$new_sid" ]
then
	error_sid_not_match
fi
new_sid=`echo $new_sid`

# Compare new_sid again $instance, if same then install has likely worked"
if [ "$new_sid" != "$instance" ]
then
	error_sid_not_match
fi

exit_program 0
