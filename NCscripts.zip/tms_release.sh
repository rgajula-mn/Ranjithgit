#!/bin/ksh
set -x
. /irb/bce/admin/ccm_wa/PRD-bce/PRD/build_scripts/core_functions_svn.sh
. /irb/bce/admin/ccm_wa/PRD-bce/PRD/build_scripts/buildweb_functions_svn.sh
CM_DB=`cm_connection`
rl_tag=$1
ins_sql="insert into release values ('TMS','$rl_tag','T')"
sql_query $CM_DB "$ins_sql"
