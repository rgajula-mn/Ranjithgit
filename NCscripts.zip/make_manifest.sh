#!/bin/sh

set -x

#BCE_BUILD_SCRIPTS=/irb/bce/users/sgraham1/PRD-sg/PRD/build_scripts
#export BCE_BUILD_SCRIPTS

. $BCE_BUILD_SCRIPTS/buildweb_functions_svn.sh
. $BCE_BUILD_SCRIPTS/core_functions_svn.sh

ccm_project=$1
logDate=$2
LOGDIR=${BCE_LOG}
#ccm_database=$3
release_tag=$3


tmp_file_2=/tmp/tasks$$

CPTDATABASE="cpt/cpt@webca.world"
BUILDWEB_DB="buildweb/georgespass@webca.world"
export CPTDATABASE tmp_file_2

if [ -f $tmp_file_2 ]
then
	rm $tmp_file_2
	if [ $? -ne 0 ]
	then
		echo "Cannot delete $tmp_file_2"
		exit 1
	fi
fi

#CCM_ADDR=`ccm start -q -m -nogui -d ${ccm_database} -r build_mgr`
#export CCM_ADDR

project_name=`echo $ccm_project | cut -d'-' -f1`
project_version=`echo $ccm_project | cut -d'-' -f2`

#ccm query "name='$project_name' and version='$project_version'" > /dev/null
#release_tag=`ccm attr -s release @1`

project_version_number=`echo $release_tag | cut -d'_' -f2`
project_state=`echo $project_version | sed -e 's/\([a-z]*\)[0-9].*/\1/'`
project_os_oracle=`echo $project_version | sed -e "s/$project_state${project_version_number}\.//"`


logdir=$LOGDIR/manifest_files/$project_name/$project_version_number/${project_state}/$project_os_oracle/$logDate

mkdir -p $logdir
if [ $? -ne 0 ]
then
	echo "Error: Cannot create $logdir"
	exit 1
fi

logfile=$logdir/manifest-$ccm_project.html

echo "<HTML><HEAD><TITLE>Manifest file for $ccm_project</TITLE></HEAD><BODY>" > $logfile

if [ -z "$ccm_project" ]
then
	echo "Error: You must enter a CCM Project to make a Manifest for"
	exit 1
fi



echo "<H1>Object List for $ccm_project</H1>" >> $logfile
echo "<H2>Top Level Project $ccm_project</H2>" >> $logfile
echo "<TABLE border=1><TH>Name</TH><TH>Version</TH><TH>Type</TH><TH>Instance</TH>" >> $logfile
#ccm query "is_member_of('$ccm_project') and type!='project'" -u -f "<TR><TD>%name</TD><TD>%version</TD><TD>%type</TD><TD>%instance</TD>" >> $logfile
echo "</TABLE>" >> $logfile

#for i in `ccm query "is_member_of('$ccm_project')" -t project -u -f "%displayname"`
#do
#	echo "<H2>Sub-Project $i</H2>" >> $logfile
#	echo "<TABLE border=1><TH>Name</TH><TH>Version</TH><TH>Type</TH><TH>Instance</TH>" >> $logfile
# 	ccm query "is_member_of('$i')" -u -f "<TR><TD>%name</TD><TD>%version</TD><TD>%type</TD><TD>%instance</TD>" >> $logfile
#	echo "</TABLE>" >> $logfile
#	echo $i
#done
. $BCE_BUILD_SCRIPTS/svn_new.svn 
sql="select MANIFEST_SEQ.nextval from dual"
tmp_number=`sql_query ${BUILDWEB_DB} "$sql"`
seq_number=`echo $tmp_number`

sql="insert into manifest_file (manifest_id, manifest, release_tag) values ('$seq_number', '$logfile', '$release_tag')"
sql_query ${BUILDWEB_DB} "$sql"

echo "<H1>CRs that have been actioned in this build.</H1>" >> $logfile

echo "<TABLE border=1><TH>CR Number</TH><TH>Enterer</TH><TH>Company</TH><TH>Synopsis</TH><TH>Subsystem</TH><TH>Severity</TH><TH>Task Number</TH><TH>Task Completion</TH>" >> $logfile

count=`echo $project_version_number|awk -F'.' '{print NF}'`

if [ $count -eq 3 ]
then
pro_ver=`echo $project_version_number|awk -F'.' '{print $1"."$2"."}'`
elif [ $count -eq 4 ]
then
pro_ver=`echo $project_version_number|awk -F'.' '{print $1"."$2"."$3"."}'`
fi

svn log https://svnhd.netcracker.com/$project_name/branches/MR/${pro_ver}x | grep 'RBM-' | sed -e 's/ //g'|sed -e 's/RBM-/ /g'|cut -d ' ' -f2|cut -c1-5| uniq -d > $logdir/svn_log.log

#svn log https://svnhd.netcracker.com/$project_name/branches/MR/${pro_ver}x >> $logdir/svn_log.log
#grep RBM- $logdir/svn_log.log >> $logdir/svn_log_final.log
#sed 's/ //g' $logdir/svn_log_final.log > $logdir/svn_log_final_1.log

#for task_string in `ccm reconfigure_properties -show all_tasks -u -f "%task_number %release %local_to" $ccm_project | grep "$release_tag" | sort -n | sed -e 's/  *$//' | sed -e 's/ /xxxs/g'`
#do
#	orig_task=`echo $task_string | sed -e 's/xxxs/ /g' | awk '{print $1}'`
#	local_to=`echo $task_string | sed -e 's/xxxs/ /g' | awk '{print $3}'`
#	local_to_set=""
#	case $local_to in
#		CB2)
#			task=`expr $orig_task + 1000000`
#			local_to_set=1000000
#			;;
#		CB5)
#			task=`expr $orig_task + 6000000`
#			local_to_set=6000000
#			;;
#		OR1)
#			task=`expr $orig_task + 2000000`
#			local_to_set=2000000
#			;;
#		OR2)
#			task=`expr $orig_task + 7000000`
#			local_to_set=7000000
#			;;
#		*)
#			task=$orig_task
#			;;
#	esac

#for i in `cat $logdir/svn_log_final_1.log`
#do
#	i=`echo "${i// /}"`
#	t=`echo $i|awk -F'RBM-' '{print $NF}'`
#	t=`expr $t + 800000000`
#	echo $t >> task_list

#done


#awk '!x[$0]++' task_list > task_list_final

#cat $logdir/svn_log_final.log|grep 'RBM'|tr 'RBM' '\nRBM'|grep '^RB'|sed 's/[:digit:]//g'|sed 's/[:a-z:]//g'|sed 's/[-,>]//g'|sed 's/[:A-Z:]//g'|uniq -d > $logdir/task_list_final

for i in `cat $logdir/svn_log.log`
do 
	t=`expr $i + 800000000`
	echo $t >> $logdir/task_list_final


done

for task in `cat $logdir/task_list_final`
do
			
	sql="SELECT '<TR><TD>', GENEVAPRS.PROBLEM_NUMBER, '</TD><TD>',
		GENEVAPRS.ENTERER, '</TD><TD>',
		GENEVAPRS.SUBMITTER_COMPANY, '</TD><TD>', 
		GENEVAPRS.PROBLEM_SYNOPSIS, '</TD><TD>',
		GENEVAPRS.PRODUCT_SUBSYS, '</TD><TD>',
		GENEVAPRS.SEVERITY, '</TD><TD>',
		PROBLEMHASTASK.TASK_NUMBER, '</TD><TD>',
		TASK.COMPLETION_DATE, '</TD>'
	FROM CPT.GENEVAPRS GENEVAPRS, CPT.TASK TASK, CPT.PROBLEMHASTASK PROBLEMHASTASK
	WHERE GENEVAPRS.PROBLEM_NUMBER=PROBLEMHASTASK.PROBLEM_NUMBER(+)
		AND PROBLEMHASTASK.TASK_NUMBER = TASK.TASK_NUMBER(+)
		AND TASK.TASK_NUMBER='$task'
	ORDER BY GENEVAPRS.PROBLEM_NUMBER asc, GENEVAPRS.SEVERITY desc;"

	#if [ "$local_to" = "CB1" ]
	#then
#		sql_query ${CPTDATABASE} "$sql" >> $tmp_file_2
#	else
#		sql_query ${CPTDATABASE} "$sql" | sed -e "s/$task/$local_to#$orig_task/g" >> $tmp_file_2
#	fi

sql_query ${CPTDATABASE} "$sql" >>  $logdir/gen.txt

	sql="insert into manifest_task (manifest_id, task) values ('$seq_number', '$task')"
	sql_query ${BUILDWEB_DB} "$sql"
done
#cat $tmp_file_2 | sort -n >> $logfile
cat $logdir/gen.txt | sort -n >> $logfile

echo "</TABLE>" >> $logfile

#ccm stop

echo "</BODY></HTML>" >> $logfile
mv $logdir/task_list_final $logdir/task_list_final_bk

echo "seq_number=$seq_number"
exit 0
