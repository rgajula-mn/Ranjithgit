#!/bin/sh
bld_date=$1
set -x 
rc_rel=$2
rc_ora=$3
rc_no=$4
rc_mjno=$5
ora_version=`echo "${rc_ora:(-3)}"`
usage()
{
echo "Usage: <sript name> <build date> <release> <oracle> <rc no> <mjr_release_no>"
echo "Eg: rc_steps.sh 20120314 rc_release(6.0.2) oracle11g rc_num(6) major_release_number(6.0)"
exit 1
}

if [ $# -ne 5 ]
then
        echo "Enter correct arguments"
        usage
fi


echo "value of rc: $bld_date, $rc_rel, $rc_ora"

#####sourcing the environment script######
echo "$BCE_LOG/$bld_date/env-RB_sqa$rc_rel.linux.$rc_ora.sh"
. "$BCE_LOG/$bld_date/env-RB_sqa$rc_rel.linux.$rc_ora.sh"

######changing the directory to APICAT to run genxsd script#########
cd  $CCM_ROOT/APICAT/ppet/SRC
ls -lL $CCM_ROOT/APICAT/ppet/SRC

sql=`sqlplus $DATABASE << +END
               set feed off
                set head off
		@genxsd.sql
               exit
+END`
echo $sql
ls -lL $CCM_ROOT/APICAT/ppet/SRC

tmp=`echo $rc_mjno | tr -d "."`
echo "tmp value $tmp"
##########Changing directory to webservices directory to generate the javadoc zip######
cd /irb/bce/build/web/RBAPI-sqa$rc_rel/RBAPI/build_output/webservices/javadoc
zip -r /irb/bce/build/web/RBAPI-sqa$rc_rel/RBAPI/build_release_all/distrib/external/webservices_javadoc.zip  *
ls -ltr /irb/bce/build/web/RBAPI-sqa$rc_rel/RBAPI/build_release_all/distrib/external/webservices_javadoc.zip
chmod 755 -R  /irb/bce/release/rb/$rc_mjno/RBINSTALL-sqa$rc_rel.linux.oracle11g/RBINSTALL/RB/RB/doc/eca/
cp  /irb/bce/build/web/RBAPI-sqa$rc_rel/RBAPI/build_release_all/distrib/external/javadoc.zip /irb/bce/release/rb/$rc_mjno/RBINSTALL-sqa$rc_rel.linux.$rc_ora/RBINSTALL/RB/RB/doc/eca/javadoc.zip

cp  /irb/bce/build/web/RBAPI-sqa$rc_rel/RBAPI/build_release_all/distrib/external/webservices_javadoc.zip /irb/bce/release/rb/$rc_mjno/RBINSTALL-sqa$rc_rel.linux.$rc_ora/RBINSTALL/RB/RB/doc/eca/webservices_javadoc.zip
##########running Saffire and Zenpack Zips############
echo $rc_rel
echo "rc_release is $rc_rel"
mkdir -p /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full
 
cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/SAFfire_RTK.zip /irb/bce/release/rb/$rc_mjno/RBSAFFIRE-sqa$rc_rel.linux.$rc_ora/RBSAFFIRE

cp /irb/bce/release/rb/$rc_mjno/RBSAFFIRE-sqa$rc_rel.linux.$rc_ora/RBSAFFIRE/SAFfire_RTK.zip /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/SAFfire_RTK.zip_11g
mv /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/SAFfire_RTK.zip_11g /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/RBSAFFIRE-$rc_rel'lX'.zip
ls -ltr /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/*SAFFIRE*

	mkdir -p /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/zenpack

if [ $tmp -eq 61 ] 
then
	cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.NetCracker.RTCC-6.1-py2.6.egg /irb/bce/release/rb/$rc_mjno/RBZENPACK-sqa$rc_rel.linux.$rc_ora/RBZENPACK/ZenPacks.NetCracker.RTCC_6.1_py2.6.egg
	cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.NetCracker.RTCC-6.1-py2.6.egg /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/zenpack
elif [ $tmp -eq 70 ]
then
        cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.NetCracker.RTCC-7.0-py2.7.egg /irb/bce/release/rb/$rc_mjno/RBZENPACK-sqa$rc_rel.linux.$rc_ora/RBZENPACK/ZenPacks.NetCracker.RTCC-7.0-py2.7.egg
        cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.NetCracker.RTCC-7.0-py2.7.egg /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/zenpack
elif [ $tmp -eq 80 ]
then
        cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.NetCracker.RTCC-6.1-py2.7.egg /irb/bce/release/rb/$rc_mjno/RBZENPACK-sqa$rc_rel.linux.$rc_ora/RBZENPACK/ZenPacks.NetCracker.RTCC-6.1-py2.7.egg
        cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.NetCracker.RTCC-6.1-py2.7.egg /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/zenpack
elif [ $tmp -ge 90 ]
then
	 cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.NetCracker.RTCC-9.0-py2.7.egg /irb/bce/release/rb/$rc_mjno/RBZENPACK-sqa$rc_rel.linux.$rc_ora/ZenPacks.NetCracker.RTCC-9.0-py2.7.egg
	cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.NetCracker.RTCC-9.0-py2.7.egg /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/zenpack
else
	cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.Convergys.RTCC-4.0-py2.4.egg /irb/bce/release/rb/$rc_mjno/RBZENPACK-sqa$rc_rel.linux.$rc_ora/RBZENPACK/ZenPacks.Convergys.RTCC_4.0_py2.4.egg
	cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.Convergys.IAM-1.0-py2.4.egg /irb/bce/release/rb/$rc_mjno/RBZENPACK-sqa$rc_rel.linux.$rc_ora/RBZENPACK/ZenPacks.Convergys.IAM_1.0_py2.4.egg
	cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.Convergys.RTCC-4.0-py2.6.egg /irb/bce/release/rb/$rc_mjno/RBZENPACK-sqa$rc_rel.linux.$rc_ora/RBZENPACK/ZenPacks.Convergys.RTCC_4.0_py2.6.egg
	cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.Convergys.IAM-1.0-py2.6.egg /irb/bce/release/rb/$rc_mjno/RBZENPACK-sqa$rc_rel.linux.$rc_ora/RBZENPACK/ZenPacks.Convergys.IAM_1.0_py2.6.egg

	cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.Convergys.RTCC-4.0-py2.4.egg /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/zenpack
	cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.Convergys.IAM-1.0-py2.4.egg /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/zenpack
	cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.Convergys.RTCC-4.0-py2.6.egg /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/zenpack
	cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/ZenPacks.Convergys.IAM-1.0-py2.6.egg /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/zenpack
fi
ls -ltr /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/zenpack 
cd /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/zenpack
zip -r /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/RBZENPACK-$rc_rel'lX'$ora_version.zip *
ls -ltr /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/*ZENPACK*
rm -rf /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/zenpack

#################
################# Copying RTCAINSTALL.zip from  ALLBATCH/bin to candidate/rc location ############
if [ $tmp -ge 61 ] 
then
ls -ltr /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/RTCAINSTALL.zip
if [ $? -eq 0 ]
then
cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/ALLBATCH/bin/RTCAINSTALL.zip /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/
mv /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/RTCAINSTALL.zip /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/RTCAINSTALL-$rc_rel'lX'$ora_version.zip
fi
fi
#################
################# OPENSAF_RPM.zip from  OPERABILITY/bin  to candidate/rc location ############
if [ $tmp -ge 61 ]
then
ls -ltr /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/OPERABILITY/bin/OPENSAF_RPM.zip
if [ $? -eq 0 ]
then
cp /irb/bce/build/rb/$rc_mjno/RB-sqa$rc_rel.linux.$rc_ora/RB/OPERABILITY/bin/OPENSAF_RPM.zip /irb/candidate/rc/rb/$rc_mjno/RB_$rc_rel.RC$rc_no/full/RBOPENSAF-$rc_rel'lX'$ora_version.zip
fi
fi
############
