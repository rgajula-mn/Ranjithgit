#!/bin/sh
#
# Extra functions supporting BFG
#
# andyd 25 June 1999
#

run_day() {
	echo ""
	echo $*
	runtoday="yes"
	while [ `echo "$1" | egrep -i "^(\-|\+)(Mon|Tue|Wed|Thu|Fri|Sat|Sun)"` ]
	do
		day_today=`date '+%a'`
		runday=`echo "$1" | sed -e 's/\-//g' -e 's/\+//g'`
		echo $day_today $runday
		if [ `echo "$1" | grep "\+"` ]
		then
			# Only run on days
			if [ "$day_today" != "$runday" ]
			then
				runtoday="no"
			else
				runtoday="yes"
				shift
				break
			fi
		else
			# Do not run on days
			if [ "$day_today" = "$runday" ]
			then
				runtoday="no"
				shift
				break
			else
				runtoday="yes"
			fi
		fi
		shift
	done

	while [ `echo "$1" | egrep -i "^(\-|\+)(Mon|Tue|Wed|Thu|Fri|Sat|Sun)"` ]
	do
		shift
	done

	if [ "$runtoday" = "no" ]
	then
		echo "Not running Today: $*"
		return 1
	fi

	echo "Running: $*"

	command="$1"

	while [ ! -z "$2" ]
	do
		command="$command $2"
		shift
	done
	echo command = $command
	
	$command
}

################################################################
# function that calls run_rtest.sh in the background:
################################################################

run_test() {
	if [ -z "${test_scripts}" ]
	then
		test_scripts=${BCE_TEST_SCRIPTS}
	fi
	
	today=`/bin/date '+%Y%m%d'`
	mkdir -p "${BCE_LOG}/${today}"

	command="${test_scripts}/run_rtest.sh" 
	
	while [ ! -z "$1" ]
	do
		if [ "$1" = "-p" ]
		then
			logFile="${BCE_LOG}/${today}/rtest-${2}.log"
		fi
		command="$command $1"
		shift
	done
	
	echo command = $command

	$command < /dev/null > ${logFile} 2>&1 &
	return 0
}

cleanupForBFG() {
	LOG_ROOT=$1
	if [ -n "$LOG_ROOT" -a -d "$LOG_ROOT" ]
	then
	    cd ${LOG_ROOT}
	    if [ "`uname -n`" = 'parc' ] 
	    then
	       DAYS=+2
	    else
	       DAYS=+5
	    fi
            if [ -x /usr/local/bin/find ] 
	    then
		/usr/local/bin/find . -mtime ${DAYS}  -type d -exec \chmod 777 {} \;
		/usr/local/bin/find . -mtime ${DAYS} -maxdepth 1 -exec \rm -rf {} \;
	    else
		/bin/find . -mtime ${DAYS} -type d -exec \chmod 777 {} \;
		/bin/find . -mtime ${DAYS} -type d -exec \rm -rf {} \;
	    fi
	    SAVENOW=`/usr/bin/date '+%Y%m%d'`
	    if [ ! -z "$TRACE_GDB" ]
	    then
		unset TRACE_GDB
	    fi
	    if [ ! -z "$TRACE_LEVEL" ]
	    then
		unset TRACE_LEVEL
	    fi
	else
	    echo "Error: LOG_ROOT not set, or set to a non-existent directory."
	fi
}

send_if_exists() {
	if [ -f $1 ]
	then
		cat $1 | /usr/lib/sendmail $2
	fi
}

mailResultsForBFG() {
	cd ${LOG_ROOT}/${1}/results
	send_if_exists summoutALL.html pdm.geneva.bce.rtest.log@convergys.com
	send_if_exists summoutALL.html "`cat ${BCE_ADMIN}/rtest/mail-results-to/summoutALL.recipients`"
	send_if_exists summoutAPI.html "`cat ${BCE_ADMIN}/rtest/mail-results-to/summoutAPI.recipients`"
	send_if_exists summoutBILL.html "`cat ${BCE_ADMIN}/rtest/mail-results-to/summoutBILL.recipients`"
	send_if_exists summoutCORE.html "`cat ${BCE_ADMIN}/rtest/mail-results-to/summoutCORE.recipients`"
	send_if_exists summoutIO.html "`cat ${BCE_ADMIN}/rtest/mail-results-to/summoutIO.recipients`"
	send_if_exists summoutRATE.html "`cat ${BCE_ADMIN}/rtest/mail-results-to/summoutRATE.recipients`"
        send_if_exists summoutREPORTS.html "`cat ${BCE_ADMIN}/rtest/mail-results-to/summoutREPORTS.recipients`"
}
		
enableCRUDE() {
	TRACE_GDB=ON
	TRACE_LEVEL=FULL
	export TRACE_GDB TRACE_LEVEL
}

################################################################
# Strip all duplicates from a PATH variable without re-ordering
################################################################
# Mandatory Param 1 - Original Path
################################################################
#
# Return values
# 0 Success
# 1 Failure
#
################################################################

stripPath() {
	oldPath="$1"
	if [ -z "${oldPath}" ]
	then
		return 1
	fi
	newPath=`echo "$oldPath" | tr ':' ' '`
	outPath=":"
	ignPath=""
	for aString in ${newPath}
	do
		if [ ! -z "$aString" ]
		then
			a=`echo "$aString" | sed -e 's/\/$//g'`
			echo "${outPath}" | egrep ":${a}:" > /dev/null
			if [ $? -eq 1 -o "${a}" = "." ]
			then
				outPath="${outPath}${a}:"
			else
				ignPath="${ignPath}${a}:"
			fi
		fi
	done
	outPath=`echo "$outPath" | sed -e 's/^://g;s/:$//g'`
	echo "${outPath}"
	return 0
}
