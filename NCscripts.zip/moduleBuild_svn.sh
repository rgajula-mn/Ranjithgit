#!/bin/ksh

set -x
. /home/genadmin/.bce.ini
#. ~/.bce.ini
. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
logdt=`date '+%Y%m%d%H%M%S'`
cat /dev/null > ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
if [ $# -ne 1 ]
then
	echo "[INFO] Date: `date`" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
	echo "[INFO] Script usage: moduleBuild.sh <release tag>. E.g. moduleBuild.sh RB_5.3.6.5" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
	exit
fi
	echo "[INFO] Date: `date`" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
os=`uname -a | cut -d" " -f1`
if [ "$os" != "Linux" ]
then
	echo "[INFO] This is not a linux machine." >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
	echo "[INFO] Please run the script in Linux machines - lilac, alder, cedar, rowan etc." >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
	echo "[INFO] Script usage: moduleBuild.sh <release tag>. E.g. moduleBuild.sh RB_5.3.6.5" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
	exit
fi

releaseTag=$1
project=`echo $releaseTag | cut -d"_" -f1`
releaseNum=`echo $releaseTag | sed 's/.*_//'`
minorRelease=`echo $releaseTag | sed -e "s/.*_//g" | cut -d'.' -f1-2`
projectLowerCase=`echo $project | tr '[A-Z]' '[a-z]'`
APICORE=1
APICAT=2
APICUSTACC=3
APISYSCONFIG=4
GNVUA=5
REPORTS=6
CORE=7
VPACORE=8
RATE=9
BILL=10
FINANCE=11
OPERABILITY=12
INSTALLATION=13
result=`sqlplus -s buildweb/georgespass@webca.world << EOF
	whenever sqlerror exit failure
	set feed off
	set head off
	select OPER_SYS,ORACLE_NAME from patch_platforms where project='$project' and version='$releaseNum';
	exit
EOF`
platform=`echo $result | cut -d" " -f1`
oracle=`echo $result | cut -d " " -f2`
CCM_ROOT="/irb/bce/build/$projectLowerCase/$minorRelease/$project-sqa$releaseNum.$platform.$oracle/$project/"
#. $CCM_ROOT/env*.sh
prep_project=`echo $CCM_ROOT | cut -d"/" -f7`
LIST_OF_MODULES=""
LIST_OF_PROJECTS=""

#        startCCM /ccm/prd
#        if [ -z "${CCM_ADDR}" ]
#        then
#                printf "\t[ERROR] CCM Failed to start. Exiting program.\n" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
#                cleanUpCCM
#                exit 1
#        else
#                printf "[INFO] CCM Started\n" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
#        fi
echo "[INFO] Starting reconfigure..." >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
echo "[INFO] ccm_root value....... $CCM_ROOT..." >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
cd $CCM_ROOT
SVN_HOME=/tools/svn_client/subversion-1.7.13
PATH=$SVN_HOME/bin:$PATH
LD_LIBRARY_PATH=$SVN_HOME/lib:$LD_LIBRARY_PATH
export PATH LD_LIBRARY_PATH SVN_HOME
svn update > ${BCE_LOG}/partialbuild/svn_up_$1.$logdt.log
#cp ${BCE_LOG}/partialbuild/svn_up_RB_5.3.8.217.20161121094725.log ${BCE_LOG}/partialbuild/svn_up_$1.$logdt.log
#ccm reconf -r -p $project-sqa${releaseNum}.${platform}.${oracle} >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
patchTasks=`sqlplus -s cpt/cpt@webca.world << EOF
            whenever sqlerror exit failure
            set feed off
            set head off
            select TASK_NUMBER from task where RELEASE='$releaseTag';
            exit
EOF`

#patchTasks=`ccm query -t task "release='$releaseTag' and status='completed' and owner!='genadmin'" -f %task_number | awk '{print $2}'`
cat /dev/null > /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
echo "[INFO] Querying tasks" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
for task in $patchTasks
do
	echo "-------------------------------------" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
	echo "[TASK] $task" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
	result=`sqlplus -s cpt/cpt@webca.world << EOF
        whenever sqlerror exit failure
        set feed off
        set head off
        select unique(deliverable_name) from submittedtaskdeliverable where task_number in ($task);
      exit
EOF`
	for deliverable in $result
	do
		echo "[DELIVERABLE] $deliverable" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
		query_output=`echo $deliverable | grep "\.plb\$"`
		if [ $? -eq 0 ]
		then
			deliverable=`echo $deliverable | sed "s/plb$/bdy/"`
			fileWorkArea=`find $CCM_ROOT -name $deliverable`
			module=`echo $fileWorkArea | cut -d"/" -f10`
			subproject=`echo $fileWorkArea | cut -d"/" -f9`
			output=`find $CCM_ROOT/$subproject -name "Makefile" -exec egrep -n "MODULES =[\t[:space:]]+.+${module}[\t[:space:]]+|MODULES \+=[\t[:space:]]+${module}$|[\t[:space:]]+${module}[\t[:space:]]+[\\]$" {} \; | grep -v "^#"`
			if [ "$output" = "" ]
			then
				echo "[ERROR] $module was not mentioned in Makefile in $CCM_ROOT/$subproject." >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
			else
				linenumber=`echo $output | cut -d ":" -f1`
						gnvua_ob=`echo $deliverable|grep 'GNVUA'`
						if [ $? = 0 ]
	                                        then
                                                        module='GNVUA'
                                                else
                                                        module=`echo $i|cut -d"/" -f9`
                                                fi
				echo "[FOUND] Found $deliverable in $module" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
			fi
			eval echo $subproject:$module:\${$subproject}.$linenumber >> /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
			LIST_OF_MODULES=`echo $LIST_OF_MODULES $module`
			LIST_OF_PROJECTS=`echo $LIST_OF_PROJECTS $subproject`
		fi
		query_output=`echo $deliverable | grep "\.so\$"`
		if [ $? -eq 0 ]
		then
			output=`find $CCM_ROOT -maxdepth 4 -name "Makefile" -exec egrep -l "[\t[:space:]]+=[\t[:space:]]+$deliverable" {} \; | grep -v "CUST_LIB" | grep -v "^#"`
			module=`echo $output | cut -d "/" -f10`
			#output=`find $CCM_ROOT -maxdepth 2 -name "Makefile" -exec egrep -Hn "MODULES =[\t[:space:]]+.+${module}[\t[:space:]]+|MODULES \+=[\t[:space:]]+${module}$|[\t[:space:]]+${module}[\t[:space:]]+[\\]$" {} \; | grep -v "^#"`
			for i in `find $CCM_ROOT -maxdepth 2 -name "Makefile"`
			do
				cat /dev/null > /tmp/temp_makefile
				for j in $(sed -n '/#/!p' $i)
				do
					echo $j >> /tmp/temp_makefile
				done
				output=`cat /tmp/temp_makefile | sed -n '/MODULE/,/include/p' | egrep -v "^[#=(@+:%]|MODULE|include" | grep -nw $module`
				if [ $? -eq 0 ]
				then
					subproject=`echo $i|cut -d"/" -f9`
					echo "[FOUND] Found $deliverable in $subproject" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
					found="T"
					break
				fi
			done		
			if [ "$found" != "T" ]
			then
				echo "[ERROR] $module was not mentioned in Makefile in $CCM_ROOT." >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
				found=""
			else
				
				linenumber=`echo $output | cut -d ":" -f1`
				#subproject=`echo $output | cut -d ":" -f1 | cut -d "/" -f9`
				found=""
			fi
			eval echo $subproject:$module:\${$subproject}.$linenumber >> /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
                        LIST_OF_MODULES=`echo $LIST_OF_MODULES $module`
                        LIST_OF_PROJECTS=`echo $LIST_OF_PROJECTS $subproject`
		fi
		query_output=`echo $deliverable | grep -v "\." | egrep -v "Messages_VPA|Messages_API|Schema|APIs|APICORE|None_-_Rtest_only"`
		if [ $? -eq 0 ]
		then
			#output=`find $CCM_ROOT -maxdepth 2 -name "Makefile" -exec egrep -Hn "MODULES =[\t[:space:]]+.+${deliverable}[\t[:space:]]+|MODULES \+=[\t[:space:]]+${deliverable}$|[\t[:space:]]+${deliverable}[\t[:space:]]+[\\]$|[\t[:space:]]+${deliverable}[\t[:space:]]+" {} \; | grep -v "^#"`
			for i in `find $CCM_ROOT -maxdepth 2 -name "Makefile"`
                        do
                                cat /dev/null > /tmp/temp_makefile
                                for j in $(sed -n '/#/!p' $i)
                                do
                                        echo $j >> /tmp/temp_makefile
                                done
                                output=`cat /tmp/temp_makefile | sed -n '/MODULE/,/include/p' | egrep -v "^[#=(@+:%]|MODULE|include" | grep -nw $deliverable`
                                if [ $? -eq 0 ]
                                then
                                        subproject=`echo $i|cut -d"/" -f9`
					echo "[FOUND] Found $deliverable in $subproject" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
					found="T"
                                        break
                                fi
                        done
			if [ "$found" != "T" ]
			then
				echo "[ERROR] $deliverable was not mentioned in Makefile in $CCM_ROOT." >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
			else
				linenumber=`echo $output | cut -d ":" -f1`
				#subproject=`echo $output | cut -d ":" -f1 | cut -d "/" -f9`
				module=$deliverable
				found=""
			fi
			eval echo $subproject:$module:\${$subproject}.$linenumber >> /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
                        LIST_OF_MODULES=`echo $LIST_OF_MODULES $module`
                        LIST_OF_PROJECTS=`echo $LIST_OF_PROJECTS $subproject`
		fi
	done
#	echo "[INFO] Querying objects in task Cb1#$task" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
#	objects=`ccm task CB1#$task -sh obj | grep -v "dir" | awk '{print $2}'`
#	for object in $objects
#	do
#		echo "[OBJECT] $object" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
#		fileName=`echo $object | cut -d ":" -f1 | cut -d "-" -f1`
#		fileVersion=`echo $object |cut -d ":" -f1 | cut -d "-" -f2`
#		fileWorkArea=`ccm finduse $object -prep_proj | grep  sqa${releaseNum} | tr -d '^[\t]+' | egrep -v "PATCH|INSTALL"`

#                        cd $CCM_ROOT 
#                        export PATCH=/tools/svn_client_rhel6/bin/svn:$PATCH
#                         svn update > ${BCE_LOG}/partialbuild/svn_up_$1.$logdt.log
#                        objects=`cat ${BCE_LOG}/partialbuild/svn_up_$1.$logdt.log |cut -d ' ' -f2`
			objects=`cat ${BCE_LOG}/partialbuild/svn_up_$1.$logdt.log|grep -v Updated|grep -v Restored|grep -v genevamessages.txt|grep -v revision|awk '{print $2}'|grep -v "'.'"|grep -v 'to'|sort`
                        for object in $objects
                      do
                          echo "[OBJECT] $object" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
                   fileWorkArea=$object
		if [ "$fileWorkArea" != "" ]
		then
			proj=`echo $fileWorkArea | cut -d "/" -f1`
			if [ "$proj" = "PC" -o "proj" = "SCHEMA" ]
			then
				echo "[SKIP] Skipping PC/SCHEMA project" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
				continue
			fi
			module=`echo $fileWorkArea | cut -d "/" -f2`
                        if [ "$module" != "SRC" -a "$module" != "source" -a "$module" != "RTEST" -a "$module" != "DOC" ]
                        then
                                subproject=`echo $fileWorkArea | cut -d "/" -f1`
                                #output=`find $CCM_ROOT/$subproject -name "Makefile" -exec egrep -n "MODULES =[\t[:space:]]+.+${module}[\t[:space:]]+|MODULES \+=[\t[:space:]]+${module}$|[\t[:space:]]+${module}[\t[:space:]]+[\\]$|[\t[:space:]]+${module}[\t[:space:]]+" {} \; | grep -v "^#" `
				#output=`find $CCM_ROOT -maxdepth 2 -name "Makefile" -exec egrep -Hn "MODULES =[\t[:space:]]+.+${module}[\t[:space:]]+|MODULES \+=[\t[:space:]]+${module}$|[\t[:space:]]+${module}[\t[:space:]]+[\\]$|[\t[:space:]]+.+[\t[:space:]]+${module}[\t[:space:]]+" {} \; | grep -v "^#"`
				for i in `find $CCM_ROOT -maxdepth 2 -name "Makefile"|sort`
	                        do
        	                        cat /dev/null > /tmp/temp_makefile
                	                for j in $(sed -n '/#/!p' $i)
                        	        do
                                	        echo $j >> /tmp/temp_makefile
	                                done
        	                        output=`cat /tmp/temp_makefile | sed -n '/MODULE/,/include/p' | egrep -v "^[#=(@+:%]|MODULE|include" | grep -nw $module`
                	                if [ $? -eq 0 ]
                        	        then
						gnvua_ob=`echo $object|grep 'GNVUA'`
						if [ $? = 0 ]
						then
							subproject='GNVUA'
						else
                                        		subproject=`echo $i|cut -d"/" -f9`
						fi
						echo "[FOUND] Found $object in $subproject" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
						found="T"
 	                                       break
                                	fi
	                        done
                                if [ "$found" != "T" ]
                                then
                                        echo "[ERROR] $object->$module was not mentioned in Makefile in $CCM_ROOT/$subproject." >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
                                else
                                        linenumber=`echo $output | cut -d ":" -f1`
					found=""
                                fi
                                eval echo $subproject:$module:\${$subproject}.$linenumber >> /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
                                LIST_OF_MODULES=`echo $LIST_OF_MODULES $module`
                                LIST_OF_PROJECTS=`echo $LIST_OF_PROJECTS $subproject`
                        else
                                echo "[SKIP] $object is found in $module in $fileWorkArea. Skipping..." >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
                        fi
		else
			echo "[ERROR] Work Area not found for $object." >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
		fi
	done	
		
	done
	echo ""

printf "\n[INFO] LIST_OF_MODULES TO BUILD:\n`echo $LIST_OF_MODULES | tr ' ' '\n' | sort | uniq`\n" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
printf "\n[INFO] LIST_OF_PROJECTS:\n`echo $LIST_OF_PROJECTS | tr ' ' '\n' | sort | uniq`\n\n" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
#sort -n /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle} -t ":" -k3 | uniq | awk -F: '{print $1,$2}' > /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}.tmp
#sort -n /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle} -t ":" -k3 | uniq  > /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}.tmp
sort -n /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle} -t "." -k2 | uniq  > /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}.tmp
rm -rf /tmp/${releaseTag}_*.txt
for i in `cat /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}.tmp`
do 
	echo $i|grep OPERABILITY >> /tmp/${releaseTag}_operability.txt
	echo $i|grep APICAT >> /tmp/${releaseTag}_apicat.txt
	echo $i|grep APICORE >> /tmp/${releaseTag}_apicore.txt
	echo $i|grep APICUSTACC >> /tmp/${releaseTag}_apicustacc.txt
	echo $i|grep APISYSCONFIG >> /tmp/${releaseTag}_apisys.txt
	echo $i|grep GNVUA >> /tmp/${releaseTag}_gnvua.txt
	echo $i|grep REPORTS >> /tmp/${releaseTag}_reports.txt
	echo $i|grep -v VPACORE|grep CORE >> /tmp/${releaseTag}_core.txt
	echo $i|grep VPACORE >> /tmp/${releaseTag}_vpacore.txt
	echo $i|grep promointeg >> /tmp/${releaseTag}_promointeg.txt
	echo $i|grep BILL >> /tmp/${releaseTag}_bill.txt
	echo $i|grep RATE >> /tmp/${releaseTag}_rate.txt
	echo $i|grep FINANCE >> /tmp/${releaseTag}_finance.txt
done
cat /tmp/${releaseTag}_apicat.txt > /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
cat /tmp/${releaseTag}_apicore.txt >>  /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
cat /tmp/${releaseTag}_apicustacc.txt >>  /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
cat /tmp/${releaseTag}_apisys.txt >>  /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
cat /tmp/${releaseTag}_gnvua.txt >>  /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
cat /tmp/${releaseTag}_reports.txt >>  /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
cat /tmp/${releaseTag}_core.txt >>  /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
cat /tmp/${releaseTag}_vpacore.txt >>  /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
cat /tmp/${releaseTag}_promointeg.txt >>  /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
cat /tmp/${releaseTag}_bill.txt >>  /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
cat /tmp/${releaseTag}_rate.txt >>  /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
cat /tmp/${releaseTag}_finance.txt >>  /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
cat /tmp/${releaseTag}_operability.txt >>  /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}

#mv /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}.tmp /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}
	#machine=`sqlplus -s buildweb/georgespass@webca.world
	machine=`sqlplus -s buildweb/georgespass@webca.world << EOF
        whenever sqlerror exit failure
        set feed off
        set head off
	select MACHINE from overrides_for_release where PROJECT='$project' and VERSION='$releaseNum' and PLATFORM='$platform' and ORACLE_PLATFORM='$oracle';
	exit
EOF`
if [ "$machine" = "" ]
then
	machine=`sqlplus -s buildweb/georgespass@webca.world << EOF
        whenever sqlerror exit failure
        set feed off
        set head off
        select MACHINE from defaults_for_release where PROJECT='$project' and MAJOR_RELEASE='$minorRelease' and PLATFORM='$platform' and ORACLE_PLATFORM='$oracle';
	exit
EOF`
	echo $machine
fi
log_part=`echo ${BCE_LOG}/partialbuild/runPartialBuild_make_log_$1.$logdt.log`
echo "[INFO] ***************************************************" >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
echo "[INFO] Starting module build." >> ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.$logdt.log
touch ${BCE_LOG}/partialbuild/runPartialBuild_make_log_$1.$logdt.log
if [ $machine = "camdl121"  -o $machine = "camvl21" -o $machine = "camdl30" -o $machine = "box" -o $machine = "camal32" -o $machine = "albatross" ]
then
	echo "ssh $machine $BCE_BUILD_SCRIPTS/runPartialBuild.sh $releaseTag $platform $oracle $CCM_ROOT $log_part $logdt" >> ${BCE_LOG}/partialbuild/runPartialBuild_make_log_$1.$logdt.log 2>&1
	ssh $machine "bash .bce.ini; $BCE_BUILD_SCRIPTS/runPartialBuild.sh $releaseTag $platform $oracle $CCM_ROOT $log_part $logdt" >> ${BCE_LOG}/partialbuild/runPartialBuild_make_log_$1.$logdt.log 2>&1
else
	echo "ssh $machine $BCE_BUILD_SCRIPTS/runPartialBuild.sh $releaseTag $platform $oracle $CCM_ROOT $log_part $logdt" >> ${BCE_LOG}/partialbuild/runPartialBuild_make_log_$1.$logdt.log 2>&1
	ssh $machine "bash ~/.bce.ini; $BCE_BUILD_SCRIPTS/runPartialBuild.sh $releaseTag $platform $oracle $CCM_ROOT $log_part $logdt" >> ${BCE_LOG}/partialbuild/runPartialBuild_make_log_$1.$logdt.log 2>&1
fi
