#!/bin/ksh
set -x

# This script will install Platform, RBM and ECA using the RB_IU_HANDLER
# into a clean database. Will catch any errors and create a report of the
# installation process. Should be run after the creation of each release
# candidate. Currently Backend SE database only.

# Include files
. $BCE_BUILD_SCRIPTS/buildweb_functions_svn.sh
. $BCE_BUILD_SCRIPTS/core_functions_svn.sh

# Default Variables
RANDOM_NUMBER=$$


# Usage function

usage()
{
	echo "$0 <-p ccm project> <-z RB zip file inc path> [-h]"
	echo ""
	echo "e.g. $0 -p RB-sqa4.1.1.solaris.oracle10g -z /irb/drop/rc/rb/4.1/RB_4.1.1.RC1.1/full/RB-4.1.1lX10g.zip"
	echo ""
	echo "where:"
	echo "	synergy project      = is a valid genadmin project for this release"
	echo "	RB zip file inc path = is the path to the RB zip file"
	echo "  -h shoulds this help information"
	exit 1
}

ORACLE_SID=""

# Argument handler
while getopts s:p:z:h the_option
do
    case $the_option in
        s)
		    ORACLE_SID="$OPTARG"
            ;;
        h)
            usage
            ;;
        p)
            CCM_PROJECT="$OPTARG"
            export CCM_PROJECT
            ;;
        z)
            RB_PACKAGE_PLUS_PATH="$OPTARG"
            export RB_PACKAGE_PLUS_PATH
            ;;
        [?])
            usage
            ;;
    esac
done

if [ -z "$CCM_PROJECT" ]
then
	echo "You must enter a Synergy Project name"
	usage
fi

if [ -z "$RB_PACKAGE_PLUS_PATH" ]
then
	echo "You must enter a valid RB zip file + path"
	echo "You entered -z $RB_PACKAGE_PLUS_PATH"
	usage
fi

# Take Apart the CCM_PROJECT variable
ORACLE_VERSION=`echo $CCM_PROJECT | sed -e 's/.*\.//'`
REMAIN_1=`echo $CCM_PROJECT | sed -e "s/\.$ORACLE_VERSION//g"`
PLATFORM_OS=`echo $REMAIN_1 | sed -e 's/.*\.//'`
REMAIN_2=`echo $REMAIN_1 | sed -e "s/\.$PLATFORM_OS//g"`
RB_VERSION=`echo $REMAIN_2 | sed -e 's/.*-[a-z]*//g'`
RB_MAJOR_VERSION=`echo $RB_VERSION | cut -d'.' -f1-2`

# Allocate a clean database
echo "Info: Attempting to find a free databases, may take upto 15 minutes"
if [ -z "$ORACLE_SID" ]
then
	ORACLE_SID=`choose_build_db.sh -o $ORACLE_VERSION -p $CCM_PROJECT -m $RB_MAJOR_VERSION -t sqa -e EE -l 0.1 -i | cut -d'.' -f1`
fi

if [ $? -ne 0 ]
then
	echo "Error: Running choose_build_db.sh gave"
	echo $ORACLE_SID
	exit 6
fi
export ORACLE_SID

CACHE1_SID=`choose_build_db.sh -o $ORACLE_VERSION -p $CCM_PROJECT -m $RB_MAJOR_VERSION -t sqa -e SE -l 0.1 -i | cut -d'.' -f1`
if [ $? -ne 0 ]
then
	echo "Error: Running choose_build_db.sh gave"
	echo $CACHE1_SID
	exit 6
fi
export CACHE1_SID

CACHE2_SID=`choose_build_db.sh -o $ORACLE_VERSION -p $CCM_PROJECT -m $RB_MAJOR_VERSION -t sqa -e SE -l 0.1 -i | cut -d'.' -f1`
if [ $? -ne 0 ]
then
	echo "Error: Running choose_build_db.sh gave"
	echo $CACHE2_SID
	exit 6
fi
export CACHE2_SID

# INFINYS_ROOT is the variable which stores the installation location of Infinys
INFINYS_ROOT=/irb/archive/archive3/infinys_installs/$CCM_PROJECT
export INFINYS_ROOT
if [ -d $INFINYS_ROOT ]
then
	echo "Info: $INFINYS_ROOT already existed - DELETING"

	chmod -R 777 $INFINYS_ROOT > /dev/null 2>&1
	rm -rf $INFINYS_ROOT
	if [ $? -ne 0 ]
	then
		echo "Error: Cannot delete old INFINYS_ROOT: $INFINYS_ROOT"
		exit 6
	fi
fi

mkdir -p $INFINYS_ROOT
if [ $? -ne 0 ]
then
	echo "Error: Failed to create $INFINYS_ROOT"
	exit 6
fi

# Create PKG_ROOT (package root) this is where the packaes to install will be located
# PKG_ROOT will be $INFINYS_ROOT/packages
PKG_ROOT=$INFINYS_ROOT/packages
export PKG_ROOT
mkdir -p $PKG_ROOT

# Setup oracle connectiosn to BUILDWEB database
find_sqlhome 12.1.0.1.SE
BUILDWEB_DB=`buildweb_connection`

# Determine the packages to install from $CCM_PROJECT (INSTALLER, UTILITIES, PLATFORM, RB and ECA)
# RB needed came from the arguments to this file
RB_PACKAGE_NAME=`basename $RB_PACKAGE_PLUS_PATH`
RB_PACKAGE_PATH=`dirname $RB_PACKAGE_PLUS_PATH`
echo "Info: Using RB:          $RB_PACKAGE_PLUS_PATH"

# ECA should come from same location as RB (just weblogic for now)
ECA_PACKAGE_PATH=`dirname $RB_PACKAGE_PLUS_PATH`
ECA_PACKAGE_NAME=`ls $ECA_PACKAGE_PATH | grep ECA | grep WebLogic | grep zip | head -1`
ECA_PACKAGE_PLUS_PATH=$ECA_PACKAGE_PATH/$ECA_PACKAGE_NAME
echo "Info: Using ECA:         $ECA_PACKAGE_PLUS_PATH"

# PLATFORM should come from depversion
PF_PACKAGE_PATH=`choose_platform.sh RB $RB_VERSION $ORACLE_VERSION prd`/../..
if [ $? -ne 0 ]
then
	echo "Error: From choose_platform.sh RB $RB_VERSION $ORACLE_VERSION prd"
	exit 1
fi
PF_PACKAGE_NAME=`ls $PF_PACKAGE_PATH | grep zip`
PF_PACKAGE_PLUS_PATH=$PF_PACKAGE_PATH/$PF_PACKAGE_NAME
PF_VERSION=`echo $PF_PACKAGE_PATH | sed -e 's/.*\/IPF\(.*\)\/PF-.*/\1/'`
echo "Info: Using Platform:    $PF_PACKAGE_PLUS_PATH"

# INSTALLER should come from depversion

sql="select depversion from depversion where project='PLATFORM' and version='$PF_VERSION';"
RESULT_TMP=`sql_query $BUILDWEB_DB "$sql" N`
IS_VERSION=`echo $RESULT_TMP`
sql="select path from path_details where project='INSTALLER' and version='$IS_VERSION';"
RESULT_TMP=`sql_query $BUILDWEB_DB "$sql" N`
IS_PACKAGE_PATH=`echo $RESULT_TMP`
IS_PACKAGE_NAME=`ls $IS_PACKAGE_PATH | grep jar`
IS_PACKAGE_PLUS_PATH=$IS_PACKAGE_PATH/$IS_PACKAGE_NAME

if [ -z "$IS_PACKAGE_NAME" -o -z "$IS_PACKAGE_PATH" ]
then
	echo "Error: Cannot find the correct version or PATH for INSTALLER"
	exit 3
fi

echo "Info: Using Installer:   $IS_PACKAGE_PLUS_PATH"

# UTILITIES should come from depversion
sql="select depversion from depversion where project='INSTALLER' and version='$IS_VERSION';"
RESULT_TMP=`sql_query $BUILDWEB_DB "$sql" N`
UTIL_VERSION=`echo $RESULT_TMP`
sql="select path from path_details where project='UTILITIES' and version='$UTIL_VERSION';"
RESULT_TMP=`sql_query $BUILDWEB_DB "$sql" N`
UTIL_PACKAGE_PATH=`echo $RESULT_TMP`
UTIL_PACKAGE_NAME=`ls $UTIL_PACKAGE_PATH | grep zip`
UTIL_PACKAGE_PLUS_PATH=$UTIL_PACKAGE_PATH/$UTIL_PACKAGE_NAME

if [ -z "$UTIL_PACKAGE_NAME" -o -z "$UTIL_PACKAGE_PATH" ]
then
	echo "Error: Cannot find the correct version or PATH for UTILITIES"
	exit 3
fi

echo "Info: Using Utilities:   $UTIL_PACKAGE_PLUS_PATH"

# Link the packages to install into PKG_ROOT
#ln -s $RB_PACKAGE_PLUS_PATH $PKG_ROOT/.
#ln -s $ECA_PACKAGE_PLUS_PATH $PKG_ROOT/.
#ln -s $PF_PACKAGE_PLUS_PATH $PKG_ROOT/.
#ln -s $IS_PACKAGE_PLUS_PATH $PKG_ROOT/.
#ln -s $UTIL_PACKAGE_PLUS_PATH $PKG_ROOT/.

# Extract the infinys.env file from Utilities
#cd $INFINYS_ROOT
#unzip -oqj $PKG_ROOT/$UTIL_PACKAGE_NAME UTILITIES/Installation/infinys.env
#INFINYS_ENV_FILE=$INFINYS_ROOT/infinys.env
#touch $INFINYS_ROOT/infinys.env
#chmod 755 $INFINYS_ROOT/infinys.env

# Update the infinys.env file

INFINYS_LOGS=$INFINYS_ROOT/logs
TMP_ROOT=$INFINYS_ROOT/tmp
STAGE_ROOT=$INFINYS_ROOT/stage
DEPLOYABLE_ROOT=$INFINYS_ROOT/deployable
ARCHIVE_ROOT=$INFINYS_ROOT/archive
export INFINYS_LOGS TMP_ROOT STAGE_ROOT DEPLOYABLE_ROOT ARCHIVE_ROOT


for i in `ls / | grep Disk1`
do
	if [ -d "/$i/app/weblogic/weblogic_10.3.6" ]
	then
		export BEA_HOME=/$i/app/weblogic/weblogic_10.3.6
		continue
	fi
done
if [ -z "$BEA_HOME" ]
then
	echo "Error: Cannot find BEA Weblogic 10.3.6"
	exit 4
fi
WL_HOME=$BEA_HOME/wlserver_10.3
export WL_HOME BEA_HOME

#JAVA_HOME=/tools/java/jdk1.7.0_25
JAVA_HOME=/tools/java/jdk1.8.0_65
export JAVA_HOME

TWO_TASK=$ORACLE_SID
export TWO_TASK

DB_USERNAME=geneva_admin
DATABASE=$DB_USERNAME/$DB_USERNAME@$ORACLE_SID
CVG_LICENSE_PATH=/opt/RB/license/$RB_MAJOR_VERSION
CVG_LICENSE_FILE=$CVG_LICENSE_PATH/license.xml
CVG_LICENSE_CERTIFICATE=$CVG_LICENSE_PATH/license.crt
COMMSERVER_NO_ACK=Y

export CVG_LICENSE_PATH DATABASE CVG_LICENSE_CERTIFICATE CVG_LICENSE_FILE COMMSERVER_NO_ACK

PATH=$INFINYS_ROOT/PF/bin:$INFINYS_ROOT/RB/bin:$STAGE_ROOT/RB/RB/bin:$STAGE_ROOT/PF/platform/bin:$TMP_ROOT/PF/platform/bin:$JAVA_HOME/bin:.:$ORACLE_HOME/bin:/sbin:/usr/sbin:/usr/bin:/bin:$PATH

LD_LIBRARY_PATH=$ORACLE_HOME/obackup/lib:$ORACLE_HOME/lib:$ORACLE_HOME/lib32:$INFINYS_ROOT/PF/lib:$INFINYS_ROOT/RB/lib:$TMP_ROOT/PF/platform/lib:$STAGE_ROOT/PF/platform/lib:$TMP_ROOT/RB/RB/lib:$STAGE_ROOT/RB/RB/lib:$STAGE_ROOT/RB/RB/lib:$LD_LIBRARY_PATH

LIBPATH=$LD_LIBRARY_PATH
SHLIB_PATH=$LD_LIBRARY_PATH

export PATH LD_LIBRARY_PATH SHLIB_PATH LIBPATH

# Unzip the RB_IU_HANDLER from the RB package
cd $INFINYS_ROOT
unzip -j $RB_PACKAGE_PLUS_PATH RB/RB/RBIUH/RB_IU_Handler.ksh -d `pwd` > /dev/null 2>&1
#chmod 755 RB_IU_Handler.ksh
#rm RB_IU_Handler.ksh
#cp ../RB_IU_Handler.ksh .

unzip -j $RB_PACKAGE_PLUS_PATH RB/RB/RBIUH/rbiuh_config_sample.xml -d `pwd` > /dev/null 2>&1
`ls -altr $INFINYS_ROOT/`
cp $INFINYS_ROOT/rbiuh_config_sample.xml $INFINYS_ROOT/rbiuh_config.xml

#cp ../rbiuh_config_sample.xml rbiuh_config.xml
CONFIG_FILE=rbiuh_config.xml
mkdir -p RB/CORE/TOOL

database_server=`database_server.sh $ORACLE_SID`

cache1_server=`database_server.sh $CACHE1_SID`
cache2_server=`database_server.sh $CACHE2_SID`

chmod u+w $CONFIG_FILE
cat ${CONFIG_FILE} | sed -e "s|ENTER_YOUR_INFINYS_ROOT_DIR|$INFINYS_ROOT|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_YOUR_PACKAGE_ROOT_DIR|$PKG_ROOT|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_RB_ZIP_FILE_PATH|$RB_PACKAGE_PATH|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_RB_ZIP_FILE_NAME|$RB_PACKAGE_NAME|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_PF_ZIP_FILE_PATH|$PF_PACKAGE_PATH|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_PF_ZIP_FILE_NAME|$PF_PACKAGE_NAME|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_UTILITIES_ZIP_FILE_PATH|$UTIL_PACKAGE_PATH|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_UTILITIES_ZIP_FILE_NAME|$UTIL_PACKAGE_NAME|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_ECA_ZIP_FILE_PATH|$ECA_PACKAGE_PATH|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_ECA_ZIP_FILE_NAME|$ECA_PACKAGE_NAME|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_TAP3_ZIP_FILE_PATH|$TAP3_PACKAGE_PATH|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_TAP3_ZIP_FILE_NAME|$TAP3_PACKAGE_NAME|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_VI_X_ZIP_FILE_PATH|$VI_X_PACKAGE_PATH|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_VI_X_ZIP_FILE_NAME|$VI_X_PACKAGE_NAME|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_VI_CTL_ZIP_FILE_PATH|$VI_CTL_PACKAGE_PATH|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_VI_CTL_ZIP_FILE_NAME|$VI_CTL_PACKAGE_NAME|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_VI_STQ_ZIP_FILE_PATH|$VI_STQ_PACKAGE_PATH|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_VI_STQ_ZIP_FILE_NAME|$VI_STQ_PACKAGE_NAME|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_ALU_ZIP_FILE_PATH|$ALU_PACKAGE_PATH|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_ALU_ZIP_FILE_NAME|$ALU_PACKAGE_NAME|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_APR_ZIP_FILE_PATH|$APR_PACKAGE_PATH|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_APR_ZIP_FILE_NAME|$APR_PACKAGE_NAME|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_PCMI_ZIP_FILE_PATH|$PCMI_PACKAGE_PATH|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_PCMI_ZIP_FILE_NAME|$PCMI_PACKAGE_NAME|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE}  | sed -e "s|ENTER_CVG_INFINYS_PF_PATH|$INFINYS_ROOT/CVG_INFINYS_PF_BE|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_ORACLE_USERNAME|irbora11|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE}  | sed -e "s|ENTER_BACKEND_SERVER_NAME1|`hostname`|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "/ENTER_BACKEND_SERVER_NAME2/d" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_BACKEND_DB_HOST_NAME|$database_server|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_BACKEND_DB_SID|$ORACLE_SID|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_ORACLE_HOME_PATH|$ORACLE_HOME|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_JAVA_HOME_PATH|$JAVA_HOME|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CVG_LICENSE_PATH|$CVG_LICENSE_PATH|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_WEB_SERVER_HOME|$BEA_HOME/wlserver_10.3|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_WEB_SERVER_CONTAINER|none|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_ECA_YES_OR_NO|no|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_TAP3_YES_OR_NO|no|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_ALU_YES_OR_NO|no|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_APR_YES_OR_NO|no|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_VI_X_YES_OR_NO|no|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_VI_CTL_YES_OR_NO|no|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_VI_STQ_YES_OR_NO|no|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_DOMAIN_YES_OR_NO|yes|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_OLCRTR_YES_OR_NO|no|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_OLCCACHES_YES_OR_NO|yes|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_WEB_SERVER_DOMAIN_NAME|Infinys|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_WEB_SERVER_PORT|23451|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_SERVER_OS|lX|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CVG_LICENSE_XML_FILE|license.xml|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CVG_LICENSE_CERTIFICATE|license.crt|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_BACKEND_DB_GLOBAL_NAME|$ORACLE_SID|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_YOUR_INFINYS_ENV_FILE_NAME|infinys.env|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_BACKEND_SKIP_VALIDATION_YES_OR_NO|yes|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "/ZIP_FILE_NAME/d" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "/ENTER_UNUSED/d" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_RAC_YES_OR_NO|no|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_T_OR_R_OR_F|T|g"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_DOMAINGROUP1_NAME|DOMAINGROUP1|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_DOMAINGROUP2_NAME|DOMAINGROUP2|g"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_HA_YES_OR_NO|no|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_COLL_HOST|`hostname`|g"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_COLL_PORT|33441|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_COLL_INTERVAL|60|g"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_COLL_TMPDIR|$INFINYS_ROOT/tmp|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_COMM1_DOMAIN|D1|g"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_COMM1_PORT|33441|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_COMM1_HOST|`hostname`|g"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_RP1_HOST_NAME|`hostname`|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "/ENTER_RP2_HOST_NAME/d"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CUSTOM_CACHE_FILE||g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CUSTOM_CACHE_DIR||g"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CACHE_SKIP_VALIDATION_YES_OR_NO|yes|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CACHE_CVG_INFINYS_PF_PATH|$INFINYS_ROOT/CVG_INFINYS_PF_BE|g"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CACHE_ORACLE_USERNAME|irbora11|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "/ENTER_CS1_CDB2_SERVICE_NAME/d"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "/ENTER_CS2_CDB2_SERVICE_NAME/d" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CACHESERVER1_HOSTNAME|$cache1_server|g"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CS1_CDB1_SERVICE_NAME|$CACHE1_SID|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CS1_CDB1_SID|$CACHE1_SID|g"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CACHESERVER2_HOSTNAME|$cache2_server|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CS2_CDB1_SERVICE_NAME|$CACHE2_SID|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CS2_CDB1_SID|$CACHE2_SID|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_LOGICAL_HOSTNAME1|$cache1_server|g"  > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_LOGICAL_HOSTNAME2|$cache2_server|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CDS1_CACHE_TYPE|customer|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CDS1_DB_SERVICE_NAME|$CACHE1_SID|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CDS1_DOMAIN_GROUPID|1|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CDS2_CACHE_TYPE|reference|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CDS2_DB_SERVICE_NAME|$CACHE1_SID|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CDS2_DOMAIN_GROUPID||g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CDS3_CACHE_TYPE|domainLookup|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CDS3_DB_SERVICE_NAME|$CACHE1_SID|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CDS3_DOMAIN_GROUPID||g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CDS4_CACHE_TYPE|customer|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CDS4_DB_SERVICE_NAME|$CACHE1_SID|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CDS4_DOMAIN_GROUPID|2|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CDS5_CACHE_TYPE|reference|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CDS5_DB_SERVICE_NAME|$CACHE2_SID|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CDS5_DOMAIN_GROUPID||g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CDS6_CACHE_TYPE|domainLookup|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CDS6_DB_SERVICE_NAME|$CACHE2_SID|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CDS6_DOMAIN_GROUPID||g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CDS7_CACHE_TYPE|customer|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CDS7_DB_SERVICE_NAME|$CACHE2_SID|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CDS7_DOMAIN_GROUPID|1|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CDS8_CACHE_TYPE|customer|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_CDS8_DB_SERVICE_NAME|$CACHE2_SID|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_CDS8_DOMAIN_GROUPID|2|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "/ENTER_CDS9_CACHE_TYPE/d" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "/ENTER_CDS10_CACHE_TYPE/d" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "/ENTER_CDS11_CACHE_TYPE/d" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "/ENTER_CDS12_CACHE_TYPE/d" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_EXPORT_DIR|$INFINYS_ROOT/OCL_EXPORT|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 | sed -e "s|ENTER_PCMI_YES_OR_NO|no|g" > ${CONFIG_FILE}
cat ${CONFIG_FILE} | sed -e "s|ENTER_RP1_COMM_PORT|33441|g" > ${CONFIG_FILE}2
cat ${CONFIG_FILE}2 > ${CONFIG_FILE}

mkdir CVG_INFINYS_PF_BE
chmod 777 CVG_INFINYS_PF_BE

mkdir OCL_EXPORT
chmod 777 OCL_EXPORT

# Update rbiuh_params.txt
echo TwoTask="$ORACLE_SID"
echo OracleHost="$database_server"
echo OracleListenerPort="1521"

echo "Info: $database_server is the database server for $ORACLE_SID"

# Run the Installation
RBIUH_LOG=$INFINYS_ROOT/RBIUH.log
echo n > /tmp/no
echo "Writing to $RBIUH_LOG"

###############################
# Run It!
echo $currentShell
ksh ./RB_IU_Handler.ksh -configFile $CONFIG_FILE -installOrUpgrade -deploy -bypass > $RBIUH_LOG

if [ $? -eq 0 ]
then
	echo "SUCCESS: PF and RB has installed successfully"
	echo "    DBSID                 = $ORACLE_SID"
	echo "    Installation Location = $INFINYS_ROOT"
	echo "In the unlikely event that you are interested in the RB_IU_Handler log file: $RBIUH_LOG"
else
	echo "Error: Installation failed! Disaster, I have no idea what to do now"
	echo "RB_IU_Handler log file: $RBIUH_LOG"
	echo "Abandon Ship, Abandon Ship!! The Klingons are on the starboard bow!"
	exit 9
fi

exit 0
