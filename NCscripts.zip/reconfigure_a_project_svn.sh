#!/bin/sh
set -x
. ${BCE_BUILD_SCRIPTS}/svn_new.svn

if [ $# -lt 2 ]
then
	exit
fi
echo "svn home is: $SVN_HOME"

ccm_project=$1
logDate=$2
LOGDIR=${BCE_LOG}/$logDate
#ccm_database=$3
bld_proj=`echo ${ccm_project} | awk -F/ '{print $NF}'`
svn_up="$SVN_HOME/bin/svn"
svn_up_v="update"
echo "........$svn_up..........."
product_name=`echo ${bld_proj} | awk -F- '{print $1}'`

rm -f $LOGDIR/svn-update-$bld_proj $LOGDIR/svn-update-$bld_proj-FAILED $LOGDIR/svn-update-$bld_proj-PASSED

#CCM_ADDR=`ccm start -q -m -nogui -d ${ccm_database} -r build_mgr`
#export CCM_ADDR	

# Find out the release tag
Proj=`echo ${ccm_project} | cut -d- -f1`
Version=`echo ${ccm_project} | cut -d- -f2`

#release_tag=`ccm query -t project  "version='${Version}'and project='${Proj}'" -f "%release" | awk -F" " '{print $NF}'`
# Find out if a gatekeeper project

#waittime=600
#waited=0

#cat ${BCE_ADMIN}/buildweb_config/gatekeeper_releases | egrep -v '^#' | egrep "${release_tag}" > /dev/null
#if [ ${?} = 0 ]; then
	
#	while [ ! -f ${LOGDIR}/baseline_${release_tag}.complete ]
#	do
#		echo "Gatekeeper folder \"${LOGDIR}/baseline_${release_tag}.complete\" was not found... waiting"
#		sleep 120
#		waited=`expr $waited + 120`
#		if [ ${waited} -gt ${waittime} ];then
#			echo "gatekeeper baselining did not complete..."
#			break
#		fi
#	done

#fi

#echo "Date:" `date` "Project:" $bld_proj "Reconfiguring project"
echo "Date:" `date` "Project:" $bld_proj "started svn-update"
#echo ccm reconfigure -r -p $ccm_project
echo "svn-update $bld_proj"
#ccm reconfigure -r -p $ccm_project >> $LOGDIR/svn-update-$ccm_project 2>&1
#############################here we are doing svn update for required build projects#############################
echo "server name:`uname -a`"
#echo "cd $ccm_project/$product_name && svn-update" >> $LOGDIR/svn-update-$bld_proj 2>&1
cd $ccm_project/$product_name 
$svn_up update >> $LOGDIR/svn-update-$bld_proj 2>&1 
error_status=$?
echo "svn-update result: $error_status"
if [ $error_status -ne 0 ] 
then
	echo "reconfigure_a_project: Date:" `date` "Project:" $bld_proj "Project update FAILED"
	echo > $LOGDIR/svn-update-$bld_proj-FAILED
	continue
else
	echo "reconfigure_a_project: Date:" `date` "Project:" $bld_proj "Project update succeeded"
	echo > $LOGDIR/svn-update-$bld_proj-PASSED
	grep "Parallel versions selected by selection rules" ${LOGDIR}/svn-update-$bld_proj
fi
  
echo "Date:" `date` "Project:" $bld_proj "Object names and head revision number"				
#ccm reconfigure_properties -show all_tasks -u -f "%task_number#%task_subsys#%task_synopsis" $ccm_project | sed -e 's/  *$//' >> $LOGDIR/tasks-$ccm_project

echo "reconfigure_a_project: Date:" `date` "Project:" $bld_proj "update complete"

#ccm stop

#manifest_seq_number=`make_manifest.sh $ccm_project $logDate $ccm_database | grep seq_number | head -1 | cut -d'=' -f2`

#echo manifest_seq_number=$manifest_seq_number >> $LOGDIR/svn-update-$ccm_project

