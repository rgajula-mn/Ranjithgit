#!/bin/sh
set -x
#
########################################################################
#
#  Script:              db_functions.sh
#  Instance:            1
#  Author:              sfp
#  Start date:          21/05/2003
#  Version:             %full_filespec: db_functions.sh-143.1.11.1.132.1.11:shsrc:CB1#1 %
#
#  Description:         Created to contain some core functions for work
#                       in the database.
#
#  (C) Convergys, 2002.
#  Convergys refers to Convergys Corporation or any of its wholly owned
#
########################################################################

schema_TopUps_and_devOwned ()
{
	build_or_test=$1
	SCHEMA=$2
	ccm_project=$3
	majorrelease=$4
	DATABASE=$5
	log=$6
	dbmajorrel=$7
	ccm_state=$8

	sqa_top_anyway="no"

	echo "DATABASE = $DATABASE" >> ${log}

	echo $DATABASE | grep "4_0_3" > /dev/null
	if [ $? -eq 0 ]
	then
		echo "Overriding the DO NOT TOPUP SQA" >> ${log}
		sqa_top_anyway="yes"
	fi

	sqa_type="no"
	if [ "$ccm_state" = "sqa" -o "$ccm_state" = "conts"  -o "$ccm_state" = "mem" -o "$ccm_state" = "lint" -o "$ccm_state" = "cov" -o "$ccm_state" = "test" ]
	then
		echo "Release is a sqa type build: $ccm_state" >> ${log}
		sqa_type="yes"
	fi

#       Development Interim Schema Installation for RB only
	echo "Starting the Interim Schema Section of Install (ccm_project = $ccm_project, sqa_type=$sqa_type, sqa_top_anyway=$sqa_top_anyway)" >> ${log}
	if [ "$ccm_project" = "RB" -o  "$ccm_project" = "RTCA" ]
	then
		if [ "$sqa_type" = "no" -o "$sqa_top_anyway" = "yes" ]
		then
			echo "We are working on an $ccm_project project - Looking for Schema Topup Changes" >> ${log}
			if [ -d "$SCHEMA/SRC/schemaTopUp/${ccm_project}${majorrelease}/build_bce" ]
			then
				echo "We have a $SCHEMA/SRC/schemaTopUp/${ccm_project}${majorrelease}/build_bce directory" >> ${log}
				cd $SCHEMA/SRC/schemaTopUp/${ccm_project}${majorrelease}/build_bce
				if [ -f "build_top_up.sql" ]
				then
					if [ "$build_or_test" = "BUILD" ]
					then
						echo "Loading SchemaTopUp file build_top_up.sql" >> ${log}
						sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
						@build_top_up.sql
						exit
+ENDSQL
					else
						cat build_top_up.sql | sed -e 's/trigger/non_trigger/g' > rtest_top_up.sql
						echo "Loading SchemaTopUp file build_top_up.sql" >> ${log}
						sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
						@rtest_top_up.sql
						exit
+ENDSQL
					fi
				fi
			
			fi
			echo "We are working on an $ccm_project project - Looking for development owned schema changes" >> ${log}
			if [ -d "$SCHEMA/SRC/development_owned" ]
			then
				echo "We have a $SCHEMA/SRC/development_owned directory" >> ${log}
				cd $SCHEMA/SRC/development_owned
				finished_upgrades=0
				# Find out the version of my installed RB Schema
				SCHEMA_LETTER=`sqlplus -s $DATABASE << +END
				set feed off
				set head off
				select LETTER from VERSION_${ccm_project}_${dbmajorrel};
				exit
+END`
				
				SCHEMA_LETTER=`echo $SCHEMA_LETTER`
				if [ -z "$SCHEMA_LETTER" ]
				then
					echo "No Schema Letter found!" >> ${log}
					echo "Using alternate method to find Letter" >> ${log}
					SCHEMA_LETTER=`grep 'TOLETTER=' $SCHEMA/install/scripts/schema_VERSION.sh | cut -d'"' -f2`
				fi
				echo "We are upgrading from $SCHEMA_LETTER" >> ${log}
				upgrade_dir=`ls | grep "${majorrelease}${SCHEMA_LETTER}_${majorrelease}"`
				echo "`ls` ${majorrelease}${SCHEMA_LETTER}_${majorrelease} `pwd`" >> ${log}
				echo "We are going to us the upgrade directory $upgrade_dir" >> ${log}
				while [ ! -z "${upgrade_dir}" ]
				do
					echo "Changing into the upgrade directory" >> ${log}
					finished_upgrades=1
					# We have an upgrade to carry out
					cd $upgrade_dir
					if [ "$build_or_test" = "BUILD" ]
					then
						for interim_schema_script in `ls | grep -v interim_schema_for | grep -v S1_trigger.sql | grep "\.sql"`
						do
							echo "Installing Interim Schema File $interim_schema_script" >> ${log}
							sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
							@$interim_schema_script
							exit
+ENDSQL
						done
					else
						echo "Installing Interim Schema File S1_trigger.sql" >> ${log}
						sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
						@S1_trigger.sql
						exit
+ENDSQL
					fi
					cd ..
					schema_upgraded_to=`echo $upgrade_dir | cut -d'_' -f2 | sed -e 's/[0-9\.]*//g'`
					echo "We are upgrading from $SCHEMA_LETTER" >> ${log}
					upgrade_dir=`ls | grep "${majorrelease}${schema_upgraded_to}_${majorrelease}"`
				done
			fi
		fi
	else
		echo "No Interim schema Installed" >> ${log}
	fi
	echo "End of the Interim Schema Section of Install" >> ${log}
}


# Function used to create a Geneva DATABASE....

createDB() # ${SCHEMA} ${DATABASE} ${log} ${SYSDATABASE} ${dbspec} ${dbmajorrel} ${queues} ${filelist_number} ${oracle_ver} ${major_release} {ccm project}
{
    backend_olc_db=""

    SCHEMA=${1}
    DATABASE=${2}
    log=${3}
    SYSDATABASE="${4}"
    dbspec=${5}
    dbmajorrel=${6}
    queues=${7}
    filelist_number=${8}
    oracle_ver=${9}
    shift
    majorrelease=${9}
    shift
    ccm_project=${9}
    shift
    the_option=${9}
    shift
    ccm_state=${9}
    shift
    olc_yes=${9} # set to yes if this database is going to be used as part of an OLC pair.
    shift
    backend_olc_db=${9} # set to the OLC database for setting up the OLC_CACHE Database
    shift
    backend_olc_db_sys=${9} # set to the OLC SYS database for setting up the OLC Database

    echo "Running against Database: $DATABASE"

    if [ "$filelist_number" = "" ]
    then
        filelist_number=1
    fi


	echo SCHEMA = $SCHEMA	
	echo DATABASE = $DATABASE	
	echo log = $log	
	echo SYSDATABASE = $SYSDATABASE	
	echo dbspec = $dbspec	
	echo dbmajorrel = $dbmajorrel	
	echo queues = $queues	
	echo filelist_number = $filelist_number	
	echo oracle_ver = $oracle_ver	
	echo majorrelease = $majorrelease	
	echo ccm_project = $ccm_project	
	echo the_option = $the_option	
	echo ccm_state = $ccm_state	
	echo olc_yes = $olc_yes	
	echo backend_olc_db = $backend_olc_db	
	echo backend_olc_db_sys = $backend_olc_db_sys	


#        if [ -f ${SCHEMA}/SRC/dropqueue.sql -a "$queues" = "yes" ]
#        then
#            echo "Dropping queues against ${DATABASE}"
#	    sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
#            @${SCHEMA}/SRC/dropqueue.sql
#            exit
#+ENDSQL
#        # Sleep for one minute while the queue is properly dropped
#            sleep 60
#        fi
    
    . /irb/bce/admin/ccm_wa/PRD-bce/PRD/build_scripts/svn_new_us.svn
    cd $SCHEMA/../
    echo $SCHEMA
    svn up > /irb/bce/admin/log/partialbuild/svn_${minor_release}_sng.log
    if [ -z /irb/bce/admin/log/partialbuild/svn_${minor_release}_sng.log ]
    then
     printf "\t SVN UP command not happened correctly, pls check and re-run the build \n"
    fi
    RB_INSTALL=`cat /irb/bce/admin/log/partialbuild/svn_${minor_release}_sng.log|grep 'SCHEMA/install/'`

                                                pfsec=`echo ${dbspec}`
                                                pf_user=`echo ${pfsec}`
						pf_loc=`echo $PF_HOME | sed -e 's/\(.*\)\/.*\/.*\/.*$/\1/g'`
                                               U_USER=`echo $pfsec|tr [a-z] [A-Z]`
                                               PFUSR_IN_DB=`sqlplus -s  ${SYSDATABASE} << +END
                                                            whenever sqlerror exit failure
                                                            set feed off
                                                            set head off
                                                            select USERNAME from dba_users where USERNAME='${U_USER}';
                                                            exit
+END`

    if [ -z $RB_INSTALL ] && [ ! -z $PFUSR_IN_DB ]
    then
                printf "\t We No Need To Install RB SCHEMA Installation Again As No Files Pulled In svn up Command \n" >> ${log} 2>&1
                RB_INSTALL_DO=NO
    else
                printf "\t I'm Going For RB SCHEMA Installation As Files Have Been Pulled In SVN UP Command \n" >> ${log} 2>&1
                RB_INSTALL_DO=YES
   fi
	

if [ "$RB_INSTALL_DO" = YES ] 
then

	echo "Dropping and re-creating user ${dbspec}"
	new_oracle=no
	if [ "${oracle_ver}" = "oracle10g" -a "${ccm_project}" = "RB" ]
	then
		new_oracle=yes
	fi
	
	if [ "${oracle_ver}" = "oracle11g" -o "${oracle_ver}" = "oracle12c" ]
	then
	            sqlplus -s "${SYSDATABASE}" >> ${log} 2>&1 << +ENDSQL
	            drop user ${dbspec} cascade;
	       	    create user ${dbspec}
	            identified by ${dbspec}
	            default tablespace data
	            temporary tablespace temp;
	            grant dba to ${dbspec} with admin option;
	            grant delete on error\$ to ${dbspec};
		    grant select on dba_triggers to ${dbspec};
		    grant execute on dbms_lock to ${dbspec};
		    grant select on gv_\$transaction to ${dbspec};
		    commit;
	            exit
+ENDSQL
	else
		if [ "$new_oracle" = "yes" ]
		then
	            sqlplus -s "${SYSDATABASE}" >> ${log} 2>&1 << +ENDSQL
	            drop user ${dbspec} cascade;
	       	    create user ${dbspec}
	            identified by ${dbspec}
	            default tablespace data
	            temporary tablespace temp;
	            grant dba to ${dbspec} with admin option;
	            grant delete on user_errors to ${dbspec};
		    grant select on dba_triggers to ${dbspec};
		    grant execute on dbms_lock to ${dbspec};
		    grant select on gv_\$transaction to ${dbspec};
		    commit;
	            exit
+ENDSQL
		else
	            sqlplus -s "${SYSDATABASE}" >> ${log} 2>&1 << +ENDSQL
	            drop user ${dbspec} cascade;
	            create user ${dbspec}
	            identified by ${dbspec}
	            default tablespace data
	            temporary tablespace temp
	            quota unlimited on data
	            quota unlimited on temp;
	            grant dba to ${dbspec} with admin option;
	            grant delete on user_errors to ${dbspec};
		    grant select on dba_triggers to ${dbspec};
	            commit;
	            exit
+ENDSQL
		fi
	fi

        if [ -f ${SCHEMA}/roles/sysprivs.sql ]
        then
                echo "Found file $SCHEMA/roles/sysprivs.sql"
                sqlplus -s "${SYSDATABASE}" >> ${log} 2>&1 << +ENDSQL
                @${SCHEMA}/roles/sysprivs.sql ${dbspec} rbm
                exit
+ENDSQL
		if [ "$ccm_state" = "dev" -a "$ccm_state" = "conts" ]
		then
			if [ $majorrelease = "4.0" -o $majorrelease = "4.1" -o $majorrelease = "4.2" -o $majorrelease = "4.3" -o $majorrelease = "4.4" -o $majorrelease = "5.0"  -o $majorrelease = "5.1" -o $majorrelease = "5.2" -o $majorrelease = "5.3"  -o $majorrelease = "6.0"  -o $majorrelease = "6.1"  -o $majorrelease = "7.0"  -o $majorrelease = "8.0"  -o $majorrelease = "9.0" ]
			then
              	  		sqlplus -s "${SYSDATABASE}" >> ${log} 2>&1 << +ENDSQL
                		@${SCHEMA}/olc/roles/sysprivs.sql ${dbspec}
                		exit
+ENDSQL
			fi
		fi
        else
                echo "Not found file $SCHEMA/roles/sysprivs.sql"
                sqlplus -s "${SYSDATABASE}" >> ${log} 2>&1 << +ENDSQL
                grant select on sys.dba_roles to ${dbspec};
                grant select on sys.dba_role_privs to ${dbspec};
                grant select on sys.dba_tab_privs to ${dbspec};
                grant grant any roles to ${dbspec};
                grant create role to ${dbspec};
                grant create sequence to ${dbspec};
                grant select on sys.dba_profiles to ${dbspec} with grant option;
                grant select on sys.dba_USERS to ${dbspec} with grant option;
                grant select on sys.dba_TABLESPACES to ${dbspec} with grant option;
                commit;
                exit
+ENDSQL
        fi

# Add the grants for Oracle Queues (if required by this Geneva project)

# New check required for 5.3 project structure changes, inclusion of new schema project. : sfp 20/02/2003
# Plus if it is 5.3 then we need to grant execute to dbms_pipe

        if [ -f ${SCHEMA}/SRC/dropqueue.sql -a ! -f ${SCHEMA}/roles/sysprivs.sql ]
        then
            sqlplus -s "${SYSDATABASE}" >> ${log} 2>&1 << +ENDSQL
            grant execute on dbms_aq to ${dbspec};
            grant execute on dbms_aqadm to ${dbspec};
            grant execute on dbms_pipe to ${dbspec};
            commit;
	exit
+ENDSQL
	fi
fi
# load the schema, making sure it stops before the roles and synonyms are created
# use the old or new mechanism depending on what's there

	if [ -f ${SCHEMA}/install/install.sh ]
	then

		# for RB the Platform schema also needs to be installed
#		if [ ! -z "${backend_olc_db}" ]
#		then
#			echo "This is the CACHE OLC DB and has no platform install"
#		else
			if [ "${the_option}" = "dbuser_no_packages" ]
			then
				echo "This is a dbuser_no_packages and no platform install"
			else
				if [ "${ccm_project}" = "RB" -o "${ccm_project}" = "PCMI" -o "${ccm_project}" = "RTCA" ]
				then
					db_username=`echo $DATABASE | cut -d'/' -f1`
					echo "" >> ${log} 2>&1
					echo "" >> ${log} 2>&1
					echo " -------- Installation of the Platform Schema ---------" >> ${log} 2>&1
					db_sid=`echo $DATABASE | cut -d '@' -f2 | tr '[a-z]' '[A-Z]' | cut -d'.' -f1` >> ${log} 2>&1
                                                #pfsec=`echo ${dbspec}|sed -e 's/_//g'|sed -e 's/sqa//g'|sed -e 's/11g/1g/g'|sed -e 's/12c/2c/g'|sed -e 's/10g/0g/g'`
                                               PFUSR_IN_DB=`sqlplus -s  ${SYSDATABASE} << +END
                                                            whenever sqlerror exit failure
                                                            set feed off
                                                            set head off
                                                            select USERNAME from dba_users where USERNAME='${U_USER}_PF';
                                                            exit
+END`

                                                printf "\t User in DB was $U_USER \n"

                                                . ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh
                                                MR=`echo $minor_release|cut -d '.' -f1-3`
                                                BWEB=`buildweb_connection`
                                                pfdep="select DEPVERSION from depversion where VERSION='$MR' and DEPPROJECT='PLATFORM'";
                                                PF_pch_cpy="select PLATFORM_VERSION from PATCH_COMPANY_PF where PATCH_VERSION='${minor_release}'";
                                                pfrel="select DEPVERSION from depversion where VERSION='${minor_release}' and DEPPROJECT='PLATFORM'";
                                                PF_rl_dep=`sql_query $BWEB "$pfrel"`
                                                PF_rl_dep=`echo $PF_rl_dep|tr -d ' '`
                                                PF_company=`sql_query $BWEB "$PF_pch_cpy"`
                                                PF_company=`echo $PF_company|tr -d ' '`
                                                PF_dep=`sql_query $BWEB "$pfdep"`
                                                PF_dep=`echo $PF_dep|tr -d ' '`

                                                        if [ ! -z "$PF_company" ]
                                                        then
                                                         patch_pf="$PF_company"
                                                        else
                                                         if [ ! -z "$PF_rl_dep" ]
                                                         then
                                                          patch_pf="$PF_rl_dep"
                                                         else
                                                          patch_pf="$PF_dep"
                                                         fi
                                                        fi

                                        PF_in_db=`sqlplus -s  ${SYSDATABASE} << +END
                                                  whenever sqlerror exit failure
                                                  set feed off
                                                  set head off
                                                  select value from ${U_USER}_PF.systemregistryentry where name like '%currentDatabaseVersion%';
                                                  exit
+END`

                                                 PF_in_db=`echo $PF_in_db|tr -d ' '`
                                                 printf "\t PF in DB is $PF_in_db \n"
                                                 printf "\t PF in dep/pchcmppf is  $patch_pf \n"


                                    if [ "$patch_pf" == "$PF_in_db" ] && [ ! -z $PFUSR_IN_DB ]
                                    then
                                         printf "\t PF installation is not required, using existing PF $patch_pf \n"  >> ${log} 2>&1
                                         PF_INSTALL=NO
                                    else 
                                                printf "\t I'm Going For PF Installtion \n" >> ${log} 2>&1
                                                echo "${BCE_BUILD_SCRIPTS}/platform_db_install_sng_db.sh ${pf_loc} $db_sid ${JAVA_HOME} $pf_user" >> ${log} 2>&1
                                                ${BCE_BUILD_SCRIPTS}/platform_db_install_sng_db.sh ${pf_loc} $db_sid $JAVA_HOME $pf_user >> ${log} 2>&1
                                                pf_installation_check=`cat ${log}|grep -w Success`
                                                if [ -z $pf_installation_check ]
                                                then
                                                   printf "\t PF installation was failed...... Please check and re-run the build again \n" >> ${log} 2>&1
                                        PF_in_db=`sqlplus -s  ${SYSDATABASE} << +END
                                                  whenever sqlerror exit failure
                                                  set feed off
                                                  set head off
                                                  drop user ${U_USER}_PF cascade;
                                                  drop user ${U_USER} cascade;
                                                  exit
+END`
                                                   exit
                                                fi
						sqlplus -s ${SYSDATABASE} >> ${log} 2>&1 << +ENDSQL
                                                       GRANT ALL on ${pfsec}_PF.PFMESSAGE to ${dbspec} with grant option;
                                                       GRANT ALL on ${pfsec}_PF.AUDITLOG to ${dbspec} with grant option;
                                                       GRANT ALL on ${pfsec}_PF.PF_PERFORMANCE_LOG to ${dbspec} with grant option;
                                                       GRANT ALL on ${pfsec}_PF.PF_PERFORMANCE_LOG_CONFIG to ${dbspec} with grant option;
                                                       GRANT ALL on ${pfsec}_PF.SYSTEMREGISTRYENTRY to ${dbspec} with grant option;
                                                       GRANT EXECUTE on ${pfsec}_PF.DATA_SECURITY to ${dbspec} with grant option;
                                                       GRANT EXECUTE on ${pfsec}_PF.SYSREG to ${dbspec} with grant option;
                                                       GRANT ALL on ${pfsec}_AUDIT.PF_AUDIT_SENS_DATA to ${dbspec} with grant option;
                                                       GRANT ALL on ${pfsec}_PF.TRACE_LEVEL to ${dbspec} with grant option;
                                                       grant select on v_\$session to ${dbspec} with grant option;
                                                       exit
+ENDSQL
						sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
							-- Create table
							create table PFMESSAGE
							(
							  MESSAGE_DOMAIN         VARCHAR2(16) not null,
							  MESSAGE_NUMBER         NUMBER(5) not null,
							  MESSAGE_TYPE           VARCHAR2(1) not null,
							  MESSAGE_TEXT           VARCHAR2(400) not null,
							  MESSAGE_NAME           VARCHAR2(64) not null,
							  ERROR_MESSAGE_CATEGORY NUMBER(2)
							);
							-- Create/Recreate primary, unique and foreign key constraints 
							alter table PFMESSAGE
							  add constraint PFMESSAGE_PK primary key (MESSAGE_DOMAIN, MESSAGE_NUMBER)
							  using index 
							  tablespace DATA
							  pctfree 10
							  initrans 2
							  maxtrans 255
							  storage
							  (
							    initial 64K
							    next 64K
							    minextents 1
							    maxextents unlimited
							    pctincrease 0
							  );
							alter table PFMESSAGE
							  add constraint PFMESSAGE_UK1 unique (MESSAGE_NAME)
							  using index 
							  tablespace DATA
							  pctfree 10
							  initrans 2
							  maxtrans 255
							  storage
							  (
							    initial 64K
							    next 64K
							    minextents 1
							    maxextents unlimited
							    pctincrease 0
							  );
                                                          create synonym AUDITLOG for ${pfsec}_pf.AUDITLOG;
                                                          create synonym PF_PERFORMANCE_LOG for ${pfsec}_pf.PF_PERFORMANCE_LOG;
                                                          create synonym PF_PERFORMANCE_LOG_CONFIG for ${pfsec}_pf.PF_PERFORMANCE_LOG_CONFIG;
                                                          create synonym SYSTEMREGISTRYENTRY for ${pfsec}_pf.SYSTEMREGISTRYENTRY;
                                                          create synonym DATA_SECURITY for ${pfsec}_pf.DATA_SECURITY;
                                                          create synonym SYSREG for ${pfsec}_pf.SYSREG;
                                                          create synonym PF_AUDIT_SENS_DATA for ${pfsec}_audit.PF_AUDIT_SENS_DATA;
                                                          create synonym TRACE_LEVEL for ${pfsec}_pf.TRACE_LEVEL;
						
							exit
+ENDSQL
					rm /tmp/imp_parfile.$$.txt >> ${log} 2>&1
	
	
					#Disable Platform triggers before installation of RB schema
					echo "Disabling triggers against ${DATABASE}" >> ${log} 2>&1
					cd ${SCHEMA}/migration/scripts
					sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
					whenever sqlerror exit failure
					@fixalltriggers.sql DISABLE
					exit
+ENDSQL

					# Install the java procedures
					if [ -f $PF_HOME/lib/pf-storedproc1.4.jar ]
					then
						echo "Load the Platform Java File: $PF_HOME/lib/pf-storedproc1.4.jar"  >> ${log} 2>&1
						$ORACLE_HOME/bin/loadjava -user $DATABASE $PF_HOME/lib/pf-storedproc1.4.jar >> ${log} 2>&1
					elif [ -f $PF_HOME/lib/pf-storedproc1.5.jar ]
					then
						echo "Load the Platform Java File: $PF_HOME/lib/pf-storedproc1.5.jar"  >> ${log} 2>&1
						$ORACLE_HOME/bin/loadjava -user $DATABASE $PF_HOME/lib/pf-storedproc1.5.jar >> ${log} 2>&1
					fi
					if [ -f $PF_HOME/lib/pf-dbinstallutil.jar ]
					then
						echo "Load the Platform Java File: $PF_HOME/lib/pf-dbinstallutil.jar" >> ${log} 2>&1
						$ORACLE_HOME/bin/loadjava -user $DATABASE $PF_HOME/lib/pf-dbinstallutil.jar >> ${log} 2>&1
					fi
					echo "" >> ${log} 2>&1
					echo " -------- End of Installation of the Platform Schema ---------" >> ${log} 2>&1
					echo "" >> ${log} 2>&1
					echo "" >> ${log} 2>&1
                                    fi
				fi
			fi
if [ "$RB_INSTALL_DO" = YES ]
then
			echo "Running installation process against ${DATABASE}" >> ${log} 2>&1
			cd ${SCHEMA}/install
#			rm -f logs/* >> ${log} 2>&1
			rm -f working/* >> ${log} 2>&1
			rm -f scripts/stop_at_* >> ${log} 2>&1
			sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
			whenever sqlerror exit failure
			@migrationprocess.sql
			@../SRC/gnvschema.spc
			@../SRC/gnvschema.plb
			exit
+ENDSQL
#		fi

	    if [ -z "$backend_olc_db" ]
	    then
	      pwd >> ${log} 2>&1

	      new_lock_number=$$
              while [ -f schema_lock ]
	      do
		  lock_number=`cat schema_lock`
		  sleep 300 # 5 minutes
		  lock_number_now=`cat schema_lock`
		  if [ $lock_number -eq $lock_number_now ]
		  then
		    continue
		  fi
              done
              echo $new_lock_number > schema_lock

	      cd $SCHEMA/install
	      if [ ! -f scripts/schema_params.sql ]
	      then
                  if [ -f scripts/schema_params.sql.ccm ]
		  then
		      mv scripts/schema_params.sql.ccm scripts/schema_params.sql
		  else
		      echo "Error no schema_params.sql in scripts for $CCM_ROOT" | /usr/lib/sendmail steve.graham@convergys.com
		  fi
	      fi

	      mv scripts/schema_params.sql scripts/schema_params.sql.ccm
	      cat scripts/schema_params.sql.ccm |sed -e 's/= 'IPF_ADMIN'/= '${pfsec}_PF'/g' > scripts/schema_params.sql
		cat scripts/schema_params.sql|grep "_PF"
              install.sh ../SRC/install_filelist_${filelist_number}_for_build.txt >> ${log} 2>&1

	      if [ -f scripts/schema_params.sql.ccm ]
	      then
	      	rm scripts/schema_params.sql
	      	mv scripts/schema_params.sql.ccm scripts/schema_params.sql
	      fi

              rm schema_lock
              if [ -f schema_lock ]
              then
                  old_lock_number=`cat schema_lock`
		  if [ $old_lock_number -eq $new_lock_number ]
		  then
                    rm schema_lock
		  fi
              fi

              if [ ${dbmajorrel} = "5_4TS" -o ${dbmajorrel} = "2_2" ]
  	      then
	    	  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_geneva_5_4 to version_geneva_5_4;
		  delete from user_errors;
		  commit;
+ENDSQL
	      elif [ ${dbmajorrel} = "3_0" ]
	      then
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_rb_3_0 to version_rb_3_0;
		  delete from user_errors;
		  commit;
+ENDSQL
	      elif [ ${dbmajorrel} = "3_1" ]
	      then
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_rb_3_1 to version_rb_3_1;
		  delete from user_errors;
		  commit;
+ENDSQL
	      elif [ ${dbmajorrel} = "3_2" ]
              then
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_3_2 to version_rb_3_2;
                  delete from user_errors;
                  commit;
+ENDSQL
	      elif [ ${dbmajorrel} = "4_0" ]
	      then
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_rb_4_0 to version_rb_4_0;
		  delete from user_errors;
		  commit;
+ENDSQL
	      elif [ ${dbmajorrel} = "4_1" ]
	      then
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_rb_4_1 to version_rb_4_1;
		  delete from user_errors;
		  commit;
+ENDSQL
	      elif [ ${dbmajorrel} = "4_2" ]
	      then
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_rb_4_2 to version_rb_4_2;
		  delete from user_errors;
		  commit;
+ENDSQL
	      elif [ ${dbmajorrel} = "4_3" ]
	      then
		echo 4.3
		if [ "$ORACLE_VERSION" = "11g" ]
		then
		  echo 11g
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_rb_4_3 to version_rb_4_3;
delete from sys.error$ o where  o.obj# IN    (  select 
            e.obj#
       from 
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
		  commit;
+ENDSQL
		else
		  echo not 11g
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_rb_4_3 to version_rb_4_3;
		  delete from user_errors;
		  commit;
+ENDSQL
		fi
	      elif [ ${dbmajorrel} = "4_4" ]
	      then
		echo 4.4
		if [ "$ORACLE_VERSION" = "11g" ]
		then
		  echo 11g
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_rb_4_4 to version_rb_4_4;
delete from sys.error$ o where  o.obj# IN    (  select 
            e.obj#
       from 
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
		  commit;
+ENDSQL
		else
		  echo not 11g
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_rb_4_4 to version_rb_4_4;
		  delete from user_errors;
		  commit;
+ENDSQL
		fi
	      elif [ ${dbmajorrel} = "5_0" ]
	      then
		echo 5.0
		if [ "$ORACLE_VERSION" = "11g" ]
		then
		  echo 11g
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_rb_5_0 to version_rb_5_0;
delete from sys.error$ o where  o.obj# IN    (  select 
            e.obj#
       from 
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
		  commit;
+ENDSQL
		else
		  echo not 11g
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_rb_5_0 to version_rb_5_0;
		  delete from user_errors;
		  commit;
+ENDSQL
		fi
	      elif [ ${dbmajorrel} = "5_1" ]
	      then
		echo 5.0
		if [ "$ORACLE_VERSION" = "11g" ]
		then
		  echo 11g
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_rb_5_1 to version_rb_5_1;
delete from sys.error$ o where  o.obj# IN    (  select 
            e.obj#
       from 
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
		  commit;
+ENDSQL
		else
		  echo not 11g
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_geneva_5_1 to version_geneva_5_1;
		  delete from user_errors;
		  commit;
+ENDSQL
		fi
		########## Added for 5.2 ##########
	      elif [ ${dbmajorrel} = "5_2" ]
              then
                echo 5.2
                if [ "$ORACLE_VERSION" = "11g" ]
                then
                  echo 11g
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_5_2 to version_rb_5_2;
delete from sys.error$ o where  o.obj# IN    (  select
            e.obj#
       from
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
                  commit;
+ENDSQL
                else
                  echo not 11g
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_geneva_5_2 to version_geneva_5_2;
                  delete from user_errors;
                  commit;
+ENDSQL
                fi
		########## Added for 5.2 ##########
		########## Added for 5.3 ##########
	      elif [ ${dbmajorrel} = "5_3" ]
              then
                echo 5.2
                if [ "$ORACLE_VERSION" = "11g" ]
                then
                  echo 11g
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_5_3 to version_rb_5_3;
delete from sys.error$ o where  o.obj# IN    (  select
            e.obj#
       from
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
                  commit;
+ENDSQL
                else
                  echo not 11g
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_geneva_5_3 to version_geneva_5_3;
                  delete from user_errors;
                  commit;
+ENDSQL
                fi
		########## Added for 5.3 ##########
	      ########## Added for 6.0 ##########
              elif [ ${dbmajorrel} = "6_0" ]
              then
                echo 5.3
                if [ "$ORACLE_VERSION" = "11g" ]
                then
                  echo 11g
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_6_0 to version_rb_6_0;
delete from sys.error$ o where  o.obj# IN    (  select
            e.obj#
       from
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
                  commit;
+ENDSQL
                else
                  echo not 11g
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_6_0 to version_rb_6_0;
                  delete from user_errors;
                  commit;
+ENDSQL
                fi
                ########## Added for 6.0 ##########
	      ########## Added for 6.1 ##########
              elif [ ${dbmajorrel} = "6_1" ]
              then
                echo 6.0
                if [ "$ORACLE_VERSION" = "11g" ]
                then
                  echo 11g
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_6_1 to version_rb_6_1;
delete from sys.error$ o where  o.obj# IN    (  select
            e.obj#
       from
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
                  commit;
+ENDSQL
                else
                  echo not 11g
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_6_1 to version_rb_6_1;
                  delete from user_errors;
                  commit;
+ENDSQL
                fi
                ########## Added for 6.1 ##########
	      ########## Added for 7.0 ##########
              elif [ ${dbmajorrel} = "7_0" ]
              then
                echo 6.1
                if [ "$ORACLE_VERSION" = "11g" ]
                then
                  echo 11g
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_7_0 to version_rb_7_0;
delete from sys.error$ o where  o.obj# IN    (  select
            e.obj#
       from
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
                  commit;
+ENDSQL
                else
                  echo not 11g
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_7_0 to version_rb_7_0;
                  delete from user_errors;
                  commit;
+ENDSQL
                fi
                ########## Added for 7.0 ##########
	      ########## Added for 8.0 ##########
              elif [ ${dbmajorrel} = "8_0" ]
              then
                echo 7.0
                if [ "$ORACLE_VERSION" = "11g" ]
                then
                  echo 11g
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_8_0 to version_rb_8_0;
delete from sys.error$ o where  o.obj# IN    (  select
            e.obj#
       from
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
                  commit;
+ENDSQL
                else
                  echo not 11g
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_8_0 to version_rb_8_0;
delete from sys.error$ o where  o.obj# IN    (  select
            e.obj#
       from
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
                  commit;
+ENDSQL
                fi
                ########## Added for 8.0 ##########

	 ########## Added for 9.0 ##########
              elif [ ${dbmajorrel} = "9_0" ]
              then
                echo 8.0
                if [ "$ORACLE_VERSION" = "12c" ]
                then
                  echo 12c
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_9_0 to version_rb_9_0;
delete from sys.error$ o where  o.obj# IN    (  select
            e.obj#
       from
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
                  commit;
+ENDSQL
                else
                  echo not 12c
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_rb_9_0 to version_rb_9_0;
                  delete from user_errors;
                  commit;
+ENDSQL
                fi
                ########## Added for 9.0 ##########

	      else

		if [ "$ORACLE_VERSION" = "11g" ]
		then
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_geneva_${dbmajorrel} to version_geneva_${dbmajorrel};
delete from sys.error$ o where  o.obj# IN    (  select 
            e.obj#
       from 
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
	  	  commit;
+ENDSQL
		elif [ "$ORACLE_VERSION" = "12c" ]
                then
                  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                  whenever sqlerror exit failure
                  rename tmp_version_geneva_${dbmajorrel} to version_geneva_${dbmajorrel};
delete from sys.error$ o where  o.obj# IN    (  select
            e.obj#
       from
            sys."_CURRENT_EDITION_OBJ" o, sys.error$ e
       where o.obj# = e.obj#
            and o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 22, 28, 29, 43)
            and o.owner# = userenv('SCHEMAID'));
                  commit;
+ENDSQL

		else
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  rename tmp_version_geneva_${dbmajorrel} to version_geneva_${dbmajorrel};
		  delete from user_errors;
	  	  commit;
+ENDSQL
		fi
	      fi
	
	      schema_TopUps_and_devOwned BUILD $SCHEMA $ccm_project $majorrelease $DATABASE $log $dbmajorrel $ccm_state

  	      if [ "${ccm_project}" = "RB" -o  "$ccm_project" = "RTCA" ]
	      then
	  	  #Enable (Platform) triggers after installation of RB schema
		  echo "Enabling triggers against ${DATABASE}"
		  cd ${SCHEMA}/migration/scripts
		  sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		  whenever sqlerror exit failure
		  @fixalltriggers.sql ENABLE
		  exit
+ENDSQL
	          cd ${SCHEMA}/install
	      fi

              if [ -f ${SCHEMA}/SRC/rtdp_setup.sql ]
              then
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/rtdp_setup.sql
                      exit
+ENDSQL
              fi

              if [ -f ${SCHEMA}/SRC/costedeventattributes.sql ]
              then
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/costedeventattributes.sql
                      exit
+ENDSQL
              fi

              if [ -f ${SCHEMA}/SRC/rcif_setup.sql ]
              then
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/rcif_setup.sql
                      exit
+ENDSQL
              fi

              if [ -f ${SCHEMA}/SRC/btci_setup.sql ]
              then
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/btci_setup.sql
                      exit
+ENDSQL
              fi

              if [ -f ${SCHEMA}/SRC/cem_setup.sql ]
              then
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/cem_setup.sql
                      exit
+ENDSQL
              fi

              if [ -f ${SCHEMA}/SRC/cdr_setup.sql ]
              then
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/cdr_setup.sql
                      exit
+ENDSQL
              fi

              if [ -f ${SCHEMA}/SRC/rtdm_setup.sql ]
              then
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/rtdm_setup.sql
                      exit
+ENDSQL
              fi
###############################ARUN DELETED_FROM_HERE########################################
              if [ -f ${CORE}/SCHEMA/SRC/schema_changes_53575.sql ]
              then
		      echo "Start: Loading schema_changes_53575.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @${CORE}/SCHEMA/SRC/schema_changes_53575.sql
                      exit
+ENDSQL
		      echo "End: Loading schema_changes_53575.sql changes"
              fi
		if [ -f ${SCHEMA}/SRC/PR55943_static_data.sql ]
              	then
                      echo "Start: Loading PR55943_static_data.sql  changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL         
                      @../SRC/PR55943_static_data.sql
              
                      exit
+ENDSQL
                      echo "End: Loading PR55943_static_data.sql changes"
             	 fi
	
		if [ -f ${SCHEMA}/SRC/pub_create_ipgextracharges.sql ]
              then
                      echo "Start:  starting 60589 DHL schema scripts "
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                                          @../SRC/pub_create_ipgextracharges.sql
					  @../SRC/pub_create_recache_objects.sql
                        exit
+ENDSQL
                      echo "End: starting 60589 DHL schema scripts   "
              fi

	 if [ -f ${SCHEMA}/SRC/CR58500_data.sql ]
              then
                      echo "Start:  starting CR58500_data.sql "
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                                          @../SRC/CR58500_data.sql
                        exit
+ENDSQL
                      echo "End: CR58500_data.sql "
              fi

if [ -f ${CORE}/SCHEMA/SRC/create_btd_objects.sql ]
              then
                      echo "Start: Loading create_btd_objects.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @${CORE}/SCHEMA/SRC/create_btd_objects.sql
                      exit
+ENDSQL
                      echo "End: Loading create_btd_objects.sql changes"
              fi

if [ -f ${SCHEMA}/SRC/create_btd_objects.sql ]
              then
                      echo "Start: Loading create_btd_objects.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/create_btd_objects.sql
                      exit
+ENDSQL
                      echo "End: Loading create_btd_objects.sql changes"
              fi
		if [ -f ${SCHEMA}/SRC/schema_changes_53575.sql ]
              then
                      echo "Start: Loading schema_changes_53575.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/schema_changes_53575.sql
                                  exit
+ENDSQL
                      echo "End: Loading schema_changes_53575.sql changes"
              fi

              if [ -f ${SCHEMA}/SRC/topup_for_445_137.sql ]
              then
		      echo "Start: Loading topup_for_445_137.sql "
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/topup_for_445_137.sql
                      exit
+ENDSQL
		      echo "End: Loading topup_for_445_137.sql"
              fi

              if [ -f ${SCHEMA}/SRC/schemaTopUp/RB5.3/scripts/topup_for_5356.sql ]
              then
		      echo "Start: Loading topup_for_5356.sql"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/schemaTopUp/RB5.3/scripts/topup_for_5356.sql
                      exit
+ENDSQL
		      echo "End: Loading topup_for_5356.sql changes"
              fi

	      if [ -f ${VPACORE}/CEI/SRC/ice_leap_schema.sql  ]
	      then
		      echo "Start: Loading ice_leap_schema.sql changes"
		      sqlplus -s  ${DATABASE} >> ${log} 2>&1 << +ENDSQL
		      @${VPACORE}/CEI/SRC/ice_leap_schema.sql
		      exit
+ENDSQL
		      echo "End: Loading ice_leap_schema.sql changes"
	      fi
	
if [ -f ${SCHEMA}/SRC/CR59701_changes_2.sql ]
              then
                      echo "Start:  starting CR59701_changes_2.sql  "
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                                          @../SRC/CR59701_changes_2.sql


                      exit
+ENDSQL
                      echo "End: Loading CR59701_changes_2.sql "
fi
		 if [ -f ${SCHEMA}/SRC/PR59871_schema_migration.sql ]
              then
                      echo "Start: Loading PR59871_schema_migration.sql   changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                   
                      @../SRC/PR59871_schema_migration.sql
                      exit
+ENDSQL
                      echo "End: Loading PR59871_schema_migration.sql   changes"
              fi
		if [ -f ${SCHEMA}/SRC/addIbanBicColumns.sql  ]
              then
                      echo "Start: Loading createPRMANDATE3View.sql,addIbanBicColumns.sql  createPVPAYMENTMETHOD7View.sql   changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/addIbanBicColumns.sql 
                      @../SRC/createPRMANDATE3View.sql 
                      @../SRC/createPVPAYMENTMETHOD7View.sql 
                      exit
+ENDSQL
                fi


  if [ -f ${SCHEMA}/SRC/schemaTopUp/RB3.0/schema_top_up_for_3_0_R_patch_52373.sql ]
              then
		      echo "Start: Loading schema_top_up_for_3_0_R_patch_52373.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/schemaTopUp/RB3.0/schema_top_up_for_3_0_R_patch_52373.sql
                      exit
+ENDSQL
		      echo "End: Loading schema_top_up_for_3_0_R_patch_52373.sql changes"
              fi

              if [ -f ${SCHEMA}/SRC/schemaTopUp/RB4.4/schema_top_up_for_4_4_h.sql ]
              then
		      echo "Start: Loading schema_top_up_for_4_4_h.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/schemaTopUp/RB4.4/schema_top_up_for_4_4_h.sql
                      exit
+ENDSQL
		      echo "End: Loading schema_top_up_for_4_4_h.sql changes"
              fi

              if [ -f ${SCHEMA}/SRC/pr51880_create_ICOINTERNALCURRCODE.sql ]
              then
                      echo "Start: Loading pr51880_create_ICOINTERNALCURRCODE.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/pr51880_create_ICOINTERNALCURRCODE.sql
                      exit
+ENDSQL
                      echo "End: Loading pr51880_create_ICOINTERNALCURRCODE.sql changes"
              fi


	      if [ -f ${SCHEMA}/SRC/pr51935_create_CUSTPRODSPLITDETAILS.sql ]
	      then
		      echo "Start: Loading pr51935_create_CUSTPRODSPLITDETAILS.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/pr51935_create_CUSTPRODSPLITDETAILS.sql
                      exit
+ENDSQL
                      echo "End: Loading pr51935_create_CUSTPRODSPLITDETAILS.sql changes"
              fi
# if [ -f ${SCHEMA}/SRC/PR55184_schema_changes.sql ]
#              then
#                      echo "Start:  starting PR55184_schema_changes.sql "
#                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
#                                          @../SRC/PR55184_drop_schema_changes.sql
#                                          @../SRC/PR55184_schema_changes.sql
#                      			  exit
#+ENDSQL
#                      echo "End: Loading PR55184_schema_changes.sql  "
#              fi
			  
	      if [ -f ${SCHEMA}/SRC/PR58969.sql ]
              then
                      echo "Start: Loading PR58969.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      exit
+ENDSQL
                      echo "End: Loading PR58969.sql  changes"
              fi
              if [ -f ${SCHEMA}/SRC/createTerminatedAccDriverTable.sql ]
              then
		      echo "Start: Loading createTerminatedAccDriverTable.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/createTerminatedAccDriverTable.sql
                      exit
+ENDSQL
		      echo "End: Loading createTerminatedAccDriverTable.sql changes"
              fi

             if [ -f ${SCHEMA}/SRC/modify_ratingrevenuesummary.sql ] 
 		then
                      echo "Start: Loading modify_ratingrevenuesummary changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                      @../SRC/modify_ratingrevenuesummary.sql
                      exit
+ENDSQL
                      echo "End: Loading modify_ratingrevenuesummary.sql changes"
              fi

              if [ -f ${SCHEMA}/SRC/schemaTopUp/RB3.0/schema_top_up_for_3_0_R_patch_49267.sql ]
              then
		      echo "Start: Loading schema_top_up_for_3_0_R_patch_49267.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
			define genevauser='geneva_admin'
                      @../SRC/schemaTopUp/RB3.0/schema_top_up_for_3_0_R_patch_49267.sql
                      exit
+ENDSQL
		      echo "End: Loading schema_top_up_for_3_0_R_patch_49267.sql changes"
              fi

		 if [ -f ${SCHEMA}/SRC/schemaTopUp/RB3.0/schema_top_up_for_3_0_R_patch_49961.sql ]
              then
                      echo "Start: Loading schema_top_up_for_3_0_R_patch_49961.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                        define genevauser='geneva_admin'
                        define datatablespace='DATA'
                        define indextablespace='DATA'
                      @../SRC/schemaTopUp/RB3.0/schema_top_up_for_3_0_R_patch_49961.sql
                      exit
+ENDSQL
                      echo "End: Loading schema_top_up_for_3_0_R_patch_49961.sql changes"
              fi
 if [ -f ${SCHEMA}/SRC/CR61988_schema.sql ]
              then
                      echo "Start: Loading CR61988_schema.sql  &  PR60837_drop.sql changes"
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL

                      @../SRC/CR61988_schema.sql

                      exit
+ENDSQL
                      echo "End: Loading CR61988_schema.sql  &  PR60837_drop.sql changes"
              fi

  if [ -f ${SCHEMA}/SRC/61569_grants_and_views.sql ]
              then
                      echo "Start:  starting 61569_grants_and_views.sql "
                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
                                        
                                          @../SRC/61569_grants_and_views.sql


                      exit
+ENDSQL
                      echo "End: Loading 61569_grants_and_views.sql"
              fi
########Commented below sql file execution as per Chris Mail################
#if [ -f ${SCHEMA}/SRC/cr89711_changes.sql ]
#                then
#                      echo "Start: Loading cr89711_changes.sql "
#                      sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
#                      @../SRC/cr89711_changes.sql

#                       exit
#+ENDSQL
#                      echo "End: Loading cr89711_changes.sql"
#                fi


		t_date=`date '+%Y%m%d'`
		logdt=`date '+%Y%m%d%H%M%S'`
		temp_path=$BCE_LOG/$t_date
		if [ ! -d $BCE_LOG/$t_date ]
		then
			mkdir -p $temp_path
		fi
			. ${BCE_BUILD_SCRIPTS}/svn_new_us.svn
		echo "************Start of Execution of schema_changes_sql files************"	
		for i in `ls ../SRC/*change*.sql`
                do
                        svn_last_rev_no=`svn info $i|grep 'Last Changed Rev'|cut -d':' -f2-`
                        echo "$i $svn_last_rev_no" >> $temp_path/changes_sql_${minor_release}_$logdt.txt
                done
		#for i in `ls ../SRC/*changes.sql`
                #do
                #        svn_last_rev_no=`svn info $i|grep 'Last Changed Rev'|cut -d':' -f2-`
                #        echo "$i $svn_last_rev_no" >> $temp_path/changes_sql_${minor_release}_$logdt.txt
                #done
		#for i in `ls ../SRC/*CHANGES.sql`
		#do
		#	svn_last_rev_no=`svn info $i|grep 'Last Changed Rev'|cut -d':' -f2-`
		#	echo "$i $svn_last_rev_no" >> $temp_path/changes_sql_${minor_release}_$logdt.txt
		#done
		for i in `ls ../SRC/*CHANGE*.sql`
                do
                        svn_last_rev_no=`svn info $i|grep 'Last Changed Rev'|cut -d':' -f2-`
                        echo "$i $svn_last_rev_no" >> $temp_path/changes_sql_${minor_release}_$logdt.txt
                done
		cat $temp_path/changes_sql_${minor_release}_$logdt.txt
		echo "###################Below is the Order of Execuition of changes_sql files############"
		cat $temp_path/changes_sql_${minor_release}_$logdt.txt|sort -nk2
		echo "Generating sequence for files with same revision no"
		for i in `cat $temp_path/changes_sql_${minor_release}_$logdt.txt|sort -nk2|awk '{print $2}'|uniq`
		do
			count=`cat $temp_path/changes_sql_${minor_release}_$logdt.txt|grep $i|wc -l`
			if [ $count -gt 1 ]
			then
				cat $temp_path/changes_sql_${minor_release}_$logdt.txt|sort -nk2|grep $i|awk '{print $1}'|sort -nr >> $temp_path/fin_changes_sql_${minor_release}_$logdt.txt
			elif [ $count -eq 1 ]
			then
				cat $temp_path/changes_sql_${minor_release}_$logdt.txt|sort -nk2|grep $i|awk '{print $1}' >> $temp_path/fin_changes_sql_${minor_release}_$logdt.txt
			fi
		done
		echo "######################SEQUENCE OF EXECUITION OF SCHEMA CHANGES"
		cat $temp_path/fin_changes_sql_${minor_release}_$logdt.txt
		echo "#######################Start of execuition of files###################"
		#for i in `cat $temp_path/changes_sql_${minor_release}_$logdt.txt|sort -nk2|awk '{print $1}'`
		for i in `cat $temp_path/fin_changes_sql_${minor_release}_$logdt.txt`
		do
			Schema_Change_File_Name=`echo $i|cut -d'/' -f3`
			echo "Start: Loading $Schema_Change_File_Name "
			sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
			@$i
			exit
+ENDSQL
		echo "End: Loading $Schema_Change_File_Name"
		done
		echo "************END of Execution of schema_changes_sql files************"
############################################################ARUN END OF CHANGES.SQL EXECUTION###############################
	  else


		# Install the CACHE Database (CACHE_DATABASE)
		# Currently no official scripts exist, so temp. use dev schema

		CACHE_DATABASE=$DATABASE
		CACHE_SID_WORLD=`echo $CACHE_DATABASE | cut -d '@' -f2 | tr '[a-z]' '[A-Z]'`
		DATABASE=$backend_olc_db
		export CACHE_DATABASE DATABASE CACHE_SID_WORLD
		echo just before createinstance: DATABASE=$DATABASE >> ${log} 2>&1
		echo just before createinstance: CACHE_DATABASE=$CACHE_DATABASE >> ${log} 2>&1
		cd $SCHEMA/olc
		cd procedures
		if [ `ls | wc -l` -eq 0 ]
		then
			ln -s ../../procedures/*cache* .
		fi
		cd ..
#old?		preprocess.sh

		# Enter a record in the RBM Backend CACHEINSTANCE table with the SEQUENCE_OFFSET column set for each Cache Instance (SERVICE_NAME column) that needs to be installed

		echo backend_olc_db_sys=$backend_olc_db_sys >> ${log} 2>&1
		if [ ${dbmajorrel} = "4_0" ]
		then
			schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
			set feed off
			set head off
			select letter from version_rb_4_0;
			exit
+ENDSQL`
		elif [ ${dbmajorrel} = "4_1" ]
		then
			schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
			set feed off
			set head off
			select letter from version_rb_4_1;
			exit
+ENDSQL`
		elif [ ${dbmajorrel} = "4_2" ]
		then
			schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
			set feed off
			set head off
			select letter from version_rb_4_2;
			exit
+ENDSQL`
		elif [ ${dbmajorrel} = "4_3" ]
		then
			schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
			set feed off
			set head off
			select letter from version_rb_4_3;
			exit
+ENDSQL`
		elif [ ${dbmajorrel} = "4_4" ]
		then
			schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
			set feed off
			set head off
			select letter from version_rb_4_4;
			exit
+ENDSQL`
		elif [ ${dbmajorrel} = "5_0" ]
		then
			schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
			set feed off
			set head off
			select letter from version_rb_5_0;
			exit
+ENDSQL`
		elif [ ${dbmajorrel} = "5_1" ]
		then
			schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
			set feed off
			set head off
			select letter from version_rb_5_1;
			exit
+ENDSQL`

		########## Added for 5.2 ##########
		elif [ ${dbmajorrel} = "5_2" ]
                then
                        schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
                        set feed off
                        set head off
                        select letter from version_rb_5_2;
                        exit
+ENDSQL`

		########## Added for 5.2 ##########
		########## Added for 5.3 ##########
		elif [ ${dbmajorrel} = "5_3" ]
                then
                        schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
                        set feed off
                        set head off
                        select letter from version_rb_5_3;
                        exit
+ENDSQL`

		########## Added for 5.3 ##########
		########## Added for 6.0 ##########
		elif [ ${dbmajorrel} = "6_0" ]
                then
                        schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
                        set feed off
                        set head off
                        select letter from version_rb_6_0;
                        exit
+ENDSQL`

		########## Added for 6.0 ##########
		########## Added for 6.1 ##########
		elif [ ${dbmajorrel} = "6_1" ]
                then
                        schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
                        set feed off
                        set head off
                        select letter from version_rb_6_1;
                        exit
+ENDSQL`

		########## Added for 6.1 ##########
		########## Added for 7.0 ##########
		elif [ ${dbmajorrel} = "7_0" ]
                then
                        schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
                        set feed off
                        set head off
                        select letter from version_rb_7_0;
                        exit
+ENDSQL`

		########## Added for 7.0 ##########
		########## Added for 8.0 ##########
		elif [ ${dbmajorrel} = "8_0" ]
                then
                        schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
                        set feed off
                        set head off
                        select letter from version_rb_8_0;
                        exit
+ENDSQL`

		########## Added for 8.0 ##########
		
		  ########## Added for 9.0 ##########
                elif [ ${dbmajorrel} = "9_0" ]
                then
                        schema_letter=`sqlplus -s ${backend_olc_db} >> ${log} 2>&1 << +ENDSQL
                        set feed off
                        set head off
                        select letter from version_rb_9_0;
                        exit
+ENDSQL`

                fi
                ########## Added for 9.0 ##########


		dbmajorreldot=`echo $dbmajorrel | tr '_' '.'`

		schema_let=`echo $schema_letter`
		schema_ver=${dbmajorreldot}${schema_let}
		echo "Mangled Schema_ver=${schema_ver}" >> ${log} 2>&1

		seqnum=`sqlplus -s ${backend_olc_db} << +ENDSQL
		set feed off
		set head off
		select sequenceoffsetseq.nextval from dual;
		exit
+ENDSQL`

		seqnumber=`echo $seqnum`
		echo "Sequence Number=$seqnumber" >> ${log} 2>&1
		sqlplus -s ${backend_olc_db} << +ENDSQL
		insert into cacheinstance (service_name, schema_version, sequence_offset) values ('$CACHE_SID_WORLD','$schema_ver','$seqnumber');
		exit
+ENDSQL

		echo "Run roles/sysprivs.sql into $backend_olc_db_sys" >> ${log} 2>&1
                sqlplus -s ${backend_olc_db_sys} >> ${log} 2>&1 << +ENDSQL
                @roles/sysprivs.sql $dbspec rbm
                exit
+ENDSQL

		mv scripts/olc_instance.txt scripts/olc_instance.txt.ccm
		cp scripts/olc_instance.txt.ccm scripts/olc_instance.txt
		chmod 777 scripts/olc_instance.txt
		echo "sys sys $CACHE_SID_WORLD" >> scripts/olc_instance.txt
		echo "The olc_instance.txt looks like:" >> ${log} 2>&1
		echo "--------------------"  >> ${log} 2>&1
		cat scripts/olc_instance.txt >> ${log} 2>&1
		echo "--------------------" >> ${log} 2>&1
		
		echo "sg: Running install.sh" >> ${log} 2>&1
		install.sh >> ${log} 2>&1
		echo $? >> ${log} 2>&1
		if [ ${dbmajorrel} = "4_0" ]
		then
			sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
			whenever sqlerror exit failure
			rename tmp_version_rb_4_0 to version_rb_4_0;
			delete from user_errors;
			commit;
+ENDSQL
		elif [ ${dbmajorrel} = "4_1" ]
		then
			sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
			whenever sqlerror exit failure
			rename tmp_version_rb_4_1 to version_rb_4_1;
			delete from user_errors;
			commit;
+ENDSQL
		elif [ ${dbmajorrel} = "4_2" ]
		then
			sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
			whenever sqlerror exit failure
			rename tmp_version_rb_4_2 to version_rb_4_2;
			delete from user_errors;
			commit;
+ENDSQL
		elif [ ${dbmajorrel} = "4_3" ]
		then
			sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
			whenever sqlerror exit failure
			rename tmp_version_rb_4_3 to version_rb_4_3;
			delete from user_errors;
			commit;
+ENDSQL
		elif [ ${dbmajorrel} = "4_4" ]
		then
			sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
			whenever sqlerror exit failure
			rename tmp_version_rb_4_4 to version_rb_4_4;
			delete from user_errors;
			commit;
+ENDSQL
		elif [ ${dbmajorrel} = "5_0" ]
		then
			sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
			whenever sqlerror exit failure
			rename tmp_version_rb_5_0 to version_rb_5_0;
			delete from user_errors;
			commit;
+ENDSQL
		elif [ ${dbmajorrel} = "5_1" ]
		then
			sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
			whenever sqlerror exit failure
			rename tmp_version_rb_5_1 to version_rb_5_1;
			delete from user_errors;
			commit;
+ENDSQL
		########## Added for 5.2 ##########
		elif [ ${dbmajorrel} = "5_2" ]
                then
                        sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
                        whenever sqlerror exit failure
                        rename tmp_version_rb_5_2 to version_rb_5_2;
                        delete from user_errors;
                        commit;
+ENDSQL
		########## Added for 5.2 ##########
		########## Added for 5.3 ##########
		elif [ ${dbmajorrel} = "5_3" ]
                then
                        sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
                        whenever sqlerror exit failure
                        rename tmp_version_rb_5_3 to version_rb_5_3;
                        delete from user_errors;
                        commit;
+ENDSQL
		########## Added for 5.3 ##########
		########## Added for 6.0 ##########
		elif [ ${dbmajorrel} = "6_0" ]
                then
                        sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
                        whenever sqlerror exit failure
                        rename tmp_version_rb_6_0 to version_rb_6_0;
                        delete from user_errors;
                        commit;
+ENDSQL
		########## Added for 6.0 ##########
		########## Added for 6.1 ##########
		elif [ ${dbmajorrel} = "6_1" ]
                then
                        sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
                        whenever sqlerror exit failure
                        rename tmp_version_rb_6_1 to version_rb_6_1;
                        delete from user_errors;
                        commit;
+ENDSQL
		########## Added for 6.1 ##########
		########## Added for 7.0 ##########
		elif [ ${dbmajorrel} = "7_0" ]
                then
                        sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
                        whenever sqlerror exit failure
                        rename tmp_version_rb_7_0 to version_rb_7_0;
                        delete from user_errors;
                        commit;
+ENDSQL
		########## Added for 7.0 ##########
		########## Added for 8.0 ##########
		elif [ ${dbmajorrel} = "8_0" ]
                then
                        sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
                        whenever sqlerror exit failure
                        rename tmp_version_rb_8_0 to version_rb_8_0;
                        delete from user_errors;
                        commit;
+ENDSQL
		########## Added for 8.0 ##########

		  ########## Added for 9.0 ##########
                elif [ ${dbmajorrel} = "9_0" ]
                then
                        sqlplus -s ${CACHE_DATABASE} >> ${log} 2>&1 << +ENDSQL
                        whenever sqlerror exit failure
                        rename tmp_version_rb_9_0 to version_rb_9_0;
                        delete from user_errors;
                        commit;
+ENDSQL
                fi
                ########## Added for 9.0 ##########



		rm scripts/olc_instance.txt
		mv scripts/olc_instance.txt.ccm scripts/olc_instance.txt
		
	  fi
                              RB_installation_check=`cat ${log}|grep 'W7_queue_propagation.sql'`
                                          if [ -z "$RB_installation_check" ]
                                          then
                                                 printf "\t RB schema installation was failed....... Please cehck and re-run the build \n" >> ${log} 2>&1
                                               PFUSR_IN_DB=`sqlplus -s  ${SYSDATABASE} << +END
                                                            whenever sqlerror exit failure
                                                            set feed off
                                                            set head off
                                                            drop user S_VZW_903XL cascade;
                                                            exit
+END`
                                          exit
                                          fi
        fi	
        else
            cd ${SCHEMA}/SRC
            sqlplus -s ${DATABASE} >> ${log} 2>&1 << +ENDSQL
            @schema.sql
            ${dbspec}
            exit
+ENDSQL
fi 
return 0
}

# Function used to create an Online Charging Server database....

createDB_OCS() # ${SCHEMA} ${DATABASE} ${log} ${SYSDATABASE} ${DATABASE_OCS} ${dbspec_ocs}
{
    SCHEMA=${1}
    DATABASE=${2}
    log=${3}
    SYSDATABASE="${4}"
    DATABASE_OCS=${5}
    dbspec_ocs=${6}
    oracle_ver=${7}
    majorrelease=${8}

    if [ "${DATABASE_OCS}" != "" ]
    then
        echo "Dropping and creating OCS user ${DATABASE_OCS}..." >> ${log}
	new_oracle=no
	if [ "${ccm_project}" = "RB"  -o "${ccm_project}" = "RTCA" ]
	then
		new_oracle=yes
	fi

		if [ "${new_oracle}" = "yes" ]
		then
	            sqlplus -s "${SYSDATABASE}" >> ${log} 2>&1 << +ENDSQL
	            drop user ${dbspec_ocs} cascade;

	            create user ${dbspec_ocs}
	                identified by ${dbspec_ocs}
	                default tablespace data
	                temporary tablespace temp;

	            grant dba to ${dbspec_ocs} with admin option;
	            grant create session   to ${dbspec_ocs};
	            grant create table     to ${dbspec_ocs};
	            grant create view      to ${dbspec_ocs};
	            grant create procedure to ${dbspec_ocs};
	            grant create sequence  to ${dbspec_ocs};

	            exit success
+ENDSQL
		else
	            sqlplus -s "${SYSDATABASE}" >> ${log} 2>&1 << +ENDSQL
	            drop user ${dbspec_ocs} cascade;

	            create user ${dbspec_ocs}
	                identified by ${dbspec_ocs}
	                default tablespace data
	                temporary tablespace temp
	            	quota unlimited on data
	            	quota unlimited on temp;

	            grant dba to ${dbspec_ocs} with admin option;
	            grant create session   to ${dbspec_ocs};
	            grant create table     to ${dbspec_ocs};
	            grant create view      to ${dbspec_ocs};
	            grant create procedure to ${dbspec_ocs};
	            grant create sequence  to ${dbspec_ocs};

	            exit success
+ENDSQL
		fi
        echo "Dropping and creating OCS user ${DATABASE_OCS} complete" >> ${log}

        if [ -d ${SCHEMA}/SRC/ocs ]
        then
            echo "Loading OCS schema..." >> ${log}
            cd ${SCHEMA}/SRC/ocs

	    DATABASE_ORIG=$DATABASE
	    DATABASE=$DATABASE_OCS

	    siemens_installer.sh install

	    DATABASE=$DATABASE_ORIG

# Removed and replaced with install_schema.sh lines above.
#            sqlplus -s "${DATABASE_OCS}" >> ${log} 2>&1 << +ENDSQL
#            @table.sql
#            @index.sql
#	    @materialized_view.sql
#            @view.sql
#            @sequence.sql
#            exit success
#+ENDSQL

            echo "Loading OCS schema complete" >> ${log}
        else
            echo "OCS schema directory not found - OCS schema not loaded" >> ${log}
        fi
	    if [ "$PLATFORM" = "solaris32" ]
	    then
		if [ -f ${SCHEMA}/../RATE/design/RB3.0/createPfmessageSynonymOCS.sql ]
		then
			sqlplus -s ${DATABASE_OCS} >> ${log} 2>&1 << +ENDSQL
			@${CCM_ROOT}/RATE/design/RB3.0/createPfmessageSynonymOCS.sql
			exit
+ENDSQL
		fi
	    fi

    else
        echo "DATABASE_OCS not set, OCS user creation skipped" >> ${log}
    fi
}

checkQueues()
{
if [ -f ${SCHEMA}/SRC/dropqueue.sql ]
then
    sqlplus -s ${DATABASE} << +ENDSQL
    @/irb/bce/admin/build_scripts/checkForQueues.sql ${DBNAME}
    exit
+ENDSQL
fi
}
