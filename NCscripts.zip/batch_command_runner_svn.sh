#!/bin/ksh
set -x

if [ -f ~/.bce.ini ]
then
	. ~/.bce.ini
fi

. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh

logdir=${BCE_LOG}/BCR
html_logdir=logs

if [ ! -d "$logdir" ]
then
	mkdir -p $logdir
fi

tmp_file="/tmp/batch_command_runner.$$"
lock_file="/tmp/lock_batch_command_runner"
preview="FALSE"

if [ "$1" = "-u" ]
then
	# Usage
	echo "$0"
	echo "	Runs the batch commands in the state wait in buildweb"
	exit 0
fi 

BUILDWEB_DB=`buildweb_connection`

find_sqlhome 9.2.0.SE
if [ $? -ne 0 ]
then
	echo "$0: Error: Cannot find valid SQLPLUS"
	exit 1
fi

sql="select command_id,',',rerun_number,',',rerun_max,',',create_dtm,',',parent_command_id,',',username,';' from batch_command_summary where status='wait' and machine='`hostname`' and runas='`whoami`' ORDER BY command_id;"

raw_commands=`sql_query $BUILDWEB_DB "$sql" "y" | sed -e 's/[	 ]*,[	 ]*/,/g' | sed -e 's/ /xxxspace/g'`
wait_commands=`echo $raw_commands | sed -e 's/ /xxxspace/g' | tr ';' ' '`

error_on_sql_query()
{
	status=$1

	if [ $status -ne 0 ]
	then
		echo "Error Returned from sql_query: $status"
		exit 5
	fi
}

find_children ()
{
	command_ids=$1
	find_children_commands=""

	for i in $command_ids
	do
		sql="select command_id,',',rerun_number,',',rerun_max,',',create_dtm,',',parent_command_id,',',username,';' from batch_command_summary where parent_command_id='$i' and machine='`hostname`' and runas='`whoami`' ORDER BY create_dtm;"
		raw_commands=`sql_query $BUILDWEB_DB "$sql" "y" | sed -e 's/[	 ]*,[	 ]*/,/g' | sed -e 's/ /xxxspace/g'`
		find_children_commands="$find_children_commands `echo $raw_commands | sed -e 's/ /xxxspace/g' | tr ';' ' '`"
		sql="update batch_command_summary set status='group_wait' where command_id='$i';"
		sql_query $BUILDWEB_DB "$sql" "y"
		error_on_sql_query $?
		for j in $find_children_commands
		do
			child_command_id=`echo $j | cut -d',' -f1 | sed -e 's/xxxspace/ /g' | sed -e 's/^ //g;s/ $//g'`
			find_children_commands="$find_children_commands `find_children $child_command_id`"
		done	
	done
	echo $find_children_commands
}

while [ -f $lock_file ]
do
	sleep 10
done

touch $lock_file > /dev/null 2>&1
chmod 777 $lock_file > /dev/null 2>&1

for raw_batch_command_data in $wait_commands
do
	command_id=`echo $raw_batch_command_data | cut -d',' -f1 | sed -e 's/xxxspace/ /g' | sed -e 's/^ //g;s/ $//g'`

	group_commands="$group_commands `find_children $command_id`"

	parent_and_group_commands="$raw_batch_command_data $group_commands"
	break
done

rm $lock_file > /dev/null 2>&1

for raw_batch_command_data in $parent_and_group_commands
do
	echo $raw_batch_command_data
	command_id=`echo $raw_batch_command_data | cut -d',' -f1 | sed -e 's/xxxspace/ /g' | sed -e 's/^ //g;s/ $//g' | sed -e 's/ //g'`
	rerun_number=`echo $raw_batch_command_data | cut -d',' -f2 | sed -e 's/xxxspace/ /g' | sed -e 's/^ //g;s/ $//g'`
	rerun_max=`echo $raw_batch_command_data | cut -d',' -f3 | sed -e 's/xxxspace/ /g' | sed -e 's/^ //g;s/ $//g'`
	create_dtm=`echo $raw_batch_command_data | cut -d',' -f4 | sed -e 's/xxxspace/ /g' | sed -e 's/^ //g;s/ $//g'`
	parent_command_id=`echo $raw_batch_command_data | cut -d',' -f5 | sed -e 's/xxxspace/ /g' | sed -e 's/^ //g;s/ $//g'`
	username=`echo $raw_batch_command_data | cut -d',' -f5 | sed -e 's/xxxspace/ /g' | sed -e 's/^ //g;s/ $//g'`

	if [ ! -z "$parent_command_id" -a $rerun_number = 0 ]
	then
		sql="select status from batch_command_summary where command_id='$parent_command_id';"
		parent_status=`sql_query $BUILDWEB_DB "$sql" "y" | sed -e 's/[	 ]*,[	 ]*/,/g' | sed -e 's/ //g' | perl -e 'while (<STDIN>){$x = <STDIN>;$x=~s/\s//g;print $x;}' `
		echo -$parent_status- is the parents status
		if [ "$parent_status" != "success" ]
		then	
			echo "This is first try of running this command and its parent: $parent_command_id is not yet successful" 
			sql="update batch_command_summary set status='wait' where command_id='$command_id';"
			sql_query $BUILDWEB_DB "$sql" "y" 
			error_on_sql_query $?
			continue
		fi
	fi
		
	sql="select DBMS_LOB.substr(command,5000,1) from batch_command_summary where command_id='$command_id';"

	start_time=`get_date_time_for_buildweb`
	logfile="$logdir/${start_time}_`hostname`_$$"
	htmlfile="$html_logdir/${start_time}_`hostname`_$$"
	command_file=${logfile}_cmd

	raw_command=`sql_query $BUILDWEB_DB "$sql" "y" | sed -e 's/[	 ]*,[	 ]*/,/g' | sed -e 's/ /xxxspace/g'`
	echo $raw_command|grep 'true'
	sql_query $BUILDWEB_DB "$sql" "y" | sed -e 's/[	 ]*,[	 ]*/,/g' | sed -e 's/ /xxxspace/g'
	#sql_query $BUILDWEB_DB "$sql" "y" | sed -e 's/-d "/genadmin /' -e 's/true}"/sridhar/' -e "s/genadmin /-d '/" -e "s/sridhar/true}'/"  -e 's/APSTARGET}}"/sridhar/' -e "s/sridhar/}}'/" 
	#sql_query $BUILDWEB_DB "$sql" "y" | sed -e 's/APSTARGET}}\"/sridhar/' -e "s/sridhar/}}'/"
	echo "descirption of sql is: $sql"
	sql_query $BUILDWEB_DB "$sql" "y" > ${command_file}
	error_on_sql_query $?
	chmod 755 ${command_file}
	
	sql="update batch_command_summary set execute_dtm=to_date('$start_time','YYYYMMDDHH24MISS'), status='execute' where command_id='$command_id';"
	sql_query $BUILDWEB_DB "$sql" "y"
	error_on_sql_query $?

	run_number=`expr $rerun_number + 1`

	cat $command_file 2>&1
	ls -la $command_file
	command_file1=${command_file}_newcmd
	command_file2=${command_file}_newcmd1
	curl_ver=`cat $command_file |grep -i curl`
	
	if [ ! -z "$curl_ver" ]
	then
	cat $command_file|sed -e 's/-d "/genadmin /' -e 's/true}"/sridhar/' -e "s/genadmin /-d '/" -e "s/sridhar/true}'/"|sed -e "s/-/\//g"|sed -e "s/\/k/-k/g"|sed -e "s/\/H/-H/g"|sed -e "s/\/X/-X/g"|sed -e "s/\/d/-d/g"|sed -e "s/\/u/-u/g"|sed -e "s/Content\/Type/Content-Type/g"|sed -e "s/BUILDWEB\/bce_svn/BUILDWEB-bce_svn/g" >> $command_file1
	cat $command_file1|sed -e 's/APSTARGET}}"/SRIDHAR/g'  -e "s/SRIDHAR/}}'/g" -e "s/RBM\//RBM-/g" >> $command_file2
	ls -la $command_file2
	chmod 755 ${command_file2}	
	$command_file2 > $logfile 2>&1
	command_result_status=$?
	else
	$command_file > $logfile 2>&1
	command_result_status=$?
	fi

#	$command_file2 > $logfile 2>&1
#	command_result_status=$?

	end_time=`get_date_time_for_buildweb`

	sql="update batch_command_summary set result_code='$command_result_status', complete_dtm=to_date('$end_time','YYYYMMDDHH24MISS') where command_id='$command_id';"
	sql_query $BUILDWEB_DB "$sql" "y"
	error_on_sql_query $?

	# Upload the logfile
	sql="update batch_command_summary set result='$htmlfile' where command_id='$command_id';"
	sql_query $BUILDWEB_DB "$sql" "y"
	error_on_sql_query $?
	echo "update complete"
	# End of Upload the logfile

	if [ $command_result_status -ne 0 ]
	then
		# Command Failed
		sql="update batch_command_summary set status='auto rerun' where command_id='$command_id';"
		sql_query $BUILDWEB_DB "$sql" "y"
		error_on_sql_query $?
	else
		# Command Success
		sql="update batch_command_summary set status='success' where command_id='$command_id';"
		echo $sql
		sql_query $BUILDWEB_DB "$sql" "y"
		error_on_sql_query $?
	fi
done


if [ -f "$tmp_file" ]
then
	#rm $tmp_file
	echo $tmp_file
fi
#This block is added to run the task and target moving commands on tms

cd /irb/bce/users/genadmin/BUILDWEB-bce_svn/BUILDWEB/APS/supporting_files/run

chmod 755 task_cmd* target*

for i in `ls target.*`; do $i; done
for h in `ls task_cmd*`; do $h; done

mv task_cmd* target* /irb/bce/users/genadmin/BUILDWEB-bce_svn/BUILDWEB/APS/supporting_files/don

exit 0
