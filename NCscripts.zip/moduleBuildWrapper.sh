#!/bin/sh
#set -x
partial_build.us.sh $1 >& ${BCE_LOG}/partialbuild/moduleBuild_make_log_$1.log 2>&1
