#!/bin/sh

# This script will find all the messages from a build project and concatanate
# all into one file. This is for the rtests to run.

# Usage:
# cd to the top level of a project and the run. Will create a file in 
# mess/ called rtest_messages


echo "Starting to create the rtest messages file"

tmp_mess_files=mess/all_mess_files
tmp_mess_files1=mess/all_mess_files1
tmp_mess_files2=mess/all_mess_files2
rtest_mess_file=mess/rtest_messages

if [ -f "$CCM_ROOT/$tmp_mess_files" ]
then
	rm $CCM_ROOT/$tmp_mess_files
fi

if [ -f "$CCM_ROOT/$tmp_mess_files1" ]
then
	rm $CCM_ROOT/$tmp_mess_files1
	mkdir -p $CCM_ROOT/$tmp_mess_files1
fi

if [ -d "$CCM_ROOT/$tmp_mess_files1" ]
then
	chmod -R 777 $CCM_ROOT/$tmp_mess_files1
	rm -rf $CCM_ROOT/$tmp_mess_files1/*.xml
fi

if [ -f "$rtest_mess_file" ]
then
	rm $rtest_mess_file
fi
xmlHeader="<?xml version="\"1.0\"" encoding="\"US-ASCII\"" ?>"
rootText="<RBmessages>"
rootEndText="</RBmessages>"
echo "$xmlHeader"  > $rtest_mess_file
echo "$rootText" >> $rtest_mess_file

product_ms=`echo $CCM_ROOT|cut -d '/' -f5`

if [ "$product_ms" = "rb" ]
then 
	find . -name "*essage*.xml" -print | grep -v "CORE/mess" | grep -v ALLBATCH|grep -v PDALtestMessages.xml| grep -v testGetDomainMessageInfo.xml| grep -v testGetDomainMessageInfo1.xml| grep -v testGetDomainMessageInfo2.xml| grep -v testGetDomainMessageInfo3.xml| grep -v testGetDomainMessageInfo4.xml  > $tmp_mess_files
elif [ "$product_ms" = "rtca" ]
then
	find . -name "*essage*[s].xml" -print | grep -v "CORE/mess" | grep -v ALLBATCH|grep -v PDALtestMessages.xml|grep -v testGetDomainMessageInfo.xml|grep -v testGetDomainMessageInfo1.xml|grep -v testGetDomainMessageInfo2.xml|grep -v testGetDomainMessageInfo3.xml|grep -v testGetDomainMessageInfo4.xml  > $tmp_mess_files
fi
	
for i in `cat $tmp_mess_files`; do cp $i $tmp_mess_files1; done

echo "finished the find to create the rtest messages file"

for i in `find $tmp_mess_files1 -name "*essage*.xml"`
do
#Replace single backslash to double backslash,as echo will suppress one backslash
   sed 's#\\#\\\\#g' $i >> "$i"_tmp
   cat "$i"_tmp | while read line
   do
      if [ "$line" != "$xmlHeader" ]
      then
          if [ "$line" != "$rootText" ]
          then
              if [ "$line" != "$rootEndText" ]
              then
                 echo "$line" >> $rtest_mess_file
              fi
          fi
      fi
   done
rm -f "$i"_tmp

done
echo "$rootEndText" >> $rtest_mess_file

if [ -f "$tmp_mess_files" ]
then
        rm $tmp_mess_files
fi

echo "Finished creating the rtest messages file"
