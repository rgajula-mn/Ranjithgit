#!/bin/ksh
echo "create_ac_db.sh: SCRIPT START"

if [ $# -ne 7 ]; then
  echo "create_ac_db.sh: $0 <state> <solution version> <core reltag> <database> <oracle version> <steve version> <project>"
  echo "create_ac_db.sh: e.g. $0 sqa 4.3.6 GEN_5.4.22 COB3 10.2.0.SE 1 GPI"
  exit 1
fi 

. $BCE_BUILD_SCRIPTS/set_ac_paths.sh $1 $2 $3 $4 $5 $6 $7

export OUTPUT_ROOT=""
BUILD_LOG=${LOGDIR}/create_db_${THE_PLATFORM}_${THE_VERSION}_${THE_COREVERSION}_${DATABASE_VER_NAME}_${DATTIM}.log
echo "create_ac_db.sh: The build log is located: ${BUILD_LOG}"
MYCWD=`pwd`

echo "create_ac_db.sh: PROJ=" $PROJ > $BUILD_LOG 2>&1
echo "create_ac_db.sh: DATABASE=" $DATABASE >> $BUILD_LOG 2>&1
echo "create_ac_db.sh: CCM_ROOT=" $CCM_ROOT >> $BUILD_LOG 2>&1
echo "create_ac_db.sh: CORE=" $CORE >> $BUILD_LOG 2>&1
echo "create_ac_db.sh: TOOL=" $TOOL >> $BUILD_LOG 2>&1
echo "create_ac_db.sh: STEVE=" $STEVE >> $BUILD_LOG 2>&1

echo "create_ac_db.sh: " >> $BUILD_LOG 2>&1
echo "create_ac_db.sh: My CWD = ${MYCWD}" >> $BUILD_LOG 2>&1
echo "create_ac_db.sh: " >> $BUILD_LOG 2>&1


echo "create_ac_db.sh: build_scripts is $BCE_BUILD_SCRIPTS"  | tee -a $BUILD_LOG


# cdSchemaInstall
# cd to schema install directory and clear out logs etc.
cdSchemaInstall()
{
        echo "create_ac_db.sh: START cdSchemaInstall()"
	cd ${CCM_ROOT}/../${PROJ}/${THE_PROJECT}/SCHEMA/install >> $BUILD_LOG 2>&1

	pwd >> $BUILD_LOG 2>&1

	rm -f logs/* >> $BUILD_LOG 2>&1
	rm -f working/* >> $BUILD_LOG 2>&1
	rm -f scripts/stop_at_* >> $BUILD_LOG 2>&1
        echo "create_ac_db.sh: END cdSchemaInstall()"
}

# clearMigrationProcess
# needed for TAP from 7.3 onwards, as the gnvschema package fails to complete (because the
# roles aren't present) but because the order in which things are done, migrationprocess is
# not cleared out, causing TAP installation to fall over
clearMigrationProcess()
{
        echo "create_ac_db.sh: START clearMigrationProcess()"
	echo "create_ac_db.sh: About to delete from migrationprocess table, current contents are:" >> $BUILD_LOG 2>&1
	sqlplus -s $DATABASE >> $BUILD_LOG 2>&1 << +ENDSQL
	set linesize 512;
	select scriptname,lastmessage from migrationprocess;
	delete from migrationprocess;
	commit;
	exit;
+ENDSQL
        echo "create_ac_db.sh: END clearMigrationProcess()"
}

#makeInstallFileList3
# creates the filelist3 in the current directory
makeInstallFileList3()
{
    echo "create_ac_db.sh: START makeInstallFileList3()" | tee -a $BUILD_LOG
    schemaSrcDir=`pwd`
    echo "create_ac_db.sh: Creating install_filelist_3_for_build.txt in $schemaSrcDir" | tee -a  $BUILD_LOG

    if [ -f install_filelist_1_for_build.txt ]
    then
	if [ -f  install_filelist_3_for_build.txt ]
	then
	    rm -f install_filelist_3_for_build.txt >>  $BUILD_LOG 2>&1
	fi
	stopline=`grep stop_at install_filelist_1_for_build.txt`
	echo "create_ac_db.sh: Removing ${stopline} from ${schemaSrcDir}/install_filelist_1_for_build.txt"  >> $BUILD_LOG 2>&1
	grep -v stop_at install_filelist_1_for_build.txt > install_filelist_3_for_build.txt	    
    else
	echo "create_ac_db.sh: Error: cannot find install_filelist_1_for_build.txt in ${schemaSrcDir}"  >> $BUILD_LOG 2>&1
    fi
    echo "create_ac_db.sh: END makeInstallFileList3()"
}

# createSpdInstallFileList3
# cretaes install_filelist_3 in the component's schema directory, only
# needed for spd
createSpdInstallFileList3()
{
    echo "create_ac_db.sh: START createSpdInstallFileList3()"
    cd ${CCM_ROOT}/../${PROJ}/${THE_PROJECT}/SCHEMA/SRC  >> $BUILD_LOG 2>&1

    makeInstallFileList3
    echo "create_ac_db.sh: END createSpdInstallFileList3()"
}


# createInstallFileList3
# Creates the install_filelist_3 file based on install_filelist_1_for_build.txt
# in the Core Geneva schema. Remove the stop line from the end of the file
createInstallFileList3()
{
    echo "create_ac_db.sh: START createInstallFileList3()" | tee -a $BUILD_LOG
    cd ${GENEVA_ROOT}/${THE_COREPROJECT}  >> $BUILD_LOG 2>&1
    if [ -d SCHEMA ]                                    # Geneva 5.3 and later
    then
	cd SCHEMA/SRC  >> $BUILD_LOG 2>&1
    else                                                # Geneva 5.2 and earlier
	cd CORE/SCHEMA/SRC  >> $BUILD_LOG 2>&1
    fi
    makeInstallFileList3
    echo "create_ac_db.sh: END createInstallFileList3()" | tee -a $BUILD_LOG
}


# renameVersionGeneva
# Because the Geneva installation doesn't finish properly, the version_geneva table
# does not get correctly named (EG OLD_VERSION_GENEVA), which may cause the subsequent
# component installation to fail. This ensures that the table does get renamed
renameVersionGeneva()
{
    echo "create_ac_db.sh: START renameVersionGeneva()"
    echo "create_ac_db.sh: Tidying VERSION_GENEVA table"
    sqlplus -s $DATABASE @${BCE_BUILD_SCRIPTS}/create_ac_db_tidygenevaversion.sql >> $BUILD_LOG 2>&1
    echo "create_ac_db.sh: END renameVersionGeneva()"
}

# does our dependent version of Geneva exist in the releases to build
# file. Should only be called if all environment variables already
# exist. If so, then it means they have been exported from overnight_builds
# return 1 if dependent version exists
# return 0 if dependent version does not exist

DependsOnPrepGeneva()
{
    echo "create_ac_db.sh: START DependsOnPrepGeneva()" | tee -a $BUILD_LOG
    relToBuild=${releasesToBuildPath}/${releasesToBuildFile}
    if [ ! -f $relToBuild ]
    then
	echo "create_ac_db.sh: Error: unable to find releases to build file $relToBuild"  | tee -a $BUILD_LOG
	return 0
    fi

    echo "create_ac_db.sh: releasesToBuild = $relToBuild"  | tee -a $BUILD_LOG
    echo "create_ac_db.sh: GEN_LOGDIR      = $GEN_LOGDIR" | tee -a $BUILD_LOG

    # we're looking for GENEVA <release>:sqa[all] or RB <release>:sqa[all] or something like it

    echo "create_ac_db.sh: Looking for $THE_COREVERSION in $relToBuild" >>  $BUILD_LOG 2>&1

    grep "${THE_COREPROJECT}  *${THE_COREVERSION}:" $relToBuild | grep 'sqa\[all\]' >>  $BUILD_LOG 2>&1

    res=$?
    if [ $res -eq 0 ]
    then
	echo "create_ac_db.sh: We depend on prep Geneva"  | tee -a $BUILD_LOG
	return 1
    else
	echo "create_ac_db.sh: We do not depend on prep Geneva"  | tee -a $BUILD_LOG
	return 0
    fi
    echo "create_ac_db.sh: END DependsOnPrepGeneva()" | tee -a $BUILD_LOG
}


# NeedToWaitForGeneva - are we dependent on a prep Geneva build which is due to build
# tonight? And are we being called from overnight_builds? If so, then return 1
# otherwise return 0

NeedToWaitForGeneva()
{
    echo "create_ac_db.sh: START NeedToWaitForGeneva()" | tee -a $BUILD_LOG
    if [ -d $RELEASE_DIR ]
    then
	echo "create_ac_db.sh: ${RELEASE_DIR} exists, using procedures from there, no need to wait"  | tee -a $BUILD_LOG
	return 0                  # no need to wait
    fi

# GPI now builds at 8pm so ignore the next few lines
    # GPI is always built at 6am, this means that the logic here would not work, so
    # don't wait if GPI, just take our chances
    # NB If ever we change this, we would need to make sure we were looking in last nights log file
    # for the Geneva build complete
#    if [ $THE_PROJECT = 'GPI' ]
#    then
#	echo "create_ac_db.sh: GPI does not need to wait for Geneva" | tee -a $BUILD_LOG
# 	return 0
#    fi

    # are we dependent on Geneva building tonight? We need the releases to build file, and the logfile directory
    if [ $releasesToBuildPath ]
    then
        if [ $releasesToBuildFile ]
	then
	    if [ $GEN_LOGDIR ]
	    then
		DependsOnPrepGeneva
		if [ $? -eq 1 ]
		then
		    return 1      # 1 means we have to wait
		fi
	    fi
	fi
    fi
    echo "create_ac_db.sh: No need to wait for Geneva"  | tee -a $BUILD_LOG
    return 0
    echo "create_ac_db.sh: END NeedToWaitForGeneva()" | tee -a $BUILD_LOG
}

# wait for either the build complete flag to appear, or the reconfigure fail flag
# or else we time out. If 
WaitForGenevaBuildToComplete()
{
    echo "create_ac_db.sh: START WaitForGenevaBuildToComplete()"
    hours=10
    timeToWait=`expr ${hours} \* 60 \* 60`

    echo "create_ac_db.sh: waiting ${hours} hours (${timeToWait} seconds) for Geneva ${THE_COREVERSION}"  | tee -a $BUILD_LOG

    elapsedTime=0              # time in seconds
    timeToSleep=300            # ie sleep  5 minutes

    buildComplete="buildComplete-${THE_COREPROJECT}-sqa${THE_COREVERSION}.${THE_PLATFORM}.${DATABASE_VER_NAME}.log"
    reconfigureFailed="reconfigure-${THE_COREPROJECT}-sqa${THE_COREVERSION}.${THE_PLATFORM}.${DATABASE_VER_NAME}-FAILED"
    echo "create_ac_db.sh: Looking for file ${buildComplete} or ${reconfigureFailed}" | tee -a $BUILD_LOG

    until [ `expr $elapsedTime \>= $timeToWait` -eq 1 ]
    do
	if [ -f ${GEN_LOGDIR}/${reconfigureFailed} ]
	then
	    echo "create_ac_db.sh: Error: **** ${reconfigureFailed} at `date` - build may have built with yesterdays procedures" | tee -a $BUILD_LOG
	    return
	fi
	if [ -f ${GEN_LOGDIR}/${buildComplete} ]
	then
	    echo "create_ac_db.sh: Found ${buildComplete} at `date`" | tee -a $BUILD_LOG
	    return
	fi
	
	sleep $timeToSleep
	elapsedTime=`expr $elapsedTime + $timeToSleep`
	echo "create_ac_db.sh: elapsed time $elapsedTime, at `date`" | tee -a $BUILD_LOG
    done

    # if we get here, we haven't found either build complete or reconfigure failed flag
    echo "create_ac_db.sh: Error: **** timed out at `date` waiting for $buildComplete" | tee -a $BUILD_LOG
    echo "create_ac_db.sh: END WaitForGenevaBuildToComplete()"
}

echo "create_ac_db.sh: 1000 Checking to see if we need to wait for Geneva"
NeedToWaitForGeneva
if [ $? -eq 1 ]
then
    echo "create_ac_db.sh: waiting for Geneva build to complete" | tee -a $BUILD_LOG
    WaitForGenevaBuildToComplete
fi


echo "create_ac_db.sh: 2000 Checking to see if the project is not PFCORE"
if [ "$THE_PROJECT" != "PFCORE" ]
then
    echo "create_ac_db.sh: 2001 Calling createInstallFileList3" | tee -a $BUILD_LOG
    createInstallFileList3

    cmd="build_project_svn -s sqa -m ${GENEVA_MAJOR} -r ${THE_COREVERSION}.${THE_PLATFORM}.${DATABASE_VER_NAME} -o ${DATABASE_VER_NAME} -t dbuser -d ${DAT} -p ${THE_COREPROJECT} -u ${THE_DB_USER}@${THE_DB} -A 3 -L"

    echo "create_ac_db.sh: 2002 cmd = ${cmd}"
    echo $cmd >> $BUILD_LOG 2>&1
    $cmd >> $BUILD_LOG 2>&1

    pwd >> $BUILD_LOG 2>&1

    echo "create_ac_db.sh: 2003 pre ls ..."
    ls -la ${GENEVA_ROOT}/${THE_COREPROJECT}/sql/all_public_package_spc.sql
    echo "create_ac_db.sh: 2004 ... post ls"
fi
    
echo "create_ac_db.sh: RELEASE_DIR = ${RELEASE_DIR}" >> $BUILD_LOG 2>&1
echo "create_ac_db.sh: GENEVA_ROOT = ${GENEVA_ROOT}" >> $BUILD_LOG 2>&1

echo "create_ac_db.sh: 3000 Checking to see if procedure load needs to be done"
if test ! -s ${GENEVA_ROOT}/${THE_COREPROJECT}/sql/all_public_package_spc.sql
then
    echo "create_ac_db.sh: 3100 Loading procedures"
    if [ -d ${RELEASE_DIR}/schema/procedures ]
    then
	PROCEDURES_DIR=${RELEASE_DIR}/schema/procedures
    elif [ -d ${RELEASE_DIR}/RB/RB/schema/procedures ]
    then
	PROCEDURES_DIR=${RELEASE_DIR}/RB/RB/schema/procedures
    else
	echo "create_ac_db.sh: **** Cannot find procedures directory in ${RELEASE_DIR}"
    fi
    echo "create_ac_db.sh: Loading procedures from RELEASE_DIR  ${PROCEDURES_DIR}" | tee -a $BUILD_LOG
    ls -la ${PROCEDURES_DIR}  >> $BUILD_LOG 2>&1
    cd ${PROCEDURES_DIR}

    sqlplus -s $DATABASE >> $BUILD_LOG 2>&1 << +ENDSQL
    @all_public_package_spc.sql
    @all_private_package_spc.plb
    @all_public_standalone_procs.sql
    @all_private_standalone_procs.plb
    @all_public_package_bdy.sql
    @all_private_package_bdy.plb
    exit
+ENDSQL
    echo "create_ac_db.sh: 3200 Completed procedure load"
fi

if [ "$THE_PROJECT" = "PFCORE" ]; then
    cd ${GENEVA_ROOT}/${THE_COREPROJECT}/sql
    sqlplus -s $DATABASE >> $BUILD_LOG 2>&1 << +ENDSQL
    @all_public_package_spc.sql
    @all_private_package_spc.plb
    @all_public_standalone_procs.sql
    @all_private_standalone_procs.plb
    @all_public_package_bdy.sql
    @all_private_package_bdy.plb
    exit
+ENDSQL
fi

#Disable Platform triggers before installation of Extension schema
echo "Disabling triggers against ${DATABASE}" >> ${BUILD_LOG}

if [ ${THE_COREPROJECT} = "RB" ]
then
	if [ ${THE_PROJECT} = "TAP3" -o ${THE_PROJECT} = "SPD" -o ${THE_PROJECT} = "VI" ]
	then
		cdSchemaInstall
		cd ../migration/scripts
		pwd >> ${BUILD_LOG} 2>&1
		sqlplus -s ${DATABASE} >> ${BUILD_LOG} 2>&1 << +ENDSQL
		whenever sqlerror exit failure
		@fixalltriggers.sql DISABLE
		exit
+ENDSQL
	fi
fi

echo "create_ac_db.sh: 4000 Checking to see if project is TAP3/SPD/GVI/GII/GNI/NML ..."
if [ $THE_PROJECT = TAP3 ]; then
        echo "create_ac_db.sh: 4050 Project is TAP3"
        echo "create_ac_db.sh: 4100 Executing cdSchemaInstall"
	cdSchemaInstall

        echo "create_ac_db.sh: 4200 Executing clearMigrationProcess ..."
	clearMigrationProcess
        echo "create_ac_db.sh: 4201 ... done executing clearMigrationProcess"
	
#	sqlplus -s $DATABASE >> $BUILD_LOG 2>&1 << +ENDSQL
#	whenever sqlerror exit failure
#	@migrationprocess.sql
#	exit
#+ENDSQL	

#	echo "create_ac_db.sh: Dodgily Setting the db version no" >> $BUILD_LOG 2>&1

#	sqlplus -s $DATABASE >> $BUILD_LOG 2>&1 << +ENDSQL
#update version_geneva_5_2 set letter='G';
#exit;
#+ENDSQL

	echo "create_ac_db.sh: 4300 About to run the TAP Schema Install ..." >> $BUILD_LOG 2>&1

	install.sh ../SRC/install_filelist_1_for_build.txt >> $BUILD_LOG 2>&1
	echo "create_ac_db.sh: 4301 ... done running the TAP Schema Install" >> $BUILD_LOG 2>&1

	if [ -f ${MYCWD}/SCHEMA/SRC/PR57784_changes.sql ]
              then
                      echo "Start: Loading PR57784_changes.sql" >> $BUILD_LOG 2>&1
                      sqlplus -s ${DATABASE} >> $BUILD_LOG 2>&1 << +ENDSQL
                      @${MYCWD}/SCHEMA/SRC/PR57784_changes.sql >> $BUILD_LOG 2>&1
                      exit
+ENDSQL
                      echo "End: Loading PR57784_changes.sql" >> $BUILD_LOG 2>&1
        fi

        if [ -f ${MYCWD}/SCHEMA/SRC/PR55184_schema_changes.sql ]
              then
                      echo "Start: Loading PR55184_schema_changes.sql" >> $BUILD_LOG 2>&1
                      sqlplus -s ${DATABASE} >> $BUILD_LOG 2>&1 << +ENDSQL
                      @${MYCWD}/SCHEMA/SRC/PR55184_schema_changes.sql >> $BUILD_LOG 2>&1
                      exit
+ENDSQL
                      echo "End: Loading PR55184_schema_changes.sql" >> $BUILD_LOG 2>&1
        fi
        if [ -f ${MYCWD}/SCHEMA/SRC/PR59871_schema_changes_for_build.sql ]
              then
                      echo "Start: Loading PR59871_schema_changes_for_build.sql" >> $BUILD_LOG 2>&1
                      sqlplus -s ${DATABASE} >> $BUILD_LOG 2>&1 << +ENDSQL
                      @${MYCWD}/SCHEMA/SRC/PR59871_schema_changes_for_build.sql >> $BUILD_LOG 2>&1
                      exit
+ENDSQL
                      echo "End: Loading PR59871_schema_changes_for_build.sql" >> $BUILD_LOG 2>&1
        fi


        if [ -f ${MYCWD}/SCHEMA/SRC/PR85234_schema_changes.sql ]
              then
                      echo "Start: Loading PR85234_schema_changes.sql" >> $BUILD_LOG 2>&1
                      sqlplus -s ${DATABASE} >> $BUILD_LOG 2>&1 << +ENDSQL
                      @${MYCWD}/SCHEMA/SRC/PR85234_schema_changes.sql >> $BUILD_LOG 2>&1
                      exit
+ENDSQL
                      echo "End: Loading PR85234_schema_changes.sql" >> $BUILD_LOG 2>&1
        fi

        if [ -f ${MYCWD}/SCHEMA/SRC/CR80569_changes.sql ]
              then
                      echo "Start: Loading CR80569_changes.sql" >> $BUILD_LOG 2>&1
                      sqlplus -s ${DATABASE} >> $BUILD_LOG 2>&1 << +ENDSQL
                      @${MYCWD}/SCHEMA/SRC/CR80569_changes.sql >> $BUILD_LOG 2>&1
                      exit
+ENDSQL
                      echo "End: Loading CR80569_changes.sql" >> $BUILD_LOG 2>&1
        fi

	if [ -f ${MYCWD}/SCHEMA/SRC/CR89707_schema_changes.sql ]
              then
                      echo "Start: Loading CR89707_schema_changes.sql" >> $BUILD_LOG 2>&1
                      sqlplus -s ${DATABASE} >> $BUILD_LOG 2>&1 << +ENDSQL
                      @${MYCWD}/SCHEMA/SRC/CR89707_schema_changes.sql >> $BUILD_LOG 2>&1
                      exit
+ENDSQL
                      echo "End: Loading CR89707_schema_changes.sql" >> $BUILD_LOG 2>&1
        fi


        if [ -f ${MYCWD}/SCHEMA/SRC/61383_schema_changes.sql ]
              then
                      echo "Start: Loading 61383_schema_changes.sql " >> $BUILD_LOG 2>&1
                      sqlplus -s ${DATABASE} >> $BUILD_LOG 2>&1 << +ENDSQL
                      @${MYCWD}/SCHEMA/SRC/61383_schema_changes.sql >> $BUILD_LOG 2>&1
                      exit
+ENDSQL
                      echo "End: Loading 61383_schema_changes.sql " >> $BUILD_LOG 2>&1
        fi

        if [ -f ${MYCWD}/SCHEMA/SRC/62378_schema_changes.sql ]
              then
                      echo "Start: Loading 62378_schema_changes.sql " >> $BUILD_LOG 2>&1
                      sqlplus -s ${DATABASE} >> $BUILD_LOG 2>&1 << +ENDSQL
                      @${MYCWD}/SCHEMA/SRC/62378_schema_changes.sql >> $BUILD_LOG 2>&1
                      exit
+ENDSQL
                      echo "End: Loading 62378_schema_changes.sql " >> $BUILD_LOG 2>&1
        fi

elif [ $THE_PROJECT = SPD ]; then
        echo "create_ac_db.sh: 4350 Project is SPD"
        echo "create_ac_db.sh: 4400 Executing createSpdInstallFileList3"
	createSpdInstallFileList3
        echo "create_ac_db.sh: 4500 Executing cdSchemaInstall"
	cdSchemaInstall
        echo "create_ac_db.sh: 4600 Executing clearMigrationProcess"
	clearMigrationProcess
	install.sh ../SRC/install_filelist_3_for_build.txt >> $BUILD_LOG 2>&1

        echo "create_ac_db.sh: 4700 About to execute spd package build"
	sqlplus -s $DATABASE << +ENDSQL3
	whenever sqlerror exit failure
	@${CCM_ROOT}/../${PROJ}/${THE_PROJECT}/SCHEMA/procedures/gnvspdconfig.spc
	@${CCM_ROOT}/../${PROJ}/${THE_PROJECT}/SCHEMA/procedures/gnvspdgen.spc
	@${CCM_ROOT}/../${PROJ}/${THE_PROJECT}/SCHEMA/procedures/ddddelete.plb
	@${CCM_ROOT}/../${PROJ}/${THE_PROJECT}/SCHEMA/procedures/gnvspdconfig.plb
	@${CCM_ROOT}/../${PROJ}/${THE_PROJECT}/SCHEMA/procedures/gnvspdgen.plb
	commit;
	exit
+ENDSQL3
        echo "create_ac_db.sh: 4701 Done executing spd package build"
	
elif [ $THE_PROJECT = GVI -o $THE_PROJECT = VI ]; then
        echo "create_ac_db.sh: 4750 Project is GVI/VI"
	echo "create_ac_db.sh: 4800 Executing cdSchemaInstall"
	cdSchemaInstall

	STAGE_ROOT=${CCM_ROOT}/../${PROJ}/${THE_PROJECT}/SCHEMA/install
	if [ ! -d $STAGE_ROOT/LOGS/VI ]
	then
		mkdir -p $STAGE_ROOT/LOGS/VI
	fi
	echo "Output will go to ${STAGE_ROOT}"
	export STAGE_ROOT
	install.sh >> $BUILD_LOG 2>&1

elif [ $THE_PROJECT = GII ]; then
        echo "create_ac_db.sh: 4850 Project is GII"
	echo "create_ac_db.sh: 4900 Executing cdSchemaInstall"
	cdSchemaInstall

# A Bodge
	PATH=$PATH:$BCE_ROOT/build/geneva/${GENEVA_MAJOR}/GENEVA-sqa${THE_COREVERSION}.${THE_PLATFORM}.${DATABASE_VER_NAME}/GENEVA/ALLBATCH/bin
	export PATH

	echo y | install.sh >> $BUILD_LOG 2>&1

elif [ $THE_PROJECT = GNI ]; then
	cdSchemaInstall

	install.sh ../SRC/install_filelist_1_for_build.txt >> $BUILD_LOG 2>&1

########
# old code, could be needed to build TAP 2.1 or similar
#if [ $THE_PROJECT = TAP3 ]; then
#
#	cd ${CCM_ROOT}/../${PROJ}/${THE_PROJECT}/SCHEMA/SRC >> $BUILD_LOG 2>&1
#
#sqlplus -s $DATABASE >> $BUILD_LOG 2>&1 << +ENDSQL
#@tables.sql
#DATA
#DATA
#DATA
#DATA
#DATA
#@indexes.sql
#DATA
#DATA
#DATA
#DATA
#DATA
#@views.sql
#@triggers.sql
#exit
#+ENDSQL
#
#	no_errors=`grep ERROR $BUILD_LOG | wc -l`
#	echo "create_ac_db.sh: There were $no_errors errors loading the database" >> $BUILD_LOG 2>&1
#elif [ $THE_PROJECT = SPD ]; then
#        cd ${CCM_ROOT}/../${PROJ}/${THE_PROJECT}/SCHEMA/SRC >> $BUILD_LOG 2>&1
#
#sqlplus -s $DATABASE >> $BUILD_LOG 2>&1 << +ENDSQL
#@schema_params.sql
#@table.sql
#DATA
#DATA
#DATA
#@indexes.sql
#DATA
#DATA
#DATA
#@views.sql
#@../synonyms/tablesyn.sql
#@../synonyms/viewsyn.sql
#exit
#+ENDSQL
#
#        no_errors=`grep ERROR $BUILD_LOG | wc -l`
#        echo "create_ac_db.sh: There were $no_errors errors loading the database" >> $BUILD_LOG 2>&1
elif [ $THE_PROJECT = NML ]; then
        echo "create_ac_db.sh: 5050 Project is NML"
	echo "create_ac_db.sh: 5100 Executing cdSchemaInstall"

	cdSchemaInstall
	echo "create_ac_db.sh: 5200 Executing clearMigrationProcess"
	clearMigrationProcess

	# At 2.2, we added a filelist
	if [ -f ../SRC/install_filelist_1_for_build.txt ]
	then
	    echo "create_ac_db.sh: 5300 Installing NML schema using filelist" | tee -a $BUILD_LOG 2>&1
	    install.sh  ../SRC/install_filelist_1_for_build.txt >> $BUILD_LOG 2>&1
	else	
	    echo "create_ac_db.sh: 5400 Installing NML schema old style" | tee -a $BUILD_LOG 2>&1
	    
	    pwd >> $BUILD_LOG 2>&1

	    echo "create_ac_db.sh: 5500 about to use pl/sql for build ..."
	    sqlplus -s $DATABASE >> $BUILD_LOG 2>&1 << +ENDSQL
	    @scripts/schema_params.sql
	    @scripts/table.sql
	    @scripts/index.sql
	    @scripts/view.sql
	    @../synonyms/allsyn.sql
	    exit
+ENDSQL
	    echo "create_ac_db.sh: 5600 Done with pl/sql"
	fi

	no_errors=`grep ERROR $BUILD_LOG | wc -l`
	echo "create_ac_db.sh: 5700 There were $no_errors errors loading the database" >> $BUILD_LOG 2>&1
	
elif [ $THE_PROJECT = GPI ]; then
        echo "create_ac_db.sh: 5750 Project is GPI/PI"
	pwd >> $BUILD_LOG 2>&1

	CCM_ROOT="${CCM_ROOT}/../${PROJ}/${THE_PROJECT}"
	LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${CCM_ROOT}/prod/lib
	SHLIB_PATH=$LD_LIBRARY_PATH:${CCM_ROOT}/prod/lib
	cd ${CCM_ROOT}/cmd/db1/install >> $BUILD_LOG 2>&1

	echo "create_ac_db.sh: 5800 Calling installGPI.sh"
	installGPI.sh install_gpi_filelist.txt >> $BUILD_LOG 2>&1
	echo "create_ac_db.sh: 5900 installGPI.sh done"

	echo "create_ac_db.sh: 6000 Info: $0: Installation of GPI/PI DB Complete, please check logs for errors" >> $BUILD_LOG 2>&1
	echo "create_ac_db.sh: 6001 Info: $0: Installation of GPI/PI DB Complete, please check logs for errors"
else		# Generic Database
        echo "create_ac_db.sh: 6050 Project is other"
	echo
	echo "create_ac_db.sh: Creating generic Geneva Database"
	echo
fi

#Enable Platform triggers before installation of Extension schema
echo "Enabling triggers against ${DATABASE}" >> ${BUILD_LOG}
if [ ${THE_COREPROJECT} = "RB" ]
then
	if [ ${THE_PROJECT} = "TAP3" -o ${THE_PROJECT} = "SPD" -o ${THE_PROJECT} = "VI" ]
	then
		cdSchemaInstall
		cd ../migration/scripts
		pwd >> ${BUILD_LOG} 2>&1
		sqlplus -s ${DATABASE} >> ${BUILD_LOG} 2>&1 << +ENDSQL
		whenever sqlerror exit failure
		@fixalltriggers.sql ENABLE
		exit
+ENDSQL
	fi
fi

echo "create_ac_db.sh: 7000 Calling renameVersionGeneva ..."
renameVersionGeneva >>  $BUILD_LOG 2>&1
echo "create_ac_db.sh: 7100 ... done calling renameVersionGeneva"

echo "create_ac_db.sh: SCRIPT END"
exit $no_errors
