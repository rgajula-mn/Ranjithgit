#!/bin/ksh

if [ $# -ne 7 ]; then
  echo "$0 <state> <solution version> <core reltag> <database> <oracle version> <steve version> <project>"
  echo "e.g. $0 sqa 4.3.6 GEN_5.4.22 COB3 10.2.0.SE 1 GPI"
  exit 1
fi

. $BCE_BUILD_SCRIPTS/set_ac_paths.sh $1 $2 $3 $4 $5 $6 $7

export BUILD_LOG=${LOGDIR}/make_core_${THE_PLATFORM}_${THE_STATE}_${THE_VERSION}_${THE_COREVERSION}_${DATABASE_VER_NAME}_${DATTIM}.log
echo "The build log is located at ${BUILD_LOG}"


echo "PROJ            =" $PROJ        > $BUILD_LOG 2>&1
echo "DATABASE        =" $DATABASE    | tee -a $BUILD_LOG 2>&1
echo "CCM_ROOT        =" $CCM_ROOT    | tee -a $BUILD_LOG 2>&1
echo "CORE            =" $CORE        | tee -a $BUILD_LOG 2>&1
echo "OUTPUT_ROOT     =" $OUTPUT_ROOT | tee -a $BUILD_LOG 2>&1
echo "TOOL            =" $TOOL        >> $BUILD_LOG 2>&1
echo "STEVE           =" $STEVE       >> $BUILD_LOG 2>&1

echo "" >> $BUILD_LOG 2>&1

echo "ORACLE_VERSION  = $ORACLE_VERSION"   | tee -a $BUILD_LOG 2>&1
echo "ORACLE_HOME     = $ORACLE_HOME"      | tee -a $BUILD_LOG 2>&1
echo "OPT_BUILD       = $OPT_BUILD"        | tee -a $BUILD_LOG 2>&1
echo "LD_LIBRARY_PATH = $LD_LIBRARY_PATH"  | tee -a $BUILD_LOG 2>&1
echo "SOLARIS_USE_GNU = $SOLARIS_USE_GNU"  | tee -a $BUILD_LOG 2>&1
echo "MAJORRELEASE    = $MAJORRELEASE"     | tee -a $BUILD_LOG 2>&1 
echo "IS_5_3_OR_LATER = $IS_5_3_OR_LATER"     | tee -a $BUILD_LOG 2>&1
echo "IS_5_4_OR_LATER = $IS_5_4_OR_LATER"     | tee -a $BUILD_LOG 2>&1
echo "PFCORE          = $PFCORE"              | tee -a $BUILD_LOG 2>&1


export DEBUG=""

echo ENV >> $BUILD_LOG 2>&1
env >> $BUILD_LOG 2>&1


# loadMessages - load messages from current directory
loadMessages()
{
    messName=$1

    echo "***** Loading $messName messages" >> $BUILD_LOG 2>&1
    echo "" >> $BUILD_LOG 2>&1

    if [ "$IS_3_0_OR_LATER" = "1" -o "$IS_5_4_OR_LATER" = "1" ]
    then
	    for i in *.mess
	    do
		    echo $i >> $BUILD_LOG 2>&1
		    $MESSC/bin/PFmessc -d $DATABASE $i >> $BUILD_LOG 2>&1
	    done
    else
	    for i in *.mess
	    do
		    echo $i >> $BUILD_LOG 2>&1
		    $MESSC/bin/GMmessc -d $DATABASE $i >> $BUILD_LOG 2>&1
	    done
    fi
}

# buildCore - build CORE or VPACORE and load the messages
buildCore()
{
    whichCore=$1                         # full pathname
    coreName=`basename $whichCore`       # CORE or VPACORE

    echo "***** Build $coreName *****"  | tee -a $BUILD_LOG 2>&1

    export CCM_ROOT=`dirname $whichCore`
    echo "CCM_ROOT        =" $CCM_ROOT | tee -a $BUILD_LOG 2>&1
    echo "OUTPUT_ROOT     =" $OUTPUT_ROOT  | tee -a $BUILD_LOG 2>&1


    if [ ! -d $whichCore ]
    then
	echo "Error *** cannot find $whichCore" | tee -a $BUILD_LOG 2>&1
    fi

    cd $whichCore >> $BUILD_LOG 2>&1

    $MAKE_CMD -k clean >> $BUILD_LOG 2>&1
    $MAKE_CMD -k base >> $BUILD_LOG 2>&1

    # The messages to be loaded are either in the include or the mess directories
    if [ -d $whichCore/mess ]
    then
        cd ${whichCore}/mess >> $BUILD_LOG 2>&1
    else
        cd ${whichCore}/include >> $BUILD_LOG 2>&1
    fi

    loadMessages $coreName
}    


if [ $IS_5_4_OR_LATER -eq 1 ]         # just load the messages from Platform
then
    cd ${PF_HOME}/etc/messages
    loadMessages Platform
fi
buildCore $CORE
if [ $IS_5_3_OR_LATER -eq 1 ]
then
    buildCore $VPACORE
fi

## note from building 5.4 onwards I dont set OUTPUT_ROOT or CORE_OUTPUT_ROOT


echo "Now you must run:"
echo "build_ac.sh $1 $2 $3 $4 $5 $6 $7"
echo ""

echo "Subject: Build Core Results $PROJ" > ${LOGDIR}/build.tmp
echo "To: PDM.Geneva.BCE.Build.Log@Convergys.com" >> ${LOGDIR}/build.tmp
cat ${BUILD_LOG} >> ${LOGDIR}/build.tmp

cat ${LOGDIR}/build.tmp | /usr/lib/sendmail -F "${PROJ}" `cat ${BCE_ADMIN}/email/${SMALL_PROJECT}_build_managers`

exit
