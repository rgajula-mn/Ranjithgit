#!/bin/sh
#
#  Script:		web_functions.sh
#  Instance:		1
#  Author:		sfp
#  Start date:		01/09/2003
#  Version:		%full_filespec: 
#
#  Description:		
#
#
# (C) Convergys, 2002.                                          
# Convergys refers to Convergys Corporation or any of its wholly owned
# subsidiaries. 

getBuildArgs()
{
    case ${1} in
	GNVMERCAPI|GENEVAAPI)
	    case "${2}" in
		5.4|5.4TS)
		    case ${3} in
			cov)
			    makeArgs="+release +coverage";
			    clean="realClean";
			    build="+coverageReport";
			    results="build_debug_coverage/tmp/testresults";
			    jarloc="build_debug_coverage/tmp/jar";;
			dev|test|sqa|contd|conts)
			    makeArgs="+release";
			    clean="realClean";
			    build="distrib";
			    results="build_release_all/tmp/testresults";
			    jarloc="build_release_all/distrib/external/ear";;
			*)
			    echo "Project type not found";;
		    esac;;

		5.2|5.3)
		    case ${3} in
			cov)
			    makeArgs="+eca +release +coverage";
			    clean="realClean";
			    build="+coverageReport";
			    results="build_debug_coverage/tmp/testresults";
			    jarloc="build_debug_coverage/tmp/jar";;
			dev|contd|test)
			    makeArgs="+eca";
			    clean="realClean";
			    build="";
			    results="build_debug_eca/tmp/testresults";
			    jarloc="build_debug_eca/tmp/jar";;
			sqa|conts)
			    makeArgs="+release +eca";
			    clean="realClean";
			    build="distrib";
			    results="build_release_eca/tmp/testresults";
			    jarloc="build_release_eca/distrib/external/jar";;
			*)
			    echo "Project type not found";;
		    esac;;
		*)
		    echo "Major release is not recongnised. Please configure the web_functions.sh";;
	    esac;;

	RBAPI)
	    case "${2}" in
		3.*|4.*|5.*|6.*|7.*|8.*|9.*)
		    case ${4} in
			3.0.3.c2|3.0.4)
		            case ${3} in
    			        cov)
			            makeArgs="+release +coverage";
			            clean="realClean";
		    	            build="+coverageReport";
			            results="build_debug_coverage/tmp/testresults";
			            jarloc="build_debug_coverage/tmp/jar";;
			        dev|test|sqa|contd|conts)
			            makeArgs="+release";
			            clean="realClean";
			            build="distrib";
		    	            results="build_release_all/tmp/testresults";
			            jarloc="build_release_all/distrib/internal/ear";;
			        *)
		    	            echo "Project type not found";;
		            esac;;
			*)
		            case ${3} in
			        test|sqa|conts)
			            makeArgs="+release";
			            clean="+clean";
			            build="distrib";
		    	            results="build_output/testresults";
			            jarloc="build_output/distrib/internal";;
			        dev|contd)
			            makeArgs="";
			            clean="+clean";
			            build="distrib";
		    	            results="build_output/testresults";
			            jarloc="build_output/distrib/internal";;
			        *)
		    	            echo "Project type not found";;
		            esac;;
		    esac;;
		*)
		    echo "Major release is not recongnised. Please configure the web_functions.sh";;
	    esac;;

	PCMIAPI)
		case "${2}" in
		  1.*)
		    case ${4} in
			*)
			  case ${3} in
				sqa)
				  #makeArgs="ecapcmi";
                                    makeArgs="+release";
                                    clean="+clean";
                                    build="all";
                                    results="build_output/testresults";
                                    jarloc="build_output/distrib/internal";;
			  esac;;
		  esac;;
		esac;;

	PCMI)
		case "${2}" in
		  1.*)
		    case ${4} in
			*)
			  case ${3} in
				sqa)
				  #makeArgs="ecapcmi";
                                    makeArgs="+release";
                                    clean="+clean";
                                    build="all";
                                    results="build_output/testresults";
                                    jarloc="build_output/distrib/internal";;
			  esac;;
		  esac;;
		esac;;

	CSA)
	    case ${state} in
		dev|test|contd)
		    clean="realClean";
		    build="";;
		sqa|conts)
		    clean="+release realClean";
		    build="+release distrib";;
		*)
		    echo "Project type not found";;
	    esac
		;;
	*) 
	    echo "Project type not found";;
    esac
}

getWebserverArgs()
{

# need to create an name for the projects location, which will be passed to the script

    case ${1} in

	weblogic)
	    wshome="/Disk1/bea";
	    domainHome="${wshome}/user_projects/"${2}"";
	    rtestArgs="+testWL70 eca";
	    if [ "$3" = "5.4TS" -o "$3" = "5.4" ]
	    then
	    	rtestArgs="+testWL70 all";
	    fi
	    startWS="startWebLogic.sh";
	    error="no";
	    stopServer="bea";
	    deployLoc=""${wshome}"/jarDeploy";;

	# Service pack 1 & 3 has been disabled at the request of ECA team
	# we now only support the latest version of Weblogic. However, sp1 & 3
	# have been left in the event that we need to replicate customer issues
    	    
	#weblogic_8_1)
	#    wshome="/Disk1/bea_811";
	#    domainHome="${wshome}/user_projects/domains/"${2}"";
	#    rtestArgs="+testWL81 eca";
    	#    startWS="startWebLogic.sh";
	#    error="no";
	#    stopServer="bea_811";
	#    deployLoc=""${wshome}"/jarDeploy";;
	
	weblogic_8_1)
	    wshome="/Disk1/bea_814";
	    domainHome="${wshome}/user_projects/domains/"${2}"";
	    #rtestArgs="+testWL81 eca";
	    rtestArgs="+testWL81 eca";
	    if [ "$3" = "5.4TS" -o "$3" = "5.4" ]
	    then
	    	rtestArgs="+testWL81 all";
	    fi
    	    startWS="startWebLogic.sh";
	    error="no";
	    stopServer="stopWebLogic.sh";
	    deployLoc=""${wshome}"/jarDeploy";;

	weblogic_9_1)

		if [ `hostname` = "snowbell" ]
		then
			#wshome="/Disk0/Weblogic_910";
			wshome="/Disk0/weblogic_9.1/weblogic91";
			domainHome="${wshome}/user_projects/domains/"${2}"";
			rtestArgs="+testWL91 all";
			case $3 in
			3.0|3.1|3.2|4.*|5.*)
				if [ "$4" != "3.0.3.c2" -a "$4" != "3.0.4" ]
				then
					rtestArgs="test_wl91 onereport";
					fi
				;;
			esac
			#rtestArgs="+testWL91 eca";
			#rtestArgs="+testWL91 **/config/TestReadAllCountryData*";
			startWS="startWebLogic.sh";
			error="no";
			stopServer="stopWebLogic.sh";
			deployLoc=""${domainHome}"/servers/AdminServer/upload";
			if [ ! -d ${deployLoc} ]
			then
				mkdir -p ${deployLoc};
			fi
		else
			wshome="/Disk1/bea_910";
			domainHome="${wshome}/user_projects/domains/"${2}"";
			#rtestArgs="+testWL81 eca";
			rtestArgs="+testWL81 eca";
			if [ "$3" = "5.4TS" -o "$3" = "5.4" ]
			then
				rtestArgs="+testWL81 all";
			fi
			startWS="startWebLogic.sh";
			error="no";
			stopServer="stopWebLogic.sh";
			deployLoc=""${wshome}"/jarDeploy";
		fi
		;;
	weblogic_10_0)

		if [ `hostname` = "snowbell" ]
		then
			#wshome="/Disk0/Weblogic_10.1";
			wshome="/Disk1/weblogic_10.1";
			domainHome="${wshome}/user_projects/domains/"${2}"";
			case $3 in
			3.0|3.1|3.2|4.*|5.*)
				rtestArgs="test_wl10 onereport";
				;;
			esac
			startWS="startWebLogic.sh";
			error="no";
			stopServer="stopWebLogic.sh";
			deployLoc=""${domainHome}"/servers/AdminServer/upload";
			if [ ! -d ${deployLoc} ]
			then
				mkdir -p ${deployLoc};
			fi
		fi
                if [ `hostname` = "alder" ]
                then
                        wshome="/Disk0/weblogic_10.1";
                        domainHome="${wshome}/user_projects/domains/"${2}"";
                        case $3 in
                        3.0|3.1|3.2|4.*|5.*|6.*|7.*)
                                rtestArgs="test_wl10 onereport";
                                ;;
                        esac
                        startWS="startWebLogic.sh";
                        error="no";
                        stopServer="stopWebLogic.sh";
                        deployLoc=""${domainHome}"/servers/AdminServer/upload";
                        if [ ! -d ${deployLoc} ]
                        then
                                mkdir -p ${deployLoc};
                        fi
                fi
		;;
	 weblogic_10_3)
                if [ `hostname` = "alder" ]
                then
                        wshome="/Disk0/weblogic_10.1/weblogic-10.3.6";
                        domainHome="${wshome}/user_projects/domains/"${2}"";
                        case $3 in
                        8.*)
                                rtestArgs="test_wl10 onereport";
                                ;;
                        esac
                        startWS="startWebLogic.sh";
                        error="no";
                        stopServer="stopWebLogic.sh";
                        deployLoc=""${domainHome}"/servers/AdminServer/upload";
                        if [ ! -d ${deployLoc} ]
                        then
                                mkdir -p ${deployLoc};
                        fi
                fi

		;;
	 weblogic_12_1)
                if [ `hostname` = "camvldev02" ]
                then
                        wshome="/Disk1/app/weblogic/weblogic_12130/wlserver";
                        domainHome="${wshome}/user_projects/domains/"${2}"";
                        case $3 in
                        8.*|9.*)
                                rtestArgs="test_wl12 onereport";
                                ;;
                        esac
                        startWS="startWebLogic.sh";
                        error="no";
                        stopServer="stopWebLogic.sh";
                        deployLoc=""${domainHome}"/servers/AdminServer/upload";
                        if [ ! -d ${deployLoc} ]
                        then
                                mkdir -p ${deployLoc};
                        fi
                fi

		;;

	
	#weblogic_8_1_3)
	#    wshome="/Disk1/bea_813";
	#    domainHome="${wshome}/user_projects/domains/"${2}"";
	#    rtestArgs="+testWL81 eca";
    	#    startWS="startWebLogic.sh";
	#    error="no";
	#    stopServer="stopWebLogic.sh";
	#    deployLoc=""${wshome}"/jarDeploy";;

	#weblogic_8_1_4)
	#    wshome="/Disk1/bea_814";
	#    domainHome="${wshome}/user_projects/domains/"${2}"";
	#    rtestArgs="+testWL81 eca";
    	#    startWS="startWebLogic.sh";
	#    error="no";
	#    stopServer="stopWebLogic.sh";
	#    deployLoc=""${wshome}"/jarDeploy";;

	    # configFile variable added only for jboss_30 and jboss_32 webservers. These are required
	    # so that we can switch the webserver from 5.3 to 5.4. The configuration file contains info
	    # relating to the connection methods and database username/password.

	jboss_3_0)
	    wshome="/Disk1/jboss_30/JB";
	    domainHome="${wshome}/bin";
	    #rtestArgs="+testJB30 eca";
	    rtestArgs="+testJB30 eca";
	    if [ "$3" = "5.4TS" -o "$3" = "5.4" ]
	    then
	    	rtestArgs="+testJB30 all";
	    fi
	    startWS="urun.sh";
	    error="no";
	    stopServer="shutdown.sh -S";
	    configFile="${wshome}/"${2}"/geneva-db-service.xml";
	    configDeploy="${wshome}/server/default/deploy";
	    deployLoc="${wshome}/server/default/deploy";;
	
	jboss_3_2)
	    wshome="/Disk1/jboss_32/JB";
	    domainHome="${wshome}/bin";
	    #rtestArgs="+testJB32 eca";
	    rtestArgs="+testJB32 eca";
	    if [ "$3" = "5.4TS" -o "$3" = "5.4" ]
	    then
	    	rtestArgs="+testJB32 all";
	    fi
	    startWS="urun.sh";
	    error="no";
	    stopServer="shutdown.sh -S";
	    configFile="${wshome}/"${2}"/oracle-ds.xml";
    	    configDeploy="${wshome}/server/default/deploy";
	    deployLoc=""${wshome}"/server/default/deploy";;

	jboss_4_0)
	    wshome="/Disk0/jboss-4.0.2";
	    domainHome="${wshome}/bin";
	    rtestArgs="+testJB40 all";
	    #rtestArgs="+testJB40 eca";
		case $3 in
		3.0|3.1|3.2|4.*|5.*)
	      		if [ "$4" != "3.0.3.c2" -a "$4" != "3.0.4" ]
	      		then
				rtestArgs="test_jb40 onereport";
	      		fi
			;;
		esac
	    startWS="urun.sh";
	    error="no";
	    stopServer="shutdown.sh -S";
	    configFile="${wshome}/"${2}"/oracle-ds.xml";
    	    configDeploy="${wshome}/server/default/deploy";
	    deployLoc=""${wshome}"/server/default/deploy";;

	jboss_4_2)
	    wshome="/tools/jboss-4.2.2.BCE_ONLY-${3}";
	    domainHome="${wshome}/bin";
	    rtestArgs="+testJB42 all";
	    #rtestArgs="+testJB42 eca";
		case $3 in
		3.0|3.1|3.2|4.*|5.*)
			rtestArgs="test_jb42 onereport";
	    		;;
		esac
	    startWS="urun.sh";
	    error="no";
	    stopServer="shutdown.sh -S";
	    configFile="${wshome}/"${2}"/oracle-ds.xml";
    	    configDeploy="${wshome}/server/default/deploy";
	    deployLoc=""${wshome}"/server/default/deploy";;
	    
	jboss_4_3)
	    wshome="/tools/jboss-4.3.BCE_ONLY-${3}";
	    domainHome="${wshome}/bin";
	    rtestArgs="+testJB43 all";
		case $3 in
		3.0|3.1|3.2|4.*|5.*)
			rtestArgs="test_jb43 onereport";
	    		;;
		esac
	    startWS="urun.sh";
	    error="no";
	    stopServer="shutdown.sh -S";
	    configFile="${wshome}/"${2}"/oracle-ds.xml";
    	    configDeploy="${wshome}/server/production/deploy";
	    deployLoc=""${wshome}"/server/production/deploy";;
	    
	jboss_6_1)
	    wshome="/tools/jboss-eap-6.1.0/jboss-eap-6.1";
	    domainHome="${wshome}/bin";
	    rtestArgs="+testJB61 all";
		case $3 in
		8.*|9.*)
			rtestArgs="test_jb61 onereport";
	    		;;
		esac
	    startWS="urun.sh";
	    error="no";
	    stopServer="shutdown.sh -S";
	    configFile="${wshome}/"${2}"/oracle-ds.xml";
    	    configDeploy="${wshome}/server/production/deploy";
	    deployLoc=""${wshome}"/server/production/deploy";;
	    
	    
	websphere_5_1)
	    wshome="/Disk1/WebSphere_51/AppServer";
	    domainHome="${wshome}/bin";
	    #rtestArgs="+testWS51 eca";
	    rtestArgs="+testWS51 eca";
	    if [ "$3" = "5.4TS" -o "$3" = "5.4" ]
	    then
	    	rtestArgs="+testWS51 all";
	    fi
	    startWS="startServer.sh server1 -username system -password system";
            deployWS="wsadmin.sh server1 -username system -password system";
	    error="no";
	    stopServer="stopServer.sh server1 -username system -password system";
	    # main copy location of file, but symlink has been created to the 
	    # proper configuration location in the osprey/celles server location.
	    configFile="${wshome}/"${2}"/resources.xml"
  	    configDeploy="${wshome}/config";
	    reDeployFile="${wshome}/config/redeployJar.jacl";
	    DeployFile="${wshome}/config/deployJar.jacl";
	    deployLoc="${wshome}/jarDeploy";;

	websphere_6_1)
	    wshome="/Disk0/WebSphere_61";
	    domainHome="${wshome}/bin";
	    #rtestArgs="+testWS51 eca";
	    rtestArgs="+testWS61 all";
		case $3 in
		3.0|3.1|3.2|4.*|5.*)
	      		if [ "$4" != "3.0.3.c2" -a "$4" != "3.0.4" ]
	      		then
				rtestArgs="test_ws61 onereport";
	      		fi
			;;
		esac
	    startWS="startServer.sh server1 -profileName AppSrv01 -username system -password pa55word";
 	    deployWS="wsadmin.sh server1 -profileName AppSrv01 -username system -password pa55word";
	    error="no";
	    stopServer="stopServer.sh server1 -profileName AppSrv01 -username system -password pa55word";
	    reDeployFile="${wshome}/config/redeployJar.jacl";
	    DeployFile="${wshome}/config/deployJar.jacl";
	    deployLoc="${wshome}/jarDeploy";;
	*)
	    echo "The webserver ${1} has not been defined";
	    error="yes";;
    esac
    export error
}

dbload() {

    DATABASE=$1
    TARGETFILE=$2
    LOGFILE=$3
    export DATABASE TARGETFILE LOGFILE

    sqlplus -s "${DATABASE}" >> ${LOGFILE} 2>&1 << +ENDSQL
    whenever sqlerror exit 1
    @${TARGETFILE}
    commit;
    exit 0
+ENDSQL
	
    return $?

}



loadStaticData()
{
    CCM_ROOT=$1
    DATABASE=$2
    makeLog=$3
    majorRelease=$4
    release=$5
	project=$6

    SCHEMA_DIR=${CCM_ROOT}/SCHEMA

    export CCM_ROOT SCHEMA_DIR DATABASE makeLog

    cd ${CCM_ROOT}/ECA/schema
    
    echo "Loading static data... for $majorRelease."

	if [ "${project}" = "GNVMERCAPI" -o "${project}" = "GENEVAAPI" -a "${majorRelease}" != "5.4" ]
	then
		echo "Running load_data.sh for non 5.4+ releases"
		echo "Loading: load_data_part1.sql into $DATABASE"
		dbload ${DATABASE} load_data_part1.sql ${makeLog}

		echo "Importing: all_tabs.dmp"
		imp ${DATABASE} GRANTS=N FULL=Y IGNORE=Y FILE=geneva/SAMPLE_DATA/all_tabs.dmp

		if [ "${release}" != "3.0.1" ]
		then
			imp ${DATABASE} GRANTS=N FULL=Y IGNORE=Y FILE=geneva/SAMPLE_DATA/large_tables.dmp
		fi

		cp ${SCHEMA_DIR}/staticdata/all_static.sql ${SCHEMA_DIR}/staticdata/static_data.sql
		chmod +w ${SCHEMA_DIR}/staticdata/static_data.sql
		cat exit.sql >>${SCHEMA_DIR}/staticdata/static_data.sql

		echo "Loading: static_data.sql" 
		dbload ${DATABASE} ${SCHEMA_DIR}/staticdata/static_data.sql ${makeLog}
		rm ${SCHEMA_DIR}/staticdata/static_data.sql

		echo "Loading: sequences.sql"
		dbload ${DATABASE} geneva/SAMPLE_DATA/sequences.sql ${makeLog}

		echo "Loading: load_data_part2.sql"
		dbload ${DATABASE} load_data_part2.sql ${makeLog}

		if [ -f "geneva/SAMPLE_DATA/templates/load_template_data.sql" ]
		then
			echo "Loading: load_template_data.sql"
			ORACLE_DIRNAME=TEMPLATE_XML_DIR_$$
			TEMPLATES_DIR=$CCM_ROOT/ECA/schema/geneva/SAMPLE_DATA/templates
			dbload ${DATABASE} "geneva/SAMPLE_DATA/templates/load_template_data.sql $ORACLE_DIRNAME $TEMPLATES_DIR" ${makeLog}
		fi


		cd ${SCHEMA_DIR}/SRC
		echo "Loading: triggers"
		dbload ${DATABASE} trigger.sql ${makeLog}

		cd ${CCM_ROOT}/ECA/schema/geneva
		echo "Enabling triggers"
		dbload ${DATABASE} "fixalltriggers.sql enable" ${makeLog}

	else

		cwd=`pwd`
		cd ${SCHEMA_DIR}/SRC
		echo "Loading: triggers"
		dbload ${DATABASE} trigger.sql ${makeLog}
		cd $cwd

		echo "Running load_data.sh for ${majorRelease} into $DATABASE"
		APICUSTACC=${CCM_ROOT}/APICUSTACC
		${CCM_ROOT}/ECA/schema/load_data.sh ${DATABASE} T >> ${makeLog}
	fi
}

splitValue()
{
    release=$1
    PRODUCT_MAJOR_VERSION=`echo $release | cut -d '.' -f1`
    PRODUCT_MINOR_VERSION=`echo $release | cut -d '.' -f2`
    PRODUCT_PATCH_VERSION=`echo $release | cut -d '.' -f3-`
    export PRODUCT_MAJOR_VERSION PRODUCT_MINOR_VERSION PRODUCT_PATCH_VERSION
}


