#!/usr/bin/perl -w
###########################################################################
#  Prints a space-separated list of releases that are compatible
# with the given release tag, as fetched from the COMPATIBLERELEASE
# table of the CPT database.
#
# Created:  10/09/2001
# Author:   ajh

use strict;
use DBI;

my $release = shift
  or usage();

die "ORACLE_HOME environment variable not set!\n"
  unless $ENV{'ORACLE_HOME'};

$ENV{'NLS_LANG'} = '';
my $dbh = DBI->connect("dbi:Oracle:",
                       'cpt/cpt@webca.world',
                       '',
                       { RaiseError => 0, PrintError => 0 })
  or die "Unable to connect to database: $DBI::errstr\n";

my $sth = $dbh->prepare("select COMPATIBLE_RELEASE
                         from   COMPATIBLERELEASE
                         connect by prior RELEASE = COMPATIBLE_RELEASE
                         start with RELEASE = ?")
  or die "Unable to prepare SQL statement: $dbh->errstr\n";

$sth->execute($release)
  or die "Unable to execute query: $dbh->errstr\n";

my @compatible_releases = map { $_->[0] } @{$sth->fetchall_arrayref()};
print join ' ', @compatible_releases;
print "\n" if @compatible_releases;

$dbh->disconnect;

###########################################################################
# Print a usage message
#
sub usage {
    print STDERR <<END_USAGE;
Usage: compatibleReleases.pl [RELEASE_TAG]

  Prints a space-separated list of releases that are compatible
with the given release tag, as fetched from the COMPATIBLERELEASE
table of the CPT database.
END_USAGE
    exit(1);
}
