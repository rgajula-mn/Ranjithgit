#!/bin/ksh
set -x
# Include Files
. $BCE_BUILD_SCRIPTS/ccm_functions_svn.sh
. $BCE_BUILD_SCRIPTS/core_functions_svn.sh
. $BCE_BUILD_SCRIPTS/buildweb_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/svn_new.svn

. ~/.bce.ini

# Temp Files
tmp_file=/tmp/auto_manual_builds_1.$$
tmp_file2=/tmp/auto_manual_builds_2.$$
if [ -f "$tmp_file" ]
then
	echo "Error: $tmp_file already exists, exiting"
	exit_program 1
fi

for temp_file in $tmp_file $tmp_file2
do

	touch $temp_file

	if [ $? -ne 0 ]
	then
		echo "Cannot create tmp file $temp_file"
		exit_program 1
	fi
done

# This script is to be used to work out which machines are used for a build and
# to set them off a running.

###########################################################################################
#
#     #######
#     #        #    #  #    #   ####    #####     #     ####   #    #   ####
#     #        #    #  ##   #  #    #     #       #    #    #  ##   #  #
#     #####    #    #  # #  #  #          #       #    #    #  # #  #   ####
#     #        #    #  #  # #  #          #       #    #    #  #  # #       #
#     #        #    #  #   ##  #    #     #       #    #    #  #   ##  #    #
#     #         ####   #    #   ####      #       #     ####   #    #   ####
#
###########################################################################################

usage()
{
	echo " "
	echo "Usage: $0 <-t Release Tag> [-f releases_to_build]"
	echo "  e.g. $0 -t GEN_5.3.46 -f releases_to_build.temp"
	echo " "
	echo "  The releases_to_build file must be in $BCE_ADMIN"
	echo "  Setting -h will display this usage page."
	echo " "
	exit_program 1
}

exit_program ()
{
	rm $tmp_file
	exit $1
}


###########################################################################################
#
#     #    #    ##       #    #    #
#     ##  ##   #  #      #    ##   #
#     # ## #  #    #     #    # #  #
#     #    #  ######     #    #  # #
#     #    #  #    #     #    #   ##
#     #    #  #    #     #    #    #
#
###########################################################################################

# If user sends ctrl-C then exit gracefully
trap 'exit_program 2'  2

# First we need to get the user input

while getopts f:p:t:ah the_option
do
	case $the_option in
	a)
		echo ""
		exit
		;;
	f)
		releases_to_build="$OPTARG"
		;;
	h)
		usage
		;;
	p)
		platforms="$OPTARG $platforms" 
		;;
	t)
		release_tag="$OPTARG"
		;;
	*)
		echo ""
		echo "Error: Unrecognised Option: $the_option in getopts"
		echo ""
		usage
		;;
	esac
done

if [ -z "$release_tag" ]
then
	echo "You must us the -t option to pass in a release tag"
	usage
fi

echo "Finding all the platforms for $release_tag"

# First we need to find the platforms for this major_release
project_release=`$BCE_BUILD_SCRIPTS/discover_release_tag.sh -t $release_tag`
project=`echo $project_release | cut -d' ' -f1`
release=`echo $project_release | cut -d' ' -f2`
major_release=`echo $release | cut -d'.' -f1-2`

BASERELEASE=$major_release
THE_PROJECT=$project
BASEPROJECT=$THE_PROJECT

if [ "$project" = "PF" ]
then 
	echo "calling pfbuild_jenkins.sh script"
	$BCE_BUILD_SCRIPTS/pfbuild_jenkins.sh $release
fi

if [ -z "$platforms" ]
then
	sol_to_geneva_conv
	get_platform_list
else
	PLATFORM_LIST=$platforms
fi

build_machines=""
reconfigure_servers=""

for state in dev test sqa
do
	for PLATFORM_ID in ${PLATFORM_LIST}
	do
		get_platform
		if [ -z "$PLATFORM_NAME" ]
		then
			echo "Error: Invalid Platform_ID $PLATFORM_ID"
			continue
		fi

		ccm_project=$project-$state$release.$PLATFORM_NAME
	
		result_from_machine_for_proj=`machine_for_projects.pl -p $ccm_project`

		echo $result_from_machine_for_proj | grep "This project should be built on" > /dev/null
		if [ $? -eq 0 ]
		then
			echo $result_from_machine_for_proj | cut -d: -f2 | sed -e 's/ //g' >> $tmp_file
		else
			echo $result_from_machine_for_proj | grep "world" > /dev/null
			if [ $? -eq 0 ]
			then
				hostname >> $tmp_file
			else
				echo "Defaults and overrides do not have this platform $ccm_project"
				continue
			fi
		fi
	
		reconfigure_servers="$reconfigure_server $reconfigure_servers"
	done
done

echo cedar >> $tmp_file2
echo lilac >> $tmp_file2
echo jay >> $tmp_file2
echo albatross >> $tmp_file2
echo tern >> $tmp_file2
echo petrel >> $tmp_file2
#echo buzzard >> $tmp_file2
echo grebe >> $tmp_file2
#echo whitby >> $tmp_file2
#echo osprey >> $tmp_file2
#echo palm >> $tmp_file2
echo snowbell >> $tmp_file2
#echo coconut >> $tmp_file2
#echo heron >> $tmp_file2
cat $tmp_file2 >> $tmp_file
all_machines=`cat $tmp_file | sort -u`
rm $tmp_file2

echo About to run on: $all_machines

if [ ! -f "${BCE_ADMIN}/$releases_to_build" ]
then
	echo "Error: invalid releases to build file $releases_to_build"
	exit_program 0
fi

echo ""
echo "Running overnight_builds on the required machines"
echo ""

for mach in $all_machines
do
	sql="select os from pdm_machines where name='$mach';"
	BUILDWEB_DB=`buildweb_connection`
    	os=`sql_query ${BUILDWEB_DB} "$sql"`
	case $os in
		HP*)
			rsh_command="remsh ${mach} -n -l genadmin "
			;;
		[Aa][Ii][Xx])
			rsh_command="rsh ${mach} -n -l genadmin "
			;;
		*)
			rsh_command="rsh -n -l genadmin ${mach} "
			;;
	esac

#       echo "Running overnight_builds_svn $releases_to_build on $mach"
#       echo "$rsh_command \"$BCE_BUILD_SCRIPTS/overnight_builds_svn $releases_to_build\"" > $tmp_file
#       /bin/chmod 777 $tmp_file
#       $tmp_file &
if [ $mach = 'camdl121' -o  $mach = 'camvlsles1' -o $mach = 'box' -o $mach = 'camdl30'  -o $mach = 'camal32' -o $mach = 'camvl21' ]
        then
        rsh_command="ssh -n -l genadmin ${mach}"
        echo "Running overnight_builds_svn $releases_to_build on $mach"
        echo "$rsh_command \"$BCE_BUILD_SCRIPTS/overnight_builds_svn $releases_to_build\"" > $tmp_file
        /bin/chmod 777 $tmp_file
        $tmp_file &
        else
        echo "Running overnight_builds_svn $releases_to_build on $mach"
        echo "$rsh_command \"$BCE_BUILD_SCRIPTS/overnight_builds_svn $releases_to_build\"" > $tmp_file
        /bin/chmod 777 $tmp_file
        $tmp_file &
        fi



done

wait

exit_program 0
