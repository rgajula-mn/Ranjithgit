#!/usr/bin/perl -w
#
#  Script:              machine_for_projects.pl
#  Subsystem:           CB1_1
#  Author:              %name: machine_for_projects.pl %
#  Start date:          Mon Jan 06 15:26:36 2003
#  Version:             %full_filespec: machine_for_projects.pl-14:perl:CB1#1 %
#
#  Description:
#
# (C) Convergys, 2002.
# Convergys refers to Convergys Corporation or any of its wholly
# owned subsidiaries.


##############################################################
#
# INCLUDES

use strict;


##############################################################
#
# VARIABLES

my $overridesFile = "/irb/bce/admin/config/overrides_for_release";
my $defaultsFile = "/irb/bce/admin/config/defaults_for_release";

my $projectString;
my $majorVersion;

my $arg;
my $overridden;

my $machine;
my $hostname;
my $database;
my $project;
my $buildState;
my $minorVersion;
my $platform;
my $oracleVersion;

my $usage = "\nUsage: $0 <-p full project name> [-d]\n" .
            "         Where full project name is a CCM Project\n" .
            "             e.g. GENEVA-sqa5.2.3.solaris.oracle9i2\n" .
            " " .
            " This script looks in defaults_for_release and overrides_for_release\n" .
            " and returns 0 if this project should be built on this machine, along\n" .
            " with the database. Returns 1 if this is the incorrect machine and\n" .
            " any other positive number for an error.\n" .
            " " .
            " If you want to ignore the machine this is running on, and just return the\n" .
            " Database you wish to run on, use the -d option.\n";



##############################################################
#
# UTILITY FUNCTIONS


sub Usage
{
    print $usage;
    exit 2;		# 2 indicates an error
}

sub Abort
{
    print $_[0];
    exit 2;
}


##############################################################
#
# COMMAND LINE PARSING


&Usage if @ARGV < 2;

$arg = shift;
my $databaseonly = "no";

# Very primitive initial check
&Usage if $arg !~ /-p|-d/;

while ($arg)
{
    if ($arg eq "-p")
    {
	$projectString = shift;
	$arg = shift;
    }
    elsif ($arg eq "-d")
    {
	$arg = shift;
	$databaseonly = "yes";
    }
}


##############################################################
#
# MAIN SCRIPT

# Deconstruct the full project string to get the project name, the build state,
# the minor version, the platform and the oracle version.

if ($projectString =~ /^(\w+)-([a-z]+)(\d+\.\d+(IN|TS)?)([\d|m|c|k|l|p|\.]*)\.(\w+)\.(\w+)$/)
{
	$project = $1;
	$buildState = $2;
	$majorVersion=$3;
	$minorVersion = "$3$5";
	$platform = $6;
	$oracleVersion = $7;
}
else
{
	print "Error machine_for_projects.pl: Cannot parse Project String: $projectString\n";
	exit 2
}

# Check to see if this build has an override machine/database
# If not, lookup the default.

checkForOverride($project, $minorVersion, $buildState, $platform, $oracleVersion);

unless (defined $overridden)
{
	lookupDefaults($project, $majorVersion, $platform, $oracleVersion);
}

# If a reference to a release has been found in the text file, exit with a value
# depending on whether this is the host running this script. Otherwise, exit
# with an error value indicating that the specified release has not been added.

if (defined $machine)
{
	$hostname = `uname -n`;

	chomp($hostname);
	chomp($machine);

	if ($hostname eq $machine or $databaseonly eq "yes")
	{
		print "$database.world";
		exit 0;
	}
	else
	{
		print "This project should be built on: $machine\n";
		exit 1;
	}
}
else
{ 
	print "Project $projectString not found in defaults/overrides for release (cannot parse).\n";
	print "    project       = $project\n";
	print "    buildState    = $buildState\n";
	print "    majorVersion  = $majorVersion\n";
	print "    minorVersion  = $minorVersion\n";
	print "    platform      = $platform\n";
	print "    oracleVersion = $oracleVersion\n";
	exit 2;
}

#print "statements for testing purposes\n";

#print "\nBuilding Project: $projectString\n\n";
#print "Machine to build on: $machine\n\n";
#print "Database to use: $database\n\n";


##############################################################
#
# FUNCTIONS


sub checkForOverride
{
    my $project = $_[0];
    my $minorVersion = $_[1];
    my $buildState = $_[2];
    my $platform = $_[3];
    my $oracleVersion = $_[4];

    my $record;
    my @elements;

    open(DRC,"<$overridesFile") || &Abort ("Cannot open $overridesFile: $!\n");

    LINE: while(<DRC>)
    {
	next LINE if /^\s*$/;     # Blank line or whitespace only
	next LINE if /^\/\/.*$/;  # // Comment
	next LINE if /^-+$/;      # One or more dashes (-)

	/^(.*)$/;                 # Anything else
	
	$record = $1;

	@elements = split /,\s*/, $record;

	if ($elements[0] eq $project &&
	    $elements[1] eq $minorVersion &&
	    $elements[2] eq $buildState &&
	    $elements[3] eq $platform &&
	    $elements[4] eq $oracleVersion)
	{
	    $machine = $elements[5];
	    $database = $elements[6];
	    $overridden = 1;
	}
    }
    close(DRC);
}


sub lookupDefaults
{
    my $project = $_[0];
    my $majorVersion = $_[1];
    my $platform = $_[2];
    my $oracleVersion = $_[3];

    my $record;
    my @elements;

    open(DRC,"<$defaultsFile") || &Abort ("Cannot open $defaultsFile: $!\n");

    LINE: while(<DRC>)
    {
	next LINE if /^\s*$/;     # Blank line or whitespace only
	next LINE if /^\/\/.*$/;  # // Comment
	next LINE if /^-+$/;      # One or more dashes (-)

	/^(.*)$/;                 # Anything else
	
	$record = $1;

	@elements = split /,\s*/, $record;

	if ($elements[0] eq $project &&
	    $elements[1] eq $majorVersion &&
	    $elements[2] eq $platform &&
	    $elements[3] eq $oracleVersion)
	{
	    $machine = $elements[4];
	    $database = $elements[5];
	}
    }
    close(DRC);
}

