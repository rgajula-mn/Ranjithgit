#!/bin/ksh
set -x
#. ~/.bce.ini
#########partial build of specific clients###########
#########after creating release tag and checking out build project##########
#########need to extract bin, lib and plb and sql to build the partial build#####

usage()
{
echo "Usage: <sript name> <release tag product baserelase majorrelease platform oracleversion>"
echo "Eg: partial_build_ice.sh RB_8.0.4.280 env-RB_sqa8.0.4.320.linux.oracle12c.sh /irb/bce/admin/log/20160921/partial_build_ice_RB_8.0.4.320.log"
exit 1
}


if [ $# -ne 4 ]
then
        echo "Enter correct arguments"
	usage
else
	echo "arguments are passed correct"
fi
patch_version=$1
env_file=$2
log=$3
CCM_ROOT=$4


patch_release=`echo $patch_ver|cut -b 1-`


#getting company name from patch_company name
#sql="select company from patch_company where version='$patch_release' and project='$product'"
#echo $sql>> $log 2>&1
#	company=`sqlplus -s buildweb/georgespass@webca.world << +END
#	set feed off
#	set head off
#	$sql;
#	exit
#+END`
#        company=`sqlplus -s buildweb/georgespass@webca.world << +END
#                set feed off
#                set head off
#                $sql;
#                exit
#+END`




#	. $log_date/$env_file >> $log 2>&1
#echo $ORCLE_HOME
#getting patches based on company name from patch_company and patch_summary
#sql="select a.version from patch_company a, patch_summary b where a.version=b.version and b.patch_status!='Cancelled' and b.patch_status!='Test' and a.company='$patch_comp' and b.project='$product' and a.version like '$baseline_rel%'"
#echo $sql>> $log 2>&1
#	patch_vers=`$ORACLE_HOME/bin/sqlplus -s buildweb/georgespass@webca.world << +END
#	set feed off
#	set head off
#	$sql;
#	exit
#+END`
#echo $patch_vers
#patch_vers=`sqlplus -s buildweb/georgespass@webca.world << +END
#                set feed off
#                set head off
#                $sql;
#                exit
#+END`
#echo "patch_versions for $patch_comp $patch_vers" >> $log 2>&1
#patch_versions=`echo $patch_vers|tr -d '\n'`
#echo "patch_ver for $patch_comp $patch_versions" >> $log 2>&1

echo "partial build start date is: `date`" >> $log 2>&1
#	echo "archive of lib and bin start date is: `date`" >> $log 2>&1
#	cp -p $log_date/$env_file $CCM_ROOT >> $log 2>&1
        . $CCM_ROOT/$env_file
	prj_plt=`echo $CCM_ROOT|cut -d '/' -f7`
	echo "$prj_plt" >> $log 2>&1
#	sql1="update BUILD_DATABASE_LOCKS set EXPIRE_TIME=EXPIRE_TIME+30 where CCM_PROJECT='$prj_plt'"
#	sqlplus -s buildweb/georgespass@webca.world >> $log 2>&1 << +ENDSQL2
#		set feed off
#		set head off
#		$sql1;
#		commit;
#		exit
#+ENDSQL2
	echo "partial build make clean start date is: `date`" >> $log 2>&1
        #cd $CCM_ROOT/ && make clean >> $log 2>&1
	#### executing make inc in below direcotries
	echo "started APICORE/datatypes & /APICORE/general compilation in database" >> $log 2>&1
	api_cc='apiinc plsql java'
	cd $CCM_ROOT/APICORE/datatypes/SRC && make $api_cc >> $log 2>&1
	cd $CCM_ROOT/APICORE/general/SRC/ && make $api_cc >> $log 2>&1
	cd $CCM_ROOT//APICORE/translate/SRC/ &&  make $api_cc >> $log 2>&1
	cd $CCM_ROOT//APICORE/error/SRC/ && make $api_cc >> $log 2>&1
	echo "completed APICORE/datatypes /APICORE/general compilation in database" >> $log 2>&1
	for i in CORE VPACORE RATE BILL OPERABILITY FINANCE PROMOINTEG
	do
		if [ -d $CCM_ROOT/$i ];then
			echo "partial build make inc start date is: `date`" >> $log 2>&1
			cd $CCM_ROOT/$i && make clean >> $log 2>&1
			cd $CCM_ROOT/$i && make inc >> $log 2>&1
			echo "partial build make inc complete date is: `date`" >> $log 2>&1
		fi
	done
	echo "toolexe started in CORE module first" >> $log 2>&1
	cd $CCM_ROOT/CORE/ && make toolexe >> $log 2>&1
	echo "toolexe completed in CORE module" >> $log 2>&1
	#### executing make geninc in below direcotries
	for i in CORE VPACORE RATE BILL OPERABILITY FINANCE PROMOINTEG
	do
		if [ -d $CCM_ROOT/$i ];then
			echo "partial build make geninc started date is: `date`" >> $log 2>&1
			cd $CCM_ROOT/$i && make geninc >> $log 2>&1
			echo "partial build  make geninc completed date is: `date`" >> $log 2>&1
		fi
	done
	#### executing make lib in below direcotries
	#### executing make in CORE direcotry
	for i in PFUNIT PFREFDATACACHE MWBASE MWSOCK MWLIC MWBUS MWDCONFIG FORMATMGR OBJSTORE PFAISINTF PFAISMOCKIMPL PFAISOPENSAFIMPL LIC PFAIS PFLOG PFPERFLOG PFTOOLS GMB GDB GDBEXT GTOFT
	do
		if [ -d $CCM_ROOT/CORE/$i ];then 
			echo "partial build make base started in $i date is: `date`" >> $log 2>&1
			cd $CCM_ROOT/CORE/$i/SRC && make base >> $log 2>&1
			echo "partial build make base completed date is: `date`" >> $log 2>&1
		fi
	done
	#### executing make lib in below direcotries
	for i in BID FEED CTH FDUcore GCAT REAL REXIL GBRT REXAL GEVA LCML GTI BRAG TRPI GUST GTR OCR SPL STA 
	do
		if [ -d $CCM_ROOT/VPACORE/$i ];then
			echo "partial build make base lib in VPACORE started date is: `date`" >> $log 2>&1
			cd $CCM_ROOT/VPACORE/$i/SRC && make base >> $log 2>&1
			echo "partial build make base lib in VPACORE completed date is: `date`" >> $log 2>&1
		fi
	done
	for i in RTDP CL CLIEG CLICFE CLIAA CLICA CLIDS CLIPA CLIDC RVPU NES
	do
		if [ -d $CCM_ROOT/RATE/$i ];then
			echo "partial build make base lib in RATE started date is: `date`" >> $log 2>&1
			cd $CCM_ROOT/RATE/$i/SRC && make base >> $log 2>&1
			echo "partial build make base lib in RATE completed date is: `date`" >> $log 2>&1
		fi
	done
	for i in BCA BCMD BDT BF BREQ BSIF BTCI GDISC GOV GPROD GSUM GTAR BOPI
	do
		if [ -d $CCM_ROOT/BILL/$i ];then
			echo "partial build make base lib in BILL started date is: `date`" >> $log 2>&1
			cd $CCM_ROOT/BILL/$i/SRC && make base >> $log 2>&1
			echo "partial build make base lib in BILL completed date is: `date`" >> $log 2>&1
		fi
	done
echo "partial script Completed at : `date`" >> $log 2>&1
