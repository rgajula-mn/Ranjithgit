#!/bin/sh
set -x
# Set up the environment
. /home/genadmin/.profile

if [ ! "${build_scripts}" ]
then
	build_scripts=/irb/bce/admin/build_scripts
fi

# Include function files
. $build_scripts/core_functions_svn.sh
. $build_scripts/ccm_functions_svn.sh
. $build_scripts/buildweb_functions_svn.sh

###########################################################################################
#
#     #######
#     #        #    #  #    #   ####    #####     #     ####   #    #   ####
#     #        #    #  ##   #  #    #     #       #    #    #  ##   #  #
#     #####    #    #  # #  #  #          #       #    #    #  # #  #   ####
#     #        #    #  #  # #  #          #       #    #    #  #  # #       #
#     #        #    #  #   ##  #    #     #       #    #    #  #   ##  #    #
#     #         ####   #    #   ####      #       #     ####   #    #   ####
#
###########################################################################################

usage()
{
        echo " "
        echo "Usage: $0 -p <project> -c <Candiate Name> -u <Username>"
        echo "  e.g. $0 -p GENEVA-sqa5.1.4.solaris.oracle8i"
        echo " "
        echo "  This script will look for prep objects owned by genadmin in the"
        echo "  entire CCM DB for release (in this example GEN_5.1.4). I will then"
        echo "  look in the build projects release and bin directory for these items"
        echo "  If found will copy to one of the Install, Test or Patch areas."
	echo ""
	echo "  Setting -c specifies the Candidate for which this report is generated, e.g., RC1"
	echo "  Setting -u specifies the Your Username - Do not enter genadmin or else!"
	echo "  Setting -a specifies that release_config_updater.sh will be run to auto-update the .xml files"
	echo "  Setting -h specifies this is a head release"
        echo " "
        exit_program 1
}



MyEcho()
{
  ## NB remove the echoing here, this just proves that you have captured stderr
  echo $@
  echo $@ >> $logfile
}


# MyAppend
# read stdin and echo to screen, and append to log file
LogScreenFile()
{
  res=0

  until [ $res -ne 0 ]
  do

    read myline
    res=$?

    if [ $res -ne 0 ]
    then
	break
    fi

    MyEcho $myline

  done
}



exit_program ()
{
        echo ""
        echo "Exiting Program with status $1:"
        case $1 in
                0)
                        echo "  Exiting Happy"
                        ;;
                1)
                        echo "  Incorrect Usage"
                        ;;
                2)
                        echo "  Ctrl-C caught"
                        ;;
                3)
                        echo "  File could not be copied"
                        ;;
		4)
			echo "  Workarea does not exist"
			;;
                *)
                        echo "  Unknown Error"
                        ;;
        esac
#	cleanUpCCM
        exit $1
}



###########################################################################################
#
#     #    #    ##       #    #    #
#     ##  ##   #  #      #    ##   #
#     # ## #  #    #     #    # #  #
#     #    #  ######     #    #  # #
#     #    #  #    #     #    #   ##
#     #    #  #    #     #    #    #
#
###########################################################################################

trap 'exit_program 2'  2

UpdateInfo="FALSE"
HeadRelease="FALSE"
# Process the command line arguments
while getopts ahc:p:u: the_option
do
	case $the_option in
	a)
		UpdateInfo="TRUE"
		;;
	c)
		candidate=$OPTARG
		;;
	h)
		HeadRelease="TRUE"
		;;
	p)
		FULL_PROJECT="$OPTARG"
		project=`echo $FULL_PROJECT | cut -d'-' -f1`
		;;
	u)
		Username=$OPTARG
		;;
	[?])
		usage
		;;
	esac
done

if [ -z "${FULL_PROJECT}" ]
then
	echo "No Project Parameter"
	usage
fi
if [ -z "${candidate}" ]
then
	echo "No Candidate Parameter"
	usage
fi

check_username $Username

# Start up CCM on build database
#product_database=`grep "^${project}," /irb/bce/admin/config/product_cm_database`
#exist_in_other_db=$?

#if [ $exist_in_other_db = 0 ]
#then
#	cut_database=`echo $product_database | cut -d',' -f2`
#	CCM_DATABASE="/ccm/$cut_database"
#else
#	CCM_DATABASE="/ccm/prd"
#fi

#startCCM "$CCM_DATABASE"
#if [ -z "${CCM_ADDR}" ]
#then
#	exit_program 4
#fi


# Get the Project name from the parameter entered (eg GENEVA or TAP3)
PROJECT=`echo $FULL_PROJECT | cut -d'-' -f1`
PROJECT_low=`echo ${PROJECT} | tr '[A-Z]' '[a-z]'`
# Get the version from the parameter entered (eg sqa5.1.4.solaris.oracle8i)
build_version=`echo ${FULL_PROJECT} | cut -d'-' -f2`

# Get the build projects release tag (eg GEN_5.1.4)
#RELEASE_TAG=`ccm query -t project "name = '$PROJECT' and version='$build_version'" -f "%release" -u`

#if [ -z "${RELEASE_TAG}" ]
#then
#	echo "Invalid Release Tag / Project does not exist"
#        usage
#fi

# Get the release number from the release tag (eg 5.1.4)
#RELEASE_NUMBER=`echo $RELEASE_TAG | cut -d'_' -f2`
dots_in_release=`echo $build_version|tr -d -c '.'|wc -c`
	if [ "$dots_in_release" -eq 2 ]
            	then
                     	RELEASE_NUMBER=`echo $build_version|cut -d '.' -f1-3|tr -d 'sqa'`
             	elif [ "$dots_in_release" -eq 3 ]
             	then
                    	RELEASE_NUMBER=`echo $build_version|cut -d '.' -f1-4|tr -d 'sqa'`

	        elif [ "$dots_in_release" -eq 4 ]
		then
			RELEASE_NUMBER=`echo $build_version|cut -d '.' -f1-3|tr -d 'sqa'`
		elif [ "$dots_in_release" -eq 5 ]
		then 
 			RELEASE_NUMBER=`echo $build_version|cut -d '.' -f1-4|tr -d 'sqa'`
	fi


echo "RELEASE_NUMBER is ......${RELEASE_NUMBER} "
maint_or_head=`echo $RELEASE_NUMBER|tr -d -c '.'|wc -c`

if [ "$PROJECT" = "TAP3" ]
then 
	RELEASE_TAG=`echo TAP'_'$RELEASE_NUMBER`
else
	RELEASE_TAG=`echo $PROJECT'_'$RELEASE_NUMBER`
fi

echo " RELEASE_TAG is .....$RELEASE_TAG"
BASERELEASE=`echo ${RELEASE_NUMBER} | cut -d'.' -f1-2`

# Get the state from the entered parameter (eg sqa)
STATE=`echo $FULL_PROJECT | sed -e 's/.*-\([a-z]*\).*/\1/g'`

discover_platform_oracle()
{
	version_string=$1
	echo $version_string | grep solaris32 > /dev/null
	if [ $? -eq 0 ]
	then
		disc_platform=solaris32
	else
		echo $version_string | grep itanium > /dev/null
		if [ $? -eq 0 ]
		then
			disc_platform=itanium
		else
			echo $version_string | grep tru64 > /dev/null
			if [ $? -eq 0 ]
			then
				disc_platform=tru64
			else
				echo $version_string | grep hp64 > /dev/null
				if [ $? -eq 0 ]
				then
					disc_platform=hp64
				else
					echo $version_string | grep linux > /dev/null
					if [ $? -eq 0 ]
					then
						disc_platform=linux
					else
					  echo $version_string | grep suselinux > /dev/null
					  if [ $? -eq 0 ]
					  then
						disc_platform=suselinux
					  else
						echo $version_string | grep solaris > /dev/null
						if [ $? -eq 0 ]
						then
							disc_platform=solaris
						else
							echo $version_string | grep aix > /dev/null
							if [ $? -eq 0 ]
							then
								disc_platform=aix
							else
								echo $version_string | grep hp > /dev/null
								if [ $? -eq 0 ]
								then
									disc_platform=hp
								else
									disc_platform=web
								fi
							fi
						fi
					  fi

					fi
				fi
			fi
		fi
	fi

	echo $version_string | grep oracle9i2 > /dev/null
	if [ $? -eq 0 ]
	then
		disc_platform=${disc_platform}_oracle9i2
	else
		echo $version_string | grep oracle9i > /dev/null
		if [ $? -eq 0 ]
		then
			disc_platform=${disc_platform}_oracle9i
		else
			echo $version_string | grep oracle8i > /dev/null
			if [ $? -eq 0 ]
			then
				disc_platform=${disc_platform}_oracle8i
			else
				echo $version_string | grep oracle8 > /dev/null
				if [ $? -eq 0 ]
				then
					disc_platform=${disc_platform}_oracle8
				else
					echo $version_string | grep oracle10g > /dev/null
					if [ $? -eq 0 ]
					then
						disc_platform=${disc_platform}_oracle10g
					else
						echo $version_string | grep at > /dev/null
						if [ $? -eq 0 ]
						then
							disc_platform=${disc_platform}_at
						else
							disc_platform=${disc_platform}_
						fi
					fi
				fi
			fi
		fi
	fi

	echo $disc_platform
	
}
platform_oracle=`discover_platform_oracle $FULL_PROJECT`
proj_platform=`echo $platform_oracle | cut -d'_' -f1`
proj_oracle=`echo $platform_oracle | cut -d'_' -f2`
ora_version=`echo ${FULL_PROJECT}|sed 's/.*.\.//g'`

echo "PROJECT           = $PROJECT"
echo "PROJECT_low           = $PROJECT_low"
echo "RELEASE_TAG       = $RELEASE_TAG"
echo "RELEASE_NUMBER    = $RELEASE_NUMBER"
echo "STATE             = $STATE"
echo "platform_oracle   = $platform_oracle"
echo "proj_platform     = $proj_platform"
echo "proj_oracle       = $proj_oracle"
echo "BASERELEASE       = $BASERELEASE"
echo "oracle_verison    = $ora_version" 

# Get the workarea for the entered project. And add the next directory
# eg /irb/bce/5.1/GENEVA-sqa5.1.4.solaris.oracle8i/GENEVA)
#build_workarea=`ccm query -t project "name = '${PROJECT}' and version = '${build_version}'" -f "%wa_path" -u`

		###################getting build work area for given project############################
		#####################added by Dhanumjaya######################
#build_workarea=`echo $build_workarea | cut -d' ' -f1`
#build_workarea="${build_workarea}/${PROJECT}"
build_workarea="${BCE_ROOT}/build/${PROJECT_low}/${BASERELEASE}/${FULL_PROJECT}/${PROJECT}"
echo "build_workarea    = $build_workarea"
chmod -R 755 $build_workarea/ALLBATCH/bin/mibs
# if workarea does not exists, exit.
if [ ! -d "$build_workarea" ]
then
	echo "$build_workarea does not exist"
	exit_program 4
fi

#cd $build_workarea
###########################################getting required install project work area #############################################
full_patch=`cat $BCE_ADMIN/config/releases_for_cb2|grep $RELEASE_TAG`
echo "full_patch is $full_patch"

	if [ "$full_patch" = "${RELEASE_TAG}" -o "$maint_or_head" -eq 2 ]
	then  
			if [ "${PROJECT}" = "RB" ]
			then
				install_workarea="${BCE_ROOT}/release/${PROJECT_low}/${BASERELEASE}/${PROJECT}INSTALL-${build_version}/${PROJECT}INSTALL/${PROJECT}/${PROJECT}"
				install_workarea1="${BCE_ROOT}/release/${PROJECT_low}/${BASERELEASE}/${PROJECT}INSTALL-${build_version}/${PROJECT}INSTALL/${PROJECT}/"
				install_workarea_rbtest="${BCE_ROOT}/release/${PROJECT_low}/${BASERELEASE}/${PROJECT}TEST-sqa${RELEASE_NUMBER}/${PROJECT}TEST/"


#############################
#FOR PROCEDURES.ZIP

	cd $build_workarea/ALLBATCH/schema/ && rm procedures.zip olc.zip roles.zip source.zip synonyms.zip
	cp /irb/bce/build/web/RBAPI-sqa$RELEASE_NUMBER/RBAPI/build_output/distrib/external/schema/eca/procedures/* $build_workarea/sql
	cp -p $build_workarea/sql/all* $build_workarea/SCHEMA/procedures/
	cd $build_workarea/SCHEMA/ && zip -r $build_workarea/ALLBATCH/schema/procedures.zip procedures -x '*cache*' 
	 zip -r $build_workarea/ALLBATCH/schema/olc.zip olc -x '*.log' -x "olc/working/*" "olc/logs/*"
	 zip -r $build_workarea/ALLBATCH/schema/roles.zip roles
	 zip -r $build_workarea/ALLBATCH/schema/source.zip source
	 zip -r $build_workarea/ALLBATCH/schema/synonyms.zip synonyms
	cp /irb/bce/build/web/RBAPI-sqa$RELEASE_NUMBER/RBAPI/build_output/distrib/external/javadoc.zip /irb/bce/build/doc/rb/5.3/eca
	cp /irb/bce/build/web/RBAPI-sqa$RELEASE_NUMBER/RBAPI/build_output/distrib/external/webservices_javadoc.zip /irb/bce/build/doc/rb/5.3/eca
##############################




                            if [ ! -d ${install_workarea} ]
                	    then
                        	mkdir -p ${install_workarea}
				cd ${install_workarea}
				mkdir -p RBIUH doc sample java include lib exe/DLL META_INF schema bin
				cd .. && mkdir -p manifest
				cd ${install_workarea}/schema && mkdir -p definitions java/api mess/enu templates
				cd ${install_workarea}/sample && mkdir -p mfm doc1 templates
				
                        	chmod 755 ${install_workarea}
			    fi
			
                            if [ ! -d ${install_workarea_rbtest} ]
                	    then
                        	mkdir -p ${install_workarea_rbtest}
				cd ${install_workarea_rbtest}
				mkdir -p solaris_oracle10g solaris32_at java etc TOOL olc_schema RTRI linux32_oracle10g schemaTopUp aix_oracle11g itanium_oracle11g linux_oracle11g solaris_oracle11g linux_oracle10g itanium_oracle10g aix_oracle10g
				mkdir -p RTRI/RTEST RTRI/SCRIPTS java/ear/weblogic_10_0/ java/ear/webservices/client/schema/Base/ java/ear/webservices/client/schema/CommonIML/ java/ear/webservices/client/schema/ECA/ java/ear/webservices/client/wsdl/ECA
				chmod 755 ${install_workarea_rbtest}
			     fi
		
			cp -p $build_workarea/configuration/infinys/META_INF/build.xml $install_workarea/META_INF
#			cp -p $build_workarea/configuration/infinys/release_information/release_info.xml $install_workarea/bin/release_info.xml
release_info_path="${BCE_ROOT}/build/${PROJECT_low}/${BASERELEASE}/${PROJECT}-sqa${RELEASE_NUMBER}.linux.$ora_version/${PROJECT}/configuration/infinys/release_information/release_info.xml"
echo "[INFO] Release info path: $release_info_path"
cp -p $release_info_path $install_workarea/bin/release_info.xml
			if [ $proj_platform = "linux" ]
			then
				cp -p $build_workarea/configuration/infinys/manifest/linux/manifest.xml $install_workarea1/manifest/
			elif [ $proj_platform = "aix" ]
			then
				cp -p $build_workarea/configuration/infinys/manifest/aix/manifest.xml $install_workarea1/manifest/
			 elif [ $proj_platform = "solaris" ]
                        then
                                cp -p $build_workarea/configuration/infinys/manifest/solaris/manifest.xml $install_workarea1/manifest/
			 elif [ $proj_platform = "itanium" ]
                        then
                                cp -p $build_workarea/configuration/infinys/manifest/itanium/manifest.xml $install_workarea1/manifest/
			 elif [ $proj_platform = "suselinux" ]
                        then
                                cp -p $build_workarea/configuration/infinys/manifest/suselinux/manifest.xml $install_workarea1/manifest/
                         fi
			cp -pr $BCE_ROOT/build/DLL/* $install_workarea/exe/DLL/
			cp -p $build_workarea/APICORE/repltriggergenerator/SRC/gnvprdrepltriggergenerator.java  $install_workarea/java/
			cp -p $build_workarea/ALLBATCH/java/ECATEST.jar  $install_workarea/java/
			#cp -p $build_workarea/APICAT/ppet/SRC/GenevaDeltas.xsd  $install_workarea/schema/definitions/
			cp -p ${BCE_ROOT}/build/${PROJECT_low}/${BASERELEASE}/${PROJECT}-sqa${RELEASE_NUMBER}.linux.$ora_version/${PROJECT}/APICAT/ppet/SRC/GenevaDeltas.xsd $install_workarea/schema/definitions/
			cp -p $build_workarea/REPORTS/RBGenericWrapper/SRC/rbreports.xsd  $install_workarea/schema/definitions/
			cp -p $build_workarea/REPORTS/RBGenericWrapper/SRC/XSLTemplate.xsl  $install_workarea/schema/definitions/
			cp -p $build_workarea/REPORTS/RBGenericWrapper/SRC/RBreportStyleSheet.xss  $install_workarea/schema/definitions/
			cp -p $build_workarea/ALLBATCH/schema/java_api.zip $install_workarea/schema/java/api/
			cp -p $build_workarea/mess/dev/geneva_messages  $install_workarea/schema/mess/enu/geneva_messages.enu
			cp -p $build_workarea/APICUSTACC/template/SRC/Template.xsd  $install_workarea/schema/templates/Template.xsd
			cp -pr $BCE_ROOT/build/doc/${PROJECT_low}/${BASERELEASE}/*   $install_workarea/doc/  
			cp -p $BCE_ROOT/build/sample/${BASERELEASE}/templates/* $install_workarea/sample/templates
			cp -p $BCE_ROOT/build/sample/${BASERELEASE}/doc1/*  $install_workarea/sample/doc1
			cp -p $build_workarea/BILL/BF/SAMPLE_DATA/disconnect.rtf $install_workarea/sample/templates
			cp -p $build_workarea/BILL/BF/SAMPLE_DATA/bcr.rtf $install_workarea/sample/templates
			cp -p $build_workarea/BILL/BF/SAMPLE_DATA/redletter.rtf $install_workarea/sample/templates
			cp -p $build_workarea/BILL/BF/SAMPLE_DATA/creditnote.rtf $install_workarea/sample/templates
			cp -p $build_workarea/BILL/BF/SAMPLE_DATA/consolidated.rtf $install_workarea/sample/templates
			cp -p $build_workarea/BILL/BF/SAMPLE_DATA/lastchance.rtf $install_workarea/sample/templates
			cp -p $build_workarea/BILL/BF/SAMPLE_DATA/table_def $install_workarea/sample/templates
			cp -p $build_workarea/OPERABILITY/MFM/RTEST/scripts/modules/ppUtil.pm $install_workarea/sample/mfm
			cp -p $build_workarea/OPERABILITY/MFM/RTEST/scripts/translate_tags.pl $install_workarea/sample/mfm
			cp -p $build_workarea/ALLBATCH/java/AISJDC.jar  $install_workarea/lib/
			cp -p $build_workarea/ALLBATCH/java/CheckDupTags.jar $install_workarea/lib/
			cp -p $build_workarea/ALLBATCH/java/AISGenerator.jar $install_workarea/lib/
			cp -p $build_workarea/ALLBATCH/java/DDSSimulator.jar $install_workarea/lib/

		############### for RBTEST ######################################
		if [ $maint_or_head -eq 2 -a "$full_patch" = "" ]
		then 
			 if [ ! -d ${install_workarea_rbtest} ]
                            then
                                mkdir -p ${install_workarea_rbtest}
                                cd ${install_workarea_rbtest}
                                mkdir -p solaris_oracle10g solaris32_at java etc TOOL olc_schema RTRI linux32_oracle10g schemaTopUp aix_oracle11g itanium_oracle11g linux_oracle11g solaris_oracle11g linux_oracle10g itanium_oracle10g aix_oracle10g
                                mkdir -p RTRI/RTEST RTRI/SCRIPTS java/ear/weblogic_10_0/ java/ear/webservices/client/schema/Base/ java/ear/webservices/client/schema/CommonIML/ java/ear/webservices/client/schema/ECA/ java/ear/webservices/client/wsdl/ECA
                                chmod 755 ${install_workarea_rbtest}
                             fi

			cp -pr $build_workarea/RATE/RTRI/RTEST/* ${install_workarea_rbtest}/RTRI/RTEST/
			cp -pr $build_workarea/RATE/RTRI/SCRIPTS/* ${install_workarea_rbtest}/RTRI/SCRIPTS/
			cp -pr $build_workarea/CORE/TOOL/* ${install_workarea_rbtest}/TOOL/
			cp -p $build_workarea/RATE/design/RB3.0/30EFdeltaSchema.sql ${install_workarea_rbtest}/etc/
			cp -p $BCE_ROOT/build/web/RBAPI-sqa$RELEASE_NUMBER/RBAPI/build_output/bws/deliverables/schema/Base/Base.xsd ${install_workarea_rbtest}/java/webservices/client/schema/Base/
			cp -p $BCE_ROOT/build/web/RBAPI-sqa$RELEASE_NUMBER/RBAPI/build_output/webservices/deliverables/schema/CommonIML/CommonIML.xsd ${install_workarea_rbtest}/java/webservices/client/schema/CommonIML/
			cp -p $BCE_ROOT/build/web/RBAPI-sqa$RELEASE_NUMBER/RBAPI/build_output/webservices/deliverables/schema/ECA/* ${install_workarea_rbtest}/java/webservices/client/schema/ECA/
			cp -p $BCE_ROOT/build/web/RBAPI-sqa$RELEASE_NUMBER/RBAPI/build_output/webservices/client/wsdl/ECA/* ${install_workarea_rbtest}/java/webservices/client/wsdl/ECA/
			
		fi
		


			    elif [ "${PROJECT}" = "TAP3" ]				
		    	    then
					install_workarea="${BCE_ROOT}/release/${PROJECT_low}/${BASERELEASE}/${PROJECT}INSTALL-${build_version}/${PROJECT}INSTALL/${PROJECT}/${PROJECT}"
                            	if [ ! -d ${install_workarea} ]
                           	then
					mkdir -p ${install_workarea}
                                        cd ${install_workarea}
					mkdir -p validation TFICM  doc sample java include  exe META_INF schema/procedures/tap3management schema/procedures/tap3config bin				
					chmod 755 ${install_workarea}
				fi
			   elif [ "${PROJECT}" = "VI" ]
                            then
		           	if [ ! -d "${BCE_ROOT}/release/${PROJECT_low}/${BASERELEASE}/${PROJECT}_XINSTALL-${build_version}" ]
				then
				install_workarea_vix="${BCE_ROOT}/release/${PROJECT_low}/${BASERELEASE}/${PROJECT}_XINSTALL-${build_version}/${PROJECT}_XINSTALL/VI_X/VI_X"
				mkdir -p $install_workarea_vix
				cd $install_workarea_vix
				mkdir -p bin  doc  exe  include  java  lib  META_INF  sample  schema  validation
				install_workarea_victl="${BCE_ROOT}/release/${PROJECT_low}/${BASERELEASE}/${PROJECT}_CTLXINSTALL-${build_version}/${PROJECT}_CTLINSTALL/VI_CTL/VI_CTL"
			        mkdir -p $install_workarea_victl
			        cd $install_workarea_victl
				mkdir -p bin  doc  exe  include  java  lib  META_INF  sample  schema  validation  vertex
				
				install_workarea_vistq="${BCE_ROOT}/release/${PROJECT_low}/${BASERELEASE}/${PROJECT}_STQINSTALL-${build_version}/${PROJECT}_STQINSTALL/VI_STQ/VI_STQ"
				mkdir -p $install_workarea_vistq
				cd install_workarea_vistq
				mkdir -p bin  doc  exe  include  java  lib  META_INF  sample  schema  validation
			  fi	
                	fi

		else
			install_workarea="${BCE_ROOT}/release/${PROJECT_low}/${BASERELEASE}/${PROJECT}PATCH-${build_version}/${PROJECT}PATCH/${PROJECT}/${PROJECT}"
			if [ ! -d ${install_workarea} ]
                	then
                        	mkdir -p ${install_workarea}
				cd ${install_workarea}
					if [ "${PROJECT}" = "RB" ]
                                          then
				              mkdir -p bin lib doc
                       			      chmod 755 ${install_workarea}
						cp -p $release_info_path $install_workarea/bin/release_info.xml
					 elif [ "${PROJECT}" = "TAP3" ]
                                	then
                                       		 mkdir -p doc bin
                                        	chmod 755 ${install_workarea}
                                fi

                fi
	fi


# Get the platform for the build project (eg SPARC)
#CCM_PLATFORM=`ccm query -t project "name='$PROJECT' and version='${build_version}'" -f "%platform" -u`

#BASERELEASE=`echo ${RELEASE_NUMBER} | cut -d'.' -f1-2`
if [ "${CCM_PLATFORM}" = "Web " -a "${PROJECT}" = "RBAPI" ]
then
	CCM_PLATFORM=`echo "${CCM_PLATFORM}|JAVA-Weblogic-Oracle10g|JAVA-Jboss-Oracle10g|JAVA-Websphere-Oracle10g|JAVA-Weblogic-Oracle11g|JAVA-Jboss-Oracle11g"`
fi
if [ "${CCM_PLATFORM}" = "Web " -a "${PROJECT}" = "PCMI" ]
then
	CCM_PLATFORM=`echo "${CCM_PLATFORM}|x86-Linux-Oracle11g"`
fi

# stop ccm on build db, start up on release db
#cleanUpCCM
#startCCMForRelease $PROJECT $RELEASE_NUMBER

# If the following ccm query changes, please also update the ccm query in the dodgy GPI bit to match.
#prep_objects=`ccm query -s prep "type!='project' and type!='project_grouping' and release='${RELEASE_TAG}' and member_status='${STATE}'" -u -f "%objectname platform=%platform" | /usr/xpg4/bin/grep -E "${CCM_PLATFORM}|<void>" | awk '{print $1}'`

#############getting prep pbjects list here for any product##############
	#if [ $full_patch != "$RELEASE_TAG" -a "$maint_or_head" -eq 3 ]
	if [ "$full_patch" = "" -a "$maint_or_head" -eq 3 ]
	then
		echo "[INFO] Copy builds called for PATCH"
		new_prep_objects=`sqlplus -s cpt/cpt@webca.world << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
select unique(DELIVERABLE_NAME) from SUBMITTEDTASKDELIVERABLE where TASK_NUMBER in (select TASK_NUMBER from task where RELEASE='${RELEASE_TAG}');
                exit
         EOF`


	
	else
	prep_objects=`cat $BCE_ADMIN/buildweb_config/copy_build_objects|grep ${PROJECT}|awk '{print $1}'`
	fi

RELEASE_TAG=`echo ${RELEASE_TAG}`

# dodgy bit for GPI 4.1/4.2 only
#if [ "$RELEASE_TAG" = "GPI_4.1.2" ]
#then
#	RELEASE_TAG2="GPI_4.2.2"
#	echo "ccm query -s prep \"type!='project' and type!='project_grouping' and release='${RELEASE_TAG2}' and member_status='${STATE}'\" -u -f \"%objectname platform=%platform\""
#	prep_objects2=`ccm query -s prep "type!='project' and type!='project_grouping' and release='${RELEASE_TAG2}' and member_status='${STATE}'" -u -f "%objectname platform=%platform" | /usr/xpg4/bin/grep -E "${CCM_PLATFORM}|<void>" | awk '{print $1}'`

#	prep_objects=`echo "$prep_objects $prep_objects2"`
#fi

#release_number=`echo $RELEASE_TAG | cut -d'_' -f2`
#major_release=`echo $release_number | cut -d'.' -f1-2`

echo "CCM_PLATFORM      = $CCM_PLATFORM"

TIME_DATE=`date "+%y%m%d%H%M%S"`
LOGDIR=/irb/bce/admin/log/copy_build
logfile="${LOGDIR}/copy_${RELEASE_TAG}_${candidate}.log"
html_log_file=copy_build/copy_${RELEASE_TAG}_${candidate}.log
if [ ! -d ${LOGDIR} ]
then
	mkdir ${LOGDIR}
	chmod 777 ${LOGDIR}
fi
echo "Logfile Location: ${logfile}"

touch $logfile

echo "----------------------------------------------------------------" >> $logfile
echo "Copy started at `date`" >> $logfile
echo ""

extra_prep_objects=`sqlplus -s cpt/cpt@webca.world << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                select unique(OBJECT_NAMe) OUTPUT from CM_ADMIN.CMOBJECT a,CPT.TASKHASCCMOBJECT b where a.OBJECT_ID=b.CCM_OBJECT_ID and b.TASK_NUMBER in(select unique(TASK_NUMBER) from SUBMITTEDTASKDELIVERABLE where TASK_NUMBER in (select TASK_NUMBER from task where RELEASE='${RELEASE_TAG}'));

 exit
         EOF`

# Set up summary variables.
total_files=0
total_reconcile=0
total_success=0
total_errors=0
total_warns=0
flag_1=0
flag_2=0
delivery_types_done=""
for exe in $new_prep_objects
do

#if [ "$exe" = "Messages_API" -o "$exe" = "Messages_VPA"  -a  "$flag_1" != 1 ]
if [ "$exe" = "Messages_VPA" ]
then
exe=Messages_API
fi

if [ "$exe" = "Messages_API" -a  "$flag_1" != "1" ]
then
flag_1=1
#echo "INSIDE Mess_API"
mess_list=`echo $extra_prep_objects|tr ' ' '\n'|egrep "\.xml\$|\.mess\$"`
	for i in ${mess_list}
	do
	found_deliverable=`find $install_workarea/ -type f -name $i`
	if [ -f "$found_deliverable" ]
	then
#echo "INSTALL WORKAREA: $found_deliverable"
echo "[SUCCESS] $i >> /tmp/$RELEASE_TAG.log"
	flag=1
	total_success=`expr $total_success + 1`
	else
	total_errors=`expr $total_errors + 1`
	echo "[FAILED] $i >> /tmp/$RELEASE_TAG.log"
echo ""
	fi
	done

fi
if [ $exe = "Schema" ]
then
#echo "INSIDE Schema"
	schema_list=`echo ${extra_prep_objects}|tr ' ' '\n'|egrep "\.sql\$"`
	for i in ${schema_list}
	do
	found_deliverable=`find $install_workarea/ -type f -name $i`
	 if [ -f "$found_deliverable" ]
	then
	echo "[SUCCESS] $i >> /tmp/$RELEASE_TAG.log"
	 total_success=`expr $total_success + 1`
        else
        total_errors=`expr $total_errors + 1`
        echo "[FAILED] $i >> /tmp/$RELEASE_TAG.log"
echo ""
        fi
	done


fi
if [ "$exe" = "APIs" -o "$exe" = "API"  -a  "$flag_2" != 1 ]
then
flag_2=1
#echo "INSIDE API"
	 api_list=`echo ${extra_prep_objects}|tr ' ' '\n'|egrep "\.bdy\$|\.spc\$"`
        for i in ${api_list}
        do
	i=`echo $i|sed 's/.bdy/.plb/g'`
        found_deliverable=`find $install_workarea/ -type f -name $i`
         if [ -f "$found_deliverable" ]
        then
        echo "[SUCCESS] $i >> /tmp/$RELEASE_TAG.log"
         total_success=`expr $total_success + 1`
        else
        total_errors=`expr $total_errors + 1`
       echo "[FAILED] $i >> /tmp/$RELEASE_TAG.log"
	echo ""
        fi
        done

fi


if [ $exe != "APIs" -a  $exe != "API" -a  $exe != "Messages_API" -a  $exe != "Messages_VPA" -a  $exe != "Schema" ]
then
found_deliverable=`find $install_workarea/ -type f -name $exe`
#ls -ltr $found_deliverable
if [ -f "$found_deliverable" ]
then
#echo "INSTALL WORKAREA: $found_deliverable"
echo "[SUCCESS] $exe >> /tmp/$RELEASE_TAG.log"
total_success=`expr $total_success + 1`
else
total_errors=`expr $total_errors + 1`
echo "[FAILED] $exe >> /tmp/$RELEASE_TAG.log"
fi
fi
done

for exe in $prep_objects
do
	total_files=`expr $total_files + 1`
	
	echo "" >> $logfile
	echo "New Prep object: $exe" >> $logfile
	found=""
	path_to_file=""
	valid_search_paths=""

	#filename=`echo $exe | cut -d'-' -f1 | sed -e 's/%/-/g'`
	filename=`echo $exe`
	echo "Filename: $filename" >> $logfile

	#fileuse=`ccm finduse $exe -prep_proj | grep "@" | egrep "MAINT|PATCH|INSTALL|TEST|LANG|SDK"`
	fileuse=`find $build_workarea/ -type f -name $exe`
	#delivery_project=`echo $fileuse | cut -d'@' -f2 | cut -d' ' -f1`
	delivery_project=$install_workarea
	#if [ -z "$fileuse" ]
	#then	
	#	total_warns=`expr $total_warns + 1`
	#	echo "[WARN] - $filename has no delivery project" 2>&1 | LogScreenFile
	#	continue
	#fi
	echo "fileuse = $fileuse" >> $logfile
	#filepartpath=`echo $fileuse | cut -d'@' -f1 | sed -e 's/-[0-9\.]*$//; s/	//g'`
	#filepartpath=`echo $fileuse | cut -d'@' -f1 | cut -d'-' -f1 | sed -e 's/	//g'`
	#proj_patch=`echo $filepartpath | cut -d'/' -f1|sed -e 's/RB//g' -e 's/GENEVA//g' -e 's/TAP3//g' -e 's/VI_X//g' -e 's/VI_CTL//g' -e 's/VI_STQ//g'`
	proj_patch=`echo $build_workarea |cut -d'/' -f7|cut -d'-' -f1|sed -e 's/RB//g' -e 's/GENEVA//g' -e 's/TAP3//g' -e 's/VI_X//g' -e 's/VI_CTL//g' -e 's/VI_STQ//g'`
	echo $proj_patch >> $logfile
#	echo "filepartpath = $filepartpath" >> $logfile

	#project_name=`echo $fileuse | cut -d'@' -f2 | cut -d'-' -f1 | sed -e 's/	//g'`
	project_name=`echo $build_workarea |cut -d'/' -f7|cut -d'-' -f1`
	project_patch=$project_name
	#project_version=`echo $fileuse | cut -d'@' -f2 | cut -d'-' -f2 | sed -e 's/	//g'|cut -d' ' -f1`
	project_version=`echo $fileuse | cut -d'@' -f2 | cut -d'-' -f2 | sed -e 's/	//g'|cut -d' ' -f1`
	if [ "${project_name}" = "ECAINSTALL" ]
	then

	project_version=`echo $fileuse | cut -d'@' -f2 | cut -d'-' -f2 | sed -e 's/	//g'`
		echo "release project = $project_name-$project_version" >> $logfile
		release_platform=`ccm query "type='project' and name='ECAINSTALL' and version='${project_version}'" -u -f "%platform" | sed -e 's/ *$//g'`
	fi

	#install_project=`echo $delivery_project | cut -d'-' -f1`
	#install_version=`echo $delivery_project | cut -d'-' -f2`

	#install_maintained_wa=`ccm query -t project "project='${install_project}' and version='${install_version}'"`
	#install_maintained_wa=`ccm attr -s maintain_wa @`
	#if [ "$install_maintained_wa" != "TRUE" ]
	#then
	#	echo "ccm query -t project \"project='${install_project}' and version='${install_version}'\""
	#	echo install_maintained_wa
	#	exit_program 4
	#fi

	# workout the workarea for the file in the install project.
	#install_workarea=`ccm query -t project "name = '${install_project}' and version = '${install_version}'" -f "%wa_path" -u`
	#install_workarea=`echo $install_workarea | cut -d' ' -f1`
	#install_workarea="${install_workarea}/${filepartpath}"

	#if [ ! -f "$install_workarea" ]
	#then
	#	total_errors=`expr $total_errors + 1`
	#	echo "[ERROR] - This directory doesn't exist: $install_workarea" 2>&1 | LogScreenFile
	#	continue
	#fi

	#the_dir=`dirname $build_workarea`
	the_dir=`dirname $fileuse`
	echo " work area is $the_dir...."
	thebase=`basename $the_dir`

	# This states where to find built objects in the build_project.
        # If a prep object is found in the exe directory of an install project
        # then it may be located in the RELEASE directory of
        # the build project. More than one path can be listed for the location
	# in the build area. Must be seperated by a <space>.
	case "${thebase}" in
	bin)
		valid_search_paths='ALLBATCH/bin ALLBATCH/test_bin bin lib VERTEX/bin prod/bin';
		;;
	mibs)
		valid_search_paths='ALLBATCH/bin/mibs';
		;;
	sbin)
		valid_search_paths='prod/sbin';
		;;
	install)
		valid_search_paths='prod/install';
		;;
	db1)
		valid_search_paths='prod/install/db1';
		;;
	scripts)
		valid_search_paths='prod/install/db1/scripts';
		;;
	pkg)
		valid_search_paths='prod/install/pkg';
		;;
	libAlternate_HPpthread)
		valid_search_paths='prod/libAlternate_HPpthread';
		;;
	Binaries)
		valid_search_paths='ALLBATCH/bin ALLBATCH/test_bin';
		;;
	etc)
		valid_search_paths='prod/etc';
		;;
	lib)
		valid_search_paths='ALLBATCH/lib ALLBATCH/test_lib ALLBATCH/test_plugin lib VERTEX/lib prod/lib build_release_all/distrib/external/jar build_release_all/distrib/external/ear/weblogic_8_1 build_release_all/distrib/external/jar/weblogic_9_1 build_release_eca/distrib/external/ear/weblogic_8_1 build_output/distrib/external/weblogic_10_0 build_output/distrib/external/weblogic_9_1 build_output/distrib/external/weblogic_10_3 ALLBATCH/java';
		if [ "${project_name}" = "ECAINSTALL" -a "${release_platform}" = "JAVA-Weblogic-Oracle10g" -o "${release_platform}" = "JAVA-Weblogic-Oracle11g" ]
		then
			valid_search_paths='build_release_all/distrib/external/jar/weblogic_9_1 build_release_all/distrib/external/jar build_release_all/distrib/external/war/weblogic_9_1 build_release_all/distrib/external/war build_release_all/distrib/external/ear/weblogic_9_1 build_release_all/distrib/external/ear build_output/distrib/external/weblogic_10_0 build_output/distrib/external/weblogic_9_1 build_output/eci/deliverables/weblogic_10_0 build_output/eci/deliverables/weblogic_9_1 build_output/ekm/deliverables/weblogic_10_0 build_output/ekm/deliverables/weblogic_9_1 build_output/eca.tca/deliverables/weblogic_10_0 build_output/eca.tca/deliverables/weblogic_9_1 build_output/eca.tca/deliverables/weblogic_10_3 build_output/distrib/external/weblogic_10_3 build_output/ekm/deliverables/weblogic_10_3 build_output/eci/deliverables/weblogic_10_3';
		elif [ "${project_name}" = "ECAINSTALL" -a "${release_platform}" = "JAVA-Jboss-Oracle10g" -o "${release_platform}" = "JAVA-Jboss-Oracle11g" ]
		then
			valid_search_paths='build_release_all/distrib/external/jar/jboss_4_0 build_release_all/distrib/external/jar build_release_all/distrib/external/war/jboss_4_0 build_release_all/distrib/external/war build_release_all/distrib/external/ear/jboss_4_0 build_release_all/distrib/external/ear build_output/distrib/external/jboss_4_0 build_output/eci/deliverables/jboss_4_0 build_output/ekm/deliverables/jboss_4_0 build_output/eca.tca/deliverables/jboss_4_0 build_output/distrib/external/jboss_4_2 build_release_all/distrib/external build_output/eci/deliverables/jboss_4_2 build_output/ekm/deliverables/jboss_4_2 build_output/eca.tca/deliverables/jboss_4_2 build_output/distrib/external/jboss_5_2 build_release_all/distrib/external build_output/eci/deliverables/jboss_5_2 build_output/ekm/deliverables/jboss_5_2 build_output/eca.tca/deliverables/jboss_5_2 build_output/distrib/external/jboss_6_1 build_release_all/distrib/external build_output/eci/deliverables/jboss_6_1 build_output/ekm/deliverables/jboss_6_1 build_output/eca.tca/deliverables/jboss_6_1';
		elif [ "${project_name}" = "ECAINSTALL" -a "${release_platform}" = "JAVA-Websphere-Oracle10g" ]
		then
			#RBClient.jar for websphere needs to be picked up from distrib/external/jar/websphere_6_1 rather than distrib/external/jar
			valid_search_paths='build_release_all/distrib/external/jar/websphere_6_1 build_release_all/distrib/external/jar build_release_all/distrib/external/war/websphere_6_1 build_release_all/distrib/external/war build_release_all/distrib/external/ear/websphere_6_1 build_release_all/distrib/external/ear build_output/eci/deliverables/websphere_6_1 build_output/ekm/deliverables/websphere_6_1 build_output/eca.tca/deliverables/websphere_6_1';
		fi
		;;
	stub)
		valid_search_paths='prod/lib/stub';
		;;
	Libraries)
		valid_search_paths='ALLBATCH/lib ALLBATCH/test_lib ALLBATCH/test_plugin';
		;;
	Post_Config_DB)
		valid_search_paths='ALLBATCH/bin';
		;;
	procedures)
		valid_search_paths='sql sqlbdy build_release_eca/distrib/external/schema/eca/procedures ALLBATCH/sqlbdy ALLBATCH/sqlspc API/sqlbdy API/sqlspc build_release_all/distrib/external/schema/eca/procedures build_output/distrib/external/schema/eca/procedures';
		;;
	definitions)
		valid_search_paths='APICAT/ppet/SRC'
		;;
	tap3config|tap3management)
		valid_search_paths='sqlbdy sqlspc';
		;;
	weblogic)
		valid_search_paths='build_release_eca/distrib/external/jar/weblogic';
		;;
        weblogic_8_1)
		valid_search_paths='build_release_eca/distrib/external/jar/weblogic_8_1 build_release_eca/tmp/jaas_config/weblogic_8_1 build_release_eca/distrib/external/jar/weblogic_8_1 build_release_all/distrib/external/ear/weblogic_8_1 build_release_all/distrib/external/jar/weblogic_8_1 build_release_all/distrib/external/ear/weblogic_8_1';
		;;
        weblogic_9_1)
		valid_search_paths='build_output/distrib/internal/weblogic_9_1';
		;;
        weblogic_10_0)
		valid_search_paths='build_output/distrib/internal/weblogic_10_0';
		;;
 	weblogic_10_3)
                valid_search_paths='build_output/distrib/internal/weblogic_10_3';
                ;;
	EKM.ear)
		valid_search_paths='build_release_all/distrib/external/war build_release_all/distrib/external/jar build_release_all/distrib/external/jar/weblogic_9_1 build_output/distrib/external/weblogic_10_0 build_output/distrib/external/weblogic_9_1 build_output/distrib/external/weblogic_10_3';
		if [ "${project_name}" = "ECAINSTALL" -a "${release_platform}" = "JAVA-Weblogic-Oracle10g" -o "${release_platform}" = "JAVA-Weblogic-Oracle11g"  ]
		then
			valid_search_paths='build_release_all/distrib/external/jar/weblogic_9_1 build_release_all/distrib/external/jar build_release_all/distrib/external/war/weblogic_9_1 build_release_all/distrib/external/war build_release_all/distrib/external/ear/weblogic_9_1 build_release_all/distrib/external/ear build_output/distrib/external/weblogic_10_0 build_output/distrib/external/weblogic_9_1 build_output/distrib/external/weblogic_10_3';
		elif [ "${project_name}" = "ECAINSTALL" -a "${release_platform}" = "JAVA-Jboss-Oracle10g" -o "${release_platform}" = "JAVA-Jboss-Oracle11g" ]
		then
			valid_search_paths='build_release_all/distrib/external/jar/jboss_4_0 build_release_all/distrib/external/jar build_release_all/distrib/external/war/jboss_4_0 build_release_all/distrib/external/war build_release_all/distrib/external/ear/jboss_4_0 build_release_all/distrib/external/ear build_output/distrib/external/jboss_4_0 build_release_all/distrib/external/jboss_4_2 build_release_all/distrib/external build_output/eci/deliverables/jboss_4_2 build_output/ekm/deliverables/jboss_4_2 build_output/eca.tca/deliverables/jboss_4_2 build_release_all/distrib/external/jboss_5_2 build_release_all/distrib/external build_output/eci/deliverables/jboss_5_2 build_output/ekm/deliverables/jboss_5_2 build_output/eca.tca/deliverables/jboss_5_2 build_release_all/distrib/external/jboss_6_1 build_release_all/distrib/external build_output/eci/deliverables/jboss_6_1 build_output/ekm/deliverables/jboss_6_1 build_output/eca.tca/deliverables/jboss_6_1';
		elif [ "${project_name}" = "ECAINSTALL" -a "${release_platform}" = "JAVA-Websphere-Oracle10g" ]
		then
			valid_search_paths='build_release_all/distrib/external/jar/websphere_6_1 build_release_all/distrib/external/jar build_release_all/distrib/external/war/websphere_6_1 build_release_all/distrib/external/war build_release_all/distrib/external/ear/websphere_6_1 build_release_all/distrib/external/ear build_output/distrib/external/websphere_6_1';
		fi
		;;
	CDS.ear)
		valid_search_paths='build_release_all/distrib/external/jar build_release_all/distrib/external/war build_output/distrib/external/weblogic_10_0 build_output/distrib/external/weblogic_9_1 build_output/distrib/external/weblogic_10_3';
		if [ "${project_name}" = "ECAINSTALL" -a "${release_platform}" = "JAVA-Weblogic-Oracle10g" -o "${release_platform}" = "JAVA-Weblogic-Oracle11g" ]
		then
			valid_search_paths='build_release_all/distrib/external/jar/weblogic_9_1 build_release_all/distrib/external/jar build_release_all/distrib/external/war/weblogic_9_1 build_release_all/distrib/external/war build_release_all/distrib/external/ear/weblogic_9_1 build_release_all/distrib/external/ear build_output/distrib/external/weblogic_10_0 build_output/distrib/external/weblogic_9_1 build_output/distrib/external/weblogic_10_3';
		elif [ "${project_name}" = "ECAINSTALL" -a "${release_platform}" = "JAVA-Jboss-Oracle10g" -o "${release_platform}" = "JAVA-Jboss-Oracle11g" ]
		then
			valid_search_paths='build_release_all/distrib/external/jar/jboss_4_0 build_release_all/distrib/external/jar build_release_all/distrib/external/war/jboss_4_0 build_release_all/distrib/external/war build_release_all/distrib/external/ear/jboss_4_0 build_release_all/distrib/external/ear build_release_all/distrib/external/jboss_4_2 build_release_all/distrib/external build_output/eci/deliverables/jboss_4_2 build_output/ekm/deliverables/jboss_4_2 build_output/eca.tca/deliverables/jboss_4_2 build_release_all/distrib/external/ear build_release_all/distrib/external/jboss_5_2 build_release_all/distrib/external build_output/eci/deliverables/jboss_5_2 build_output/ekm/deliverables/jboss_5_2 build_output/eca.tca/deliverables/jboss_5_2 build_release_all/distrib/external/jboss_6_1 build_release_all/distrib/external build_output/eci/deliverables/jboss_6_1 build_output/ekm/deliverables/jboss_6_1 build_output/eca.tca/deliverables/jboss_6_1';
		elif [ "${project_name}" = "ECAINSTALL" -a "${release_platform}" = "JAVA-Websphere-Oracle10g" ]
		then
			valid_search_paths='build_release_all/distrib/external/jar/websphere_6_1 build_release_all/distrib/external/jar build_release_all/distrib/external/war/websphere_6_1 build_release_all/distrib/external/war build_release_all/distrib/external/ear/websphere_6_1 build_release_all/distrib/external/ear';
		fi
		;;
	websphere_5_0)
		valid_search_paths='build_release_eca/distrib/external/jar/websphere_5_0';
		;;
	websphere_5_1)
		valid_search_paths='build_release_eca/distrib/external/jar/websphere_5_1 build_release_eca/tmp/jaas_config/websphere_5_1 build_release_all/distrib/external/jar/websphere_5_1';
		;;
	websphere_6_1)
		valid_search_paths='build_release_eca/distrib/external/jar/websphere_6_1 build_release_eca/tmp/jaas_config/websphere_6_1 build_release_all/distrib/external/jar/websphere_6_1 build_output/distrib/external/websphere_6_1';
		;;
	websphere)
		valid_search_paths='build_release_eca/distrib/external/jar/websphere_5_1';
		;;
	java)
		valid_search_paths='build_release_eca/distrib/internal/jar build_release_eca/distrib/internal/doc build_release_all/distrib/internal/jar ALLBATCH/java';
		;;
	Base)	valid_search_paths='build_release_all/distrib/internal/webservices/client/schema/Base build_output/distrib/internal/webservices/schema/Base';
		;;
	ECA)	valid_search_paths='build_release_all/distrib/internal/webservices/client/schema/ECA build_release_all/distrib/internal/webservices/client/schema/Base build_release_all/distrib/internal/webservices/client/schema/ECA build_release_all/distrib/internal/webservices/client/wsdl/ECA build_output/distrib/internal/webservices/wsdl/ECA build_output/webservices/deliverables/schema/ECA';
		;;
	CommonIML)
		valid_search_paths='build_release_all/distrib/internal/webservices/client/schema/ECA build_release_all/distrib/internal/webservices/client/schema/Base build_release_all/distrib/internal/webservices/client/schema/ECA build_release_all/distrib/internal/webservices/client/wsdl/ECA build_release_all/distrib/internal/webservices/client/schema/CommonIML build_output/distrib/internal/webservices/schema/CommonIML';
		;;
	jboss_3_2)
		valid_search_paths='build_release_eca/distrib/external/jar/jboss_3_2 build_release_eca/tmp/jaas_config/jboss_3_2 build_release_all/distrib/external/jar/jboss_3_2 build_release_all/distrib/external/ear/jboss_3_2';
		;;	
	jboss_4_2)
		valid_search_paths='build_release_eca/distrib/external/jar/jboss_4_2 build_release_eca/tmp/jaas_config/jboss_4_2 build_release_all/distrib/external/jar/jboss_4_2 build_release_all/distrib/external/ear/jboss_4_2 build_output/distrib/external/jboss_4_2';
		;;	
 	jboss_5_2)
valid_search_paths='build_release_eca/distrib/external/jar/jboss_5_2 build_release_eca/tmp/jaas_config/jboss_5_2 build_release_all/distrib/external/jar/jboss_5_2 build_release_all/distrib/external/ear/jboss_5_2 build_output/distrib/external/jboss_5_2';
		;;
	jboss_6_1)
valid_search_paths='build_release_eca/distrib/external/jar/jboss_6_1 build_release_eca/tmp/jaas_config/jboss_6_1 build_release_all/distrib/external/jar/jboss_6_1 build_release_all/distrib/external/ear/jboss_6_1 build_output/distrib/external/jboss_6_1';
                ;;
	jboss_3_0)
		valid_search_paths='build_release_eca/distrib/external/jar/jboss_3_0';
		;;
	jboss_2_4)
		valid_search_paths='build_release_eca/distrib/external/jar/jboss_2_4';
		;;
	client)
		valid_search_paths='build_release_eca/distrib/external/client build_release_all/distrib/external/client';
		;;
	server)
		valid_search_paths='build_release_all/distrib/internal/webservices/server';
		;;
	mess)
		valid_search_paths='mess';
		;;
	eng)
		valid_search_paths='SCHEMA/mess/eng';
		;;
	api)
		valid_search_paths='ALLBATCH/java';
		;;
	schema)
                valid_search_paths='ALLBATCH/schema schema';
                ;;
	RBIUH)
                valid_search_paths='ALLBATCH/RBIUH';
                ;;

	include)
                valid_search_paths='ALLBATCH/include';
                ;;

	eca)
		valid_search_paths='build_release_eca/distrib/external build_release_eca/distrib/external/jar build_release_all/distrib/external/jar build_release_all/distrib/external build_output/distrib/external';
		;;
        rb)
                valid_search_paths='ALLBATCH/java';
                ;;
        ECA.ear)
                valid_search_paths='build_release_all/distrib/external/ear/weblogic_8_1 build_release_eca/distrib/external/ear/weblogic_8_1 build_release_all/distrib/external/jar/weblogic_9_1 build_release_all/distrib/external/jar build_output/distrib/external/weblogic_10_0 build_output/distrib/external/weblogic_9_1 build_output/distrib/external/weblogic_10_3 build_output/webservices/deliverables';
		if [ "${project_name}" = "ECAINSTALL" -a "${release_platform}" = "JAVA-Weblogic-Oracle10g" -o "${release_platform}" = "JAVA-Weblogic-Oracle11g" ]
		then
			valid_search_paths='build_release_all/distrib/external/jar/weblogic_9_1 build_release_all/distrib/external/jar build_release_all/distrib/external/war/weblogic_9_1 build_release_all/distrib/external/war build_release_all/distrib/external/ear/weblogic_9_1 build_release_all/distrib/external/ear build_output/distrib/external/weblogic_10_0 build_output/distrib/external/weblogic_9_1 build_output/distrib/external/weblogic_10_3 build_output/webservices/deliverables';
		elif [ "${project_name}" = "ECAINSTALL" -a "${release_platform}" = "JAVA-Jboss-Oracle10g" -o "${release_platform}" = "JAVA-Jboss-Oracle11g" ]
		then
			valid_search_paths='build_release_all/distrib/external/jar/jboss_4_0 build_release_all/distrib/external/jar build_release_all/distrib/external/war/jboss_4_0 build_release_all/distrib/external/war build_release_all/distrib/external/ear/jboss_4_0 build_release_all/distrib/external/ear build_output/distrib/external/jboss_4_0 build_release_all/distrib/external/jboss_4_2 build_release_all/distrib/external build_output/eci/deliverables/jboss_4_2 build_output/ekm/deliverables/jboss_4_2 build_output/eca.tca/deliverables/jboss_4_2 build_release_all/distrib/external/jboss_5_2 build_release_all/distrib/external build_output/eci/deliverables/jboss_5_2 build_output/ekm/deliverables/jboss_5_2 build_output/eca.tca/deliverables/jboss_5_2 build_release_all/distrib/external/jboss_6_1 build_release_all/distrib/external build_output/eci/deliverables/jboss_6_1 build_output/ekm/deliverables/jboss_6_1 build_output/eca.tca/deliverables/jboss_6_1';
		elif [ "${project_name}" = "ECAINSTALL" -a "${release_platform}" = "JAVA-Websphere-Oracle10g" ]
		then
			valid_search_paths='build_release_all/distrib/external/jar/websphere_6_1  build_release_all/distrib/external/jar build_release_all/distrib/external/war/websphere_6_1 build_release_all/distrib/external/war build_release_all/distrib/external/ear/websphere_6_1 build_release_all/distrib/external/ear build_output/distrib/external/websphere_6_1';
		fi
                ;;
 
	jar)
		valid_search_paths='build_release_eca/distrib/external build_release_eca/distrib/external/jar build_release_all/distrib/external/jar build_output/distrib/external/weblogic_10_0 build_output/distrib/external/weblogic_9_1 build_output/distrib/external/weblogic_10_3';
		;;
	*)
		total_errors=`expr $total_errors + 1`
		echo "[ERROR] - Unknown location for file: $filename using: $thebase ---" 2>&1 | LogScreenFile
		continue
		;;
	esac

	# for each of the valid paths recognised in the case above, look for the file.
	for valid_path in $valid_search_paths
	do
		echo "Looking in dir: ${build_workarea}/${valid_path}" >> $logfile
		if [ ! -d ${build_workarea}/${valid_path} ]
		then
			echo "	but directory does not exists" >> $logfile
			continue
		fi
		path_to_file=`echo "${build_workarea}/${valid_path}/${filename}"`
		echo "Looking for specific file: $path_to_file" >> $logfile
		if [ -f "$path_to_file" ]
		then
			found="$path_to_file"
			break
		fi
	done

	if [ ! -f "$path_to_file" ]
	then
		total_errors=`expr $total_errors + 1`
		echo "[ERROR] - Can not find the file $filename in the build area" 2>&1 | LogScreenFile
		echo "- Used paths: $valid_search_paths" >> $logfile
		continue
	fi

#	The actual copy command. If a symlink exists as the source file, then the file has already been
#	copied. If the file is not a symlink, then copy the file to the destination, remove the built file
#	from the source location and createa  symlink in its place, to the destination file.

#	Because alot of GPI is alittle wierd, some of the stuff we are trying to copy is already symlinks
#	co have to copy every time.
	echo Copying $found to $install_workarea >> $logfile
	if [ "$project" = "GPI" -o "$project" = "GPITEST" ]
	then
		cp -p $found $install_workarea/$thebase >> $logfile 2>&1
		error_code=$?
		if [ "${error_code}" -ne 0 ]
		then
			echo "[ERROR] - Error code from copy command (cp) for GPI = $error_code" 2>&1 | LogScreenFile
			total_errors=`expr $total_errors + 1`
		else
			total_success=`expr $total_success + 1`
			echo "[SUCCESS] - GPI Copy Successful: $filename to $delivery_project" 2>&1 | LogScreenFile
			for i in `echo $fileuse`
			do
				project_type_name=`echo $i | cut -d'/' -f1`
				projectType=`what_suffix $project_type_name`
				echo "$delivery_types_done" | grep "$projectType" > /dev/null 2>&1
				if [ $? -ne 0 ]
				then
					delivery_types_done="$delivery_types_done $projectType"
				fi
			done
		fi
		
	else
		if [ ! -h "$found" ]
		then

			cp -p $found $install_workarea/$thebase >> $logfile 2>&1
			error_code=$?
			if [ "${error_code}" -ne 0 ]
			then
				echo "[ERROR] - Error code from copy command (cp) = $error_code" 2>&1 | LogScreenFile
				total_errors=`expr $total_errors + 1`
			else
				total_success=`expr $total_success + 1`
				echo "[SUCCESS] - Copy Successful: $filename" 2>&1 | LogScreenFile
				#rm $found >> $logfile
				#ln -s $install_workarea $found >> $logfile
				for i in `echo $fileuse`
				do
					project_type_name=`echo $i | cut -d'/' -f1`
					projectType=`what_suffix $project_type_name`
					echo "$delivery_types_done" | grep "$projectType" > /dev/null 2>&1
					if [ $? -ne 0 ]
					then
						delivery_types_done="$delivery_types_done $projectType"
					fi
				done
			fi
		else
			echo "[RECONCILED] - File is already reconciled: $filename" 2>&1 | LogScreenFile
			total_reconcile=`expr $total_reconcile + 1`
		fi
	fi
cp -p $release_info_path $install_workarea/bin/release_info.xml
	
done

# Run the configuration updater (5.3IN and 5.4+ releases, RB and GENEVA only, not patches)
if [ "$project" = "GENEVA" -o "$project" = "RB" ]
then
	if [ "${HeadRelease}" = "TRUE" ];then
		ReturnStatus=1
	else
		am_i_a_patch ${RELEASE_TAG}
		ReturnStatus=$?
	fi
    if [ ${ReturnStatus} -ne 0 ]
    then
	update_config=yes
	if [ "$project" = "GENEVA" ]
	then
		case $major_release in
			4.0|4.1|4.2|5.0|5.1|5.2|5.3)
				update_config=no
				;;
			*)
				update_config=yes
		esac
	fi

	if [ "$update_config" = "yes" -a "${UpdateInfo}" = "TRUE" ]
	then
		$build_scripts/release_config_updater.sh $FULL_PROJECT
	fi
    fi
fi

if [ "$project" = "GPI" ]
then
	echo "Running copy_gpi_plugin.sh hp64"
	gpi_copy_plugin.sh hp64
	echo "Running copy_gpi_plugin.sh solaris"
	gpi_copy_plugin.sh solaris
fi

# This is the section which prints out the summary
echo ""  2>&1 | LogScreenFile
printf "\t\n ------------------------------------------------ \n" 2>&1 | LogScreenFile
printf "\t[INFO] Summary for $FULL_PROJECT copy\n" 2>&1 | LogScreenFile
printf "\t -------------------------------------------------\n" 2>&1 | LogScreenFile
printf "\tTotal files   		= $total_files\n"	2>&1 | LogScreenFile
printf "\tTotal success 		= $total_success\n" 2>&1 | LogScreenFile
printf "\tTotal already reconciled 	= $total_reconcile\n" 2>&1 | LogScreenFile
printf "\tTotal errors  		= $total_errors\n" 2>&1 | LogScreenFile
printf "\tTotal warns   		= $total_warns\n" 2>&1 | LogScreenFile
printf "\t ------------------------------------------------- \n" 2>&1 | LogScreenFile
printf "\t[INFO] Please review $logfile to help solve errors and warnings\n" 2>&1 | LogScreenFile
printf "\t -------------------------------------------------\n" 2>&1 | LogScreenFile

if [ $total_success -eq 0 ]
then
	echo "########################################################"
	echo "#                                                      #"
	echo "#             WARNING: Nothing Copied                  #"
	echo "#                                                      #"
	echo "########################################################"
fi

echo delivery_types_done = $delivery_types_done
if [ $total_success -gt 0 ]
then
	for i in $delivery_types_done
	do
		printf "\t[INFO] Updating build information update_build_information.sh -p ${project} -s ${STATE} -u "${Username} -v ${RELEASE_NUMBER} -C ${html_log_file} -i ${candidate} -j ${i} -T \n" 2>&1 | LogScreenFile
		update_build_information.sh -p "${project}" -s ${STATE} -u "${Username} -v "${RELEASE_NUMBER}" -C "${html_log_file}" -i "${candidate}" -j "${i}" -T

if [ $total_success -gt 0 -a $total_errors -eq 0 -a "$proj_patch" = "PATCH" ]
then
	printf "\t ------------------------------------------------- \n" 2>&1 | LogScreenFile
	printf "\t[INFO] Started Export command for generating candidate \n" 2>&1 | LogScreenFile
	printf "\t ------------------------------------------------- \n" 2>&1 | LogScreenFile
	printf "\t[INFO] No errors found in copy build objects \n" 2>&1 | LogScreenFile
	printf "\t[INFO] export_geneva_patch -s $STATE -r $RELEASE_NUMBER -p $project -t $proj_patch -e /irb/candidate/patch/$PROJECT_low/$major_release/$RELEASE_TAG.$candidate -u $Username \n" 2>&1 | LogScreenFile
	export_geneva_patch -s $STATE -r $RELEASE_NUMBER -p $project -t $proj_patch -e /irb/candidate/patch/$PROJECT_low/$major_release/$RELEASE_TAG.$candidate -u $Username 2>&1 | LogScreenFile
	printf "\t -------------------------------------------------\n" 2>&1 | LogScreenFile
	printf "\t[INFO] Completed Export command for generating candidate\n" 2>&1 | LogScreenFile
	printf "\t -------------------------------------------------\n" 2>&1 | LogScreenFile
else
	printf "\t -----------------------------------------------------------\n" 2>&1 | LogScreenFile
	printf "\t[INFO] errors in copy build objects, not kicking off export geneva\n" 2>&1 | LogScreenFile
	printf "\t -----------------------------------------------------------\n" 2>&1 | LogScreenFile
fi

	done

	BUILDWEB_DB=`buildweb_connection`
	if [ "$proj_platform" = "web" ]
	then
		platform_query="(platform_OS='${proj_platform}' or platform_OS='web(release)')"
	elif [ "$proj_platform" = "pc" ]
	then
		platform_query="platform_OS='${proj_platform}' and platform_other is null"
	else
		platform_query="platform_OS='${proj_platform}' and platform_other='$proj_oracle'"
	fi
	sql="select build_id from build_results where project='${project}' and version='${RELEASE_NUMBER}' and buildstate='$STATE' and $platform_query order by START_TIME DESC"
	echo $sql
	build_id_tmp=`sql_query $BUILDWEB_DB "$sql" "y"`
	if [ $? -ne 0 ]
	then
		echo "Error: Adding to BUILD_RES_TO_TEST_CAND table"
		echo "sql string: $sql"
	else
		build_id=`echo $build_id_tmp | awk '{print $1}'`
		echo "Build_ID = $build_id"
		update_build_information.sh -p "${project}" -v "${RELEASE_NUMBER}" -i "${candidate}" -j "${STATE}" -K $build_id -Q
	fi
fi

exit_program 0
