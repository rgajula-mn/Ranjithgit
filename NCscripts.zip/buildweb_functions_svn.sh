#! /bin/sh
#set -x
################################################################
# Script Name : buildweb_functions_svn.sh
# Version No. : 1
# Instance No.: 1
# Last Author : rb3
# Description : A collection of utility functions, used by 
# 		other scripts to interact with the build 
#               intranet.
# (C) Convergys, 2002. Convergys refers to Convergys
# Corporation or any of its wholly owned subsidiaries.
################################################################

################################################################
# addRelToBuild:
################################################################
# This function will add an entry to the releases to build
# By default the release is entered in the last position for all
# days of the week
# INPUT:  Release Tag, State, Team Mode
# OUTPUT: Return value
# Possible inputs:
#	1: Release Tag, e.g., GEN_5.3.8
#	2: State, e.g., dev, cov, mul, sqa, test
#	3: Team Mode, e.g., BCE, ICE
#	4: Build Mode, e.g., prebuild, build, postbuild
#	5: debug mode, e.g, TRUE, FALSE
#	6: User, e.g, sg, rb3
#	7: Build Time, e.g, 20:00, 05:00
#	8: Build Type, e.g, all, dbuser, env
# Possible outputs:
#	0: Success
#       >1: Failure
################################################################

addBuildToIntranet () {
# Process inputs
	relTag=$1
	buildState=$2
	teamMode=$3
	buildMode=$4
	debug_on=$5
	Username=$6
	buildTime=$7
	buildType=$8
	
# Do we have Oracle?	
	script_debug "[DEBUG] Validating Oracle..." ${debug_on}
	validOracle=""
	for amValidOracle in `ls /opt/oracle`
	do
		amValidOracle="/opt/oracle/${amValidOracle}"
		script_debug "[DEBUG] Looking to use Oracle from ${amValidOracle}" ${debug_on}
		if [ -f "${amValidOracle}/bin/sqlplus" ]
		then
			valid_oracle=$amValidOracle
		fi
	done
	if [ -z "${valid_oracle}" ]
	then
		script_debug "[DEBUG] Oracle not found - unable to add release to intranet build pages" ${debug_on}
		return 1
	fi
# Oracle available - needed to interact with the build intranet databases
	DATABASE="buildweb/georgespass@webca.world"
	
# Validate inputs
# Check for a release tag	
	if [ -z "${relTag}" ]
	then
		script_debug "[DEBUG] Release tag was empty" ${debug_on}
		return 1
	fi
# Check for a state	
	echo ${buildState} | egrep "cov|dev|mul|sqa|test" > /dev/null
	if [ $? -ne 0 ]
	then
		script_debug "[DEBUG] Build State [${buildState}] is not valid" ${debug_on}
		return 1
	fi
# Check for a team mode
	echo ${teamMode} | egrep "BCE|ICE" > /dev/null
	if [ $? -ne 0 ]
	then
		script_debug "[DEBUG] Team Mode [${teamMode}] not valid setting to BCE" ${debug_on}
		teamMode="BCE"
	fi
# Check for a build mode
	echo ${buildMode} | egrep "prebuild|build|postbuild" > /dev/null
	if [ $? -ne 0 ]
	then
		script_debug "[DEBUG] Build Mode [${buildMode}] is not valid" ${debug_on}
		return 1
	fi
# Check for a build time
	if [ -z "${buildTime}" ]
	then
		buildTime="20:00"
	fi
# Check for a build mode
	if [ -z "${buildType}" ]
	then
		buildType="all"
	fi

	script_debug "[DEBUG] Oracle found...Processing ${relTag}" ${debug_on}

# Translate release tag into someat that can be used
	tempy=`discover_release_tag.sh -t ${relTag}`
	projjy=`echo ${tempy} | cut -d' ' -f1`
	relTag=`echo ${tempy} | cut -d' ' -f2`
	script_debug "[DEBUG] Project: ${projjy}" ${debug_on}
	script_debug "[DEBUG] Release: ${relTag}" ${debug_on}
	
# Final stages done in SQL
# 1. Get the position for the new build in the database
	relPosition=`sqlplus -s $DATABASE << +ENDSQL
	set feed off
	set head off
	set scan on
	set lines 32767
	select max(position+1) from buildrel;
	exit
+ENDSQL`
	relPosition=`echo ${relPosition}`
# 2. Do the SQL stuff
	if [ ${relPosition} -gt 0 ]
	then
		script_debug "[DEBUG] ${projjy} ${relTag} ${buildMode} ${teamMode} will be added to [${relPosition}]" ${debug_on}
		sql_data=`sqlplus -s $DATABASE << +ENDSQL
		set feed off
		set head off
		set scan on
		set lines 32767
		insert into buildrel (project,version,buildstate,position) values ('${projjy}','${relTag}','${buildMode}',${relPosition});
		exit;
+ENDSQL`
		if [ $? -ne 0 ]
		then
			script_debug "[DEBUG] Cannot Connect to $DATABASE - unable to add release to intranet build pages" ${debug_on}
			echo $sql_data
			return 2
		else
			sql_data=`sqlplus -s $DATABASE << +ENDSQL
			set feed off
			set head off
			set scan on
			set lines 32767
			insert into reltobuildtype (project,version,buildtype,buildTime,buildteam,mon,tue,wed,thu,fri,sat,sun,target) values ('${projjy}','${relTag}','${buildState}','${buildTime}','${teamMode}','1','1','1','1','1','','','${buildType}');
			exit;
+ENDSQL`
			if [ $? -ne 0 ]
			then
				script_debug "[DEBUG] Cannot Connect to $DATABASE - unable to add release to intranet build pages" ${debug_on}
				echo $sql_data
				return 2
			else
				script_debug "[DEBUG] Build intranet page has been updated" ${debug_on}
				reltobld_time=`date '+%Y%m%d%H%M%S'`
				$BCE_BUILD_SCRIPTS/update_build_information.sh -D -u $Username -p $projjy -v $relTag -l $reltobld_time
			fi
		fi
	fi
	return 0
}

buildweb_connection ()
{
	echo "buildweb/georgespass@webca.world"
}
cm_connection ()
{
	echo "cm_admin/nomad74auto@webca.world"
}


cpt_connection ()
{
	echo "cpt/cpt@webca.world"
}

rtestweb_connection ()
{
	echo "rtest/rtest@webca.world"
}

sql_query ()
{
	database=$1
	query="$2"
	query=`echo "$query" | sed -e 's/;$//g'`


	tmp_file=/tmp/buildweb_functions.$$
	touch $tmp_file
	if [ $? -ne 0 ]
	then
		echo "Error: Cannot create tmp file $tmp_file"
		rm $tmp_file
		return 1
	fi

	session_date=""
	if [ "$3" ]
	then
		session_date="ALTER SESSION SET NLS_DATE_FORMAT='dd-MON-rrrr hh24:mi:ss';"
	fi
	
	`sqlplus -s "$database" << +END > $tmp_file 2>&1
		set feed off
		set head off
		set scan on
		set pages 1000
		set lines 32767
		$session_date
		$query;
		commit;
		exit
+END`
	
	if [ $? -ne 0 ]
	then
		echo "Error: sqlplus failed to start"
		status=2
	else
		cat $tmp_file | grep "ERROR at line" > /dev/null
		status=$?
		if [ $status -eq 0 ]
		then
			status=1
		else
			status=0
		fi
	fi
	
	cat $tmp_file

	rm $tmp_file

	return $status
}

get_date_time_for_buildweb ()
{
	TIME_DATE=`date "+%Y%m%d%H%M%S"`
	echo $TIME_DATE
	return 0
}

