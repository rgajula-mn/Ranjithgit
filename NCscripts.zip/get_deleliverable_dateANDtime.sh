#!/bin/ksh
set -x

#. /home/geneva/.profile

export SVN_HOME=/tools/subversion-1.7.13
export PATH=$SVN_HOME/bin:$PATH
export LD_LIBRARY_PATH=$SVN_HOME/lib:$LD_LIBRARY_PATH

if [ ! "${BCE_BUILD_SCRIPTS}" ]
then
        BCE_BUILD_SCRIPTS=/irb/bce/admin/build_scripts
fi

#. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh
#. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
#. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh


releaseTag=$1
platform=$2
oracle=$3
projectType=$4
log_DT=$6
releaseNum=`echo $releaseTag | sed -e "s/.*_//g"`
project=`echo $releaseTag | sed -e "s/_.*//g"`
major_rel=`echo $releaseNum|cut -d'.' -f1-2`
REL_DB=$7
log_prt=$8
BuildWeb_DB="buildweb/georgespass@webca.world"
buildWorkarea=/irb/bce/build/rb/${major_rel}/${project}-${projectType}${releaseNum}.${platform}.${oracle}/${project}/ALLBATCH
workArea=/irb/bce/build/rb/${major_rel}/${project}-${projectType}${releaseNum}.${platform}.${oracle}/${project}/
echo "RELEASE TAG=$releaseTag"
echo "PLATFORM=$platform"
echo "ORACLE=$oracle"
echo "PROJECT TYPE=$projectType"
echo "RELEASE NUMBER=$releaseNum"
echo "Major Release=$major_rel"
echo "PROJECT=$project"

t_date=`date '+%Y%m%d'`
logdt=`date '+%Y%m%d%H%M%S'`
temp_path=$BCE_LOG/partialbuild
#touch $temp_path/deliverable_list_${logdt}_$releaseTag.txt
#touch $temp_path/deliverable_path_${logdt}_$releaseTag.txt
#touch $temp_path/failed_Del_list_${logdt}_${releaseTag}.txt
#touch $temp_path/incorrect_bdy_list_${logdt}_${releaseTag}.txt
echo "FILE = $temp_path/deliverable_list_${logdt}_$releaseTag.txt" >> $log_prt 2>&1

#function getTaskFileList ()
getTaskFileList ()
{
cpt_database=cpt/cpt@webca.world
task=$1
list=`sqlplus -s $cpt_database << +END
                whenever sqlerror exit failure
                set feed off
                set head off
               select OBJECT_NAMe from CM_ADMIN.CMOBJECT a,CPT.TASKHASCCMOBJECT b where a.OBJECT_ID=b.CCM_OBJECT_ID and b.TASK_NUMBER='$task';
                exit
+END`

for i in ${list[*]};do echo $i;done
}
. ${BCE_BUILD_SCRIPTS}/svn_new.svn
bdy_count=0
#function checkBdyVersionInfo ()
checkBdyVersionInfo ()
{
	del_dbys=$1
	found_path=`find ${workArea} -name $del_dbys -print`
	echo "found_path = $found_path"
        svn_last_change_rev_no=`svn info $found_path|grep 'Last Changed Rev'|cut -d':' -f2-`
        echo "##### IN PLB $i, DATABASE = ${REL_DB}, SVN REVISION CAPTURED From Build WrokArea = ${svn_last_change_rev_no}"
	file_name=`echo "$del_dbys"|cut -d'.' -f1`
	captured_version=`sqlplus -s $REL_DB << +END
        	set feed off;
                set head off;
		set lines 32767;
		select $file_name.getversion from dual;
		exit
+END`
	echo "Captured Revision No from DB is = ${captured_version}"
	output=`echo "${captured_version}"|grep ${svn_last_change_rev_no}`
	if [ $? -eq 0 ]
	then
		echo "$del_dbys is pulled properly"
	else
		echo "$del_dbys is not pulled properly"
		echo "$del_dbys" >> $temp_path/incorrect_bdy_list_${logdt}_${releaseTag}.txt
		bdy_count=`expr $bdy_count + 1`
	fi
}

printf "\n\n"
printf "\t[INFO] Delieverables existing in the patch\n"
printf "\t===========================================\n"

patchTasks=`sqlplus -s ${BuildWeb_DB} << +END
                        whenever sqlerror exit failure
                        set feed off
                        set head off
                       select TASK_NUMBER from TASK where RELEASE='$releaseTag';
                        exit
+END`

printf "\n\n"
for task in $patchTasks
do
        printf "\t[INFO] Querying task: $task.\n"
result=`sqlplus -s cpt/cpt@webca.world << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                select unique(deliverable_name) from submittedtaskdeliverable where task_number in ($task);
                exit
EOF`


	for deliverable in $result
	do
		#binary
		query_output=`echo $deliverable |grep -v "\." | egrep -v "Messages_VPA|Messages_API|Schema|APIs|None_-_Rtest_only$"`
		if [ $? -eq 0 ]
	        then
			echo $deliverable >> $temp_path/deliverable_list_${logdt}_$releaseTag.txt
		fi
		query_output=`echo $deliverable | grep "\.egg\$"`
	        if [ $? -eq 0 ]
        	then
                	echo $deliverable >> $temp_path/deliverable_list_${logdt}_$releaseTag.txt
	        fi
	
		#library
		query_output=`echo $deliverable | grep "\.so\$"`
        	if [ $? -eq 0 ]
	        then
        		if [ "$platform" = "itanium" -o "$platform" = "hp64" ]
                	then
	                	if [ $? -ne 0 ]
        	                then
                	        	deliverable=`echo $deliverable | sed 's/.so/.sl/'`
                        	fi
	                fi
			echo $deliverable >> $temp_path/deliverable_list_${logdt}_$releaseTag.txt
	        fi
		query_output=`echo $deliverable |egrep "ALL_BINARIES|ALL_LIBRARIES"`
	        if [ $? -eq 0 ]
        	then
        		if [ "$deliverable" = "ALL_BINARIES" ]
	                then
				echo "bin.zip" >> $temp_path/deliverable_list_${logdt}_$releaseTag.txt                      
                	else
				echo "lib.zip" >> $temp_path/deliverable_list_${logdt}_$releaseTag.txt
	                fi
        	fi	
		if [ "$deliverable" = "APIs" ]
		then
        		bdys=`getTaskFileList $task | grep "\.bdy\$"`
		        for plb in $bdys
        		do
                		if [ $? -eq 0 ]
	                	then
					echo "***** Calling checkBdyVersionInfo ******"
					checkBdyVersionInfo $plb
					echo "********* checkBdyVersionInfo DONE ********"
        		                plb=`echo $plb|sed 's/.bdy/.plb/g'`
					echo "$plb" >> $temp_path/deliverable_list_${logdt}_$releaseTag.txt
	                	fi
		        done
        		spcs=`getTaskFileList $task | grep "\.spc"\$`
		        for spc in $spcs
        		do
                		if [ "$spc" != "" ]
	                	then
					echo "$spc" >> $temp_path/deliverable_list_${logdt}_$releaseTag.txt
        		        fi
		        done
		fi
		query_output=`echo $deliverable | egrep "\.plb\$|\.bdy"`
		if [ $? -eq 0 ]
		then
			deliverable=`echo $deliverable|sed 's/.plb/.bdy/g'`
			echo "***** Calling checkBdyVersionInfo ******"
                        checkBdyVersionInfo $deliverable
                        echo "********* checkBdyVersionInfo DONE ********"
			deliverable=`echo $deliverable|sed 's/.bdy/.plb/g'`
			echo "$deliverable" >> $temp_path/deliverable_list_${logdt}_$releaseTag.txt	
		fi	
		query_output=`echo $deliverable | grep "\.spc\$"`
		if [ $? -eq 0 ]
		then
			spcs=$deliverable
        		for spc in $spcs
		        do
                		spcName=`echo $spcFileFourPart | cut -d":" -f1 | cut -d"-" -f1`
		                spcVersion=`echo $spcFileFourPart | cut -d":" -f1 | cut -d"-" -f2`
                		if [ "$spc" != "" ]
		                then
					echo "$deliverable" >> $temp_path/deliverable_list_${logdt}_$releaseTag.txt
                		fi
		        done
		fi

	done
done

echo "Done - Deliverable list file generated" >> $log_prt 2>&1
echo "$temp_path/deliverable_list_${logdt}_$releaseTag.txt" >> $log_prt 2>&1
#touch /irb/bce/arun_exe/file_path.txt

cat $temp_path/deliverable_list_${logdt}_$releaseTag.txt|sort|uniq > $temp_path/unique_deliverable_list_${logdt}_$releaseTag.txt
cat $temp_path/unique_deliverable_list_${logdt}_$releaseTag.txt|sort|uniq
total_files=`cat $temp_path/unique_deliverable_list_${logdt}_$releaseTag.txt|wc -l`
echo "${buildWorkarea}"

for i in `cat $temp_path/unique_deliverable_list_${logdt}_$releaseTag.txt`
do
	find ${buildWorkarea} -name $i -print >> $temp_path/deliverable_path_${logdt}_${releaseTag}.txt

done
scount=0
fcount=0
for i in `cat $temp_path/deliverable_path_${logdt}_${releaseTag}.txt`
do
	deliverable_dt=`date -r $i +%Y%m%d%H%M%S`
	echo "Deliverable $i Date and Time Stamp is = ${deliverable_dt}"
	if [ ${log_DT} -le ${deliverable_dt} ]
	then
		#echo "$i Generated Sucessfully"
		scount=`expr $scount + 1`		
	else
		#echo "********** Plesae check $i is not properly compiled, Date and Time Stamp is wrong ************"
		echo "$i" >> $temp_path/failed_Del_list_${logdt}_${releaseTag}.txt
		fcount=`expr $fcount + 1`	
	fi
done

#printf "Total $scount Deliverables are sucessfully Generated\n"
#printf "Total $fcount deliverables are incorrectly generated\n"

printf "\t===========================================\n" >> $log_prt 2>&1
printf "\tTotal Files                   = $total_files\n" >> $log_prt 2>&1
printf "\tTotal success                 = $scount\n" >> $log_prt 2>&1
printf "\tTotal Failed                  = $fcount\n" >> $log_prt 2>&1
printf "\t===========================================\n" >> $log_prt 2>&1

if [ $fcount -gt 0 -o $bdy_count -gt 0 ]
then
	if [ $bdy_count -gt 0 ]
	then
		printf "*******************************************\n" >> $log_prt 2>&1
		printf "\t List of Incorrectly Pulled Bdys\n" >> $log_prt 2>&1
		printf "*******************************************\n" >> $log_prt 2>&1
		cat $temp_path/incorrect_bdy_list_${logdt}_${releaseTag}.txt >> $log_prt 2>&1
		printf "*******************************************\n" >> $log_prt 2>&1
	fi
	printf "\t List of Failed Deliverablesis\n" >> $log_prt 2>&1
	cat $temp_path/failed_Del_list_${logdt}_${releaseTag}.txt >> $log_prt 2>&1
	exit
else
	api_lines=`cat /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}|wc -l`
	api_lines1=`cat /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle}|egrep 'API|GNVUA|REPORTS'|wc -l`
	
	if [ $api_lines -eq $api_lines1 ]
	then
        	echo "API related deliverables"
	        bld_errs1=`cat $log_prt|egrep 'Stale file handle|compilation errors'|grep -v clean|grep -v egrep|wc -l`
        	if [ $bld_errs1 -eq 0 ]
	        then
        	        echo "you can call autopatch script to generate the RC for this patch release only API related deliverables are there" >> $log_prt 2>&1
                	MAILTO=`cat /irb/bce/admin/email/head_build_managers`
	                MESSAGE="partial build is completeed successfully without any build errors, calling auto_patch_svn script for API related deliverables only"
        	        `echo $MESSAGE | mailx -s "${releaseTag}_${platform}_${oracle}.........PARTIAL BUILD" $MAILTO`
        	        echo "ssh genadmin@devapp655cn $BCE_BUILD_SCRIPTS/auto_patch_svn.sh $releaseTag $platform $oracle sqa sdavulur"  >> $log_prt 2>&1
                	ssh genadmin@devapp655cn "bash . ~/.bce.ini;. ~/.bashrc_new;$BCE_BUILD_SCRIPTS/auto_patch_svn.sh $releaseTag $platform $oracle sqa sdavulur"
	        else
        	        echo "build errors are there please check those errors in API modules" >> $log_prt 2>&1
	        fi
	else
        	echo "CC + API related deliverables"
	        bld_errs=`cat $log_prt|egrep 'Error 1|Error 2|Stale file handle|No rule to make target|collect2|compilation errors'|grep -v clean|grep -v egrep|wc -l`
        	if [ $bld_errs -eq 0 ]
	        then
        	        rm -rf $CCM_ROOT/ALLBATCH/lib/lib.zip $CCM_ROOT/ALLBATCH/bin/bin.zip
                	cd $CCM_ROOT/ALLBATCH/bin && zip -r bin.zip * -x '*.zip' -x '*.egg' -x 'GDBgen' -x 'TESTPERL'
	                cd $CCM_ROOT/ALLBATCH/lib && zip -r lib.zip * -x '*.zip' -x '*.a' -x 'EVIFdummy*.so' -x '*.d' -x '*.warn' -x '*.dup' -x '*.list' -x '*.bak' -x 'pfaismockimpl_test_config.xsd'
        	        echo "you can call autopatch script to generate the RC for this patch release CC & API deliverables are there" >> $log_prt 2>&1
                	MAILTO=`cat /irb/bce/admin/email/head_build_managers`
	                MESSAGE="partial build is completeed successfully without any build errors, calling auto_patch_svn script for CC and API related deliverables"
        	        `echo $MESSAGE | mailx -s "${releaseTag}_${platform}_${oracle}.........PARTIAL BUILD" $MAILTO`
                	echo "ssh genadmin@devapp655cn $BCE_BUILD_SCRIPTS/auto_patch_svn.sh $releaseTag $platform $oracle sqa sdavulur"  >> $log_prt 2>&1
	                ssh genadmin@devapp655cn "bash . ~/.bce.ini;. ~/.bashrc_new;$BCE_BUILD_SCRIPTS/auto_patch_svn.sh $releaseTag $platform $oracle sqa sdavulur"
        	else
	                echo "build errors are there please check those errors in API & CC releated modules" >> $log_prt 2>&1
			if [ ! -d $archivedir ]
		        then
                		${BCE_BUILD_SCRIPTS}/test_cand_avail_mail.sh $archivedir
		        fi
        	fi
	fi
fi
