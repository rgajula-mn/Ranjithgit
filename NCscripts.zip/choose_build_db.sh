#|/bin/ksh
#set -x
###########################################################################################
#
#     Set up Constants
#
###########################################################################################

. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
#. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh

BUILDWEB_DB=`buildweb_connection`
default_time=19990101010101
default_live_for=1.04
hostname=`hostname`
tmp_file=/tmp/choose_build_db_send_email.$$

default_9i2_ver_51_52_53_53IN="9.2.0.4"
default_9i2_ver_54_54TS_30="9.2.0.4"
default_10g_ver_54="10.1.0.4"
default_10g2_ver_54_30="10.2.0.2"
default_10g3_ver_31_40="10.2.0.4"
default_10g4_ver_40_41_42="10.2.0.4"
default_11g7_ver_40_41_42="11.1.0.7"
default_11g2_ver_51="11.2.0.1"
default_11g2_ver_60="11.2.0.3"
default_12c1_ver_70="12.1.0.1"
default_12c2_ver_90="12.1.0.2"

use_process_for="9.2|10.1|10.2|11.1|11.2|12.1"

people_to_email=`cat /irb/bce/admin/email/oracle_administrators`

###########################################################################################
#
#     #######
#     #        #    #  #    #   ####    #####     #     ####   #    #   ####
#     #        #    #  ##   #  #    #     #       #    #    #  ##   #  #
#     #####    #    #  # #  #  #          #       #    #    #  # #  #   ####
#     #        #    #  #  # #  #          #       #    #    #  #  # #       #
#     #        #    #  #   ##  #    #     #       #    #    #  #   ##  #    #
#     #         ####   #    #   ####      #       #     ####   #    #   ####
#
###########################################################################################

usage()
{
	echo " "
	echo "You entered $0 $* "
	echo " "
	echo "Usage: $0 <-p CCM Project> <-m geneva major> <-o oracle> <-t build type> [-e oracle edition] [-C core project] [-l length of life] [-i] [-g] [-R]"
	echo "  e.g. $0 -p GENEVA-sqa5.4.3.solaris.oracle9i2 -m 5.4 -o oracle9i2 -t sqa -R"
	echo " "
	echo "   where:"
	echo "       -p CCM Project    = GENEVA-sqa5.1.23.solaris.oracle9i2"
	echo "       -m Geneva Major   = 5.2 {has to be the geneva major release not a comp major release}"
	echo "       -t type           = [sqa|dev|test|mul|cov]"
	echo "       -o oracle         = [oracle9i2|oracle10g|oracle11g|oracle12c]"
	echo "       -e oracle edition = SE|EE default SE"
	echo "       -C core project   = The core project (GENEVA | RB)"
	echo "       -l length to life = number of days for the database to be allocated for"
	echo "       -i                = If set the script will not check you are running on correct machine"
	echo "       -g                = If running rtests use this to find the db used for the builds."
	echo "       -R                = If building project that is already locking a db the lock is removed for the new build."
	echo "       -u                = username of the person this database is to be assigned to."
	echo "       -B                = Batch Command ID"
	echo "       -a                = return the available DB count only and not an SID"
	echo " "
	exit_program 1
}

exit_program ()
{
	if [ $1 -ne 0 ]
	then
		echo "Exiting Program with status $1"
	fi
	exit $1
}

what_oracle_version ()
{
	oracle=$1
	geneva_major=$2
	project=$3
	full_project=$4

	case $oracle in
		oracle9i2)
			if [ "$project" = "GENEVA" -o "$project" = "GENEVAAPI" ]
			then
				case $geneva_major in
					5.1|5.2|5.3|5.3IN)
						echo "${default_9i2_ver_51_52_53_53IN}"
						;;
					5.4|5.4TS|2.2)	
						echo "${default_9i2_ver_54_54TS_30}"
						;;
					?)
						echo "Error: Unknown Geneva Major Release: $geneva_major for $oracle"
						exit_program 3
						;;
				esac
			elif [ "$project" = "RB" -o "$project" = "RBAPI" ]
			then
				case $geneva_major in
					3.0|3.1|3.2)
						echo "${default_9i2_ver_54_54TS_30}"
						;;
					*)
						echo "Error: Unknown RB Major Release: $geneva_major for $oracle"
						exit_program 3
						;;
				esac
			else
				echo "Error: Unknown project: $project for $oracle"
				exit_program 3
			fi
			;;
		oracle10g)
			if [ "$project" = "GENEVA" -o "$project" = "GENEVAAPI" ]
			then
				case $geneva_major in
					5.4|5.3)
						echo "${default_10g_ver_54}"
						;;
					?)
						echo "Error: Unknown Geneva Major Release: $geneva_major for $oracle"
						exit_program 3
						;;
				esac
			elif [ "$project" = "RB" -o "$project" = "RBAPI" -o "$project" = "PCMI" -o "$project" = "RTCA" ]
			then
				case $geneva_major in
					3.1|4.0|4.1|4.2|4.3|4.4|5.0|5.1|5.2|5.3|6.0|6.1|7.0|8.0|9.0)

						if [ "${edition}" = "EE" ]; then
							echo "${default_10g4_ver_40_41_42}"
						else
							echo $full_project | grep '4.0.2.[0-9]' > /dev/null
							if [ $? -eq 0 ]
							then
								echo "${default_10g3_ver_31_40}"
							else
								echo $full_project | grep '4.0.3' > /dev/null
								if [ $? -eq 0 ]
								then
									echo "${default_10g3_ver_31_40}"
								else
									echo "${default_10g4_ver_40_41_42}"
									
								fi
							fi
						fi

						;;
					3.0|3.2)
						ccm_rel_30=`echo $ccm_project | sed -e "s/\([A-Z]*-[a-z]*\)//g" | sed -e 's/^\([^alshit]*\).*/\1/g' -e 's/\.//g'`	
						if [ "${ccm_rel_30}" -eq 30381 ]
						then
							echo "${default_10g3_ver_31_40}"
						else
							echo "${default_10g2_ver_54_30}"
						fi
						;;
					?)
						echo "Error: Unknown RB Major Release: $geneva_major for $oracle"
						exit_program 3
						;;
				esac
			else
				echo "Error: Unknown project: $project for $oracle"
				exit_program 3
			fi				
			;;
		oracle11g)
			if [ "$project" = "RB" -o "$project" = "RBAPI" -o "$project" = "PCMI"  -o "$project" = "RTCA" ]
			then
				case $geneva_major in
					4.3|4.4|5.0|1.0|1.1|1.2)
						echo "${default_11g7_ver_40_41_42}"
						;;
					5.1|5.2|5.3|1.3)
						ccm_rel=`echo $ccm_project | sed -e "s/\([A-Z]*-[a-z]*\)//g" | sed -e 's/^\([^alshit]*\).*/\1/g' -e 's/\.//g'`
						ccm_plt=`echo $ccm_project | sed -e "s/\([A-Z]*-[a-z]*[0-9\.]*\)//g" | cut -d'.' -f1`
						if [ "${ccm_plt}" = "aix" -a  "${ccm_rel}" -ge 519 ]
						then
							echo "${default_11g2_ver_60}"
						else
							echo "${default_11g2_ver_51}"
						fi
						;;
					6.0|6.1|7.0|7.1|8.0|9.0|1.4|1.5|1.6)
					#	ccm_rel_80=`echo $ccm_project | sed -e "s/\([A-Z]*-[a-z]*\)//g" | sed -e 's/^\([^alshit]*\).*/\1/g' -e 's/\.//g'`	
					#	if [ "${ccm_rel_80}" -eq 8034 ]
					#	then
					#	echo "${default_12c1_ver_70}"
					#	else
						echo "${default_11g2_ver_60}"
					#	fi
                                                ;;
					?)
                                                echo "Error: Unknown RB Major Release: $geneva_major for $oracle"
                                                exit_program 3
                                                ;;
				esac
			else
                                echo "Error: Unknown project: $project for $oracle"
                                exit_program 3
                        fi
			;;
		oracle12c)
			if [ "$project" = "RB" -o "$project" = "RBAPI" -o "$project" = "PCMI"  -o "$project" = "RTCA" ]
			then
				case $geneva_major in
					8.0)
						echo "${default_12c1_ver_70}"
                                                ;;
					9.0)
						echo "${default_12c2_ver_90}"
                                                ;;
	
					?)
                                                echo "Error: Unknown RB Major Release: $geneva_major for $oracle"
                                                exit_program 3
                                                ;;
				esac
			else
                                echo "Error: Unknown project: $project for $oracle"
                                exit_program 3
                        fi
			;;
		?)
			echo "Error Unknown oracle version $oracle"
			exit_program 3
			;;
	esac
}

get_oracle_login_name ()
{
	oracle=$1
	machine_name=$2

	login_name=oracle9i

	case $oracle in
		9.2*)
			case $machine_name in
				cobra|oak|whitby|spruce|jackdaw|condor|jupiter|osprey|twister)
					login_name=oracle9i
					;;
				*)
					login_name=irbora9i
					;;
			esac
			;;
		10.1*)
			case $machine_name in
				cobra|oak|whitby|spruce|jackdaw|condor|jupiter|osprey|twister)
					login_name=ora10g
					;;
				*)
					login_name=irbora10
					;;
			esac
			;;
		10.2*)
			case $machine_name in
				cobra|oak|whitby|spruce|jackdaw|condor|jupiter|osprey|twister)
					login_name=ora10g
					;;
				*)
					login_name=irbora10
					;;
			esac
			;;
		11.1*)
			login_name=irbora11
			;;
		11.2*)
			login_name=irbora11
			;;
		12.1*)
			login_name=irbora11
			;;
		*)
			echo "Error: get_oracle_login_name: No Idea what oracle $oracle is!"
			return 1
			;;
	esac
	echo $login_name
	return 0
}

get_oracle_short_id ()
{
	oracle=$1

	case $oracle in
		9.2*)
			id=9i2
			;;
		10.1*)
			id=10g
			;;
		10.2*)
			id=10g
			;;
		11.1*)
			id=11g
			;;
		11.2*)
			id=11g
			;;
		12.1*)
			id=12c
			;;
		*)
			echo "Error: get_oracle_short_id: No Idea what oracle $oracle is!"
			return 1
			;;
	esac
	echo $id
	return 0
}


clear_locks ()
{
	current_time=`date "+%Y%m%d%H%M%S"`
	sql="select SID from build_database_locks where expire_time < to_date('$current_time','YYYYMMDDHH24MISS');";
	databases_to_delete=`sql_query $BUILDWEB_DB "$sql"`
	if [ $? -eq 0 ]
	then
		for i in `echo $databases_to_delete`
		do
			sql="delete from build_database_locks where sid='$i'";
			sql_query $BUILDWEB_DB "$sql"
			sql="select SID from das_extra_data where sid='$i'";
			das_sid=`sql_query $BUILDWEB_DB "$sql"`
			if [ ! -z "$das_sid" ]
			then
				sql="select UNIX_ID from das_extra_data where sid='$i'";
				temp1=`sql_query $BUILDWEB_DB "$sql"`
				das_uid=`echo $temp1`
				sql="delete from das_extra_data where sid='$i'";
				sql_query $BUILDWEB_DB "$sql"
				sql="insert into das_audit (actioner, action_dtm,action,sid,db_assigned_to) values ('AUTO',to_date('$current_time','YYYYMMDDHH24MISS'),'Delete','$i','$das_uid')";
				sql_query $BUILDWEB_DB "$sql"
				
				# SEND EMAIL FOR DELETION OF ALLOCATION
				echo "Hello<BR><BR>Database <B>$i</B> allocation has expired.<BR>" > /tmp/tmp_sendmail.$$
				echo "Please cease activity on this database and if you require another please return to the DAS system and request a new database<BR>" >> /tmp/tmp_sendmail.$$
				echo "Regards<BR>CIBER Team" >> /tmp/tmp_sendmail.$$
				$BCE_BUILD_SCRIPTS/html_email.sh -f $das_uid -F "DAS Allocation Expiry" -s "DAS: $selected_database_to_use Allocated to you" -m /tmp/tmp_sendmail.$$ | /usr/lib/sendmail $allocated_user
				rm /tmp/tmp_sendmail.$$
			fi
		done
	fi


	sql_query $BUILDWEB_DB "$sql"

	return $?
}

attempt_to_lock_db ()
{
	database=$1
	databases_and_machines=$2
	ccm_project=$3
	live_for=$4
	use_oracle=$5


	use_oracle_no_dots=`echo $use_oracle | sed -e 's/\.//g'`


	nolock="no"
	if [ "$6" = "NOLOCK" ]
	then
		nolock="yes"
	fi
	

	selected_database_to_use=""
	for sid_mach in $databases_and_machines
	do
		sid=`echo $sid_mach | cut -d',' -f1`
		mach=`echo $sid_mach | cut -d',' -f2`
		database_location=`echo $sid_mach | cut -d',' -f3`
		edition=`echo $sid_mach | cut -d',' -f4`
		db_os=`echo $sid_mach | cut -d',' -f5`

		pak_location=${BCE_ADMIN}/oracle_build_dbs/${db_os}_${bit}_jvm_${use_oracle_no_dots}_${edition}_${charset}.tar.Z
		if [ ! -f $pak_location ]
		then
			echo "$0, $hostname, No oracle pak file, $pak_location" | /usr/lib/sendmail $people_to_email
			echo $sid >> $pak_location.require
			continue
		fi

		# Keep a record of the dbs that use each pak file
		if [ -f "${pak_location}.usedby" ]
		then
			grep $sid ${pak_location}.usedby > /dev/null
			if [ $? -ne 0 ]
			then
				echo $sid >> ${pak_location}.usedby
			fi
			
		else
			echo $sid > ${pak_location}.usedby
		fi
			
		normal_database=""
		olc_database=""
		olc_cache_database=""

		if [ "$database_type" = "olc" ]
		then
			olc_database=$ccm_project
		elif [ "$database_type" = "olc_cache" ]
		then
			olc_cache_database=$ccm_project
		elif [ "$database_type" = "olc_cache_new" ]
		then
			olc_cache_database=${ccm_project}_2
		else
			normal_database=$ccm_project
		fi

		if [ "$allocated_user" ]
		then
			normal_database=$allocated_user
		fi
	
		current_time=`date "+%Y%m%d%H%M%S"`
		if [ ! -z "$allocated_user" ]
		then
			current_time=`date "+%Y%m%d"`235959
		fi
		sql="insert into build_database_locks (sid, lock_time, expire_time, ccm_project, ccm_project_olc, ccm_project_olc_cache) values('$sid',to_date('$current_time','YYYYMMDDHH24MISS'),to_date('$current_time','YYYYMMDDHH24MISS')+$live_for,'$normal_database','$olc_database','$olc_cache_database');"

		if [ "$nolock" != "yes" ]
		then
			lock_database $BUILDWEB_DB "$sql"
			status=$?
		else
			status=0
		fi
		if [ $status -eq 0 ]
		then
			oracle_short_id=`get_oracle_short_id $use_oracle`
			oracle_login=`get_oracle_login_name $use_oracle "${mach}"`
			if [ $? -ne 0 ]
			then
				echo "$oracle_login"
				continue
			fi
			case $PLATFORM in
				HP-UX-64|HP-UX-IA64)
					rsh_command="remsh ${mach} -n -l $oracle_login "
					;;
				aix)
					rsh_command="rsh ${mach} -n -l $oracle_login "
					;;
				*)
					rsh_command="ssh -n -l $oracle_login ${mach} "
					;;
			esac
			if [ "$mach" = "camdl125" -o "$mach" = "camdl126" -o "$mach" = "camdl125.netcracker.com" -o "$mach" = "camdl100.netcracker.com" -o "$mach" = "camdl101.netcracker.com" -o "$mach" = "camdl102.netcracker.com" -o "$mach" = "camdl103.netcracker.com" -o "$mach" = "camdl104.netcracker.com"  -o "$mach" = "camdl105.netcracker.com" -o "$mach" = "camdl106.netcracker.com"  -o "$mach" = "camdl107.netcracker.com"  -o "$mach" = "camdl108.netcracker.com"  -o "$mach" = "camdl109.emea.convergys.com"  -o "$mach" = "camdl111.emea.convergys.com"  -o "$mach" = "camdl115.emea.convergys.com"  -o "$mach" = "camdl117.emea.convergys.com"  -o "$mach" = "camdl118.emea.convergys.com"  -o "$mach" = "camdl120.emea.convergys.com"  -o "$mach" = "camdl122.emea.convergys.com"  -o "$mach" = "camdl125.netcracker.com" -o "$mach" = "camdl126.netcracker.com" -o "$mach" = "camdl111.emea.convergys.com" -o "$mach" = "camdl102.netcracker.com"   -o "$mach" = "camdl112.netcracker.com"  ]
			#if [ "$mach" = "camdl125" -o "$mach" = "camdl126" -o "$mach" = "camdl125.netcracker.com" -o "$mach" = "camdl126.netcracker.com" -o "$mach" = "camdl119.emea.convergys.com" -o "$mach" = "camdl102.netcracker.com" ]
			then 
				if [ $PLATFORM = "aix" ]
				then 
					rsh_command="ssh ${mach} -n -l $oracle_login "
				elif [ $PLATFORM = "solaris" ]
                                then
                                        rsh_command="/bin/ssh ${mach} -n -l $oracle_login "
				else
					rsh_command="ssh -n -l $oracle_login ${mach} "
				fi
			fi

			if [ ! -z "$allocated_user" ]
			then
				if [ "$oracle_login" = "ora10g" ]
				then
					sql="delete from build_database_locks where sid='$sid';"
					sql_query $database "$sql"
					continue
				fi
			fi
			rsh_output=`$rsh_command ". ~/.bce.ini; ${BCE_BUILD_SCRIPTS}/build_drop_and_create_db_inst.sh $sid $pak_location $oracle_short_id $database_location $charset $geneva_major $edition 2>&1 | sed -e 's/*/-/g'"`
			rsh_result=$?
			echo $rsh_output | grep "Exiting" > /dev/null
			if [ $? -ne 0 -a $rsh_result -eq 0 ]
			then
				selected_database_to_use="$sid"
				break;
			else
				if [ "$nolock" != "yes" ]
				then
					# Failed to logonto the machine where the DB resides, unlock the database.
					sql="delete from build_database_locks where sid='$sid';"
					sql_query $database "$sql"
				fi
				echo "" > $tmp_file
				echo "Running from $hostname - $PLATFORM" >> $tmp_file
				echo "Returned error from: $rsh_command . ~/.bce.ini; ${BCE_BUILD_SCRIPTS}/build_drop_and_create_db_inst.sh $sid $pak_location $oracle_short_id $database_location $charset $geneva_major $edition 2>&1" >> $tmp_file
				echo "-------------------------" >> $tmp_file
				echo $rsh_output >> $tmp_file
				echo "-------------------------" >> $tmp_file
				echo "" >> $tmp_file
				cat $tmp_file | /usr/lib/sendmail $people_to_email
				rm $tmp_file
				selected_database_to_use=""
				status=2
			fi
		fi
	done

	echo "$selected_database_to_use"
	return $status
}

sql_alter_date_format ()
{
	database=$1

	sqlplus -s $database << +END
		set feed off
		set head off
		set pages 1000
		alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
		exit
+END
	
	return $?
}

lock_database ()
{
	database=$1
	query="$2"

	result=`sql_query $database "$query"`
	status=$?
	if [ $status -ne 0 ]
	then
		return $status
	fi

	echo $result | grep "unique constraint" > /dev/null
	status=$?
	if [ $status -eq 0 ]
	then
		return 101
	fi

	return 0
}



check_for_value ()
{
	sql=$1
	field=$2
	value=$3
	sql_command=$4 # can be create, update or query

	if [ ! -z "$value" -a "$value" != "$default_time" ]
	then
		case $sql_command in
			update)
				if [ "$5" = "" ]
				then
					sql="$sql $field='$value',"
				else
					sql="$sql $field=to_date('$value','YYYYMMDDHH24MISS'),"
				fi
				;;
			query)
				if [ "$5" = "" ]
				then
					sql="$sql and $field='$value'"
				else
					sql="$sql and $field=to_date('$value','YYYYMMDDHH24MISS')"
				fi
				;;
			*)
				echo "check_for_value: $sql_command: Not yet implemented"
				;;
		esac
	fi
	
	echo $sql
	return 0
}


###########################################################################################
#
#     #    #    ##       #    #    #
#     ##  ##   #  #      #    ##   #
#     # ## #  #    #     #    # #  #
#     #    #  ######     #    #  # #
#     #    #  #    #     #    #   ##
#     #    #  #    #     #    #    #
#
###########################################################################################

ignore_mach=""
database_type=""
rem_lock="FALSE"
get_db_for_last_build="FALSE"

while getopts B:b:c:C:e:gil:m:n:o:p:t:u:ahzR the_option
do
	case $the_option in
	a)
		return_only_available_db_count=yes # used by run_rtest.sh
		;;
	b)
		bit="$OPTARG"
		;;
	B)
		bcr_id="$OPTARG"
		;;
	c)
		charset="$OPTARG"
		;;
	C)
		core_proj="$OPTARG"
		;;
	e)
		edition="$OPTARG"
		;;
	g)
		get_db_for_last_build="TRUE"
		;;
	h)
		usage
		;;
	i)
		ignore_mach="-d"
		;;
	l)	
		live_for="$OPTARG"
		;;
	m)
		geneva_major="$OPTARG"
		;;
	n)
		database_type="$OPTARG"
		;;
	p)
		ccm_project="$OPTARG"
		project=`echo $ccm_project | cut -d'-' -f1`
		;;
	R)
		rem_lock="TRUE"
		;;
	o)
		oracle="$OPTARG"
		if [ "${oracle}" = at ]
		then
			oracle=oracle9i2
		fi
		;;
	t)

		build_type="$OPTARG"
		;;
	u)
		allocated_user="$OPTARG"
		;;
	z)
		debug_on="TRUE"
		;;
	[?])
		usage $*
		;;
	esac
done

if [ -z "$project" -o -z "$geneva_major" -o -z "$oracle" ]
then
	echo "project        = $project"
	echo "geneva_major   = $geneva_major"
	echo "oracle         = $oracle"
	usage $*
fi

if [ -z "$core_proj" ]
then
	core_proj=$project
fi

echo "$oracle" | grep oracle > /dev/null
if [ $? -eq 0 ]
then
	oracle=`what_oracle_version $oracle $geneva_major $core_proj $ccm_project`
	echo $oracle | grep "Error:" > /dev/null 2>&1
	if [ $? -eq 0 ]
	then
		echo $oracle
		exit_program 4
	fi
fi
oracle=`echo $oracle | sed 's/^\([0-9\.]*\).*/\1/;s/\(.*\)\.$/\1/'`
dots=`echo "$oracle" | sed -e 's/[0-9]//g' | wc -c`
oracle_major=`echo $oracle | cut -d'.' -f1-2`

use_oracle=$oracle

if [ $dots -lt 4 ]
then
	use_oracle=`what_oracle_version $oracle $geneva_major $core_proj $ccm_project`
	echo $oracle | grep "Error:" > /dev/null 2>&1
	if [ $? -eq 0 ]
	then
		echo $use_oracle
		exit_program 5
	fi
fi

if [ -z "$build_type" ]
then
	build_type="sqa"
fi

if [ -z "$edition" ]
then
	edition="SE"
fi

if [ -z "$live_for" ]
then
	live_for=$default_live_for
fi

# locate an oracle_home and set it in the environment
find_sqlhome 9.2.0.SE # > /dev/null
if [ $? -ne 0 ]
then
	echo "$0: Error: Cannot find valid SQLPLUS"
	exit_program 1
fi

# Check we are running on the correct machine.
machine_for_projects_sid=`${BCE_BUILD_SCRIPTS}/machine_for_projects.pl -p ${ccm_project} ${ignore_mach}`
status=$?
if [ $status -ne 0 ]
then
	echo $machine_for_projects_sid
	exit_program 3
fi

# This process should only be used for certain oracle versions
echo $oracle_major | egrep "$use_process_for" > /dev/null
if [ $? -ne 0 ]
then
	echo "$machine_for_projects_sid"
	exit_program 0
fi

# set up the default oracle charset
if [ -z "$charset" -a "$build_type" = "mul" ]
then
	charset="UTF8"
elif [ -z "$charset" ]
then
	charset="WE8ISO8859P15"
fi

# set up the default oracle bit setting
if [ -z "$bit" ]
then
	if [ "$PLATFORM" = "solaris32" ]
	then
		bit=32
	else
		bit=64
	fi
fi

if [ "$machine_for_projects_sid" != "auto.world" ]
then
	without_world=`echo $machine_for_projects_sid | cut -d'.' -f1`
	sql="select a.sid,',',a.host,',',a.datalocation,',',a.oracle_type,',',b.bce_platform,',',a.autogen from bce_databases a, pdm_machines b where sid='$without_world' and a.host=b.name order by datalocation desc"
	my_drop_db=`sql_query $BUILDWEB_DB "$sql;"`
	drop_db=`echo $my_drop_db | cut -d',' -f6 | sed -e 's/[	 ]*//g'`
	my_drop_db=`echo $my_drop_db | cut -d',' -f1-5`
	my_drop_db=`echo $my_drop_db | sed -e 's/[	 ]*, /,/g'`
	status=0
	if [ "$drop_db" != "NODROP" ]
	then
		if [ "$get_db_for_last_build" != "TRUE" ]
		then
	 		selected_database_to_use=`attempt_to_lock_db $BUILDWEB_DB "$my_drop_db" $ccm_project $live_for $use_oracle NOLOCK`
			status=$?
		fi
	fi
	if [ $status -eq 0 ]
	then
		echo "$machine_for_projects_sid"
		exit_program 0
	else
		echo "Error: $0: Failed to recreate database status=$status" 
		exit_program 99
	fi
fi

if [ "$get_db_for_last_build" = "TRUE" ]
then
	if [ "${database_type}" = "olc" ]
	then
		sql="select SID from build_database_locks where ccm_project_olc='$ccm_project' order by LOCK_TIME DESC;"
	elif [ "${database_type}" = "olc_cache" ]
	then
		sql="select SID from build_database_locks where ccm_project_olc_cache='$ccm_project' order by LOCK_TIME DESC;"
	elif [ "$database_type" = "olc_cache_new" ]
	then
		sql="select SID from build_database_locks where ccm_project_olc_cache='${ccm_project}_2' order by LOCK_TIME DESC;"
		#echo $sql
	else
		sql="select SID from build_database_locks where ccm_project='$ccm_project' order by LOCK_TIME DESC;"
	fi
	rel_dbs=`sql_query $BUILDWEB_DB "$sql"`
	used_db=""
	for i in $rel_dbs
	do
		used_db="$i.world"
		break
	done
	if [ -z "${used_db}" ]
	then
		echo "Error: $0: Could not find a database for the rtests that the build used."
		echo "$sql"
		exit_program 1
	fi
	echo "$used_db"
	exit_program 0
fi

sql_alter_date_format $BUILDWEB_DB

if [ "${rem_lock}" = "TRUE" ]
then 
	if [ "${database_type}" = "olc" ]
	then
		sql="delete from build_database_locks where ccm_project_olc='$ccm_project';"
		sql_query $BUILDWEB_DB "$sql"
	elif [ "${database_type}" = "olc_cache" ]
	then
		sql="delete from build_database_locks where ccm_project_olc_cache='$ccm_project';"
		sql_query $BUILDWEB_DB "$sql"
	elif [ "$database_type" = "olc_cache_new" ]
	then
		sql="delete from build_database_locks where ccm_project_olc_cache='${ccm_project}_2';"
		sql_query $BUILDWEB_DB "$sql"
	else
		sql="delete from build_database_locks where ccm_project='$ccm_project';"
		sql_query $BUILDWEB_DB "$sql"
	fi
fi

clear_locks $BUILDWEB_DB

plain_sql="select DISTINCT a.sid,',',a.host,',',a.datalocation,',',a.oracle_type,',',b.bce_platform 
		from bce_databases a, pdm_machines b 
		where a.purpose='Build' and a.status='A' and 
			a.sid not in (select c.sid from build_database_locks c) and
			a.host = b.name and
			a.oracle_version like '${oracle}%' and
			a.oracle_type='$edition' and
			a.autogen = 'Y' and
			b.stop_allocation is null"

plain_sql=`check_for_value "$plain_sql" a.bit "$bit" query` 
sql="$plain_sql and b.name='$hostname'"

databases=`sql_query $BUILDWEB_DB "$sql;"`
if [ $? -ne 0 ]
then
	echo "$0: Oracle failure"
	echo $databases
	echo "$0 Oracle Failure on $hostname error=$databases" | /usr/lib/sendmail $people_to_email
	exit_program 9
fi
databases=`echo $databases | sed -e 's/[	 ]*, /,/g'`

if [ ${return_only_available_db_count:=NOTSET} = yes ]; then
	oracle_version="${oracle}.${edition}"
	count_dbs_free_sql=`echo $plain_sql | sed -e 's/.*\(from bc.*\)/select count(DISTINCT a.sid) \1/'`
	available_db_count=`sql_query $BUILDWEB_DB "$count_dbs_free_sql"`
	echo $available_db_count
	exit_program 0
fi

selected_database_to_use=`attempt_to_lock_db $BUILDWEB_DB "$databases" $ccm_project $live_for $use_oracle`
return_status=$?
if [ -z "$selected_database_to_use" -o $return_status -ne 0 ]
then
	sql="$plain_sql and b.bce_platform='$PLATFORM'"
	databases=`sql_query $BUILDWEB_DB "$sql;"`
	databases=`echo $databases | sed -e 's/[	 ]*, /,/g'`

	selected_database_to_use=`attempt_to_lock_db $BUILDWEB_DB "$databases" $ccm_project $live_for $use_oracle`
	return_status=$?
	if [ -z "$selected_database_to_use" -o $return_status -ne 0 ]
	then
		sql="$plain_sql order by a.datalocation desc"
		databases=`sql_query $BUILDWEB_DB "$sql;"`
		databases=`echo $databases | sed -e 's/[	 ]*, /,/g'`

		selected_database_to_use=`attempt_to_lock_db $BUILDWEB_DB "$databases" $ccm_project $live_for $use_oracle`
		return_status=$?
		if [ -z "$selected_database_to_use" -o $return_status -ne 0 ]
		then
			echo ""
			echo "$0: No Databases Available"
			echo "$0: SQL used = $sql"
			email_file="/tmp/choosebdb$$"
			echo "Subject: No databases available: ${oracle} ${edition}" > $email_file
			echo "There are no databases left of oracle $oracle $edition" >> $email_file
			echo "Running choose_build.db.sh from $hostname" >> $email_file
			cat $email_file | /usr/lib/sendmail $people_to_email
			rm $email_file
			if [ "$allocated_user" ]
			then
				echo "Please check http://osprey.emea.convergys.com/sql/genericview.php?configfile=view_dev_ind_dbs for when this database will be reallocated to another user"
				if [ ! -z "$bcr_id" ]
				then
					echo "Hello<BR><BR>Sadly the DAS system has been unable to allocate you database<BR>" > /tmp/tmp_sendmail.$$
					echo "The CIBER team have been informed that you required a $oracle $edition database are are doing there best to make more databases available.<BR>" >> /tmp/tmp_sendmail.$$
					echo "Please try allocating yourself a new database in 15 minutes and one should be available <A HREF=\" http://osprey.emea.convergys.com/DAS/das.php\">DAS System</a>." >> /tmp/tmp_sendmail.$$
					echo "<P>From the DAS you can:<BR><UL><LI>Extend the allocation of this database to you" >> /tmp/tmp_sendmail.$$
					echo "<LI>View the databases allocated to you" >> /tmp/tmp_sendmail.$$
					echo "<LI>Request more databases" >> /tmp/tmp_sendmail.$$
					echo "<LI>Plus much much more</UL></P>" >> /tmp/tmp_sendmail.$$
					echo "Regards<BR>CIBER Team" >> /tmp/tmp_sendmail.$$
					$BCE_BUILD_SCRIPTS/html_email.sh -f $allocated_user -F "DAS Allocation" -s "DAS: $selected_database_to_use Allocated to you" -m /tmp/tmp_sendmail.$$ | /usr/lib/sendmail $allocated_user
					rm /tmp/tmp_sendmail.$$
					email_file="/tmp/choosebdb$$"
					echo "Subject: DAS: No databases available: ${oracle} ${edition}" > $email_file
					echo "There are no databases left of oracle $oracle $edition" >> $email_file
					echo "Running choose_build.db.sh from $hostname" >> $email_file
					echo "From DAS for user: $allocated_user" >> $email_file
					cat $email_file | /usr/lib/sendmail $people_to_email
				fi
			fi
			exit_program 2
		fi
	fi
fi

# Return the SID
echo ${selected_database_to_use}.world

if [ "$allocated_user" ]
then
	echo "Please check http://osprey.emea.convergys.com/sql/genericview.php?configfile=view_dev_ind_dbs for when this database will be reallocated to another user"
	if [ ! -z "$bcr_id" ]
	then
		sql="update das_extra_data set sid='${selected_database_to_use}' where bcr_id='${bcr_id}';";
		sql_query $BUILDWEB_DB "$sql"

		echo "Hello<BR><BR>Database <B>$selected_database_to_use</B> is now allocated to you for $live_for days.<BR>" > /tmp/tmp_sendmail.$$
		echo "This database is $oracle $edition and resides on server: `database_server.sh $selected_database_to_use`<BR>" >> /tmp/tmp_sendmail.$$
		echo "Please check <A HREF=\" http://osprey.emea.convergys.com/DAS/das.php\">DAS System</a> for the databases allocated to you." >> /tmp/tmp_sendmail.$$
		echo "<P>From the DAS you can:<BR><UL><LI>Extend the allocation of this database to you" >> /tmp/tmp_sendmail.$$
		echo "<LI>View the databases allocated to you" >> /tmp/tmp_sendmail.$$
		echo "<LI>Request more databases" >> /tmp/tmp_sendmail.$$
		echo "<LI>Plus much much more</UL></P>" >> /tmp/tmp_sendmail.$$
		echo "Regards<BR>CIBER Team" >> /tmp/tmp_sendmail.$$
		$BCE_BUILD_SCRIPTS/html_email.sh -f $allocated_user -F "DAS Allocation" -s "DAS: $selected_database_to_use Allocated to you" -m /tmp/tmp_sendmail.$$ | /usr/lib/sendmail $allocated_user
		rm /tmp/tmp_sendmail.$$
	fi
fi

exit_program 0
