#!/bin/sh

# 21/11/2006 tcahill /prdservices moved to /irb/ice quick fix
set -x

. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh

############################################################################
#
# FUNCTIONS
#
############################################################################

check_for_error ()
{
	status=$1
	error_message=$2

	if [ $status -ne 0 ]
	then
		echo "$0: $error_message"
		exit 1
	fi
}

add_release_note() {
	TYPE=$1

#	create_task	
	echo "first Which release notes would you like to add to the project?"
	#if [ "$sayyes" = "yes" ]
#	then
		answer=1
#	else
#	read answer
#	fi
	while [ `echo $answer | grep "[a-zA-Z]"` ]
	do
		echo "[INFO] Which release notes would you like to add to the project?"
		read answer
	done
#	ccm use @${answer}

	update_build_info $TYPE 
}

update_build_info () {
	TYPE=$1

	project_version=`${BCE_BUILD_SCRIPTS}/discover_release_tag.sh -t $release_tag`
	the_project=`echo "$project_version" | cut -d' ' -f1`
	the_version=`echo "$project_version" | cut -d' ' -f2`
	create_time=`date "+%Y%m%d%H%M%S"`

	echo "update_build_information.sh -S bs_add_to_release -I "$TYPE" -J "Release Notes" -y $create_time -p $the_project -v $the_version"
	${BCE_BUILD_SCRIPTS}/update_build_information.sh -S bs_add_to_release -I "$TYPE" -J "Release Notes" -y $create_time -p $the_project -v $the_version
}


add_release_notes()
{
	rel_no=$1
	TYPE=$2

	echo "[INFO] Searching for [release_notes_${projPrefix}_${rel_no}.pdf]"
#	ccm query "name = 'release_notes_${projPrefix}_${rel_no}.pdf'"
	queryStatus=$?
	if [ ${queryStatus} -eq 0 ]
	then
		echo "[INFO] Release note found"
		add_release_note $TYPE
	else
		echo "[WARNING] No release note was found!"
		echo "[INFO] Attemping to determine the appropriate ccm database to initiate a DCM transfer from..."
		# At the moment dcm script only supports prd and CB5
#		CB2_ADDR=$CCM_ADDR
#		for dbQuery in cb5 prd
#		do
#			startCCM /ccm/${dbQuery}
#			echo "[INFO] Using CM Synergy on [${CCM_ADDR}] to determine location of release_notes_${projPrefix}_${rel_no}.pdf"
#			ccm query "name = 'release_notes_${projPrefix}_${rel_no}.pdf'"
#			queryStatus=$?
#			if [ ${queryStatus} -eq 0 ]
#			then
#				if [ "${dbQuery}" = "prd" ]
#				then
#					dcm_transfer.sh CB1 -r ${baserel}
#				else
#					if [ ! -z "$transfer_task" ]
#					then
#						ccm dcm -add -ts "Release notes for CB2" task${transfer_task}-1:task:CB5
#					fi
#					dcm_transfer.sh CB5 -r rel
#				fi
#				add_release_note $TYPE
#				break
#			else
#				echo "[ERROR] release_notes_${projPrefix}_${rel_no}.pdf was not found"
#			fi
#			cleanUpCCM
#		done
#		CCM_ADDR=$CB2_ADDR
	fi
}


change_to_wa_and_check_project()
{
		ccm_project=$1
		release_tag=$2

		project=`echo $ccm_project | cut -d"-" -f1`
		version=`echo $ccm_project | cut -d"-" -f2`
		
		#ccm query -t project "version='${version}' and name='${project}'" > /dev/null
		#project_release=`ccm attr -s release @`
		project_release=$release_tag
		echo "project_release is ......... $project_release"

		if [ "${project_release}" != "${release_tag}" ]
		then
			echo "Error: Project release tag ($project_release) and what you entered as argument 1 ($release_tag) do not match"
			exit 1
		fi

		#workarea=`ccm query -t project "name = '${project}' and version = '${version}'" -f "%wa_path" -u | sed -e 's/.$//'`
		project_no_type=`echo $project | sed -e 's/PATCH//g;s/MAINT//g;s/INSTALL//g'`
		this_is_full_or_patch=`cat $BCE_ADMIN/config/releases_for_cb2 |grep release_tag`
		maint_or_head=`echo $release_number|tr -d -c '.'|wc -c`
		PROJECT_low=`echo ${project_no_type} | tr '[A-Z]' '[a-z]'`
		project_version=`echo $release_tag | cut -d'_' -f2`	
		ai_format="false"				
		workarea="$BCE_ROOT/release/$PROJECT_low/$baserel/$ccm_project"
		platform=`echo ${ccm_project}|cut -d'.' -f5`
                oracle=`echo ${ccm_project}|cut -d'.' -f6`
                if [ "${platform}" = "linux" ]
                then
                        pform="lX"
                fi
                if [ "${oracle}" = "oracle12c" ]
                then
                        ora_ver="12c"
                elif [ "${oracle}" = "oracle11g" ]
                then
                        ora_ver="11g"
                fi
                old_target="$workarea/$project"
                proj=`echo $release_tag | cut -d'_' -f1`
                rel_package="${proj}-${project_version}${pform}${ora_ver}.zip"
                echo "Verificaton of Candidate and Release"
                /irb/bce/admin/ccm_wa/PRD-bce/PRD/build_scripts/comp_releaseAndcand.sh ${project_version} ${proj} ${old_target} ${rel_package}
		if [ $? -ne 0 ]
		then
			echo "Can not get the work area for $ccm_project from CCM"
			exit 1
		fi
		echo "The work area for the $project project is: $workarea"

	
		if [ -d "$workarea/$project/doc" ]
		then
			cd $workarea/$project/doc
		elif [ -f "$workarea/$project/$project_no_type/$project_no_type/install/comp_install.xml" ]
		then
		        workarea=`sqlplus -s buildweb/georgespass@webca.world << +END
                		set feed off;
	                	set head off;
	        	        set pagesize 0;
        	        	alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
				select export_location from test_cand_summary where rowid=(select max(rowid) from test_cand_summary where project='$project_no_type' and version='$project_version');
				exit;
			+END`
			
			 #workarea="/irb/candidate/patch/${PROJECT_low}/$baserel/${workarea}/"
			 zip=`find ${workarea} -name '*autoinstaller.zip'`
			 IN1=`find ${workarea} -name '*.docx'`
			 IN=`basename "${IN1}"`
			 if [ -f "$zip" ] && [ -f "$IN1" ]
			 then
			         cd $workarea
		        	 ai_format="true"
			         patch_name=`basename ${zip} | cut -d '_' -f1`
			         output_name="${patch_name}-ai.zip"
			 fi
		elif [ -d "$workarea/$project/$project_no_type/$project_no_type/doc" ]
		then
			cd $workarea/$project/$project_no_type/$project_no_type/doc
		fi
		
}

#create_task() {
#	if [ -z "$task" ]
#	then
#		synopsis="Add release notes to $release_tag"
#		task=`ccm task -create -release $release_tag -subsystem "Build" -synopsis "$synopsis" -resolver $whoami`

#		echo $task | grep created > /dev/null
#		if [ $? -ne 0 ]
#		then
#			echo "Task not created successfully"
#			exit 1
#		fi
#		task=`echo $task | awk '{print $2}'`
#	fi
#
#	ccm task -default $task
#	check_for_error $? "Could not set default task to: $task"
#}

usage()
{
	echo "Usage: $0 <-t release tag> [-i Install/Patch project] [-m Maint project] [-d task] [-r Reviewer] [-p release note prefix] [-b task]"
	echo ""
	echo "	-t	The release tag for the project"
	echo "	-i	An Install or Patch project to add release notes too"
	echo "	-m	A Maintenance project to add release notes too"
	echo "	-d	A task already created"
	echo "	-r	Create reviews, reviewed by reviewer"
	echo "	-p	prefix for the release notes, e.g., geneva|tap"
	echo "  -b      A task to transfer from cb5 to cb2"
	echo "  -y      Answer yes or 1 to everything!"
	echo ""
	echo "  Eg      $0 -t SPD_3.1.4.2 -i SPDINSTALL-nickc -p spd"
	exit 1
}


############################################################################
#
# Main Program
#
############################################################################

# Initialise variables
task=""
release_tag=""
reviews=""

while getopts b:d:t:i:m:p:ayr: the_option
do
	case $the_option in
	a)
		echo ""
		exit
		;;
	b)
		transfer_task=$OPTARG
		;;
	d)
		task="$OPTARG"
		;;
	i)
		ccm_project_full="$OPTARG"
		;;
	m)
		ccm_project_maint="$OPTARG"
		;;
	r)
		reviews="$OPTARG"
		;;
	t)
		release_tag="$OPTARG"
		;;
	p)
		projPrefix="$OPTARG"
		;;
	y)
		sayyes='yes'
		;;
	*)
		usage
		;;
	esac
done

if [ -z "$release_tag" ]
then
	usage
fi
echo "release tag information......... $release_tag"
project_version=`${BCE_BUILD_SCRIPTS}/discover_release_tag.sh -t $release_tag`
release_project=`echo $project_version | cut -d' ' -f1`
release_project_low=`echo $release_project| tr '[A-Z]' '[a-z]'`
echo "release_project_low = $release_project_low"
release_number=`echo $project_version | cut -d' ' -f2`
major_rel=`echo $release_number|cut -d'.' -f1-2`
nodes=`echo $release_number|awk -F'.' '{print NF}'`

# Bodge for GEN_5.4.x because release notes version number = 2.2.x
release_number=`echo $release_number | sed -e 's/^5.4/2.2/g'` 


baserel=`echo $release_number | cut -d'.' -f1-2`

whoami=`whoami`

if [ "$ccm_project_full" != "" ]
then
	change_to_wa_and_check_project $ccm_project_full $release_tag

	am_i_a_patch $release_tag
	if [ $? -eq 1 ]
	then
		# This is not a patch
		TYPE="INSTALL"
		add_release_notes $release_number $TYPE
	else
		TYPE="PATCH"
		# This is a patch
		if [ "$release_project" = "GENEVA" ]
		then
			release_notes_path=`ls /irb/ice/patches/release_notes_${release_number}.txt` 
		else
			release_notes_path=`ls /irb/ice/patches/*${release_number}.txt | grep -i "${release_project}"` 
		fi

		if [ $? -ne 0 ]
		then
		        echo "Can not find the release notes for this patch $release_number"
			exit 1
		fi
		
		if [ "$sayyes" != "yes" ]
		then
			echo "About to use the release notes: $release_notes_path; Continue? (y/n)"
			read answer

			if [ "$answer" != "y" ]
			then
				echo "Quitting, because you did not enter y"
				exit 1
			fi
		fi

		release_notes=`basename $release_notes_path`

		#if [ -f "$release_notes" ]
		#then
		#	echo "The release notes already exists, re-checkout?"
		#	if [ "$sayyes" = "yes" ]
		#	then
		#		answer=y
		#	else
		#		read answer
		#	fi
		#	if [ "$answer" = "y" ]
		#	then
		#		create_task
		#		ccm co $release_notes
		#	else
		#		echo "Not adding release notes"
		#		echo "Not checking in the default task $task"
		#		exit 1
		#	fi
		#else
		#	create_task
		#	ccm create -type txt $release_notes
		#fi

		cp $release_notes_path $release_notes
		if [ "${ai_format}" = "true" ]
		then
		        perl -i -nle 'print  if !((/INSTALLATION INSTRUCTIONS/../End of release notes/) && !(/End of release notes/))' $release_notes
		        zip -q ${output_name} `basename ${zip}` "${IN}" ${release_notes}
			echo "AI zip is generated, copying to archive location and creating link in candidate location"
			mv ${output_name} /irb/archive/${release_project_low}/${major_rel}-PATCH/
			ln -fs /irb/archive/${release_project_low}/${major_rel}-PATCH/${output_name}
		        rm -f ${zip} "${IN}" ${release_notes}
			if [ "$TYPE" = "PATCH" -o "$TYPE" = "INSTALL" -a $nodes = 4 ]
                        then

                                $BCE_BUILD_SCRIPTS/tag_creation.sh $release_project $release_number
                                #echo "we do not need tag creation now"
                                ssh devapp655cn "bash .bce.ini;$BCE_BUILD_SCRIPTS/tms_close_version.sh $release_number $release_project > ${BCE_LOG}/tms_version/tms_version_close_$release_project_$release.log" 2>&1
                        else
                                echo "we are unable to create the tags"
                        fi

		fi
		
		update_build_info $TYPE
	fi			

	if [ "$ccm_project_maint" != "" ]
	then
		change_to_wa_and_check_project $ccm_project_maint $release_tag
		
		add_release_notes $release_number $TYPE
	fi

	#if [ -n "${task}" ]
	#then
	#	echo "Do you want to checkin your default task :$task (y/n)"
	#	if [ "$sayyes" = "yes" ]
	#	then
	#		answer=y
	#	else
	#		read answer
	#	fi
#
#		if [ "$answer" = "y" ]
#		then
#			ccm task -checkin default
#			echo "You now need to reconfigure all the deliverable projects."
#			echo "I recommend you run my friend add_folder_and_reconfigure.sh"
#		fi
#	fi
fi

if [ ! -z "${reviews}" ]
then
	echo "This doesn't work yet, please raise the reviews manually using the intranet"
	today=`date '+%d-%b-%Y'`
	sql="insert into review (TASK_NUMBER,OWNER,DELIVERABLE_DESC,APPROVER,DELIVERABLE_TYPE,DELIVERABLE_VERSION,REVIEW_CREATED_DAT) values ($task,'$whoami','Review of Patch Release Notes Checker','$reviews','M','$release_tag','$today');"
#	echo $sql
fi

exit 0
