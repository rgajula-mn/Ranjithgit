#!/bin/ksh

if [ $# -lt 7 ]; then
  echo "build_ac.sh: $0 <state> <solution version> <core reltag> <database> <oracle version> <steve version> <project>"
  echo "build_ac.sh: e.g. $0 sqa 4.3.6 GEN_5.4.22 COB3 10.2.0.SE 1 GPI"
  exit 1
fi
HOST=`hostname`
echo $HOST
code_cov=$8

. $BCE_BUILD_SCRIPTS/set_ac_paths.sh $1 $2 $3 $4 $5 $6 $7

export CCM_ROOT=${CCM_ROOT}/../${PROJ}/${THE_PROJECT}
export WRONG_CCM_ROOT=${CCM_ROOT}/..
export STEVE=${CCM_ROOT}/STEVE${STEVE_VERSION}/source
#export PATH=/usr/lib/sparcv9:/tools/SUNWspro/WS6U9/lib/v9:${PATH}:${CCM_ROOT}/STEVE${STEVE_VERSION}/source/bin:$CCM_ROOT/bin:$CCM_ROOT/TAP3RPI/RTEST:$CCM_ROOT/THK/RTEST
if [ $HOST = "camvl22" ]
then
	export PATH=/tools/gnucobol-1.1_OEL6.7/bin:${PATH}:${CCM_ROOT}/STEVE${STEVE_VERSION}/source/bin:$CCM_ROOT/bin:$CCM_ROOT/TAP3RPI/RTEST:$CCM_ROOT/THK/RTEST
#export LD_LIBRARY_PATH=/usr/lib/sparcv9:/tools/SUNWspro/WS6U9/lib/v9:/usr/ucblib/sparcv9:$LD_LIBRARY_PATH:$CCM_ROOT/lib:/opt/lib/cobol/lib:/opt/microfocus/cobol/lib
	export LD_LIBRARY_PATH=/tools/gnucobol-1.1_OEL6.7/lib:$LD_LIBRARY_PATH:$CCM_ROOT/lib:$VPACORE/lib:/opt/lib/cobol/lib:/usr/lib:/opt/microfocus/cobol/lib
elif [ $HOST = "roma" ]
	then
	export ORACLE_HOME=/opt/oracle/10.2.0.2.SE
        export TNS_ADMIN=/home/geneva
        export PATH=/opt/aCC/bin/:$ORACLE_HOME/bin:$TNS_ADMIN:$PATH
 	export SHLIB_PATH=${ORACLE_HOME}/lib:$SHLIB_PATH
        export LD_LIBRARY_PATH=${SHLIB_PATH}:$LD_LIBRARY_PATH
	export PATH=/opt/microfocus/cobol/bin:${PATH}:${CCM_ROOT}/STEVE${STEVE_VERSION}/source/bin:$CCM_ROOT/bin:$CCM_ROOT/TAP3RPI/RTEST:$CCM_ROOT/THK/RTEST
#export LD_LIBRARY_PATH=/usr/lib/sparcv9:/tools/SUNWspro/WS6U9/lib/v9:/usr/ucblib/sparcv9:$LD_LIBRARY_PATH:$CCM_ROOT/lib:/opt/lib/cobol/lib:/opt/microfocus/cobol/lib
	export LD_LIBRARY_PATH=/opt/microfocus/cobol/lib:$LD_LIBRARY_PATH:$CCM_ROOT/lib:$VPACORE/lib:/opt/lib/cobol/lib:/usr/lib:/opt/microfocus/cobol/lib
elif [ $HOST = "devapp697cn" ]
then
	export COBDIR=/tools/gnucobol-1.1_RHEL7.2
	export PATH=$COBDIR/bin:$PATH
	export PATH=$PATH:${CCM_ROOT}/VERTEX/QUANTUM/Quantum/include
	export SHLIB_PATH=${CCM_ROOT}/VERTEX/QUANTUM/Quantum/lib:$SHLIB_PATH
	export LD_LIBRARY_PATH=$COBDIR/lib:$LD_LIBRARY_PATH
else
	export PATH=/opt/microfocus/_cobol_5.1.0.20/bin:${PATH}:${CCM_ROOT}/STEVE${STEVE_VERSION}/source/bin:$CCM_ROOT/bin:$CCM_ROOT/TAP3RPI/RTEST:$CCM_ROOT/THK/RTEST
	#export LD_LIBRARY_PATH=/usr/lib/sparcv9:/tools/SUNWspro/WS6U9/lib/v9:/usr/ucblib/sparcv9:$LD_LIBRARY_PATH:$CCM_ROOT/lib:/opt/lib/cobol/lib:/opt/microfocus/cobol/lib
	export LD_LIBRARY_PATH=/opt/microfocus/_cobol_5.1.0.20/lib:$LD_LIBRARY_PATH:$CCM_ROOT/lib:$VPACORE/lib:/opt/lib/cobol/lib:/usr/lib:/opt/microfocus/cobol/lib
fi
#############################TEMP CHANGES######################

#export VI_ROOT=/irb/bce/build/vi/8.0/VI-sqa8.0.1.11.linux.oracle11g/VI
#export CTQ_HOME=${VI_ROOT}/VERTEX/COMMTAXQ/CommTaxQ/64bit
#export LD_LIBRARY_PATH=$CTQ_HOME/lib:${LD_LIBRARY_PATH}
#export LD_LIBRARY_PATH=$CTQ_HOME/bin/odbc:${LD_LIBRARY_PATH}
#export LD_LIBRARY_PATH=$CTQ_HOME/bin/odbc/lib:${LD_LIBRARY_PATH}
#############################TEMP CHANGES######################



export SHLIB_PATH=$LD_LIBRARY_PATH:$CCM_ROOT/lib
export LIBPATH=$LD_LIBRARY_PATH
#export LIBPATH=$LD_LIBRARY_PATH:$CCM_ROOT/lib

export BUILD_LOG=${LOGDIR}/make_${SMALL_PROJECT}_${THE_PLATFORM}_${THE_VERSION}_${THE_COREVERSION}_${DATABASE_VER_NAME}_${DATTIM}.log
export RECONF_LOG=${LOGDIR}/reconf_${SMALL_PROJECT}_${THE_PLATFORM}_${THE_VERSION}_${THE_COREVERSION}_${DATABASE_VER_NAME}_${DATTIM}.log
echo "build_ac.sh: The build log is located at ${BUILD_LOG}"
#unset LIBPATH
export PATH=${PATH}:/usr/vac/bin

echo "build_ac.sh: OUTPUT_ROOT       =" ${OUTPUT_ROOT:-'(unset)'} >> $BUILD_LOG 2>&1
echo "build_ac.sh: LD_LIBRARY_PATH   =" $LD_LIBRARY_PATH >> ${BUILD_LOG} 2>&1
echo "build_ac.sh: LIBPATH	     =" $LIBPATH >> ${BUILD_LOG} 2>&1
echo "build_ac.sh: PROJ              =" $PROJ >> $BUILD_LOG 2>&1
echo "build_ac.sh: DATABASE          =" $DATABASE >> $BUILD_LOG 2>&1
echo "build_ac.sh: CCM_ROOT          =" $CCM_ROOT >> $BUILD_LOG 2>&1
echo "build_ac.sh: CORE              =" $CORE >> $BUILD_LOG 2>&1
echo "build_ac.sh: VPACORE           =" ${VPACORE:-'(unset)'} >> $BUILD_LOG 2>&1
echo "build_ac.sh: TOOL              =" $TOOL >> $BUILD_LOG 2>&1
echo "build_ac.sh: STEVE             =" $STEVE >> $BUILD_LOG 2>&1
echo "build_ac.sh: HOSTNAME          = `hostname`" >> $BUILD_LOG 2>&1
echo "build_ac.sh: OPT_BUILD         = $OPT_BUILD" >> $BUILD_LOG 2>&1
echo "build_ac.sh: SOLARIS_USE_GNU   = $SOLARIS_USE_GNU" >> $BUILD_LOG 2>&1
echo "build_ac.sh: ORACLE_VERSION    = $ORACLE_VERSION" >> $BUILD_LOG 2>&1
echo "build_ac.sh: PATH              = $PATH" >> $BUILD_LOG 2>&1
echo "build_ac.sh: MAJORRELEASE      = $MAJORRELEASE" >> $BUILD_LOG 2>&1
echo "build_ac.sh: IS_5_3_OR_LATER   = $IS_5_3_OR_LATER" >> $BUILD_LOG 2>&1
echo "build_ac.sh: IS_5_4_OR_LATER   = $IS_5_4_OR_LATER" >> $BUILD_LOG 2>&1
echo "build_ac.sh: IS_3_0_OR_LATER   = $IS_3_0_OR_LATER" >> $BUILD_LOG 2>&1

echo "build_ac.sh: " >> $BUILD_LOG 2>&1
env >> $BUILD_LOG 2>&1
echo "build_ac.sh: " >> $BUILD_LOG 2>&1


#################################################################
###   ADD THE MESSAGE FILES   ###

echo "build_ac.sh: " >> $BUILD_LOG 2>&1
echo "build_ac.sh: ***** Loading ${THE_PROJECT} messages" >> $BUILD_LOG 2>&1
echo "build_ac.sh: " >> $BUILD_LOG 2>&1

if [ $THE_PROJECT = "NML"  ]
then
    echo "build_ac.sh: Building message files" >> $BUILD_LOG 2>&1
    make_mess.sh  $CCM_ROOT SCHEMA/mess/eng nml_messages.mess
fi

cd ${CCM_ROOT}/SCHEMA/mess

if [ -d dev ]
then
	echo "build_ac.sh: Using messages in dev directory"
	cd dev
elif [ -d eng ]
then
	echo "build_ac.sh: Using messages in eng directory"
	cd eng
else
	echo "build_ac.sh: No dev or eng directory"
fi

if [ "$IS_3_0_OR_LATER" = "1" -o "$IS_5_4_OR_LATER" = "1" ]
then
	for i in *.mess
	do
	  echo $i >> $BUILD_LOG 2>&1
	  $MESSC/bin/PFmessc -d $DATABASE $i >> $BUILD_LOG 2>&1
	done
else
	for i in *.mess
	do
	  echo $i >> $BUILD_LOG 2>&1
	  $MESSC/bin/GMmessc -d $DATABASE $i >> $BUILD_LOG 2>&1
	done
fi

#################################################################
###   MAKE THE PRODUCT   ###

cd $CCM_ROOT

export DEBUG=""

if [ ${THE_PROJECT} = GVI -a $PLATFORM = alpha ]
then
	echo running gvi workaround
	$BCE_BUILD_SCRIPTS/gvi_tru_workaround.sh $CCM_ROOT >> ${BUILD_LOG} 2>&1
elif [ ${THE_PROJECT} = VI -a $PLATFORM = alpha ]
then
	echo running gvi workaround
	$BCE_BUILD_SCRIPTS/gvi_tru_workaround.sh $CCM_ROOT >> ${BUILD_LOG} 2>&1
else
	# As defined below, the CCM_ROOT variable is edited to remove the project name from the path location of the project
	# CCM_ROOT=/irb/bce/build/gvi/GVI-sqa3.2.99.hp64.oracle9i2 when it should read /irb/bce/build/gvi/GVI-sqa3.2.99.hp64.oracle9i2/GVI
	if [ $THE_PROJECT != 'GVI' -a $THE_PROJECT != 'VI' ]
	then
	    echo "build_ac.sh: resetting ccm_root from $CCM_ROOT to $WRONG_CCM_ROOT"  >> ${BUILD_LOG} 2>&1
	    CCM_ROOT=$WRONG_CCM_ROOT
	fi
fi

$MAKE_CMD -k clean >> ${BUILD_LOG} 2>&1

if [ ! -z "$code_cov" ]
then
	#export PATH=/tools/ccover64/bin:$PATH
	export PATH=/home/geneva/stevel/ccover64/bin:$PATH
	export COVFILE=${CCM_ROOT}/coverage.cov
	MAKE_ARGS="CC=covc --retain --no-banner --abs cc"

	if [ ${THE_PROJECT} = TAP3 ]; then
		cat ${CCM_ROOT}/${THE_PROJECT}/Makefile | sed -e '/steve:/d' -e 's/ steve / /' -e '/STEVE/d' > ${CCM_ROOT}/${THE_PROJECT}/Makefile.cov
		MAKE_CMD="$MAKE_CMD -f Makefile.cov"
	fi
	echo "build_ac.sh: COVFILE             = $COVFILE" >> $BUILD_LOG 2>&1
	echo "build_ac.sh: MAKE_CMD            = $MAKE_CMD" >> $BUILD_LOG 2>&1
	$MAKE_CMD -k "$MAKE_ARGS" >> ${BUILD_LOG} 2>&1
else
	echo "build_ac.sh: Not running in Code Coverage Mode"
	if [ $THE_PROJECT = 'GVI' -o $THE_PROJECT = 'VI' ]             # it doesn't seem to like the -k
	then
	    echo "build_ac.sh: $MAKE_CMD  $MAKE_ARGS"  >> ${BUILD_LOG} 2>&1
	    $MAKE_CMD  $MAKE_ARGS >> ${BUILD_LOG} 2>&1
	else
	    echo "build_ac.sh: $MAKE_CMD -k $MAKE_ARGS"  >> ${BUILD_LOG} 2>&1
	    $MAKE_CMD -k $MAKE_ARGS >> ${BUILD_LOG} 2>&1
	fi
fi

if [ ${THE_PROJECT} = GVI -a $PLATFORM = alpha ]
then
	$BCE_BUILD_SCRIPTS/gvi_tru_workaround.sh $CCM_ROOT clean >> ${BUILD_LOG} 2>&1
elif [ ${THE_PROJECT} = VI -a $PLATFORM = alpha ]
then
	echo running gvi workaround
	$BCE_BUILD_SCRIPTS/gvi_tru_workaround.sh $CCM_ROOT >> ${BUILD_LOG} 2>&1
fi

#################################################################
###   REGRESSION TESTS   ###


cd $CCM_ROOT

run_rtest() {
sqlplus -s $DATABASE << +END
set feed off
set scan on
delete from GPARAMS;
insert into GPARAMS (name, type, start_dtm, string_value) values
('SYSdateOverride', 'STRING', to_date('01-JAN-1993', 'DD-MON-YYYY'), 'ANY');
commit;
exit
+END
  echo "build_ac.sh: ${1} regression test ..."
  if [ ${1} = spdgeneral ]; then
    cd $CCM_ROOT/${THE_PROJECT}/API/general/RTEST
  elif [ ${1} = spdconfig ]; then
    cd $CCM_ROOT/${THE_PROJECT}/API/config/RTEST
  elif [ ${1} = tap3general ]; then
    cd $CCM_ROOT/${THE_PROJECT}/API/general/RTEST
  elif [ ${1} = tap3export ]; then
    cd $CCM_ROOT/${THE_PROJECT}/API/export/RTEST
  elif [ ${1} = tap3import ]; then
    cd $CCM_ROOT/${THE_PROJECT}/API/import/RTEST
  elif [ ${1} = tap3manage ]; then
    cd $CCM_ROOT/${THE_PROJECT}/API/manage/RTEST
  elif [ ${1} = tap3plmn ]; then
    cd $CCM_ROOT/${THE_PROJECT}/API/plmn/RTEST
  elif [ ${1} = tap3settings ]; then
    cd $CCM_ROOT/${THE_PROJECT}/API/settings/RTEST
  elif [ ${1} = steve ]; then
    cd ${STEVE}/../RTEST
  else
    cd $CCM_ROOT/${THE_PROJECT}/${1}/RTEST
  fi
  RTEST_WD=work
  rm -rf $RTEST_WD
  mkdir $RTEST_WD
  if [ ${1} = spdconfig ]; then
    `echo gnvspdconfig | dd conv=lcase 2>/dev/null`.rtest $PWD $PWD/$RTEST_WD
  elif [ ${1} = spdgeneral ]; then
    `echo gnvspdgen | dd conv=lcase 2>/dev/null`.rtest $PWD $PWD/$RTEST_WD
  elif [ ${1} = tap3general ]; then
    `echo gnvsolgen | dd conv=lcase 2>/dev/null`.rtest $PWD $PWD/$RTEST_WD
  elif [ ${1} = tap3export ]; then
    `echo gnvtap3export | dd conv=lcase 2>/dev/null`.rtest $PWD $PWD/$RTEST_WD
  elif [ ${1} = tap3manage ]; then
    `echo gnvTAP3manage 2>/dev/null`.rtest $PWD $PWD/$RTEST_WD
  elif [ ${1} = tap3import ]; then
    `echo gnvtap3import | dd conv=lcase 2>/dev/null`.rtest $PWD $PWD/$RTEST_WD
  elif [ ${1} = tap3plmn ]; then
    `echo gnvtap3plmn | dd conv=lcase 2>/dev/null`.rtest $PWD $PWD/$RTEST_WD
  elif [ ${1} = tap3settings ]; then
    `echo gnvtap3settings | dd conv=lcase 2>/dev/null`.rtest $PWD $PWD/$RTEST_WD
  else
    `echo ${1} | dd conv=lcase 2>/dev/null`.rtest $PWD $PWD/$RTEST_WD
  fi
  if [ ${1} = SPDRPI ]; then
    echo "build_ac.sh: ${1} int regression test ..."
    RTEST_WD=work2
    rm -rf $RTEST_WD
    mkdir $RTEST_WD
    `echo ${1} | dd conv=lcase 2>/dev/null`.int.rtest $PWD $PWD/$RTEST_WD
  fi
}

if [ ${THE_PROJECT} = TAP3 ]; then
# load in the procedures, if TAP 7.3 or later (ie Geneva 5.3 or later) then pick them
# up from the sqlbdy directory

sqlplus -s $DATABASE << +ENDSQL3
whenever sqlerror exit failure
@${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3config/gnvprdwarning.spc
@${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3config/gnvsolgen.spc
@${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3config/gnvtap3export.spc
@${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3config/gnvtap3import.spc
@${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3config/gnvtap3plmn.spc
@${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3config/gnvtap3settings.spc
@${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3management/gnvTAP3manage.spc
commit;
exit
+ENDSQL3

if [ $IS_5_3_OR_LATER -eq 1 ]
then
    echo "build_ac.sh: loading built plbs"   | tee -a $BUILD_LOG 2>&1  
    sqlplus -s $DATABASE << +ENDSQL3
    whenever sqlerror exit failure
    @${CCM_ROOT}/${THE_PROJECT}/sqlbdy/gnvprdwarning.plb
    @${CCM_ROOT}/${THE_PROJECT}/sqlbdy/gnvsolgen.plb
    @${CCM_ROOT}/${THE_PROJECT}/sqlbdy/gnvtap3export.plb
    @${CCM_ROOT}/${THE_PROJECT}/sqlbdy/gnvtap3import.plb
    @${CCM_ROOT}/${THE_PROJECT}/sqlbdy/gnvtap3plmn.plb
    @${CCM_ROOT}/${THE_PROJECT}/sqlbdy/gnvtap3settings.plb
    @${CCM_ROOT}/${THE_PROJECT}/sqlbdy/gnvTAP3manage.plb
    commit;
    exit
+ENDSQL3

    if [ -s ${CCM_ROOT}/${THE_PROJECT}/sqlbdy/gnvTAP3manage.plb ]
    then
	echo "build_ac.sh: loading built plbs - ${CCM_ROOT}/${THE_PROJECT}/sqlbdy/gnvtap3settings.plb"   | tee -a $BUILD_LOG 2>&1  
	sqlplus -s $DATABASE << +ENDSQL3
	whenever sqlerror exit failure	
	@${CCM_ROOT}/${THE_PROJECT}/sqlbdy/gnvTAP3manage.plb
	commit;
	exit
+ENDSQL3
    fi

else     # TAP 7.2 and earlier
    echo "build_ac.sh: loading checked in plbs"  | tee -a $BUILD_LOG 2>&1
    sqlplus -s $DATABASE << +ENDSQL3
    whenever sqlerror exit failure
    @${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3config/gnvprdwarning.plb
    @${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3config/gnvsolgen.plb
    @${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3config/gnvtap3export.plb
    @${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3config/gnvtap3import.plb
    @${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3config/gnvtap3plmn.plb
    @${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3config/gnvtap3settings.plb
    @${CCM_ROOT}/${THE_PROJECT}/SCHEMA/procedures/tap3management/gnvTAP3manage.plb
    commit;
    exit
+ENDSQL3
fi

# load in the triggers
triggerfile="${CCM_ROOT}/${THE_PROJECT}/SCHEMA/SRC/trigger.sql"
${TOOL}/runsqlplus "@${triggerfile}"

#  run_rtest steve >> ${BUILD_LOG} 2>&1
#  run_rtest TFI >> ${BUILD_LOG} 2>&1
#  run_rtest TGM >> ${BUILD_LOG} 2>&1
#  run_rtest SOLRPI >> ${BUILD_LOG} 2>&1
#  run_rtest TAP3RPI >> ${BUILD_LOG} 2>&1
#  run_rtest RUI >> ${BUILD_LOG} 2>&1
#  run_rtest RFT >> ${BUILD_LOG} 2>&1
#  run_rtest SIS >> ${BUILD_LOG} 2>&1
#  run_rtest HURG >> ${BUILD_LOG} 2>&1
#  run_rtest TFE >> ${BUILD_LOG} 2>&1
#  run_rtest TUT >> ${BUILD_LOG} 2>&1
#  run_rtest THK >> ${BUILD_LOG} 2>&1
#  run_rtest TDD >> ${BUILD_LOG} 2>&1
#  run_rtest TDA >> ${BUILD_LOG} 2>&1
#  run_rtest tap3general >> ${BUILD_LOG} 2>&1
#  run_rtest tap3manage >> ${BUILD_LOG} 2>&1
#  run_rtest tap3export >> ${BUILD_LOG} 2>&1
#  run_rtest tap3import >> ${BUILD_LOG} 2>&1
#  run_rtest tap3settings >> ${BUILD_LOG} 2>&1
#  run_rtest tap3plmn >> ${BUILD_LOG} 2>&1
#elif [ ${THE_PROJECT} = SPD ]; then
#  run_rtest EVD >> ${BUILD_LOG} 2>&1
#  run_rtest SOLRPI >> ${BUILD_LOG} 2>&1
#  run_rtest SPDRPI >> ${BUILD_LOG} 2>&1
#  run_rtest DDD >> ${BUILD_LOG} 2>&1
#  run_rtest spdconfig >> ${BUILD_LOG} 2>&1
#  run_rtest spdgeneral >> ${BUILD_LOG} 2>&1
#
#  cd $CCM_ROOT/${THE_PROJECT}/bin
#  EVD -v
#
#  COREBASERELEASE=`echo ${THE_COREVERSION} | cut -d'.' -f1-2`
#
#  rm -f RATE
#  ln -s ${BCE_ROOT}/release/${COREBASERELEASE}/GENEVAINSTALL-sqa${THE_COREVERSION}.${2}.${DATABASE_VER_NAME}/GENEVAINSTALL/bin/RATE ./RATE
#  RATE -v
#
#  rm -f FID
#  ln -s ${BCE_ROOT}/release/${COREBASERELEASE}/GENEVAINSTALL-sqa${THE_COREVERSION}.${2}.${DATABASE_VER_NAME}/GENEVAINSTALL/bin/FID ./FID
#  FID -v
#
#  cd $CCM_ROOT/${THE_PROJECT}/SYSTEST
#
#  sqlplus $DATABASE <<ENDED
#    delete from costedevent;
#ENDED
#
#  EVDsystest.sh
#
#  sqlplus $DATABASE <<ENDED
#    select   account_num, event_type_id, count(*)
#    from     costedevent
#    group by account_num, event_type_id;
#ENDED
elif [ ${THE_PROJECT} = NML ]; then
  run_rtest NMP >> ${BUILD_LOG} 2>&1
  run_rtest NMPO >> ${BUILD_LOG} 2>&1
  run_rtest JCODE >> ${BUILD_LOG} 2>&1
fi



#################################################################
###   RESULTS SUMMARY   ###

echo "build_ac.sh: Subject: Build Results, ${PROJ}" > ${LOGDIR}/build.tmp
echo "build_ac.sh: To: PDM.Geneva.BCE.Build.Log@Convergys.com" >> ${LOGDIR}/build.tmp
cat ${BUILD_LOG} >> ${LOGDIR}/build.tmp

cat ${LOGDIR}/build.tmp | /usr/lib/sendmail -F "${PROJ}" `cat ${BCE_ADMIN}/email/${SMALL_PROJECT}_build_managers`


echo "build_ac.sh: Subject: Regression Test Results, ${PROJ}" > ${LOGDIR}/build.tmp
echo "build_ac.sh: To:PDM.Geneva.BCE.Rtest.Log@Convergys.com" >> ${LOGDIR}/build.tmp
echo "build_ac.sh:  " >> ${LOGDIR}/build.tmp
echo "build_ac.sh: The Following Regression Tests failed: " >> ${LOGDIR}/build.tmp
cat ${BUILD_LOG} | grep "regression" | grep -v "on a laptop set" | grep -v PASS | grep -v passed | grep -v "\.\.\." >> ${LOGDIR}/build.tmp
echo "build_ac.sh:  " >> ${LOGDIR}/build.tmp
echo "build_ac.sh: If anything is listed in this area, you will have to manually look though the log file for the occurance of the string: " >> ${LOGDIR}/build.tmp
cat ${BUILD_LOG} | grep "Error reported in load.log" >> ${LOGDIR}/build.tmp
echo "build_ac.sh:  " >> ${LOGDIR}/build.tmp
echo "build_ac.sh: Failed to Find the following Rtests Harnesses: (Maybe due to items not building)" >> ${LOGDIR}/build.tmp
cat ${BUILD_LOG} | grep "Can't find" >> ${LOGDIR}/build.tmp
echo "build_ac.sh:  " >> ${LOGDIR}/build.tmp
echo "build_ac.sh: The Following Regression Tests passed: " >> ${LOGDIR}/build.tmp
cat ${BUILD_LOG} | grep "regression" | grep -v "on a laptop set" |  grep -v FAIL | grep -v failed | grep -v "\.\.\." >> ${LOGDIR}/build.tmp

if [ "${THE_STATE}" = "dev" ]
then
	debugemail="${THE_STATE}"
else
	debugemail=""
fi

cat ${LOGDIR}/build.tmp | /usr/lib/sendmail -F "${PROJ}" `cat ${BCE_ADMIN}/email/${debugemail}${SMALL_PROJECT}_test_managers`
