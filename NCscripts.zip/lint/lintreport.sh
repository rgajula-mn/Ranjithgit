#!/bin/sh
#                                                                               
# FILENAME    : %name: lintreport.sh %                                           
#                                                                               
# AUTHOR      : Daniel Bloy                                                     
#                                                                               
# DESCRIPTION : This script runs lint over the results of a run of lintproject.sh
#               and produces a simple report on the number of warnings and tags. 
#
#               Type 1 warnings are those that start on a new line followed by a comma.
#               Type 2 warnings are those that are contained within parenthesis.
#
# (C) Convergys, 2007.                                                          
# Convergys refers to Convergys Corporation or any of its wholly owned          
# subsidiaries.                                                                 
#                                                                

g_tags_file=

#
# Validates the input parameters and sets up the global variables.              
#
usage() {

    if [ $# -lt 1 ]; then
        echo "Usage: ${0} <results prefix>"
        exit 2
    fi

    g_tags_file=${1}.tags
}

usage $@

echo Running on result directory `pwd`...
g_temp_1=lintreport.temp.1
g_temp_2=lintreport.temp.2

g_instances_type_1=`cat *.log | grep \^E_ | cut -d , -f1 | wc -l`
g_instances_type_2=`cat *.log | grep -v 'E_INCONS_ARG_USED2' | grep \(E_ | sed -e 's/(E_/@(E_/' | cut -d @ -f2 | sed -e 's/(/ /' -e 's/)/ /' | cut -d ' ' -f2 | wc -l`
g_total_instances=`expr ${g_instances_type_1} + ${g_instances_type_2}`

echo Number of type 1 warnings .. : ${g_instances_type_1}
echo Number of type 2 warnings .. : ${g_instances_type_2}
echo Total number of warnings ... : ${g_total_instances}

cat *.log | grep \^E_ | cut -d , -f1 | sort | uniq > ${g_temp_1}
cat *.log | grep -v 'E_INCONS_ARG_USED2' | grep \(E_ | sed -e 's/(E_/@(E_/' | cut -d @ -f2 | sed -e 's/(/ /' -e 's/)/ /' | cut -d ' ' -f2 | sort | uniq > ${g_temp_2}
cat ${g_temp_1} ${g_temp_2} | sort | uniq > ${g_tags_file}

g_tags_type_1=`cat ${g_temp_1} | wc -l`
g_tags_type_2=`cat ${g_temp_2} | wc -l`
g_total_tags=`cat ${g_tags_file} | wc -l`

echo Number of type 1 tags ...... : ${g_tags_type_1}
echo Number of type 2 tags ...... : ${g_tags_type_2}
echo Total number of tags ....... : ${g_total_tags}

rm ${g_temp_1}
rm ${g_temp_2}

echo Finished





