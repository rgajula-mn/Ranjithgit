#!/bin/sh
for file in `ls -d *.o`; do
    cp ${file} ${file//.o/.i}
done




