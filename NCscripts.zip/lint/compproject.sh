#!/bin/sh
#                                                                               
# FILENAME    : %name: compproject.sh %                                           
#                                                                               
# AUTHOR      : Daniel Bloy                                                     
#                                                                               
# DESCRIPTION : This script runs the compiler over an entire code project. 
#               The compiler is run on each directory that contains a SRC sub 
#               directory. All results are collated in the given results
#               directory.
#
#               This script must be run from the projects root directory. The
#               project needs to have previously had a base build to ensure that
#               all desired modules are available.
#                                                                               
# (C) Convergys, 2007.                                                          
# Convergys refers to Convergys Corporation or any of its wholly owned          
# subsidiaries.                                                                 
#                                                                

#
# Global variables.
#

g_results_directory=

#                                                                               
# Validates the input parameters and sets up the global variables.
#                                                                               
usage() {                                                                       
                                                                                
    if [ $# -lt 1 ]; then                                                       
        echo "Usage: ${0} <results directory>"
        exit 2                                                                  
    fi                                                                          
                                                                                
    g_results_directory=${1}                                                           
                                                                                
    if [ ! -d ${g_results_directory} ]; then                                             
        echo "The specified results directory does not exist."
        exit 2                                                                  
    fi                                                                          

}                                                                               
                                                                                
#
# Program starts here
#
usage $@ 

echo Starting compiler warnings build on `pwd`...


# Now we loop through all the files in the directory and 
# see if they have a SRC directory.
for module in `ls -d *`; do

  module_exists=`cat Makefile | sed -n -e "s/MODULES/VOID/" \
                                       -e "s/[a-zA-Z]${module}/VOID/" \
                                       -e "s/${module}[a-zA-Z]/VOID/" \
                                       -e "s/.*${module}.*/${module}/p"`
  echo ${module_exists}
  
  if [ ${module} != "${module_exists}" ]; then
     echo "${module} is NOT in the Makefile"
  else
     if [ -d ${module}/SRC ]; then
        echo Running build in ${module}...
        results_file=${g_results_directory}/${module}.build.log

        # Now we build the module. Remember to clean it first though.
        cd ${module}/SRC
        echo Make clean ${module}/SRC and make
        make clean -k

        make LOCAL_CFLAGS="-DDEBUG -g" -k 1> ${results_file} 2>&1

        cd ../..
     else
        echo ${module} does not have a SRC directory to build

     fi 

  fi 
  
done

echo Finshed...



