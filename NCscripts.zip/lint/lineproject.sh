#!/bin/sh
#                                                                               
# FILENAME    : %name: lineproject.sh %                                           
#                                                                               
# AUTHOR      : Daniel Bloy                                                     
#                                                                               
# DESCRIPTION : This script runs a word count over an entire code project. 
#               The word count is run on each directory that contains a SRC sub 
#               directory. All results are collated in the given results
#               directory.
#
#               This script must be run from the projects root directory.
#                                                                               
# (C) Convergys, 2007.                                                          
# Convergys refers to Convergys Corporation or any of its wholly owned          
# subsidiaries.                                                                 
#                                                                

#
# Global variables.
#
g_results_directory=

g_c_lines=0
g_cc_lines=0
g_cpp_lines=0
g_pc_lines=0
g_h_lines=0
g_hh_lines=0
g_total_lines=0

g_result_module=MODULE
g_result_c_line=C
g_result_cc_lines=CC
g_result_cpp_lines=CPP
g_result_pc_lines=PC
g_result_h_lines=H
g_result_hh_lines=HH
g_result_total_lines=Total

#                                                                               
# Validates the input parameters and sets up the global variables.
#                                                                               
usage() {                                                                       
                                                                                
    if [ $# -lt 1 ]; then                                                       
        echo "Usage: ${0} <results directory>"
        exit 2                                                                  
    fi                                                                          
                                                                                
    g_results_directory=${1}                                                           
                                                                                
    if [ ! -d ${g_results_directory} ]; then                                             
        echo "The specified results directory does not exist."
        exit 2                                                                  
    fi                                                                          

}                                                                               

                                                                                # 
# Counts the number of lines in files of the specified
# extension in the current directory.
#
countCodeTypeForDir()
{
    file_ext=${1}
    pattern=\\.${file_ext}$
    result=0
    for file in `ls -1 | grep $pattern`; do
        z=`cat ${file} | wc -l`
        result=`expr ${result} + ${z}`
    done

    echo $result
}


#
# This function counts the number of lines for each code type in
# the current directory
#
countCodeForDir()
{
    g_c_lines=0
    g_cc_lines=0
    g_cpp_lines=0
    g_pc_lines=0
    g_h_lines=0
    g_hh_lines=0
    g_total_lines=0

    g_c_lines=`countCodeTypeForDir c`
    g_cc_lines=`countCodeTypeForDir cc`
    g_cpp_lines=`countCodeTypeForDir cpp`
    g_pc_lines=`countCodeTypeForDir pc`
    g_h_lines=`countCodeTypeForDir h`
    g_hh_lines=`countCodeTypeForDir hh`
    g_total_lines=`expr ${g_c_lines}`
    #g_total_lines=`expr ${g_c_lines} + ${g_cc_lines} + ${g_cpp_lines} + ${g_pc_lines} + ${g_h_lines} + ${g_hh_lines}`
}


#
# Program starts here
#
usage $@ 

echo Starting line counting on `pwd`...

# Now we loop through all the files in the directory and 
# see if they have a SRC directory.
for module in `ls -d *`; do

    if [ -d ${module}/SRC ]; then

        echo Running line count in ${module}...
        results_file=${g_results_directory}/${module}.build.log

        # Now we build the module. Remember to clean it first though.
        cd ${module}/SRC

        countCodeForDir

        # Generate strings for final results.
        g_result_module="${g_result_module}, ${module}"
        g_result_c_line="${g_result_c_line}, ${g_c_lines}"
        g_result_cc_lines="${g_result_cc_lines}, ${g_cc_lines}"
        g_result_cpp_lines="${g_result_cpp_lines}, ${g_cpp_lines}"
        g_result_pc_lines="${g_result_pc_lines}, ${g_pc_lines}"
        g_result_h_lines="${g_result_h_lines}, ${g_h_lines}"
        g_result_hh_lines="${g_result_hh_lines}, ${g_hh_lines}"
        g_result_total_lines="${g_result_total_lines}, ${g_total_lines}"

        echo "MODULE, ${module}" 1> ${results_file} 2>&1
        echo "C,      ${g_c_lines}" 1>> ${results_file} 2>&1
        echo "CC,     ${g_cc_lines}" 1>> ${results_file} 2>&1
        echo "CPP,    ${g_cpp_lines}" 1>> ${results_file} 2>&1
        echo "PC,     ${g_pc_lines}" 1>> ${results_file} 2>&1
        echo "H,      ${g_h_lines}" 1>> ${results_file} 2>&1
        echo "HH,     ${g_hh_lines}" 1>> ${results_file} 2>&1
        echo "Total,  ${g_total_lines}" 1>> ${results_file} 2>&1

        cd ../..

    fi 

done

echo Generating complete results.

results_file=${g_results_directory}/results.log

echo "${g_result_module}" 1> ${results_file} 2>&1
echo "${g_result_total_lines}" 1>> ${results_file} 2>&1


echo Finshed...



