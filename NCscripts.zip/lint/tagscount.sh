#!/bin/sh
#
# FILENAME    : %name: tagscount.sh %
#
# AUTHOR      : Daniel Bloy
#
# DESCRIPTION : This file is used to perform two operations. If two command line
#               arguments are specified, this script counts the number of times
#               that each tag specified within the tag file appears within the
#               given input file.
#
#               If a third parameter is specified, this script extracts all of those
#               lines containing the given extraction tag and removes all of the
#               lines that contain one of the tags specified in the tag file.
#
# (C) Convergys, 2007.
# Convergys refers to Convergys Corporation or any of its wholly owned
# subsidiaries.
#


#
# Global variables.
#
g_tag_file=
g_input_file=
g_extract_tag=

#
# Validates the input parameters and sets up the global variables.
#
usage() {

    if [ $# -lt 2 ]; then
        echo "Usage: ${0} <input file> <tag file> | <extract tag>"
        exit 2
    fi

    g_input_file=${1}
    g_tag_file=${2}

    if [ ! -f ${g_tag_file} ]; then
        echo "The specified tag file does not exist."
        exit 2
    fi

    if [ ! -f ${g_input_file} ]; then
        echo "The specified input file does not exist."
        exit 2
    fi

    if [ $# -eq 3 ]; then
        g_extract_tag=${3}
    fi

}

usage $@

#
# If no extract has been specified then we simply count the tags
#
if [ "${g_extract_tag}" = "" ]; then
    for tag in `cat ${g_tag_file}`; do
        count=`cat ${g_input_file} | grep "${tag}" | wc -l`
        echo ${tag}, ${count}
    done
else
    extract_cmd=
    for tag in `cat ${g_tag_file}`; do
        extract_cmd="${extract_cmd} -e ""/${tag}/d"""
    done
    cat ${g_input_file} | grep "${g_extract_tag}" | sed ${extract_cmd}
fi

