#!/bin/sh
#                                                                               
# FILENAME    : %name: compresults.sh %                                           
#                                                                               
# AUTHOR      : Daniel Bloy                                                     
#                                                                               
# DESCRIPTION : This script runs over the results from a run of compproject.sh
#               and produces a tabulated result of the warnings from all build 
#               log files for all modules.
#                                                                               
# (C) Convergys, 2007.                                                          
# Convergys refers to Convergys Corporation or any of its wholly owned          
# subsidiaries.                                                                 
#                                                                

#
# Global variables.
#
g_results_file=

g_number_of_lines=0

g_temp_1=compresults.temp.1

#                                                                               
# Validates the input parameters and sets up the global variables.
#                                                                               
usage() {                                                                       
                                                                                
    if [ $# -lt 1 ]; then
        echo "Usage: ${0} <results file>"
        exit 2                                                                  
    fi                                                                          

    g_results_file=${1}
}                                                                               
                                                                                
#
# Program starts here
#
usage $@ 

echo Calculating results for `pwd`...

#
# Prepare the format of the results file and determine how many lines it will have.
#
echo "MODULE_NAME" >  ${g_results_file}
echo "Warnings"    >> ${g_results_file}

# Now we loop through all the build log files.
for log_file in `ls -d *.build.log`; do

    # Determine the module name.
    module_name=`echo ${log_file} | sed -e 's/.build.log//'`

    if [ -f ${log_file} ]; then

        echo Now processing ${module_name}...

        number_of_warnings=`grep -i warning ${log_file} | \
            sed -e '/is too large and will not be expanded inline/d' \
                -e '/is too large to generate inline/d' \
                -e '/WARNING/d' \
                -e '/Warning.s. detected/d' \
                -e '/GTLpthread.hh/d' \
                -e '/CMqueueParse.l/d' \
                -e '/.irb.infinys.release.platform/d' \
                -e '/.tools.SUNWspro.WS6U2.include/d' \
		-e '/Clock skew detected/d' \
                -e '/LOGFILE.REGISTRY.CONTEXT/d'\
                -e '/xarch.v9.is.deprecated/d'\
                -e '/CORE.PFAIS.SRC/d'\
                -e '/CORE.PFTOOLS.SRC/d'\
                -e '/CORE.TM.SRC.TMPImain/d'\
                -e '/PF..AIS..PF/d'\
                -e '/.SunStudio11.SUNWspro.prod.include/d' | wc -l`

          results_line=`cat ${g_results_file} | sed -n -e "1,1 p"`
        echo "${results_line},${module_name}" > ${g_temp_1}

        results_line=`cat ${g_results_file} | sed -n -e "2,2 p"`
        echo "${results_line},${number_of_warnings}" >> ${g_temp_1}

        # Now we overwrite the old results file
        cp ${g_temp_1} ${g_results_file}

    fi 

done

rm ${g_temp_1}

echo Finished.

