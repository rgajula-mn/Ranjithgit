#!/bin/sh

# Output the number of messages loaded into the database.
countmessages(){
    echo ""

sqlplus -s ${DATABASE} <<EOF 
    set serverout on;
    set heading off;

    declare 
        iCount binary_integer;
    begin
        select count(*) into iCount from GMmessage ;
        dbms_output.put_line(iCount || ' messages loaded.');  
    end;
/
EOF
}

# Delete the existing messages from the database.
deletemessages(){
    echo Now deleting messages from the database...

sqlplus -s ${DATABASE} <<EOF >> load.log
    truncate table PFMESSAGE;
    commit;
    truncate table GMMESSAGE;
    commit;
EOF

    echo Done.
    echo ""
}

# Load the actual messages.
loadmessages()
{
    dir=${1}
    if [ -n "$dir" ] && [ -d $dir ]; then
        cd $dir
        echo Loading messages for `pwd`...

        # Now we loop through all the files in the directory and 
        # see if they have a SRC directory.
        for src_dir in `ls -d *`; do

            if [ -d ${src_dir}/SRC ]; then

                # Now we load the message files.
                cd ${src_dir}/SRC

                for message_file in `ls -d *.mess`; do
                    $MESSAGE_TOOL -d $DATABASE ${message_file}
                done

                cd ../..

            fi 

        done

        # The above look could be replaced with the following but it
        # doesn't work on all platforms.
        # find -name \*\.mess -exec $MESSAGE_TOOL -d $DATABASE {} \;    
    fi
}


# Remember start
pushd `pwd`

echo Loading messages for $CCM_ROOT
echo into database $DATABASE...
echo ""

# Locate the message tool to use first.
MESSAGE_TOOL=PFmessc
if `which GMmessc`
then
    MESSAGE_TOOL=GMmessc
fi
echo Using $MESSAGE_TOOL to load the messages.


deletemessages

loadmessages $SCHEMA
loadmessages $CORE
loadmessages $VPACORE
loadmessages $RATE
loadmessages $BILL
loadmessages $FINANCE

countmessages

popd
