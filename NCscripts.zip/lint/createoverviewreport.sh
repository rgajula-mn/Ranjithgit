#!/bin/sh
#
# FILENAME    : %name: createoverviewreport.sh %
#
# AUTHOR      : Jeremy Wadley
#
# DESCRIPTION : Compiles a very high level and simple html output 
#               for Compiler and Lint Warnings (save to calling function)
#
# (C) Convergys, 2007.
# Convergys refers to Convergys Corporation or any of its wholly owned
# subsidiaries.
#



#
# Validates the input parameters and sets up the global variables.
#
usage() {

    if [ $# -lt  1 ]; then
        echo "Usage: ${0} <results directory>"
        exit 2
    fi

    overview_results_directory=${1}
    overview_report=$overview_results_directory/reports/warnings_overview_report.html

    
    if [ ! -d ${overview_results_directory} ]; then
        echo "The specified results directory does not exist."
        exit 2
    fi

    rm -rf ${overview_results_directory}/tmp
    mkdir -p ${overview_results_directory}/tmp
    
    g_temp_compiler_file=${overview_results_directory}/tmp/compileroverview.log.tmp
    g_temp_lint_file=${overview_results_directory}/tmp/lintoverview.log.tmp
    
    
    g_compiler_total=0
    g_lint_total=0
}

# Dumps the data file in a html table.
dump_table() {
	FILE=${1}
	CAPTION=${2}
	input_total=${3}

	echo "<h2>${CAPTION}</h2>" >> $overview_report
	echo "<table border=\"1\">" >> $overview_report

	row=1
	total=0
  
	OUTPUT_LINE="<tr><th align=center>Total</th>"
	OUTPUT_LINE="${OUTPUT_LINE}</tr>"

	echo "${OUTPUT_LINE}" >> $overview_report
     
	column=1
	row=2

	for line in `cat ${FILE}` 
	do

		if [ ${column} -eq 1 ] 
		then
			# Total Column
			OUTPUT_LINE="<tr>"
			if [ $line -ne 0 ]
			then
				color="bgcolor=lightsalmon"
			else
				color="bgcolor=lightgreen"
			fi
			OUTPUT_LINE="${OUTPUT_LINE}<td ${color} align=center>${line}</td>"
			column=2
		else
			# Project Column
			OUTPUT_LINE="${OUTPUT_LINE}<td align=center><a href='warnings_detailed_report.html#${line}'>${line}</a></td>"
			OUTPUT_LINE="${OUTPUT_LINE}</tr>"
			echo ${OUTPUT_LINE} >> $overview_report
			column=1
			row=`expr ${row} + 1`
		fi
	done

	if [ ${input_total} -gt 0 ] 
	then
		color="bgcolor=lightsalmon"
	else
		color="bgcolor=lightgreen"
	fi

	echo "<th ${color} align=center>${input_total}</th>" >> $overview_report
	echo "<td colspan=${column}>&nbsp;</td>" >> $overview_report
	echo "</table>" >> $overview_report
}

#
# Prints at the top of the report the state of the build
#
print_build_stats() {
   cd ${1}
   
   error_count=0
   
   echo "<h2>Build Status:    Reporting Currently Under Development</h2>" >> $overview_report
#   for dir in `ls -d * | grep -v API`; do
#     if [ -d ${dir} ]; then
#       cd ${dir}
#       echo "<H3>In the ${dir} Project</H3>"
#       echo "<TABLE>"
#       echo "<tr><th width=150>Module</th><th width=150>Module Errors</th><th width=150>Running Total Errors</th></tr>"
#       
#       for make_log in `ls *.build.log`; do
#           log_errors=`cat $make_log | compiler_errors_wc`
#           error_count=`expr ${error_count} + ${log_errors}`
#	   if [ $log_errors -gt 0 ]
#	   then
#	       module=`echo $make_log | cut -d'.' -f1`
#               echo "<tr><td>$module</td><td>${log_errors}</td>"
#               echo "<td>${error_count}</td></tr>"
#	   fi
#       done
#       echo "</TABLE>"
#       
#       cd ..
#     fi
#   done
#   
#   echo "Build Error Count = ${error_count}<BR>"
   echo
}


#
# Program starts here
#
usage $@ 

# process Compiler warnings first
cd ${overview_results_directory}/compiler.logs

tmp_compiler_count=0
for compiler_dir in `ls -d *`; do
    if [ -d ${compiler_dir} ]; then
        cd ${compiler_dir}
        compileroverviewreport.sh ${compiler_dir} ${g_temp_compiler_file}
        tmp_compiler_count=$?
        g_compiler_total=`expr ${g_compiler_total} + ${tmp_compiler_count}`
        cd ..
    fi
done
cd ..

# process Lint warnings first

cd ${overview_results_directory}/lint.logs

tmp_lint_count=0
for lint_dir in `ls -d *`; do
    if [ -d ${lint_dir} ]; then
        cd ${lint_dir}
        lintoverviewreport.sh ${lint_dir} ${g_temp_lint_file}
        tmp_lint_count=`cat ${g_temp_lint_file} | grep "${lint_dir}$" | awk '{print $1}'`
        g_lint_total=`expr ${g_lint_total} + ${tmp_lint_count}`
        cd ..
    fi
done
cd ..


echo "<html>" > $overview_report
echo "<head>" >> $overview_report
echo "</head>" >> $overview_report
echo "<body>" >> $overview_report

date=`date '+%A %e %B  %Y'`
echo "<h2>Compiler and Lint Warning Results Overview </h2>" >> $overview_report
echo "<h2>\tReport Produced: ${date}</h2>" >> $overview_report

print_build_stats ${overview_results_directory}/compiler.logs


dump_table ${g_temp_compiler_file} "COMPILER WARNINGS" ${g_compiler_total}
dump_table ${g_temp_lint_file} "LINT WARNINGS" ${g_lint_total}

echo "LINTWARNINGS: $g_lint_total"

echo "<h2>Detailed Information</h2>" >> $overview_report
echo "<a target=\"_blank\" href=\"warnings_detailed_report.html\">Detailed Report </a><br><br>" >> $overview_report

echo "</body>" >> $overview_report
echo "</html>" >> $overview_report


rm -rf ${overview_results_directory}/tmp
