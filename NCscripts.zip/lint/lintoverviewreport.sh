#!/bin/sh
#                                                                               
# FILENAME    : %name: lintoverviewreport.sh %                                           
#                                                                               
# AUTHOR      : Jeremy Wadley                                                     
#                                                                               
# DESCRIPTION : This script summarises the findings of the Lint build, 
#               summarising at a global and directory level. 
#
# #
# (C) Convergys, 2007.                                                          
# Convergys refers to Convergys Corporation or any of its wholly owned          
# subsidiaries.                                                                 
#                                                                


#
# Validates the input parameters and sets up the global variables.              
#
usage() {

    if [ $# -lt 2 ]; then
        echo "Usage: ${0} <directory>  <reportfile>"
        exit 2
    fi

    lint_dir=${1}
    g_report_file=${2}
}

usage $@


g_instances_type_1=`cat *.log | grep \^E_ | cut -d , -f1 | wc -l`
g_instances_type_2=`cat *.log | grep -v 'E_INCONS_ARG_USED2' | grep \(E_ | sed -e 's/(E_/@(E_/' | cut -d @ -f2 | sed -e 's/(/ /' -e 's/)/ /' | cut -d ' ' -f2 | wc -l`
g_total_instances=`expr ${g_instances_type_1} + ${g_instances_type_2}`


echo "${g_total_instances} ${lint_dir}" >> ${g_report_file}
