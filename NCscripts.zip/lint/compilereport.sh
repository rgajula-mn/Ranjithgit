#!/bin/sh
#
# FILENAME    : %name: compilereport.sh %
#
# AUTHOR      : Daniel Bloy
#
# DESCRIPTION : Compiles a very simpl html report of the compiler and lint
#               warning results.
#
# (C) Convergys, 2007.
# Convergys refers to Convergys Corporation or any of its wholly owned
# subsidiaries.
#


#
# Global variables.
#
g_results_directory=


#
# Validates the input parameters and sets up the global variables.
#
usage() {

    if [ $# -lt 1 ]; then
        echo "Usage: ${0} <results directory>"
        exit 2
    fi

    g_results_directory=${1}

    if [ ! -d ${g_results_directory} ]; then
        echo "The specified results directory does not exist."
        exit 2
    fi

}

# Dumps the data file in a html table.
dump_table() {

    FILE=${1}
    CAPTION=${2}
    WARN_OR_LINT=${3}

    project=`echo $CAPTION | cut -d' ' -f1`

    echo "<h3><A NAME='$project'>${CAPTION}</a></h3>"
    echo "<table border=\"1\">"

    row=1
    total=0
    # Because of an inconsistency in output formats, force spaces to zeros.
    for line in `cat ${FILE} | sed -e 'y/ /0/'`; do
        OUTPUT_LINE="<tr>"
        column=1

        # Do we need to count the totals for this line.
        if [ ${row} -gt 1 ]; then

            row_total=0
            temp_col=0
            numbers=`echo ${line} | sed -e 'y/,/ /'`
            for number in ${numbers} 
	    do
                if [ ${temp_col} -eq 0 ] 
                then
                    temp_col=1
                else
                    row_total=`expr ${row_total} + ${number}`
                fi
            done
            total=`expr ${total} + ${row_total}`

            color=""
            if [ ${row_total} -gt 0 ] 
	    then
                color="bgcolor=lightsalmon"
	    else
   		continue
            fi
            OUTPUT_LINE="${OUTPUT_LINE}<td ${color} align=center>${row_total}</td>"
        else
            OUTPUT_LINE="${OUTPUT_LINE}<th align=center>Total</th>"
        fi

        line=`echo ${line} | sed -e 'y/,/ /'`
        for tag in ${line} 
	do
            if [ ${row} -eq 1 ] || [ ${column} -eq 1 ] 
            then
		echo $tag | grep "^E_" > /dev/null
		if [ $? -eq 0 ]
		then
			taghyp=`echo $tag | sed -e 's/_/-/g'`
                	OUTPUT_LINE="${OUTPUT_LINE}<th align=center><A HREF='http://osprey.emea.convergys.com/lint/errors.html#${taghyp}'>${tag}</a></th>"
		else
			if [ "$WARN_OR_LINT" = "lint" ]
			then
				if [ "${tag}" = "MODULE_NAME" ]
				then
                			OUTPUT_LINE="${OUTPUT_LINE}<th align=center>Module Name</th>"
				else
					taghyp=`find $g_results_directory/../lint.logs -name "${tag}.build.log" -print | sed -e 's/.*\/.*\/\(.*\/.*\/\)/\1/'`
                			OUTPUT_LINE="${OUTPUT_LINE}<th align=center><A HREF='../${taghyp}'>${tag}</A></th>"
				fi
			else
                		OUTPUT_LINE="${OUTPUT_LINE}<th align=center>${tag}</th>"
			fi
		fi
            else
                # Because of an inconsistency in output formats, force reformat
                # of the numbers here.
                tag=`expr ${tag} + 0`
                color=""
                if [ ${tag} -gt 0 ] 
                then
                    color="bgcolor=lightblue"
                fi
                OUTPUT_LINE="${OUTPUT_LINE}<td ${color} align=center>${tag}</td>"
            fi
            column=`expr ${column} + 1`
        done

        OUTPUT_LINE="${OUTPUT_LINE}</tr>"
        
        echo ${OUTPUT_LINE}

        row=`expr ${row} + 1`
    done

    if [ ${total} -gt 0 ]
    then
        color="bgcolor=lightsalmon"
    fi

    echo "<td ${color} align=center>${total}</td>"

    if [ ${total} -gt 0 ]
    then
    	echo "<td colspan=${column}>&nbsp;</td>"
    else
    	echo "<td bgcolor=lightgreen colspan=${column}>There were no warnings for this project</td>"
    fi

    echo "</table>"

}

#
# Prints at the top of the report the state of the build
#
print_build_stats() {
   COMPILER_FILE_DIR=${1}
   
   echo "<h3>Build Status</h3>"
   echo "Under Development"
   echo
}

#
# Program starts here
#
usage $@ 

echo "<html>"
echo "<head>"
echo "</head>"
echo "<body>"

date=`date '+%A %e %B  %Y'`
echo "<h1>Compiler and Lint Warning Results</h1>"
echo "<h2>\tReport Produced: ${date}\n</h2>"

print_build_stats ${g_results_directory}

dump_table ${g_results_directory}/CORE.compiler.results "CORE compiler warnings" "compiler"
dump_table ${g_results_directory}/CORE.lint.results "CORE lint warnings" "lint"

dump_table ${g_results_directory}/VPACORE.compiler.results "VPACORE compiler warnings" "compiler"
dump_table ${g_results_directory}/VPACORE.lint.results "VPACORE lint warnings" "lint"

dump_table ${g_results_directory}/OPERABILITY.compiler.results "OPERABILITY compiler warnings" "compiler"
dump_table ${g_results_directory}/OPERABILITY.lint.results "OPERABILITY lint warnings" "lint"

dump_table ${g_results_directory}/RATE.compiler.results "RATE compiler warnings" "compiler"
dump_table ${g_results_directory}/RATE.lint.results "RATE lint warnings" "lint"

dump_table ${g_results_directory}/BILL.compiler.results "BILL compiler warnings" "compiler"
dump_table ${g_results_directory}/BILL.lint.results "BILL lint warnings" "lint"

dump_table ${g_results_directory}/FINANCE.compiler.results "FINANCE compiler warnings" "compiler"
dump_table ${g_results_directory}/FINANCE.lint.results "FINANCE lint warnings" "lint"

echo "</body>"
echo "</html>"
