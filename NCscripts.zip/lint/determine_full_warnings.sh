#!/bin/sh
#
# FILENAME    : %name: determine_full_warnings.sh %
#
# AUTHOR      : Jeremy Wadley
#
# DESCRIPTION : This script runs all of the other scripts required to produce a
#               full report of the warnings (compiler and lint) that exist 
#               within an RB project. The compiler and lint is run across all of
#               the following projects (in the following order):
#                   * CORE
#                   * VPACORE
#                   * RATE
#                   * BILL
#                   * FINANCE
#
#               The results are placed in the following directory structure.
#                   <results_dir>
#                       |
#                       +--compiler.logs
#                       |    |
#                       |    +--BILL (compiler log files)
#                       |    |
#                       |    +--CORE (compiler log files)
#                       |    |
#                       |    +--FINANCE (compiler log files)
#                       |    |
#                       |    +--RATE (compiler log files)
#                       |    |
#                       |    +--VPACORE (compiler log files)
#                       |    
#                       +--lint.logs
#                       |    |
#                       |    +--BILL (lint log files)
#                       |    |
#                       |    +--CORE (lint log files)
#                       |    |
#                       |    +--FINANCE (lint log files)
#                       |    |
#                       |    +--RATE (lint log files)
#                       |    |
#                       |    +--VPACORE (lint log files)
#                       |    
#                       +--reports (html report)
#                       |    
#                       +--results (all result files)
#
#
# (C) Convergys, 2007.
# Convergys refers to Convergys Corporation or any of its wholly owned
# subsidiaries.
#                                                                


#
# Global variables.
#

if [ $# -lt 1 ]; then                                                       
    echo "Usage: ${0} <Release>"
    exit 2                                                                  
fi                                                                          

g_release=${1}

# results will be in root dir of project built.
report_date=`date +%Y-%m-%d`

g_reporting_base=${CCM_ROOT}/LINT_REPORTS

g_results_base=${CCM_ROOT}/LINT_REPORTS/${report_date}  

g_compiler_logs_directory=
g_lint_logs_directory=
g_results_directory=
g_tags_file=
g_reports_directory=
g_latest_reports_directory=
#
# Validates the input parameters and sets up the global variables.
#


#
# Program starts here
#


# Simple validation in case this is run in error.

if [ -z "${CCM_ROOT}" ]; then
    echo "The specified CCM_ROOT directory does not exist; please ensure"
    echo "that the environment is correctly setup for a version of RB."
    exit 2
fi

echo Starting compiler and lint warnings report build ${CCM_ROOT}...

# Set locations for result files.
g_compiler_logs_directory=${g_results_base}/compiler.logs
g_lint_logs_directory=${g_results_base}/lint.logs
g_results_directory=${g_results_base}/results
g_reports_directory=${g_results_base}/reports
g_tags_file=${g_results_directory}/lint.all.tags
g_latest_reports_directory=${g_reporting_base}/${g_release}/${report_date}
g_last_report_only_directory=${g_reporting_base}/${g_release}/LAST_REPORT

mkdir -p ${g_results_base}
mkdir -p ${g_compiler_logs_directory}
mkdir -p ${g_lint_logs_directory}
mkdir -p ${g_results_directory}
mkdir -p ${g_reports_directory}
mkdir -m 777 -p ${g_latest_reports_directory}
mkdir -m 777 -p ${g_last_report_only_directory}

echo Compiler logs ........ : ${g_compiler_logs_directory}
echo Lint logs ............ : ${g_lint_logs_directory}
echo Results files ........ : ${g_results_directory}
echo Report files ......... : ${g_reports_directory}
echo Lint tag file ........ : ${g_tags_file}
echo Latests Reports files .. ${g_latest_reports_directory}

echo Cleaning projects...
cd ${CCM_ROOT}/CORE
echo Cleaning CORE
make clean -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/VPACORE
echo Cleaning VPACORE
make clean -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/OPERABILITY
echo Cleaning OPERABILITY
make clean -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/RATE
echo Cleaning RATE
make clean -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/BILL
echo Cleaning BILL
make clean -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/FINANCE
echo Cleaning FINANCE
make clean -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1


echo Building base builds on projects...
cd ${CCM_ROOT}/CORE
echo Make base CORE
make base -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/VPACORE
echo Make base VPACORE
make base -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/OPERABILITY
echo Make base OPERABILITY
make base -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/RATE
echo Make base RATE
make base -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/BILL
echo Make base BILL
make base -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/FINANCE
echo Make base FINANCE
make base -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1


echo Running compiler warning builds on projects...
mkdir -p ${g_compiler_logs_directory}

cd ${CCM_ROOT}/CORE
mkdir -p ${g_compiler_logs_directory}/CORE
echo Full make and report warnings for CORE
compproject.sh ${g_compiler_logs_directory}/CORE  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/VPACORE
mkdir -p ${g_compiler_logs_directory}/VPACORE
echo Full make and report warnings for VPACORE
compproject.sh ${g_compiler_logs_directory}/VPACORE  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/OPERABILITY
mkdir -p ${g_compiler_logs_directory}/OPERABILITY
echo Full make and report warnings for OPERABILITY
compproject.sh ${g_compiler_logs_directory}/OPERABILITY  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/RATE
mkdir -p ${g_compiler_logs_directory}/RATE
echo Full make and report warnings for RATE
compproject.sh ${g_compiler_logs_directory}/RATE  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/BILL
mkdir ${g_compiler_logs_directory}/BILL
echo Full make and report warnings for BILL
compproject.sh ${g_compiler_logs_directory}/BILL  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${CCM_ROOT}/FINANCE
mkdir ${g_compiler_logs_directory}/FINANCE
echo Full make and report warnings for FINANCE
compproject.sh ${g_compiler_logs_directory}/FINANCE  >> ${g_compiler_logs_directory}/general_make.log 2>&1


echo Producing results for compiler warnings...
mkdir ${g_results_directory}

cd ${g_compiler_logs_directory}/CORE
compresults.sh ${g_results_directory}/CORE.compiler.results  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${g_compiler_logs_directory}/VPACORE
compresults.sh ${g_results_directory}/VPACORE.compiler.results  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${g_compiler_logs_directory}/OPERABILITY
compresults.sh ${g_results_directory}/OPERABILITY.compiler.results  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${g_compiler_logs_directory}/RATE
compresults.sh ${g_results_directory}/RATE.compiler.results  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${g_compiler_logs_directory}/BILL
compresults.sh ${g_results_directory}/BILL.compiler.results  >> ${g_compiler_logs_directory}/general_make.log 2>&1

cd ${g_compiler_logs_directory}/FINANCE
compresults.sh ${g_results_directory}/FINANCE.compiler.results  >> ${g_compiler_logs_directory}/general_make.log 2>&1


cd ${CCM_ROOT}/CORE   
mkdir -p ${g_lint_logs_directory}/CORE  
echo LINT make for CORE
lintproject.sh ${g_lint_logs_directory}/CORE  >> ${g_lint_logs_directory}/general_lint.log 2>&1      

cd ${CCM_ROOT}/VPACORE
mkdir -p ${g_lint_logs_directory}/VPACORE
echo LINT make for VPACORE
lintproject.sh ${g_lint_logs_directory}/VPACORE  >> ${g_lint_logs_directory}/general_lint.log 2>&1 

cd ${CCM_ROOT}/OPERABILITY
mkdir -p ${g_lint_logs_directory}/OPERABILITY
echo LINT make for OPERABILITY
lintproject.sh ${g_lint_logs_directory}/OPERABILITY  >> ${g_lint_logs_directory}/general_lint.log 2>&1 

cd ${CCM_ROOT}/RATE
mkdir -p ${g_lint_logs_directory}/RATE
echo LINT make for RATE
lintproject.sh ${g_lint_logs_directory}/RATE  >> ${g_lint_logs_directory}/general_lint.log 2>&1 

cd ${CCM_ROOT}/BILL
mkdir ${g_lint_logs_directory}/BILL
echo LINT make for BILL
lintproject.sh ${g_lint_logs_directory}/BILL  >> ${g_lint_logs_directory}/general_lint.log 2>&1 

cd ${CCM_ROOT}/FINANCE
mkdir ${g_lint_logs_directory}/FINANCE
echo LINT make for FINANCE
lintproject.sh ${g_lint_logs_directory}/FINANCE  >> ${g_lint_logs_directory}/general_lint.log 2>&1 


echo Producing tag files from lint results...
cd ${g_lint_logs_directory}/CORE
lintreport.sh ${g_results_directory}/CORE.lint

cd ${g_lint_logs_directory}/VPACORE
lintreport.sh ${g_results_directory}/VPACORE.lint

cd ${g_lint_logs_directory}/OPERABILITY
lintreport.sh ${g_results_directory}/OPERABILITY.lint

cd ${g_lint_logs_directory}/RATE
lintreport.sh ${g_results_directory}/RATE.lint

cd ${g_lint_logs_directory}/BILL
lintreport.sh ${g_results_directory}/BILL.lint

cd ${g_lint_logs_directory}/FINANCE
lintreport.sh ${g_results_directory}/FINANCE.lint

# Produce master tags file.
cd ${g_results_directory}
cat *.lint.tags | sort | uniq > ${g_tags_file}


echo Producing results for lint warnings...

cd ${g_lint_logs_directory}/CORE
lintresults.sh ${g_tags_file} ${g_results_directory}/CORE.lint.results

cd ${g_lint_logs_directory}/VPACORE
lintresults.sh ${g_tags_file} ${g_results_directory}/VPACORE.lint.results

cd ${g_lint_logs_directory}/OPERABILITY
lintresults.sh ${g_tags_file} ${g_results_directory}/OPERABILITY.lint.results

cd ${g_lint_logs_directory}/RATE
lintresults.sh ${g_tags_file} ${g_results_directory}/RATE.lint.results

cd ${g_lint_logs_directory}/BILL
lintresults.sh ${g_tags_file} ${g_results_directory}/BILL.lint.results

cd ${g_lint_logs_directory}/FINANCE
lintresults.sh ${g_tags_file} ${g_results_directory}/FINANCE.lint.results


echo Producing reports...
mkdir ${g_reports_directory}

cd ${g_reports_directory}
compilereport.sh ${g_results_directory} > warnings_detailed_report.html

# make everything readable and executable
chmod 755 ${g_results_base}/*
chmod 755 ${g_results_base}/*/*
chmod 755 ${g_results_base}/*/*/*

createoverviewreport.sh ${g_results_base} > warnings_overview_report.html

#if reports created, then  copy to latest reports directory.
#make new links for Latest Report directory
if [ -f "warnings_detailed_report.html" ] && 
   [ -f "warnings_overview_report.html" ]; then
  # add links for build report
  ln -s -f ${g_reports_directory}/warnings_detailed_report.html ${g_latest_reports_directory}/warnings_detailed_report.html
  ln -s -f ${g_reports_directory}/warnings_overview_report.html ${g_latest_reports_directory}/warnings_overview_report.html
  
  # add links for LAST REPORT ONLY directory for management's eyes only.
  rm -f ${g_last_report_only_directory}/*
  ln -s -f ${g_reports_directory}/warnings_detailed_report.html ${g_last_report_only_directory}/warnings_detailed_report.html
  ln -s -f ${g_reports_directory}/warnings_overview_report.html ${g_last_report_only_directory}/warnings_overview_report.html
  
  # add links for rate_vpa LAST REPORT ONLY directory ---- This will become the main dir.
  rm -f ${g_last_report_only_directory}/*
  ln -s -f ${g_reports_directory}/warnings_detailed_report.html ${g_reports_directory}/../LAST_REPORT/warnings_detailed_report.html
  ln -s -f ${g_reports_directory}/warnings_overview_report.html ${g_reports_directory}/../LAST_REPORT/warnings_overview_report.html
  
fi
 
echo Finshed ... Now check reports directory



