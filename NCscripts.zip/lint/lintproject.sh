#!/bin/sh
#                                                                               
# FILENAME    : %name: lintproject.sh %                                           
#                                                                               
# AUTHOR      : Daniel Bloy                                                     
#                                                                               
# DESCRIPTION : This script runs lint over an entire code project. lint
#               is run on each directory that contains a SRC sub 
#               directory. All results are collated in the given results
#               directory.
#
#               This script must be run from the projects root directory.
#                                                                               
# (C) Convergys, 2007.                                                          
# Convergys refers to Convergys Corporation or any of its wholly owned          
# subsidiaries.                                                                 
#                                                                

#
# Global variables.
#

g_results_directory=

#                                                                               
# Validates the input parameters and sets up the global variables.
#                                                                               
usage() {                                                                       
                                                                                
    if [ $# -lt 1 ]; then                                                       
        echo "Usage: ${0} <results directory>"
        exit 2                                                                  
    fi                                                                          
                                                                                
    g_results_directory=${1}                                                           
                                                                                
    if [ ! -d ${g_results_directory} ]; then                                             
        echo "The specified results directory does not exist."
        exit 2                                                                  
    fi                                                                          

}                                                                               
                                                                                
#
# Program starts here
#
usage $@ 

echo Starting lint build on `pwd`...

# Now we loop through all the files in the directory and 
# see if they have a SRC directory.
for module in `ls -d *`; do

    if [ -d ${module}/SRC ]; then

        echo Running lint build in ${module}...
        results_file=${g_results_directory}/${module}.build.log

        # Now we build the project.
        cd ${module}/SRC
        make LOCAL_CFLAGS="-DDEBUG -g" lint -k 1> ${results_file} 2>&1
        cd ../..

    fi 

done

echo Finished...



