#!/bin/sh

# Global variables.
#
g_output_log_file=
g_output_results_file=
g_tag_file=

#
# Validates the input parameters and sets up the global variables.
#
usage() {

    if [ $# -lt 1 ]; then
        echo "Usage: ${0} <output file pattern>"
        exit 2
    fi

    g_output_log_file=${1}.log
    g_output_results_file=${1}.tags
    g_tag_file=${TOOL}/lint.tags

    if [ ! -f ${g_tag_file} ]; then
        echo "The specified tag file does not exist."
        exit 2
    fi

}

perform() {
    echo Running lint on `pwd`...

    echo Running "make lint"...
    echo Running "make lint"... 1> ${g_output_log_file} 2>&1
    make lint -k 1>> ${g_output_log_file} 2>&1

    echo Counting tags...
    ${TOOL}/counttags ${g_output_log_file} ${g_tag_file} > ${g_output_results_file}

    echo Finished... 1>> ${g_output_log_file} 2>&1
}

usage $@

perform


