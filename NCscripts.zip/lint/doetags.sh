#!/bin/sh

gentags()
{
    dir=${1}
    if [ -n "$dir" ] && [ -d $dir ]; then
        cd $dir
        echo Building tags for `pwd`...
        find -name \*\.h  | xargs etags -o $CCM_ROOT/TAGS --append -
        find -name \*\.hh | xargs etags -o $CCM_ROOT/TAGS --append -
        find -name \*\.c  | xargs etags -o $CCM_ROOT/TAGS --append -
        find -name \*\.cc | xargs etags -o $CCM_ROOT/TAGS --append - 
    fi
}

# Delete the old tags file.
if [ -e $CCM_ROOT/TAGS ]; then
    rm $CCM_ROOT/TAGS
fi

gentags $SCHEMA
gentags $CORE
gentags $VPACORE
gentags $RATE
gentags $BILL
gentags $FINANCE

