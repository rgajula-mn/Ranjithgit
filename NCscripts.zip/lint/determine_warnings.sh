#!/bin/sh
#
# FILENAME    : %name: determine_warnings.sh %
#
# AUTHOR      : Jeremy Wadley
#
# DESCRIPTION : This script produces an overview report of the warnings (compiler and lint) 
#               that exist within an RB project on the day ran. It also produces a detailed
#               report for each module.
#
#               The compiler and lint makes are run across the following projects:
#                   * CORE
#                   * VPACORE
#                   * RATE
#                   * BILL
#                   * FINANCE
#
#               The results are placed in the following directory structure.
#
#                   <run_date_dir>
#                       |
#                       +--compiler.logs  
#                       |    |
#                       |    +--BILL (compiler log files)
#                       |    |
#                       |    +--CORE (compiler log files)
#                       |    |
#                       |    +--FINANCE (compiler log files)
#                       |    |
#                       |    +--RATE (compiler log files)
#                       |    |
#                       |    +--VPACORE (compiler log files)
#                       |    
#                       +--lint.logs
#                       |    |
#                       |    +--BILL (lint log files)
#                       |    |
#                       |    +--CORE (lint log files)
#                       |    |
#                       |    +--FINANCE (lint log files)
#                       |    |
#                       |    +--RATE (lint log files)
#                       |    |
#                       |    +--VPACORE (lint log files)
#                       |    
#                       +--reports (html report)
#                       |    
#                       +--results (all result files)
#
#                On a successful run the reports are copied to ${CCM_ROOT}/LATEST_REPORTS/<report_date>
#
#                Honour to Daniel Bloy for the initial version of these scripts (2007).
#
# (C) Convergys, 2008.
# Convergys refers to Convergys Corporation or any of its wholly owned
# subsidiaries.
#                                                                


#
# Global variables.
#

reports_directory=$1

# results will be in root dir of project built.
report_date=`date +%Y-%m-%d`
if [ -z "$reports_directory" ]
then
	g_lint_dir=${CCM_ROOT}/LINT_REPORTS
else
	g_lint_dir=$reports_directory
fi
g_results_base=${g_lint_dir}/${report_date}  

#
# Validates the input parameters and sets up the global variables.
#


#
# Program starts here
#

# Simple validation in case this is run in error.

if [ -z "${CCM_ROOT}" ]; then
    echo "The specified CCM_ROOT directory does not exist; please ensure"
    echo "that the environment is correctly setup for a version of RB."
    exit 2
fi

echo Starting compiler and lint warnings report build ${CCM_ROOT}...

# Set locations for result files.
g_compiler_logs_directory=${g_results_base}/compiler.logs
g_lint_logs_directory=${g_results_base}/lint.logs
g_results_directory=${g_results_base}/results
g_reports_directory=${g_results_base}/reports
g_tags_file=${g_results_directory}/lint.all.tags

mkdir -p ${g_results_base}
mkdir -p ${g_compiler_logs_directory}
mkdir -p ${g_lint_logs_directory}
mkdir -p ${g_results_directory}
mkdir -p ${g_reports_directory}


echo Compiler logs .. : ${g_compiler_logs_directory}
echo Lint logs ...... : ${g_lint_logs_directory}
echo Results files .. : ${g_results_directory}
echo Report files ... : ${g_reports_directory}
echo Lint tag file .. : ${g_tags_file}

echo Cleaning projects...

stetest=0
if [ "$stetest" = "0" ]
then
	for project in APICORE APICAT APICUSTACC APISYSCONFIG CORE VPACORE OPERABILITY RATE BILL FINANCE
	do
		cd ${CCM_ROOT}/${project}
		echo Cleaning $project
		make clean -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1
	done


	echo Building base builds on projects...
	for project in APICORE APICAT APICUSTACC APISYSCONFIG CORE VPACORE OPERABILITY RATE BILL FINANCE
	do
		cd ${CCM_ROOT}/${project}
		echo Make base ${project}
		make base -k  >> ${g_compiler_logs_directory}/general_make.log 2>&1
	done


	echo Running compiler warning builds on projects...
	for project in APICORE APICAT APICUSTACC APISYSCONFIG CORE VPACORE OPERABILITY RATE BILL FINANCE
	do
		cd ${CCM_ROOT}/${project}
		mkdir -p ${g_compiler_logs_directory}/${project}
		echo Full make and report warnings for ${project}
		compproject.sh ${g_compiler_logs_directory}/${project}  >> ${g_compiler_logs_directory}/general_make.log 2>&1
	done


	echo Producing results for compiler warnings...
	for project in CORE VPACORE OPERABILITY RATE BILL FINANCE
	do
		cd ${g_compiler_logs_directory}/${project}
		compresults.sh ${g_results_directory}/${project}.compiler.results  >> ${g_compiler_logs_directory}/general_make.log 2>&1
	done

	cat ${g_compiler_logs_directory}/general_make.log

	echo Running lint warning builds on projects...
	for project in CORE VPACORE OPERABILITY RATE BILL FINANCE
	do
		cd ${CCM_ROOT}/${project}   
		mkdir -p ${g_lint_logs_directory}/${project}  
		echo LINT make for ${project}
		lintproject.sh ${g_lint_logs_directory}/${project}  >> ${g_lint_logs_directory}/general_lint.log 2>&1      
	done

	echo Producing tag files from lint results...
	for project in CORE VPACORE OPERABILITY RATE BILL FINANCE
	do
		cd ${g_lint_logs_directory}/${project}
		lintreport.sh ${g_results_directory}/${project}.lint
	done

	# Produce master tags file.
	cd ${g_results_directory}
	cat *.lint.tags | sort | uniq > ${g_tags_file}


	echo Producing results for lint warnings...
	for project in CORE VPACORE OPERABILITY RATE BILL FINANCE
	do
		cd ${g_lint_logs_directory}/${project}
		lintresults.sh ${g_tags_file} ${g_results_directory}/${project}.lint.results
	done
fi

echo Producing reports...
cd ${g_reports_directory}
compilereport.sh ${g_results_directory} > warnings_detailed_report.html

createoverviewreport.sh ${g_results_base} 

#if reports created, then  copy to latest reports directory.
#make new links for Latest Report directory
if [ -f "warnings_detailed_report.html" ] && 
   [ -f "warnings_overview_report.html" ]; then
  rm -rf ${g_lint_dir}/LATEST_REPORT
  mkdir -p ${g_lint_dir}/LATEST_REPORT
  ln -s ${g_reports_directory}/warnings_detailed_report.html ${g_lint_dir}/LATEST_REPORT/warnings_detailed_report.html
  ln -s ${g_reports_directory}/warnings_overview_report.html ${g_lint_dir}/LATEST_REPORT/warnings_overview_report.html
fi
 
echo Finshed ... Now check reports directory
