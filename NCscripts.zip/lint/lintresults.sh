#!/bin/sh
#                                                                               
# FILENAME    : %name: lintresults.sh %                                           
#                                                                               
# AUTHOR      : Daniel Bloy                                                     
#                                                                               
# DESCRIPTION : This script runs over the results from a run of lintproject.sh
#               with an input tag file and produces a tabulated result of the tags
#               from all build log files for all modules.
#                                                                               
# (C) Convergys, 2007.                                                          
# Convergys refers to Convergys Corporation or any of its wholly owned          
# subsidiaries.                                                                 
#                                                                

#
# Global variables.
#
g_tag_file=
g_results_file=

g_number_of_lines=0

g_temp_1=lintresults.temp.1
g_temp_2=lintresults.temp.2

#                                                                               
# Validates the input parameters and sets up the global variables.
#                                                                               
usage() {                                                                       
                                                                                
    if [ $# -lt 2 ]; then
        echo "Usage: ${0} <tag file> <results file>"
        exit 2                                                                  
    fi                                                                          

    g_tag_file=${1}
    g_results_file=${2}
                                                                                
    if [ ! -f ${g_tag_file} ]; then                                             
        echo "The specified tag file does not exist."
        exit 2                                                                  
    fi                                                                          

}                                                                               
                                                                                
#
# Program starts here
#
usage $@ 

echo Calculating results for `pwd`...

#
# Prepare the format of the results file and determine how many lines it will have.
#
echo "MODULE_NAME" >  ${g_results_file}
cat  ${g_tag_file} >> ${g_results_file}
g_number_of_lines=`cat ${g_results_file} | wc -l`

# Now we loop through all the build log files.
for log_file in `ls -d *.build.log`; do

    # Determine the module name.
    module_name=`echo ${log_file} | sed -e 's/.build.log//'`

    if [ -f ${log_file} ]; then

        echo Now processing ${module_name}...

        # Count the tags in the log file, prefixing with the module name (to line 
        # up with the results file).
        echo "${module_name}," > ${g_temp_1}
        ${TOOL}/counttags ${log_file} ${g_tag_file} >> ${g_temp_1}

        # Merge these module results with the full results. The first line is done separately 
        # from the rest of the lines.
        results_line=`cat ${g_results_file} | sed -n -e "1,1 p"`
        echo "${results_line},${module_name}" > ${g_temp_2}

        # Lets now copy across the values for the tags.
        line=2
        while [ ${line} -le ${g_number_of_lines} ] ; do
            
            results_line=`cat ${g_results_file} | sed -n -e "${line},${line} p"`
            temp_line=`cat ${g_temp_1} | sed -n -e "${line},${line} p"| cut -d , -f2`
            echo "${results_line},${temp_line}" >> ${g_temp_2}

            line=`expr $line + 1`
        done

        # Now we overwrite the old results file
        cp ${g_temp_2} ${g_results_file}

    fi 

done

rm ${g_temp_1}
rm ${g_temp_2}

echo Finished.

