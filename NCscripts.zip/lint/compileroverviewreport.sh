#!/bin/sh
#                                                                               
# FILENAME    : %name: compileroverviewreport.sh %                                           
#                                                                               
# AUTHOR      : Jeremy Wadley                                                     
#                                                                               
# DESCRIPTION : This script summarises the findings of the Compiler build, 
#               summarising at a global and directory level. 
#
# #
# (C) Convergys, 2007.                                                          
# Convergys refers to Convergys Corporation or any of its wholly owned          
# subsidiaries.                                                                 
#                                                                

g_tags_file=

#
# Validates the input parameters and sets up the global variables.              
#
usage() {

    if [ $# -lt 2 ]; then
        echo "Usage: ${0} <directory> <reportfile> "
        exit 2
    fi
    
    report_dir=${1}
    g_results_file=${2}
    total_warnings=0

}

usage $@


# Now we loop through all the build log files.
for log_file in `ls -d *.build.log`; do

    number_of_warnings=`grep -i warning ${log_file} | \
        sed -e '/is too large and will not be expanded inline/d' \
            -e '/is too large to generate inline/d' \
            -e '/WARNING/d' \
            -e '/Warning.s. detected/d' \
            -e '/GTLpthread.hh/d' \
            -e '/CMqueueParse.l/d' \
            -e '/.irb.infinys.release.platform/d' \
            -e '/.tools.SUNWspro.WS6U2.include/d' \
	    -e '/Clock skew detected/d' \
            -e '/LOGFILE.REGISTRY.CONTEXT/d'\
            -e '/LOGFILE_REGISTRY_CONTEXT/d'\
            -e '/xarch.v9.is.deprecated/d'\
            -e '/CORE.PFAIS.SRC/d'\
            -e '/CORE.PFTOOLS.SRC/d'\
            -e '/CORE.TM.SRC.TMPImain/d'\
            -e '/PF..AIS..PF/d'\
            -e '/.SunStudio11.SUNWspro.prod.include/d' | wc -l`

    total_warnings=`expr ${total_warnings} + ${number_of_warnings}`  

done

echo "${total_warnings} ${report_dir}" >> ${g_results_file}

exit $total_warnings


