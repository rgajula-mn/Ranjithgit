drop user PFBCE_OSPLATFORM_PF cascade;
drop user PFBCE_OSPLATFORM_UT cascade;
drop user PFBCE_OSPLATFORM_SEC cascade;
drop user PFBCE_OSPLATFORM_AUDIT cascade;
drop user RBRELEASE cascade;
drop user RBRELEASE_OCS cascade;
