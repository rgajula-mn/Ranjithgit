#set -x
#!/bin/sh

. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh

exit_program ()
{
	if [ $1 -gt 0 ]
	then
	echo ""
		echo "Exiting Program with status $1"
		case $1 in
			1)
				echo "Because of incorrect arguments given to script"
				;;
			2)
				echo "Caught Ctrl-C"
				;;
			*)
				echo "Unknown Error"
				;;
		esac
	fi
	
	exit $1
}

trap 'exit_program 2'  2

config_file="${BCE_ADMIN}/buildweb_config/platform_version"
CONFIG_PROJECT=1
CONFIG_MACHINE_PLATFORM=2
CONFIG_ORACLE=3
CONFIG_RELEASE=4
CONFIG_CVG_PF_VERSION=5
CONFIG_SDK_PATH=6
CONFIG_PRD_PATH=7

if [ $# -lt 3 ]
then
	echo "Usage:"
	echo "	$0 <PROJECT> <RELEASE> <ORACLE> [sdk|prd]"
	echo "eg:"
	echo "	$0 GENEVA 5.4.1 oracle9i2 sdk"
	exit_program 1
fi

project=`echo $1 | tr '[a-z]' '[A-Z]'`
if [ "${project}" = "GENEVAAPI" ]
then
	project=GENEVA
elif [ "${project}" = "RBAPI" ]
then
	project=RB	
fi

release=$2
oracle=`echo $3 | sed -e 's/.*oracle//'`

if [ "$4" = "" ]
then
	return_platform=sdk
else
	return_platform=$4
fi

special_bit=$5
if [ "$special_bit" = "32" ]
then
	special_bit=$5
else
	special_bit=""
fi

output_path ()
{
	if [ $2 = "prd" ]
	then
		outpur=`echo $1 | cut -d, -f$CONFIG_PRD_PATH`
		echo $outpur
	else
		outpur=`echo $1 | cut -d, -f$CONFIG_SDK_PATH`
		echo $outpur
	fi
}

if [ "$project" = "" -o "$release" = "" ]
then
	exit_program 1
fi

if [ "$PLATFORM" = "RHEL3-EM64T" -o "$PLATFORM" = "RHEL4-EM64T" -o "$PLATFORM" = "RHEL5-EM64T" -o "$PLATFORM" = "RHEL6-EM64T" -o "$PLATFORM" = "RHEL7-EM64T" ]
then
	PLATFORM=linux
fi

if [ "$PLATFORM" = "SLE11-EM64T" ]
then
	PLATFORM=suselinux
fi

available_platforms=`grep "${project}," $config_file | grep -v "#" | grep "${PLATFORM}${special_bit}," | grep ", $oracle," | sed -e 's/[ |	]*//g' | sed -e '/^$/d'`
lines_available=`grep "${project}," $config_file | grep -v "#" | grep "${PLATFORM}${special_bit}," | sed -e 's/[ |	]*//g' | sed -e '/^$/d' | wc -l`
if [ $lines_available -eq 0 ]
then
	echo "Error: Unable to find any CVG Platforms in $config_file"
	exit_program 3
fi

next_best=0
next_best_path=""

for i in `echo $available_platforms`
do
	config_release=`echo $i | cut -d, -f$CONFIG_RELEASE`
	if [ "$config_release" = "$release" ]
	then
		output_path $i $return_platform
		exit_program 0
	fi

	config_major=`echo $config_release | cut -d. -f1-2`
	this_major=`echo $release | cut -d. -f1-2`

	if [ "$config_major" = "$this_major" ]
	then
		config_minor=`echo $config_release | cut -d. -f3`
		this_minor=`echo $release | cut -d. -f3`
		if [ -z "$config_minor" ]
		then
			continue
		fi
		if [ $config_minor -le $this_minor ]
		then
			minor_config_minor=`echo $config_release | cut -d. -f4`
			minor_this_minor=`echo $release | cut -d. -f4`
			
			if [ ! -z "$minor_config_minor" ]
			then
				if [ "$minor_this_minor" != "$minor_config_minor" ]
				then
					continue
				fi
			fi

			if [ $next_best -lt $config_minor ]
			then
				next_best_path=`output_path $i $return_platform`
				next_best=$config_minor
			fi
			
		fi
	fi
done

if [ "$next_best" -gt 0 ]
then
	echo "$next_best_path"
	exit_program 0
fi

exit_program 3
