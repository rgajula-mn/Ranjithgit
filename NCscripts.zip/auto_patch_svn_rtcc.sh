#!/bin/bash
#set -x
. /home/geneva/.profile

if [ ! "${BCE_BUILD_SCRIPTS}" ]
then
        BCE_BUILD_SCRIPTS=/irb/bce/admin/build_scripts
fi

. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/patch_functions_svn_rtcc.sh
releaseTag=$1
platform=$2
oracle=$3
projectType=$4
releaseNum=`echo $releaseTag | sed -e "s/.*_//g"`
project=`echo $releaseTag | sed -e "s/_.*//g"`
if [ "$project" = "TAP" ]
then
	project="TAP3"
fi
if [ "$project" = "GEN" ]
then
	project="GENEVA"
fi
projectLowerCase=`echo $project | tr '[A-Z]' '[a-z]'`
majorRelease=`echo $releaseTag | sed -e "s/.*_//g" | cut -d'.' -f1-2`
synergyPlatform=`cat /irb/bce/admin/buildweb_config/ccm_platform_details | grep "$platform.$oracle" | awk '{print $2}'`
DATABASE="buildweb/georgespass@webca.world"
CCM_DATABASE_CB1="/ccm/prd"
CCM_DATABASE_CB2="/ccm/cb2"
expectedRC=""
previousRC=""
validPlatforms=("hp64" "tru64" "hp" "solaris" "aix" "itanium" "linux" "solaris32")
validOracle=("oracle9i2" "oracle10g_cancelled" "oracle11g" "oracle10g" "oracle10gcancelled" "oracle8i" "oracle9i" "at" "oracle8")
buildPath="/irb/bce/build"
pathToAllDeliverables="$buildPath/$projectLowerCase/$majorRelease/$project-$projectType$releaseNum.$platform.$oracle/$project/ALLBATCH"
workArea=""
patchWorkArea=""
newTaskCreated=""
isNewTaskCreated=""
userid=""

if [ "$project" = "GENEVA" -a "$majorRelease" = "5.4" ]
then
	patchType="RBPATCH"
	majorRelease="2.2"
	projectLowerCase="rb"
elif [ "$project" = "GENEVA" -a "$majorRelease" = "5.3" ]
then
	patchType="GENEVAPATCH"
else
	patchType="RBPATCH"
fi

function start(){
	isMachineValid
	if [ $# -lt 5 ]
	then
        	printf  "[ERROR] Enter correct arguments\n"
	        usage
		exit
	else
		areParametersValid $@ 
		displayEnteredValues
		findExpectedRC
		if [ "$expectedRC" != "" ]
		then
			#startSynergy
			setupPatch
			anyNewDeliverablesAsked

#exit
		#	if [ $previousRC -ge 1 ]
		#	then
				#compareCurrentAndPreviousRC
		#	fi
#			deliverablesToPrepState
		printf  "[ERROR] Calling Copy build Script"
			runCopyBuildObjects
#			checkinDefaultTask
		fi
	fi
}
start $@
