#!/bin/ksh
set -x
. /home/genadmin/.bce.ini
releaseTag=$1
platform=$2
oracle=$3
CCM_ROOT=$4
log_prt=$5
log_dt=$6
schema_change='FALSE'
. $CCM_ROOT/env*.sh
if [ $platform = 'itanium' ]
then
	make1="gmake"
else
	make1="make"
fi
for i in  `cat ${BCE_LOG}/partialbuild/svn_up_$releaseTag.$log_dt.log|egrep '_changes.sql|_change.sql'|awk '{print $2}'`
#for i in  `cat ${BCE_LOG}/partialbuild/svn_up_RB_6.1.6.265.20161104093125.log|grep _changes.sql|cut -d' ' -f2`
do
#sql=`cat $CCM_ROOT/$i|grep 'create table\|alter table\|create or replace view'`
#if [ ! -z "$sql" ]
#then
	sqlplus -s $DATABASE << +ENDSQL
    	@$CCM_ROOT/$i
    	exit
+ENDSQL
	cd $CCM_ROOT/CORE/GDB/SRC
	$make1 clean; $make1
	schema_change='TRUE'
#fi
done
echo ""
echo ""
#cat /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle} | cut -d":" -f1 | awk '{print $1}' | uniq | while read line
#cat /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle} |  cut -d":" -f1-2 | awk '{print $1}' |sed -e 's#:#/#g'| uniq |while read line
#do
#cd $CCM_ROOT/$line/SRC
#echo "========================================="
#echo "[MAKE CLEAN; MAKE BASE] in `pwd`"
#echo "========================================="
#echo "In directory `pwd`"
#echo "Running make clean; make base in $line/SRC"
#$make1 clean; $make1 base 
#done

echo ""
echo ""
#cat /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle} | uniq | while read line
cat /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle} | cut -d":" -f1 | awk '{print $1}' | uniq | while read line
do
	apis=`echo $line|egrep 'API|GNVUA|REPORTS'`
	if [ $? = 0 ]
	then
		cc_api='apiinc plsql java'
		cat /irb/bce/admin/log/partialbuild/buildOrder_${releaseTag}_${platform}_${oracle} | uniq | while read line_api
		do
			line_api=`echo $line_api | cut -d":" -f1-2 | tr ':' '/'` 	
			plsql1=`echo $line_api|egrep 'API|GNVUA|REPORTS'`
			if [ $? = 0 ]
        		then
				cd $CCM_ROOT/$line_api/SRC
				echo "========================================="
				echo "[MAKE] in `pwd`"
				echo "========================================="
				echo "In directory `pwd`"
				echo "Running make $cc_api for $line_api sub-module."
				if [ $schema_change = 'TRUE' ]
				then
					$make1 clean; $make1 $cc_api
				else
					$make1 $cc_api
				fi
			fi
			
		done
	else	
		cc_api='all'
		cd $CCM_ROOT/$line
		echo "========================================="
		echo "[MAKE] in `pwd`"
		echo "========================================="
		echo "In directory `pwd`"
		echo "Running make $cc_api for $line module."
		if [ $schema_change = 'TRUE' ]
		then
			$make1 clean; $make1 $cc_api 
		else
			$make1 $cc_api 
		fi
	fi
done
echo "get_deleliverable_dateANDtime.sh $releaseTag $platform $oracle sqa sdavulur ${log_dt} $DATABASE $log_prt" >> $log_prt 2>&1
ssh genadmin@devapp655cn . ~/.bce.ini;${BCE_BUILD_SCRIPTS}/get_deleliverable_dateANDtime.sh $releaseTag $platform $oracle sqa sdavulur ${log_dt} $DATABASE $log_prt
