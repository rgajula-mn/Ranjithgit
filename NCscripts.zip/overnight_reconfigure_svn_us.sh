#!/bin/sh
set -x
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh

hostname=`hostname`
# master timeout multiplier is in seconds (300 = 5 minutes)

whoami=`whoami`
#ccm_database="/ccm/prd"

if [ $# -lt 3 ]
then
	exit
fi

releases_to_build=$1
hour_start_time=$2
logdate=$3
LOGDIR=${BCE_LOG}/$logdate

if [ ! -d "${LOGDIR}" ]
then
	mkdir -p $LOGDIR
fi

for project in `cat ${releases_to_build} | egrep -v "(^$|^#)" | tr ' ' -`
        do
                THE_PROJECT="`echo ${project} | cut -d- -f1`"
                core_release="`echo ${project} | cut -d- -f2 | cut -d_ -f1 | cut -d: -f1`"
                projectStates="`echo ${project} | cut -d: -f2`"
 	for i in `echo $projectStates | tr '-' ' '`
                do
                        release_tag=`discover_release_tag.sh -p $THE_PROJECT -r $core_release`
                        echo $i | grep dbuser > /dev/null
                        if [ $? -eq 0 ]
                        then
                                echo dbuser so ignore
                                continue
                        fi
                        state=`echo $i | cut -d'[' -f1`

                        echo $i $THE_PROJECT $core_release $release_tag

			for i in `cat $BCE_ADMIN/buildweb_config/build_path|grep $THE_PROJECT|grep $core_release|grep $state|awk '{print $3"/"$1"-sqabuild"$2"."$4"."$5}'`
			 do
				fp=`echo $i|sed  "s/sqabuild/$state/g"`
				project="$fp $projects_to_reconfigure"
				echo "value of ${BCE_BUILD_SCRIPTS}/reconfigure_a_project_svn.sh $project $logdate"
				${BCE_BUILD_SCRIPTS}/reconfigure_a_project_svn.sh $project $logdate &
			 done
		done
	done

exit 0
