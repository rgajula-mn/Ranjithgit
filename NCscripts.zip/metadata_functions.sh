#!/usr/local/bin/bash
export ORACLE_HOME=/opt/oracle/9.2.0.SE
export PATH=$ORACLE_HOME/bin:$PATH
set -x
derivePatch()
{
rel=$1
project=`echo $rel|cut -d '_' -f1`
version=`echo $rel|cut -d '_' -f2`
patch_spl_val=`echo $version|awk -F'.' '{print $1"."$2"."$3".x"}'`


#echo "curl -k -H \"Content-Type: application/json\" -X POST -u ciber:8d#d56hg https://tms-dev.netcracker.com/rest/tms-toolkit/1.0/metadata/version/$pr_id/SVN%20Branch%20Path -d\"https://svnca.netcracker.com/$project/branches/Patches/DT_TMPL/DT_TMPL_7.0.3.x\""

#echo "Deriving the Svn branch for patch"
if [ $project = "GEN" ]
then
project1="RB"
project="GENEVA"
fi
database="buildweb/georgespass@webca.world"
client=`sqlplus -s $database << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                set lines 2000 pages 2000
select unique(b.company) as client from patch_company b, cOMPANY_GPCODE a where a.COMPANY_NAME=b.COMPANY and b.VERSION='$version' and b.PROJECT='$project';

EOF`
client=`echo $client|sed "s/'//g"`


if [ $project = "TAP" ]
then
project="TAP3"
fi

if [ $project = "PF" ]
then
link=`sqlplus -s $database << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
		set lines 2000 pages 2000
select 'https://svnhd.netcracker.com'||'/$project/'||'branches/Patches/'||a.GPCODE_SVN||'/'||a.GP_CODE||'_$patch_spl_val' as link from COMPANY_GPCODE a, patch_company b where a.COMPANY_NAME=b.COMPANY and b.VERSION='$version' and b.PROJECT='$project';

EOF`
elif [ $project = "RB" ] 
then
link=`sqlplus -s $database << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                set lines 2000 pages 2000
select 'https://svncn.netcracker.com'||'/$project/'||'branches/Patches/'||a.GPCODE_SVN||'/'||a.GP_CODE||'_$patch_spl_val' as link from COMPANY_GPCODE a, patch_company b where a.COMPANY_NAME=b.COMPANY and b.VERSION='$version' and b.PROJECT='$project' and a.gp_code not like '%OTE_GEN%';

EOF`
elif [ $project = "GENEVA" ] 
then
link=`sqlplus -s $database << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                set lines 2000 pages 2000
select 'https://svncn.netcracker.com'||'/$project1/'||'branches/Patches/'||a.GPCODE_SVN||'/'||a.GP_CODE||'_$patch_spl_val' as link from COMPANY_GPCODE a, patch_company b where a.COMPANY_NAME=b.COMPANY and b.VERSION='$version' and b.PROJECT='$project';

EOF`
else
link=`sqlplus -s $database << EOF
                whenever sqlerror exit failure
                set feed off
                set head off
                set lines 2000 pages 2000
select 'https://svncn.netcracker.com'||'/$project/'||'branches/Patches/'||a.GPCODE_SVN||'/'||a.GP_CODE||'_$patch_spl_val' as link from COMPANY_GPCODE a, patch_company b where a.COMPANY_NAME=b.COMPANY and b.VERSION='$version' and b.PROJECT='$project';

EOF`
fi

if [ "${client}" = "OTE SA"  -a "${project}" = "GENEVA" ]
then
#link=`echo $link|sed 's#https://svncn.netcracker.com/RB/branches/Patches/OTE/OTE_5.3.62.x##g'`
link=`echo 'https://svncn.netcracker.com/RB/branches/Patches/OTE/OTE_GEN_5.3.62.x'`
fi

output=`echo $link|sed 's/\n//g'`
echo "$output"




}

