#!/bin/bash
set -x


. /home/genadmin/.profile


project=$2
release=$1
old_target=$3
echo "Release Directory = $old_target"
release_workarea="$old_target/$project/$project"

workarea=`sqlplus -s buildweb/georgespass@webca.world << +END
                                set feed off;
                                set head off;
                                set pagesize 0;
                                alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
                                select export_location from test_cand_summary where rowid=(select max(rowid) from test_cand_summary where project='$project' and version='${release}');
                                exit;
+END`

echo "Export Location = $workarea"
archive=$4
dots_in_release=`echo ${archive}|tr -d -c '.'|wc -c`
if [ "$dots_in_release" -eq 4 ]
then
	cand_dir=`echo ${archive}|cut -d'.' -f1-4`
elif [ "$dots_in_release" -eq 3 ]
then
	cand_dir=`echo ${archive}|cut -d'.' -f1-3`
fi
Cand_path="$workarea/${cand_dir}"
comp_cand_rel ()
{
if [ $cand_file_count -eq $rel_file_count ]
then
	echo "Equal No. of Files"
	find ${Cand_path} -type f|sort|egrep -v 'release_notes|component_version.sql|sys_scripts.sql|first.sql'|while read line
        do
        	cdt=`date -r $line +%Y%m%d%H%M%S`
                cfsize=`stat --printf="%s" $line`
                r_file=`basename $line`
                r_file_path=`find $old_target -name $r_file`
                rdt=`date -r $r_file_path +%Y%m%d%H%M%S`
                rfsize=`stat --printf="%s" $r_file_path`
                echo "Candidate Path File DT and Size = $line , $rdt,$rfsize"
                echo "Release Path File DT and Size = $r_file_path , $rdt,$rfsize"
                if [ "$rdt" = "$cdt" ] && [ "$rfsize" = "$cfsize" ]
                then
                	echo "Files are Equal"
                else
                        echo "File $c_file  DateTime or Size Donot Match, Please check"
                        exit 1
                fi
        done
else
	echo "Few Files Missing, Please Verify"
	exit 1
fi
}
if [ -f "$old_target/${project}/${project}/install/comp_install.xml" ]
then
        echo "Its a AutoInstaller Candidate"
	if [ -f "${Cand_path}_autoinstaller.zip" ]
	then
		echo "Package Found"
		cd $workarea
		unzip ${cand_dir}_autoinstaller.zip
		cd install
		p_dir=`pwd`
		Cand_path="${p_dir}/RB/"
		echo "Candidate Files Location = $Cand_path"
		unzip ${cand_dir}.zip
		cand_file_count=`find RB/ -type f|egrep -v 'component_version.sql|sys_scripts.sql|first.sql'|wc -l`
		rel_file_count=`find $old_target -type f|egrep -v 'release_notes|comp_install.xml'|wc -l`	
		comp_cand_rel	
		rm  -rf $workarea/install $workarea/install.xml
	else
		echo "AI Package not found"
	fi
else
        if [ -d $Cand_path ]
        then
		cand_file_count=`find $Cand_path -type f|wc -l`
		rel_file_count=`find $old_target -type f|grep -v release_notes|wc -l`
		comp_cand_rel
        elif [ -f "${Cand_path}.zip" ]
        then
                echo "Candidate is a zip file"
		cd $workarea
		rm -rf RB
		unzip ${cand_dir}.zip 
		p_dir=`pwd`
                Cand_path="${p_dir}/RB/"
		echo "Candidate Files Location = $Cand_path"
		cand_file_count=`find $Cand_path -type f|egrep -v 'component_version.sql|sys_scripts.sql|first.sql'|wc -l`
                rel_file_count=`find $old_target -type f|egrep -v 'release_notes|comp_install.xml'|wc -l`
                comp_cand_rel
                rm  -rf RB
        fi
fi
