#!/bin/bash

project=$1
version=$2
company=$3
platform=$4
oracle=$5
maint=`echo "$version"|cut -d"." -f1,2,3`

if [ $# -ne 5 ]
then
echo "[info] Number of params are wrong"
exit

fi 

if [ \( "$company" == "BT Global Services Antilla" -o "$company" == "BT Retail Avalon" -o "$company" == "BT Retail Avalon_RD" -o "$company" == "BT Global Services Antilla CORE" -o "$company" == "BT Phoenix"-o "$company" == "BT Phoenix" -o "$company" == "BT Openreach" -o "$company" == "BT Phoenix_CORE" "$company" == "BTW Atlantis" -o "$company" == "BTW Genius" -o "$company" == "BT Retail Avalon Core" -o "$company" == "BT Retail Avalon CET" -o "$company" == "BT Plusnet" \) -a \( "$platform" == "linux" \) ]
then
	if [ "$maint" == "8.0.4" -o "$maint" == "5.3.8" ]
	then
		machine="devapp724cn"
	elif [ "$maint" == "9.0.4" -o "$maint" == "7.0.6" -o "$maint" == "9.0.3" ]
	then
		machine="devapp723cn"
	fi
	echo "[info] Overriding"
	/irb/bce/users/pavu0613/Myscripts/clientoverrides/override.sh "$project" "$version" "sqa" "$platform" "$oracle" "$machine" "auto" "i"
fi 

if [ \( "$maint" == "8.0.4" \) -a \( "$company" == "Bouygues" \) -a \( "$platform" == "linux" \) ]
then
	machine="devapp783cn"
	echo "[info] Overriding"
	/irb/bce/users/pavu0613/Myscripts/clientoverrides/override.sh "$project" "$version" "sqa" "$platform" "$oracle" "$machine" "auto" "i"
fi 

if [ \( "$company" == "Telefonica Ecuador" -o "$company" == "Telefonica Ecuador_RD" -o "$company" == "Telefonica Spain" -o "$company" == "Telefonica Spain_RD" -o "$company" == "Telefonica CAM" -o "$company" == "Telefonica CAM_RD" -o "$company" == "Verizon B2B_RH7_RD" -o "$company" == "Verizon B2B RH7" \) -a \( "$platform" == "linux" \) ]
then
	machine="devapp697cn"
	echo "[info] Overriding"
	/irb/bce/users/pavu0613/Myscripts/clientoverrides/override.sh "$project" "$version" "sqa" "$platform" "$oracle" "$machine" "auto" "i"
fi
if [ \( "$maint" == "7.0.3" \) -a \( "$company" == "C-Spire" \) -a \( "$platform" == "suselinux" \) ]
then
	machine="devapp791cn"
	echo "[info] Overriding"
	/irb/bce/users/pavu0613/Myscripts/clientoverrides/override.sh "$project" "$version" "sqa" "$platform" "$oracle" "$machine" "auto" "i"
fi
if [ \( "$maint" == "7.0.3" -o "$maint" == "8.0.4" -o "$maint" == "6.1.6" \) -a \( "$company" == "TMPL_SR3_DM1" -o "$company" == "Cogeco" -o "$company" == "Verizon B2B_RH6" \) -a \( "$platform" == "linux" \) ]
then
	machine="devapp655cn"
	echo "[info] Overriding"
	/irb/bce/users/pavu0613/Myscripts/clientoverrides/override.sh "$project" "$version" "sqa" "$platform" "$oracle" "$machine" "auto" "i"
fi
if [ \( "$maint" == "9.0.4" -o "$maint" == "9.0.2" \) -a \( "$company" == "Maxcom" \) -a \( "$platform" == "linux" \) ]
then
	machine="devapp655cn"
	echo "[info] Overriding"
	/irb/bce/users/pavu0613/Myscripts/clientoverrides/override.sh "$project" "$version" "sqa" "$platform" "$oracle" "$machine" "auto" "i"
fi
echo ""

