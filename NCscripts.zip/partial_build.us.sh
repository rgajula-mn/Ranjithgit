#!/bin/ksh
#set -x
. ~/.bce.ini
. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh

#########partial build of specific clients###########
#########after creating release tag and checking out build project##########
#########need to extract bin, lib and plb and sql to build the partial build#####
export ORACLE_HOME=/opt/oracle/9.2.0.SE
export PATH=$ORACLE_HOME/bin:$PATH

usage()
{
#echo "Usage: <sript name> <release tag product baserelase majorrelease platform oracleversion>"
#echo "Eg: partial_build.sh 5.3.5.67 RB 5.3.5 5.3 linux oracle11g"
echo "Usage: <sript name> <release>"
echo "Eg: partial_build.sh RB_5.3.5.67"
exit 1
}


if [ $# -ne 1 ]
then
        echo "Enter correct arguments"
	usage
else
	echo "arguments are passed correct"
fi
td_date=`date '+%Y%m%d'`
log_date=`echo "/irb/bce/admin/log/$td_date"`
logdt=`date '+%Y%m%d%H%M%S'`

if [ ! -d $log_date ]
then 
	mkdir -p $log_date
fi

patch_rel=$1
log1=`echo $log_date/partial_build_ice_$patch_rel.$logdt.log`
log=`echo $log_date/partial_build_$patch_rel.$logdt.log`
#`rm $log_date/partial_build_ice.log`
touch $log_date/partial_build_ice.$logdt.log
echo "partial script started at : `date`" >> $log 2>&1
echo "patch_rel is $patch_rel" >> $log 2>&1
patch_release=`echo $patch_rel|cut -d '_' -f2`
product=`echo $patch_rel|cut -d '_' -f1`
baseline_rel=`echo $patch_rel|cut -d '_' -f2|cut -d '.' -f1-3`
major_rel=`echo $patch_rel|cut -d '_' -f2|cut -d '.' -f1-2`
#################getting platform from patch_platforms#####################
sql="select oper_sys from patch_platforms where version='$patch_release' and project='$product'"
echo $sql>> $log 2>&1
	platform=`sqlplus -s buildweb/georgespass@webca.world << +END
                set feed off
                set head off
                $sql;
                exit
+END`
platform=`echo $platform|cut -b 1-`
####################getting oracle version from patch_platforms###########################
sql="select oracle_name from patch_platforms where version='$patch_release' and project='$product'"
echo $sql>> $log 2>&1
	oracle_ver=`sqlplus -s buildweb/georgespass@webca.world << +END
                set feed off
                set head off
                $sql;
                exit
+END`
oracle_ver=`echo $oracle_ver|cut -b 1-`

if [ $platform = 'linux' ]
then
	plt_map='lX'
elif [ $platform = 'solaris' ]
then 
	plt_map='sS'
elif [ $platform = 'aix' ]
then 
	plt_map='aP'
elif [ $platform = 'itanium' ]
then 
	plt_map='hI'
fi
bld_cmp_log=`echo $log_date/buildComplete-$product-sqa$patch_release.$platform.$oracle_ver.$logdt.log`
env_file=`echo env-$product"_sqa"$patch_release.$platform.$oracle_ver.sh`
#`rm $log_date/partial_build_ice.log`
touch $log_date/partial_build_ice.$logdt.log
b=0
found=0
######################getting company name from patch_company name########################
sql="select company from patch_company where version='$patch_release' and project='$product'"
echo $sql>> $log 2>&1
	company=`sqlplus -s buildweb/georgespass@webca.world << +END
                set feed off
                set head off
                $sql;
                exit
+END`

echo "company information: $company" >> $log 2>&1

patch_comp=`echo $company|cut -b 1-`
echo "patch company information $patch_comp" >> $log 2>&1
if [ "$patch_comp" == "Telefonica Ecuador" -o "$patch_comp" == "Telecom Egypt" -o "$patch_comp" == "Telefonica Uruguay" ]
then
	echo "Calling Single DB Partial Scirpt for $patch_comp"
	echo "[INFO] /irb/bce/raga1015/SNG/partial_build.sng.sh $patch_rel"
	/irb/bce/raga1015/SNG/partial_build.sng.sh $patch_rel
	exit
fi
######################getting patches based on company name from patch_company and patch_summary#########################
sql="select a.version from patch_company a, patch_summary b where a.version=b.version and b.patch_status!='Cancelled' and b.patch_status!='Test' and a.company='$patch_comp' and b.project='$product' and a.version like '$baseline_rel%'"
echo $sql>> $log 2>&1
patch_versions=`sqlplus -s buildweb/georgespass@webca.world << +END
                set feed off
                set head off
                $sql;
                exit
+END`
patch_versions=`echo $patch_versions|cut -b 1-`
echo "patch_versions for $patch_comp $patch_versions" >> $log 2>&1

product_val=`echo $product| tr '[:upper:]' '[:lower:]'`

if [ $oracle_ver = 'oracle11g' ]
then
     ora_ver=11g
elif [ $oracle_ver = 'oracle10g' ]
then
     ora_ver=10g
elif [ $oracle_ver = 'oracle12c' ]
then
     ora_ver=12c
fi

echo "environment date is: `date`" >> $log 2>&1
echo "patch release    is: $patch_release" >> $log 2>&1
echo "product          is: $product" >> $log 2>&1
echo "baseline         is: $baseline_rel" >> $log 2>&1
echo "major_rel        is: $major_rel" >> $log 2>&1
echo "platform         is: $platform" >> $log 2>&1
echo "platform mapping is: $plt_map" >> $log 2>&1
echo "product_val      is: $product_val" >> $log 2>&1
echo "oracle_version   is: $ora_ver" >> $log 2>&1
echo "todays date      is: $td_date" >> $log 2>&1
echo "Log Date         is: $log_date" >> $log 2>&1
echo "Build Complt log is: $bld_cmp_log" >> $log 2>&1
echo "environment file is: $env_file" >> $log 2>&1
echo "log & env file   is: $log_date/$env_file" >> $log 2>&1



machine_def=`cat $BCE_ADMIN/buildweb_config/overrides_for_release|grep "$patch_release"|cut -d ' ' -f6|cut -d ',' -f1`
echo "machine value from overrides_for_release is: $machine_def" >> $log 2>&1

if [ -z $machine_def ]
then
	machine_def=`cat $BCE_ADMIN/buildweb_config/defaults_for_release|grep "$major_rel"|grep "$product"|grep -w "$platform"|grep "$oracle_ver"|cut -d ' ' -f5|cut -d ',' -f1`
	echo "machine value from default_for_release is: $machine_def" >> $log 2>&1
fi

CCM_ROOT=/irb/bce/build/$product_val/$major_rel/$product-sqa${patch_release}.${platform}.${oracle_ver}/$product
echo "CCM_ROOT=$CCM_ROOT"

cd $CCM_ROOT
pwd=`pwd`
echo $pwd >> $log 2>&1

ls -alrt $CCM_ROOT/env*.sh
if [ $? == 0 ]
then
  r=`ls |grep env*.sh`
version=`echo $r|rev |cut -d '.' -f4-|rev|cut -d '_' -f2|cut -c4-`
#version=`echo $r|perl -ne 'chomp;print scalar reverse . "\n";'|cut -d '.' -f4-|perl -ne 'chomp;print scalar reverse . "\n";'|cut -d '_' -f2|cut -c4-`
 form_rel=RB-sqa$version.$platform.$oracle_ver
 db_available=`sqlplus -s buildweb/georgespass@webca.world << EOF
			whenever sqlerror exit failure
            set feed off
            set head off
            select SID from BUILD_DATABASE_LOCKS where CCM_PROJECT='$form_rel';
            exit
EOF`
         if [ -z $db_available ]
         then
           rm $CCM_ROOT/env*.sh
         fi
fi
db_check=`echo $db_available` 
#cd $CCM_ROOT/ALLBATCH/bin/
#bin_z=`ls -ltr |tail -1|awk '{print $9}'`
#if [ $bin_z = 'bin.zip'  -a -f $CCM_ROOT/ALLBATCH/bin/bin.zip ]
#if [ $bin_z = 'bin.zip' ]
#then
#	echo "no need to unzip the bin.zip" >> $log 2>&1
#else
#	echo "unzip is required for bin directory" >> $log 2>&1
#	unzip -o bin.zip >> $log 2>&1
#fi
#cd $CCM_ROOT/ALLBATCH/lib/
#lib_z=`ls -ltr |tail -1|awk '{print $9}'`
#if [ $lib_z = 'lib.zip' -a -f $CCM_ROOT/ALLBATCH/lib/lib.zip ]
#if [ $lib_z = 'lib.zip' ]
#then
#	echo "no need to unzip the lib.zip" >> $log 2>&1
#else
#	echo "unzip is required for lib directory" >> $log 2>&1
#	unzip -o lib.zip >> $log 2>&1
#fi
#ls -alrt $CCM_ROOT/ALLBATCH/bin/GDBgen
#if [ $? == 0 ]
if [ -f $CCM_ROOT/ALLBATCH/bin/GDBgen ]
then
 found=`expr $b + 1`
fi
if [ "$platform" == itanium ]
then
   mwbase=libRbmwbase.sl
else
   mwbase=libRbmwbase.so
fi
ls -alrt $CCM_ROOT/ALLBATCH/lib/$mwbase
#if [ $? == 0 ]
if [ -f $CCM_ROOT/ALLBATCH/lib/$mwbase ]
then
  found=`expr $found + 1` 
fi
rsh='ssh'
echo "$rsh"
cd $CCM_ROOT
if [ ! -z "$db_available" ]
then
  r=`ls env*.sh`
#  version=`echo $r|rev |cut -d '.' -f4-|rev|cut -d '_' -f2|cut -c4-`
   version=`echo $r|perl -ne 'chomp;print scalar reverse . "\n";'|cut -d '.' -f4-|perl -ne 'chomp;print scalar reverse . "\n";'|cut -d '_' -f2|cut -c4-`
   if [ "$version" != "$patch_release" ]
   then
       sed -i 's/RB-sqa'$version'/RB-sqa'$patch_release'/g' $CCM_ROOT/env-RB_sqa$version.$platform.$oracle_ver.sh
#      cat $CCM_ROOT/env-RB_sqa$version.$platform.$oracle_ver.sh|sed -e 's/RB-sqa'$version'/RB-sqa'$patch_release'/g' 
       mv $CCM_ROOT/env-RB_sqa$version.$platform.$oracle_ver.sh $CCM_ROOT/env-RB_sqa$patch_release.$platform.$oracle_ver.sh
  form=RB-sqa$patch_release.$platform.$oracle_ver
  `sqlplus -s buildweb/georgespass@webca.world << EOF
            whenever sqlerror exit failure
            set feed off
            set head off
            update BUILD_DATABASE_LOCKS set CCM_PROJECT='$form' where SID like '%$db_check%';
            exit
EOF`
      fi
#if [ "$version" != "$patch_release" ]
#  then
#     rm env-RB_sqa$version.$platform.$oracle_ver.sh
#  fi
   echo "env file is available in workarea"
    if [ "$found" -ne 2 ]
    then
            echo  " first loop $rsh $machine_def bash . ~/.bce.ini; partial_build_ice.sh  $patch_rel $log1 $env_file $CCM_ROOT" >> $log 2>&1
            $rsh $machine_def "bash . ~/.bce.ini; partial_build_ice.sh $patch_rel $env_file $log1 $CCM_ROOT" >> $log1 2>&1
     fi
else
	echo "partial build start date is: `date`" >> $log 2>&1
        echo "build_project_partial_us1 -p $product -s sqa -o $oracle_ver -r $patch_release.$platform.$oracle_ver -m $major_rel -d $td_date  -t all" >> $log 2>&1
	$rsh $machine_def  " $BCE_BUILD_SCRIPTS/build_project_partial_us1 -p $product -s sqa -o $oracle_ver -r $patch_release.$platform.$oracle_ver -m $major_rel -d $td_date  -t all" >> $log 2>&1
        prj_plt=`echo $CCM_ROOT|cut -d '/' -f7`
        echo "$prj_plt" >> $log 2>&1
        sql1="update BUILD_DATABASE_LOCKS set EXPIRE_TIME=EXPIRE_TIME+30 where CCM_PROJECT='$prj_plt'"
        sqlplus -s buildweb/georgespass@webca.world >> $log 2>&1 << +ENDSQL2
        set feed off
        set head off
        $sql1;
        commit;
        exit
+ENDSQL2
        cp -pr $log_date/$env_file $CCM_ROOT
        if [ "$found" -ne 2 ]
        then
            echo  "else loop $rsh $machine_def bash . ~/.bce.ini; partial_build_ice.sh  $patch_rel $log $env_file $log1 $CCM_ROOT" >> $log 2>&1
            $rsh $machine_def "bash . ~/.bce.ini; $BCE_BUILD_SCRIPTS/partial_build_ice.sh $patch_rel $env_file $log1 $CCM_ROOT" >> $log1 2>&1
       fi
fi
      echo "ssh genadmin@devapp696cn moduleBuild_svn.sh $patch_rel" >> $log 2>&1
 #     ssh genadmin@devapp696cn $BCE_BUILD_SCRIPTS/moduleBuild_svn.sh $patch_rel >> $log 2>&1
	$BCE_BUILD_SCRIPTS/moduleBuild_svn.sh $patch_rel >> $log 2>&1
if [ -f $bld_cmp_log ]
	then
#		echo "build is completed" >> $log 2>&1
#		cp -pr $log_date/$env_file $CCM_ROOT
                echo "build is completed" >> $log 2>&1
fi
