#|/bin/ksh

###########################################################################################
#
#     Set up Constants
#
###########################################################################################

. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh

BUILDWEB_DB=`buildweb_connection`
default_time=19990101010101
input_end_time=$default_time
input_export_time=$default_time
input_archive_time=$default_time
input_iso_time=$default_time
input_release_time=$default_time
input_prep_co_time=$default_time


###########################################################################################
#
#     #######
#     #        #    #  #    #   ####    #####     #     ####   #    #   ####
#     #        #    #  ##   #  #    #     #       #    #    #  ##   #  #
#     #####    #    #  # #  #  #          #       #    #    #  # #  #   ####
#     #        #    #  #  # #  #          #       #    #    #  #  # #       #
#     #        #    #  #   ##  #    #     #       #    #    #  #   ##  #    #
#     #         ####   #    #   ####      #       #     ####   #    #   ####
#
###########################################################################################

usage()
{
	echo " "
	echo "You entered $0 $* "
	echo " "
	echo "Usage: $0"
	echo "  e.g. $0"
	echo " "
	exit_program 1
}

exit_program ()
{
	echo ""
	echo "Exiting Program with status $1"
	exit $1
}

check_for_value ()
{
	sql=$1
	field=$2
	value=$3

	if [ ! -z "$value" -a "$value" != "$default_time" ]
	then
		if [ "$4" = "" ]
		then
			sql="$sql $field='$value',"
		else
			sql="$sql $field=to_date('$value','YYYYMMDDHH24MISS'),"
		fi
	fi
	
	echo $sql
}

###########################################################################################
#
#     #    #    ##       #    #    #
#     ##  ##   #  #      #    ##   #
#     # ## #  #    #     #    # #  #
#     #    #  ######     #    #  # #
#     #    #  #    #     #    #   ##
#     #    #  #    #     #    #    #
#
###########################################################################################

section="build_results"

#while getopts b:c:d:e:f:g:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:y:A:C:E:F:G:H:I:J:P:S:U:V:W:X:BDNORTahz the_option
while [ ! -z "$*" ]
do
	the_option=`echo "$1" | cut -d- -f2`
	OPTARG="$2"

	shift

	case $the_option in
	A)
		input_lint_path="$OPTARG"
		shift
		;;
	B)
		section="build_results"
		;;
	C)
		input_copy_build="$OPTARG"
		shift
		;;
	D)
		section="build_summary"
		;;
	E)
		input_prep_co_time="$OPTARG"
		shift
		;;
	F)
		input_test_to_release="$OPTARG"
		shift
		;;
	G)
		input_test_to_release_result="$OPTARG"
		shift
		;;
	H)
		input_lint_warns="$OPTARG"
		shift
		;;
	I)
		input_item1="$OPTARG"
		shift
		;;
	J)
		input_item2="$OPTARG"
		shift
		;;
	K)
		input_seq_number="$OPTARG"
		shift
		;;
	L)
		input_location="$OPTARG"
		shift
		;;
	M)
		input_release_mgr="$OPTARG"
		shift
		;;
	N)
		section="patch_summary"
		;;
	O)
		section="maintenance_summary"
		;;
	P)
		input_copy_pc_build="$OPTARG"
		shift
		;;
	Q)
		section="build_res_to_test_cand"
		;;
	R)
		section="release_summary"
		;;
	S)
		input_table_name="$OPTARG"
		shift
		section="bs_table"
		;;
	T)
		section="test_summary"
		;;
	U)
		input_machine="$OPTARG"
		shift
		;;
	V)
		input_vpa_check="$OPTARG"
		shift
		;;
	W)
		input_database="$OPTARG"
		shift
		;;
	X)
		input_comments="$OPTARG"
		shift
		;;
	Y)
		section="baseline_build_folder"
		;;
	a)
		echo "abcdefghijklmnopqrstuvwxzBRT"
		exit_program 1
		;;
	b)
		input_build_summary="$OPTARG"
		shift
		;;
	c)
		input_reconf_prop="$OPTARG"
		shift
		;;
	d)
		input_reconf_errs="$OPTARG"
		shift
		;;
	e)
		input_build_errs="$OPTARG"
		shift
		;;
	f)
		input_progress="$OPTARG"
		shift
		;;
	g)
		input_progress_lmt="$OPTARG"
		shift
		;;
	h)
		usage $*
		;;
	i)
		input_cand_name="$OPTARG"
		shift
		;;
	j)
		input_rel_type="$OPTARG"
		shift
		;;
	k)
		input_review_num="$OPTARG"
		shift
		;;
	l)
		input_start_time="$OPTARG"
		shift
		;;
	m)
		input_end_time="$OPTARG"
		if [ -z "${input_end_time}" ]
		then
			input_end_time=$default_time
		fi
		shift
		;;
	n)
		input_export_time="$OPTARG"
		shift
		;;
	o)
		input_platform_os="$OPTARG"
		shift
		;;
	p)
		input_project="$OPTARG"
		shift
		;;
	q)
		input_iso_time="$OPTARG"
		shift
		;;
	r)
		input_platform_rest="$OPTARG"
		shift
		;;
	s)
		input_build_state="$OPTARG"
		shift
		;;
	t)
		input_rtest_page="$OPTARG"
		shift
		;;
	u)
		input_user="$OPTARG"
		shift
		;;
	v)
		input_version="$OPTARG"
		shift
		;;
	w)
		input_build_warns="$OPTARG"
		shift
		;;
	x)
		input_archive_time="$OPTARG"
		shift
		;;
	y)
		input_release_time="$OPTARG"
		shift
		;;
	z)
		debug_on="TRUE"
		;;
	[?])
		usage $*
		;;
	esac
done

if [ "$section" != "baseline_build_folder" ]
then
	if [ -z "$input_project" -o -z "$input_version" ]
	then
		echo "input_project     = $input_project"
		echo "input_version     = $input_version"
		usage $*
	fi
fi

find_sqlhome 9.2.0.SE
if [ $? -ne 0 ]
then
	echo "$0: Error: Cannot find valid SQLPLUS"
	exit 1
fi

if [ "$section" = "build_results" ]
then
	if [ -z "$input_build_state" -o -z "$input_start_time" -o -z "$input_platform_os" ]
	then
		echo "input_build_state = $input_build_state"
		echo "input_start_time  = $input_start_time"
		echo "input_platform_os = $input_platform_os"
		usage $*
	fi

	sql_result=`sqlplus -s $BUILDWEB_DB << +END
		set feed off
		set head off
		alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
		select * from build_results where project='$input_project' and version='$input_version' and buildstate='$input_build_state' and start_time=to_date('$input_start_time','YYYYMMDDHH24MISS') and platform_os='$input_platform_os';
		exit
+END`

	database_working=$?

	if [ $database_working -eq 0 ]
	then
		if [ -z "$sql_result" ]
		then
			echo "Info: update_build_information.sh: Creating a new row"

			sql="select BUILD_SEQ.nextval from dual"
			tmp_number=`sql_query ${BUILDWEB_DB} "$sql"`
			seq_number=`echo $tmp_number`
	
			create_sql="insert into build_results(project, version, buildstate, platform_os, platform_other, reconf_errs, reconf_prop, build_errs, build_warns, build_summary, rtest, progress, progress_lmt, start_time, end_time, machine,database, manifest_id, build_id) values('$input_project','$input_version','$input_build_state','$input_platform_os','$input_platform_rest','$input_reconf_errs','$input_reconf_prop','$input_build_errs','$input_build_warns','$input_build_summary','$input_rtest_page','$input_progress','$input_progress_lmt',to_date('$input_start_time','YYYYMMDDHH24MISS'),to_date('$input_end_time','YYYYMMDDHH24MISS'),'$input_machine','$input_database','$input_seq_number','$seq_number');"
	
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$create_sql
			exit
+END
		else
			echo "Info: update_build_information.sh: Updating an existing row"
	
			update_sql="update build_results set"
			update_sql=`check_for_value "$update_sql" project "$input_project"`
			update_sql=`check_for_value "$update_sql" version "$input_version"`
			update_sql=`check_for_value "$update_sql" buildstate "$input_build_state"`
			update_sql=`check_for_value "$update_sql" platform_os "$input_platform_os"`
			update_sql=`check_for_value "$update_sql" platform_other "$input_platform_rest"`
			update_sql=`check_for_value "$update_sql" reconf_errs "$input_reconf_errs"`
			update_sql=`check_for_value "$update_sql" reconf_prop "$input_reconf_prop"`
			update_sql=`check_for_value "$update_sql" build_errs "$input_build_errs"`
			update_sql=`check_for_value "$update_sql" build_warns "$input_build_warns"`
			update_sql=`check_for_value "$update_sql" build_summary "$input_build_summary"`
			update_sql=`check_for_value "$update_sql" rtest "$input_rtest_page"`
			update_sql=`check_for_value "$update_sql" progress "$input_progress"`
			update_sql=`check_for_value "$update_sql" machine "$input_machine"`
			update_sql=`check_for_value "$update_sql" database "$input_database"`
			update_sql=`check_for_value "$update_sql" manifest_id "$input_seq_number"`
			update_sql=`check_for_value "$update_sql" progress_lmt "$input_progress_lmt"`
			update_sql=`check_for_value "$update_sql" start_time "$input_start_time" date_time`
			update_sql=`check_for_value "$update_sql" end_time "$input_end_time" date_time`
			update_sql=`check_for_value "$update_sql" lint_warns "$input_lint_warns"`
			update_sql=`check_for_value "$update_sql" lint_path "$input_lint_path"`
			update_sql=`echo $update_sql | sed -e 's/,$//'`
			update_sql="$update_sql where project='$input_project' and version='$input_version' and buildstate='$input_build_state' and start_time=to_date('$input_start_time','YYYYMMDDHH24MISS') and platform_os='$input_platform_os';"
	
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$update_sql
			exit
+END
		fi
	fi
fi

if [ "$section" = "test_summary" ]
then
	if [ -z "$input_rel_type" -o -z "$input_cand_name" ]
	then
		echo "input_rel_type   = $input_rel_type"
		echo "input_cand_name  = $input_cand_name"
		usage $*
	fi

	select_sql="select * from test_cand_summary where project='$input_project' and version='$input_version' and cand_name='$input_cand_name' and rel_type='$input_rel_type'"

	sql_result=`sqlplus -s $BUILDWEB_DB << +END
		set feed off
		set head off
		alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
		$select_sql;
		exit
+END`
	database_working=$?

	if [ $database_working -eq 0 ]
	then
		if [ -z "$sql_result" ]
		then
			echo "Info: update_build_information.sh: Creating a new row"
	
			create_sql="insert into test_cand_summary(project, version, cand_name, reconf_prop, release_time, buildstate, rel_type, username, vpa_versions, copy_unix, copy_pc, export_location, comments, review_num) values('$input_project','$input_version','$input_cand_name','$input_reconf_prop',to_date('$input_release_time','YYYYMMDDHH24MISS'),'$input_build_state','$input_rel_type','$input_user','$input_vpa_check','$input_copy_build','$input_copy_pc_build','$input_location','$input_comments','$input_review_num');"
	
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$create_sql
			exit
+END
		else
			echo "Info: update_build_information.sh: Updating an existing row"
	
			update_sql="update test_cand_summary set"
			update_sql=`check_for_value "$update_sql" project "$input_project"`
			update_sql=`check_for_value "$update_sql" version "$input_version"`
			update_sql=`check_for_value "$update_sql" cand_name "$input_cand_name"`
			update_sql=`check_for_value "$update_sql" reconf_prop "$input_reconf_prop"`
			update_sql=`check_for_value "$update_sql" release_time "$input_release_time" date_time`
			update_sql=`check_for_value "$update_sql" buildstate "$input_build_state"`
			update_sql=`check_for_value "$update_sql" rel_type "$input_rel_type"`
			update_sql=`check_for_value "$update_sql" username "$input_user"`
			update_sql=`check_for_value "$update_sql" vpa_versions "$input_vpa_check"`
			update_sql=`check_for_value "$update_sql" copy_unix "$input_copy_build"`
			update_sql=`check_for_value "$update_sql" copy_pc "$input_copy_pc_build"`
			update_sql=`check_for_value "$update_sql" export_location "$input_location"`
			update_sql=`check_for_value "$update_sql" comments "$input_comments"`
			update_sql=`check_for_value "$update_sql" review_num "$input_review_num"`
			
			update_sql=`echo $update_sql | sed -e 's/,$//'`
			update_sql="$update_sql where project='$input_project' and version='$input_version' and rel_type='$input_rel_type' and cand_name='$input_cand_name';"

			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$update_sql
			exit
+END
		fi
	else
		echo "$sql_result"
	fi
fi

if [ "$section" = "baseline_build_folder" ]
then
	if [ -z "$input_item1" ]
	then
		echo "input_item1(folder)   = $input_item1"
		usage $*
	fi

	sql_result=`sqlplus -s $BUILDWEB_DB << +END
		set feed off
		set head off
		alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
		select * from baseline_build_folder where folder='$input_item1';
		exit
+END`

	database_working=$?

	if [ $database_working -eq 0 ]
	then
		if [ -z "$sql_result" ]
		then
			echo "Info: update_build_information.sh: Creating a new row"
	
			create_sql="insert into baseline_build_folder(project, version, folder, build_date, baseline, rc) values('$input_project','$input_version','$input_item1',to_date('$input_start_time','YYYYMMDDHH24MISS'),'$input_item2','$input_cand_name');"
	
			echo "Running the SQL command: $create_sql"
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$create_sql
			exit
+END
		else
			echo "Info: update_build_information.sh: Updating an existing row"
	
			update_sql="update baseline_build_folder set"
			update_sql=`check_for_value "$update_sql" project "$input_project"`
			update_sql=`check_for_value "$update_sql" version "$input_version"`
			update_sql=`check_for_value "$update_sql" folder "$input_item1"`
			update_sql=`check_for_value "$update_sql" build_date "$input_start_time" date_time`
			update_sql=`check_for_value "$update_sql" baseline "$input_item2"`
			update_sql=`check_for_value "$update_sql" rc "$input_cand_name"`
			
			update_sql=`echo $update_sql | sed -e 's/,$//'`
			update_sql="$update_sql where folder='$input_item1';"
	
			echo "Running the SQL command: $update_sql"
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$update_sql
			exit
+END
		fi
	fi
fi

if [ "$section" = "release_summary" ]
then
	if [ -z "$input_rel_type" ]
	then
		echo "input_rel_type   = $input_rel_type"
		usage $*
	fi

	sql_result=`sqlplus -s $BUILDWEB_DB << +END
		set feed off
		set head off
		alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
		select * from release_summary where project='$input_project' and version='$input_version' and rel_type='$input_rel_type';
		exit
+END`

	database_working=$?

	if [ $database_working -eq 0 ]
	then
		if [ -z "$sql_result" ]
		then
			echo "Info: update_build_information.sh: Creating a new row"
	
			create_sql="insert into release_summary(project, version, rel_type, reconf_prop, release_time, review_num, test_to_release, test_to_release_result, export_time, archive_time, iso_time, username, release_mgr) values('$input_project','$input_version','$input_rel_type','$input_reconf_prop',to_date('$input_release_time','YYYYMMDDHH24MISS'),'$input_review_num','$input_test_to_release','$input_test_to_release_result',to_date('$input_export_time','YYYYMMDDHH24MISS'),to_date('$input_archive_time','YYYYMMDDHH24MISS'),to_date('$input_iso_time','YYYYMMDDHH24MISS'),'$input_user','$input_release_mgr');"
	
			echo "Running the SQL command: $create_sql"
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$create_sql
			exit
+END
		else
			echo "Info: update_build_information.sh: Updating an existing row"
	
			update_sql="update release_summary set"
			update_sql=`check_for_value "$update_sql" project "$input_project"`
			update_sql=`check_for_value "$update_sql" version "$input_version"`
			update_sql=`check_for_value "$update_sql" rel_type "$input_rel_type"`
			update_sql=`check_for_value "$update_sql" reconf_prop "$input_reconf_prop"`
			update_sql=`check_for_value "$update_sql" release_time "$input_release_time" date_time`
			update_sql=`check_for_value "$update_sql" export_time "$input_export_time" date_time`
			update_sql=`check_for_value "$update_sql" archive_time "$input_archive_time" date_time`
			update_sql=`check_for_value "$update_sql" iso_time "$input_iso_time" date_time`
			update_sql=`check_for_value "$update_sql" review_num "$input_review_num"`
			update_sql=`check_for_value "$update_sql" test_to_release "$input_test_to_release"`
			update_sql=`check_for_value "$update_sql" test_to_release_result "$input_test_to_release_result"`
			update_sql=`check_for_value "$update_sql" username "$input_user"`
			update_sql=`check_for_value "$update_sql" release_mgr "$input_release_mgr"`
			
			update_sql=`echo $update_sql | sed -e 's/,$//'`
			update_sql="$update_sql where project='$input_project' and version='$input_version' and rel_type='$input_rel_type';"
	
			echo "Running the SQL command: $update_sql"
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$update_sql
			exit
+END
		fi
	fi
fi

if [ "$section" = "build_summary" ]
then
	sql_result=`sqlplus -s $BUILDWEB_DB << +END
		set feed off
		set head off
		alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
		select * from build_summary where project='$input_project' and version='$input_version';
		exit
+END`

	database_working=$?

	if [ $database_working -eq 0 ]
	then
		if [ -z "$sql_result" ]
		then
			echo "Info: update_build_information.sh: Creating a new row"
	
			if [ "$input_start_time" != "19990101010101" ]
			then
				echo "Here: $input_start_time"
				create_sql="insert into build_summary(project, version, checkout_prep_time, del_review, build_manager, rel_to_bld_time, overall_build_state) values('$input_project','$input_version',to_date('$input_prep_co_time','YYYYMMDDHH24MISS'),'$input_review_num','$input_user',to_date('$input_start_time','YYYYMMDDHH24MISS'),'OPEN');"
			else
				echo "There: $input_start_time"
				create_sql="insert into build_summary(project, version, checkout_prep_time, del_review, build_manager, overall_build_state) values('$input_project','$input_version',to_date('$input_prep_co_time','YYYYMMDDHH24MISS'),'$input_review_num','$input_user','OPEN');"
			fi
				
	
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$create_sql
			exit
+END
		else
			echo "Info: update_build_information.sh: Updating an existing row"
	
			update_sql="update build_summary set"
			update_sql=`check_for_value "$update_sql" project "$input_project"`
			update_sql=`check_for_value "$update_sql" version "$input_version"`
			update_sql=`check_for_value "$update_sql" checkout_prep_time "$input_prep_co_time" date_time`
			update_sql=`check_for_value "$update_sql" del_review "$input_review_num"`
			update_sql=`check_for_value "$update_sql" build_manager "$input_user"`
			update_sql=`check_for_value "$update_sql" rel_to_bld_time "$input_start_time" date_time`
			
			update_sql=`echo $update_sql | sed -e 's/,$//'`
			update_sql="$update_sql where project='$input_project' and version='$input_version';"
	
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$update_sql
			exit
+END
		fi
	fi
fi

if [ "$section" = "maintenance_summary" ]
then
	if [ -z "$input_build_state" ]
	then
		echo "input_build_state   = $input_build_state"
		usage $*
	fi

	sql_result=`sqlplus -s $BUILDWEB_DB << +END
		set feed off
		set head off
		alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
		select * from maintenance_summary where project='$input_project' and version='$input_version';
		exit
+END`

	database_working=$?

	if [ $database_working -eq 0 ]
	then
		if [ -z "$sql_result" ]
		then
			echo "Info: update_build_information.sh: Creating a new row"
	
			create_sql="insert into maintenance_summary(project, version, maintenance_status) values('$input_project','$input_version','$input_build_state');"
	
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$create_sql
			exit
+END
		else
			echo "Info: update_build_information.sh: Updating an existing row"
	
			update_sql="update maintenance_summary set"
			update_sql=`check_for_value "$update_sql" project "$input_project"`
			update_sql=`check_for_value "$update_sql" version "$input_version"`
			update_sql=`check_for_value "$update_sql" maintenance_status "$input_build_state"`
			
			update_sql=`echo $update_sql | sed -e 's/,$//'`
			update_sql="$update_sql where project='$input_project' and version='$input_version';"
	
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$update_sql
			exit
+END
		fi
	fi
fi

if [ "$section" = "patch_summary" ]
then
	if [ -z "$input_build_state" ]
	then
		echo "input_build_state   = $input_build_state"
		usage $*
	fi

	sql_result=`sqlplus -s $BUILDWEB_DB << +END
		set feed off
		set head off
		alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
		select * from patch_summary where project='$input_project' and version='$input_version';
		exit
+END`

	database_working=$?

	if [ $database_working -eq 0 ]
	then
		if [ -z "$sql_result" ]
		then
			echo "Info: update_build_information.sh: Creating a new row"
	
			create_sql="insert into patch_summary(project, version, patch_status) values('$input_project','$input_version','$input_build_state');"
	
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$create_sql
			exit
+END
		else
			echo "Info: update_build_information.sh: Updating an existing row"
	
			update_sql="update patch_summary set"
			update_sql=`check_for_value "$update_sql" project "$input_project"`
			update_sql=`check_for_value "$update_sql" version "$input_version"`
			update_sql=`check_for_value "$update_sql" patch_status "$input_build_state"`
			
			update_sql=`echo $update_sql | sed -e 's/,$//'`
			update_sql="$update_sql where project='$input_project' and version='$input_version';"
	
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$update_sql
			exit
+END
		fi
	fi
fi

if [ "$section" = "build_res_to_test_cand" ]
then
	if [ -z "$input_project" -o -z "$input_version" -o -z "$input_rel_type" -o -z "$input_cand_name" -o -z "$input_seq_number" ]
	then
		echo "input_project      = $input_project"
		echo "input_verion       = $input_verion"
		echo "input_rel_type     = $input_rel_type"
		echo "input_cand_name    = $input_cand_name"
		echo "input_seq_number   = $input_seq_number"
		usage $*
	fi

	sql_result=`sqlplus -s $BUILDWEB_DB << +END
		set feed off
		set head off
		alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
		select * from build_res_to_test_cand where project='$input_project' and version='$input_version' and rel_type='$input_rel_type' and cand_name='$input_cand_name' and build_id='$input_seq_number';
		exit
+END`

	database_working=$?

	if [ $database_working -eq 0 ]
	then
		if [ -z "$sql_result" ]
		then
			echo "Info: update_build_information.sh: Creating a new row: build_res_to_test_cand"
	
			create_sql="insert into build_res_to_test_cand (project, version, rel_type, cand_name, build_id) values('$input_project','$input_version','$input_rel_type','$input_cand_name','$input_seq_number');"
	
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$create_sql
			exit
+END
		else
			echo "Info: update_build_information.sh: Information already in Database: build_res_to_test_cand"
		fi
	fi
fi

if [ ! -z "$input_table_name" ]
then
	sql_result=`sqlplus -s $BUILDWEB_DB << +END | awk '{print $1}'
		set feed off
		set head off
		set heading off
		set title off
		alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
		desc $input_table_name;
		exit
+END` 
	database_working=$?

	if [ $database_working -ne 0 ]
	then
		echo "ERROR: Database not working: Stage 1"
		exit 1
	fi

	sql_result=`echo $sql_result | sed -e 's/.*--- \(.*\)$/\1/'`

	column_count=0
	for i in $sql_result
	do
		
		case $i in
			PROJECT|VERSION|CREATE_TIME|COMMENTS)
				continue
				;;
			*)
				column=$i
				;;
		esac
		column_count=`expr $column_count + 1`

		if [ $column_count -eq 1 ]
		then
			column1=$column
		else
			column2=$column
		fi
	done

	if [ -z "$input_item1" -o -z "$input_release_time" ]
	then
		echo "create_time             = $input_release_time"
		echo "input_item1($column1)   = $input_item1"
		usage $*
	fi

	insert_extra_columns="$column1"
	insert_extra_values="'$input_item1'"
	update_extra_string="$column1='$input_item1'"
	where_extra_string="$column1='$input_item1'"

	if [ $column_count -eq 2 -a -z "$input_item2" ]
	then
		echo "input_item2($column2)   = $input_item2"
		usage $*
	fi
	
	if [ $column_count -eq 2 ]
	then
		insert_extra_columns="${insert_extra_columns}, $column2"
		insert_extra_values="${insert_extra_values}, '$input_item2'"
		update_extra_string="${update_extra_string}, $column2='$input_item2'"
		where_extra_string="${where_extra_string} and $column2='$input_item2'"
	fi

	sql_result=`sqlplus -s $BUILDWEB_DB << +END
		set feed off
		set head off
		alter session set NLS_DATE_FORMAT = 'dd-MON-rrrr hh24:mi:ss';
		select * from $input_table_name where project='$input_project' and version='$input_version' and $where_extra_string;
		exit
+END`
	database_working=$?

	if [ $database_working -eq 0 ]
	then
		if [ -z "$sql_result" ]
		then
			echo "Info: update_build_information.sh: Creating a new row"
	
			create_sql="insert into $input_table_name(project, version, $insert_extra_columns, create_time, comments) values('$input_project','$input_version',$insert_extra_values,to_date('$input_release_time','YYYYMMDDHH24MISS'),'$input_comments');"
			echo $create_sql
	
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$create_sql
			exit
+END
		else
			echo "Info: update_build_information.sh: Updating an existing row"
	
			update_sql="update $input_table_name set"
			update_sql=`check_for_value "$update_sql" project "$input_project"`
			update_sql=`check_for_value "$update_sql" version "$input_version"`
			update_sql="$update_sql $update_extra_string,"
			update_sql=`check_for_value "$update_sql" create_time "$input_release_time" date_time`
			update_sql=`check_for_value "$update_sql" comments "$input_comments"`
			
			update_sql=`echo $update_sql | sed -e 's/,$//'`
			update_sql="$update_sql where project='$input_project' and version='$input_version' and $where_extra_string;"

			echo "$update_sql"
	
			sqlplus -s $BUILDWEB_DB << +END
			set feed off
			set head off
			$update_sql
			exit
+END
		fi
	else
		echo $sql_result
	fi
fi
