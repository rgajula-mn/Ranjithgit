#!/bin/bash
#set -x
. /home/genadmin/.bce.ini

if [ ! "${BCE_BUILD_SCRIPTS}" ]
then
        BCE_BUILD_SCRIPTS=/irb/bce/admin/build_scripts
fi

. ${BCE_BUILD_SCRIPTS}/buildweb_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/core_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/ccm_functions_svn.sh
. ${BCE_BUILD_SCRIPTS}/patch_functions_svn.sh


releaseTag=$1
platform=$2
oracle=$3
projectType=$4
releaseNum=`echo $releaseTag | sed -e "s/.*_//g"`
project=`echo $releaseTag | sed -e "s/_.*//g"`
#if [ "$project" = "TAP" ]
#then
#	project="TAP3"
#fi
if [ "$project" = "GEN" ]
then
	project="GENEVA"
fi
projectLowerCase=`echo $project | tr '[A-Z]' '[a-z]'`
majorRelease=`echo $releaseTag | sed -e "s/.*_//g" | cut -d'.' -f1-2`
maintRelease=`echo $releaseTag | sed -e "s/.*_//g" | cut -d'.' -f1-3`
synergyPlatform=`cat /irb/bce/admin/buildweb_config/ccm_platform_details | grep "$platform.$oracle" | awk '{print $2}'`
DATABASE="buildweb/georgespass@webca.world"
CCM_DATABASE_CB1="/ccm/prd"
CCM_DATABASE_CB2="/ccm/cb2"
expectedRC=""
previousRC=""
validPlatforms=("hp64" "tru64" "hp" "solaris" "aix" "itanium" "linux" "solaris32")
validOracle=("oracle9i2" "oracle10g_cancelled" "oracle11g" "oracle10g" "oracle10gcancelled" "oracle8i" "oracle9i" "at" "oracle8")
buildPath="/irb/bce/build"
if [ "$project" = "TAP3" ]
then
        pathToAllDeliverables="$buildPath/$projectLowerCase/$majorRelease/$project-$projectType$releaseNum.$platform.$oracle/$project/"
elif [ "$project" = "VI" ]
then
	pathToAllDeliverables="$buildPath/$projectLowerCase/$majorRelease/$project-$projectType$releaseNum.$platform.$oracle/$project/"
	echo "value of VI of pathToAllDeliverables is:" $pathToAllDeliverables
else
        pathToAllDeliverables="$buildPath/$projectLowerCase/$majorRelease/$project-$projectType$releaseNum.$platform.$oracle/$project/ALLBATCH"
	echo "value of non VI  of pathToAllDeliverables is:" $pathToAllDeliverables
fi
workArea=""
patchWorkArea=""
newTaskCreated=""
isNewTaskCreated=""
userid=""

if [ "$project" = "GENEVA" -a "$majorRelease" = "5.4" ]
then
	patchType="RBPATCH"
	majorRelease="2.2"
	projectLowerCase="rb"
elif [ "$project" = "GENEVA" -a "$majorRelease" = "5.3" ]
then
	patchType="GENEVAPATCH"
elif [ "$project" = "TAP3" ]
then
        patchType="TAP3PATCH"
elif [ "$project" = "VI" ]
then
        patchType_VI_X="VI_XPATCH"
	patchType_VI_STQ="VI_STQPATCH"
	patchType_VI_CTL="VI_CTLPATCH"
else
	patchType="RBPATCH"
fi

function start(){
#	isMachineValid_Temporarily  closing
	if [ $# -lt 5 ]
	then
        	printf  "[ERROR] Enter correct arguments\n"
	        usage
		exit
	else
		areParametersValid $@ 
		displayEnteredValues
		findExpectedRC
		if [ "$expectedRC" != "" ]
		then
			#startSynergy
			setupPatch
			if [ "$project" = "TAP3" ]
                        then
				echo "@@@@@@@@@@@@@@@@@@@@CALLING anyNewTAP3DeliverablesAsked FUNCTION@@@@@@@@@@@@@@@@@@@@@@@@@@"
				anyNewTAP3DeliverablesAsked
			elif [ "$project" = "VI" ]
			then
				echo "@@@@@@@@@@@@@@@@@@@@CALLING anyNewVIDeliverablesAsked FUNCTION@@@@@@@@@@@@@@@@@@@@@@@@@@"
                                anyNewVIDeliverablesAsked
                        else
                                anyNewDeliverablesAsked
                        fi			
			company=`findPatchCompany $project $releaseNum`
                        company=`echo $company|awk '{$1=$1;print}'`

                        Parent_Version=`findParentRelease "$project" "$company"`
                        Parent_Patch_RCno=`findParentRelease_RCno "$project" "$Parent_Version"`
                        comp_var=`echo "$company"|egrep 'TMPL|ADTL|Andorra'`
                        if [ $? -eq 0 ]
                        then
                                echo "It's $company PATCH"
                                add_release_info_xml $project $releaseNum $Parent_Version $Parent_Patch_RCno
                        fi


#exit
		#	if [ $previousRC -ge 1 ]
		#	then
				#compareCurrentAndPreviousRC
		#	fi
                #		deliverablesToPrepState
		printf  "[ERROR] Calling Copy build Script"
			runCopyBuildObjects
#			checkinDefaultTask
		fi
	fi
}
start $@
