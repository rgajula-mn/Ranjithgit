#!/bin/sh

usage() 
{
	echo "Usage:"
	echo "$0 [-r <ruleset>] [-o <output report>] [-t <spcfile>,<spcdir>,<spcdir/spcfile>,..] [-m <all|pub|sep>] [-i <internal output report>]"
	exit 1
}


work_dir=`pwd`
TOOL_DIR=`dirname $0`
ruleset="${TOOL_DIR}/ruleset.xml"
timestamp=`date +%Y-%m-%d_%H-%M-%S`
report="$work_dir/spc_report-"$timestamp".txt"
internal_report="$work_dir/internal_spc_report-"$timestamp".txt"
fileMode="R"    ## Recursive Mode ## (Default)
procMode="A"    ## All procedures validated (Default) 
jdk="$TOOL_DIR/newFile.txt"
if [ "$1" == "-version" ]
	then 
		touch $jdk
		chmod 777 $jdk
		java -version 2>$jdk
		echo "RB SPC Validation Tool version 1.2.0"
		echo `grep "version" $jdk`
		echo `unzip -p RBspcValidationTool-1.2.0.jar META-INF/MANIFEST.MF | grep "Build-Jdk"`
		rm -f $jdk
		exit 0
fi
while getopts ":r:o:t:m:i:" o; do
	case "${o}" in 
		r)
			ruleset=${OPTARG}
			;;
		o)
			report=${OPTARG}
			;;
		t)
			linear_arg_list=${OPTARG}
			fileMode="L"
                        ;;
		m)
			case ${OPTARG} in
				"all")
					procMode="A"
					;;
				"pub")
					procMode="P"
					;;
				"sep")
					procMode="S"
					;;
				*)
					usage
			esac
			;;
		i)
			internal_report=${OPTARG}
			;;
		*)
			usage
	esac
done

if [ ! -s "${ruleset}" ]
	then
		echo "${ruleset} does not exist"
		exit 1
fi

linear_no_space_list=`echo $linear_arg_list|tr -d ' '`

if [ "$fileMode" = "L" ]
	then
		"${JAVA_HOME}/bin/java" -jar "${TOOL_DIR}/RBspcValidationTool-1.2.0.jar" "$ruleset" "$linear_no_space_list" "$report" "$fileMode$procMode" "$internal_report" 
	else
		"${JAVA_HOME}/bin/java" -jar "${TOOL_DIR}/RBspcValidationTool-1.2.0.jar" "$ruleset" "$work_dir" "$report" "$fileMode$procMode$repMode" "$internal_report"
fi