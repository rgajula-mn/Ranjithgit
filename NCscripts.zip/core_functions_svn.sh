#! /bin/sh
################################################################
# Script Name : core_functions.sh
# Version No. : 3
# Instance No.: 1
# Last Author : dp2
# Description :
# A collection of utility functions, used by other scripts.
# (C) Convergys, 2002. Convergys refers to Convergys
# Corporation or any of its wholly owned subsidiaries.
################################################################
#set -x
################################################################
# Shows a debug message if debug_flag is set to "T"
################################################################

showDebugMessage()
{
   debug=`echo $debug_flag`
   if [ "$debug" = "T" ]
   then
     echo "$0 ${*}"
   fi
}

################################################################
# Spinner:
################################################################
# If not running as a redirection to a file, this function
# creates a spinning symbol:
# INPUT:  Next char needed, represented as a numeric number.
# OUTPUT: Next char needed in spin cycle, passed as error code.
# Possible inputs:
#	1: "/"
#	2: "-"
#	3: "\"
#	4: "|"
#	5: "."
#	6: Clear Line
#	7: "?/?" e.g. 5/10
#	*: delete last character
################################################################

spinner () {
        current_char=$1
	current_number=$2
	hign_number=$3
        if [ -t 1 ]
        then
                if [ -z "$current_char" ]
                then
                        current_char=0
                fi

                if [ $current_char -eq 1 ]
                then
                        echo "\b/\c"
                        return 2
                elif [ $current_char -eq 2 ]
                then
                        echo "\b-\c"
                        return 3
                elif [ $current_char -eq 3 ]
                then
                        echo "\b\\ \b\c"
                        return 4
                elif [ $current_char -eq 4 ]
                then
                        echo "\b|\c"
                        return 1
		elif [ $current_char -eq 5 ]
		then
			echo ".\c"
			return 5
		elif [ $current_char -eq 6 ]
		then
			echo "\b\b\b\b\b\b\b       \b\b\b\b\b\b\b\c"
			return 6
		elif [ $current_char -eq 7 ]
		then
			current_number=`expr $current_number + 1`
			echo "\b\b\b\b\b\b\b${current_number}/${hign_number}\c"
			return $current_number
                else
                        echo "\b \b\c"
                        return 0
                fi
        fi
        return 0
}

################################################################
# Check for special flags:
################################################################

checkForSpecialFlags() {
    if [ "${1}" = "-h" ]
    then
        automaticUsage
    elif [ "${1}" = "--help" ]
    then
	echo ""
        scriptDescription
	echo ""
	echo "- Run \"`basename ${0}` -h\" for usage."
	echo ""
        exit 1
    elif [ "${1}" = "scriptDocumentation" ]
    then
        "${1}"
        exit 0
    fi
    return 0
}

################################################################
# Usage function
################################################################

automaticUsage() {
    echo ""
    echo "- Usage:"
    echo "  `scriptRequires`"
    echo "  `basename ${0}` `scriptParameters`"
    echo ""
    echo "- e.g:"
    echo "  `basename ${0}` `scriptExample`"
    echo ""
    echo "- Necessary environment Settings:"
    echo "  `scriptEnvironment`"
    echo ""
    echo "- You will need the following permission(s) to run this script:"
    echo "  `scriptPermission`"
    echo ""
    echo "- Run \"`basename ${0}` --help\" for more info."
    echo ""
    cleanUpCCM
    exit 1
}

################################################################
# Script Documentation:
################################################################
# This function is called when automatically generating the
# build script documentation reference: (build script bible :)
################################################################

scriptDocumentation() {
    for component in "Requires" "Parameters" "Example" "Environment" "Permission" "Description"
    do
	echo "${component}"
	"script${component}"
    done
    return 0
}

################################################################
# checkUsage function
################################################################
# checkUsage takes two integers representing the min and max no.
# of arguments the function should receive, the function name
# it was called from, and that functions' arguments. Special
# flags, such as -h, are checked for. Then, if the number of
# arguments is not within the bounds, usage is called.
################################################################

checkUsage() {
    min=${1} ; max=${2} ; checkPoint=${3}
    shift ; shift ; shift
    checkForSpecialFlags "${1}"
    if [ $# -lt ${min} -o $# -gt ${max} ]
    then
	echo ""
	echo "- Script failed at: ${checkPoint} ${*}"
	automaticUsage
    fi
    return 0
}

################################################################
# Throw Exception function
################################################################
# Calls checkUsage function with parameters that are guarenteed
# to fail. Hence, script failure will be reported, usage will be
# printed, CCM will be tidied up and the program will exit.
################################################################

throwException() {
    checkUsage 0 -1 ${*}
    return 0
}

################################################################
# CCM functions:
################################################################
# ccmDbIdMatches : does the database DCM id correspond to the path? (probably internal function)
# deliverySuffixes: return a list of reg exps identifying all our delivery projects
#   startCCM: start up the CCM engine.
# startCCMForProject: starts up CCM based on project name
# startCCMForRelease: starts up CCM based on project root and release 
# setRoleCCM: set role to given argument. (Saves current role)
# cleanUpCCM: resets a set role and stops a started CCM engine.
################################################################


# Takes two args - dcm id, and database path
# returns 1 if the dcm id corresponds to the path, 0 otherwise
# NB This function could be modified to echo the correctPath, in otherwise
# return the path for a particular id
#ccmDbIdMatchesPath()
#{
#	databaseId=$1
#	databasePath=$2

	# to be safe, make sure that path ends in '/'
#	echo $databasePath | grep '/$' > /dev/null
#	if [ $? -ne  0 ]
#	then
#		databasePath="${databasePath}/"
#	fi


#	case $databaseId in

#	CB1)
#		correctPath='/ccm/prd/'
#		;;
#	*)
#		databaseNum=`echo $databaseId | tr '[A-Z]' '[a-z]'`
#		correctPath="/ccm/$databaseNum/"
#		;;

#	esac

	# COULD DO echo $correctPath, if we wanted to enhance the functionality

#	if [ $databasePath = $correctPath ]
#	then
#		return 1
#	else
#		return 0
#	fi
#}

# WaitStartCCM
#
# Start CCM using startCCM, retrying if it fails
#
# args 1: database pathname
#      2: number of retries before giving up - default 0 if not given
#      3: seconds to wait between retries - default 300 (10 mins) if not given
#
#
#waitStartCCM()
#{
#	dbPath=$1
#	retries=$2
#	sleep=$3

#	if [ ! -d ${dbPath} ]
#	then
#		return 2
#	fi

#	if [ ${retries:=0} -lt 0 ]
#	then
#		retries=0
#	fi 

#	if [ ${sleep:=300} -lt 0 ]
#	then
#		sleep=300
#	fi 

#	try=0

#	while [ 1 ]
#	do
#		startCCM $dbPath
#		if [ $? -eq 0 ]
#		then
#			return $?
#		fi

#		if [ $try -eq $retries ]
#		then
#			return 1
#		fi
#		try=`expr $try + 1`
#		echo Sleeping for $sleep seconds ...
#		sleep $sleep
#	done
#}

# Takes optional argument, database path
# Takes second optional argument - password (needed for Windows only)
# Looks for an existing ccm session, if found and no arg specified
# then uses existing ccm session
# If found, and arg specified, then verifies that the current database dcm id
# corresponds to the path specified
# Otherwise, starts a new session
# Currently only recognises existing sessions on /ccm/prd and /ccm/cb2
startCCM() {
   
    dbpath='/ccm/prd'               # default database path, if no arg specified
#    dbid=`ccm query -t admin -n dcm -u -f "%db_id" 2>/dev/null`
 #   notRunningCCM=$?

  #  needToStartCCM=0
   # pwStr=''
    #if [ $notRunningCCM -ne 0 ]
    #then
     #   needToStartCCM=1
    #fi

    if [ $1 ]                    # optional arg
    then
	dbpath=$1

	# if we have an existing session, check it's the correct one
	# ie, does the database id match with what we expect?

	if [ $notRunningCCM -eq 0 ]   # ie ccm is running
	then
	    ccmDbIdMatchesPath $dbid $dbpath
	    if [ $? -eq 0 ]
	    then
		echo Starting second ccm session on $dbpath
		needToStartCCM=1
	    fi
	fi

	# have we got second optional arg, password?
	if [ $2 ]
	then
	    pwStr="-pw $2"
	fi

    else
        # no argument is specified so, use existing session
        :
    fi    

    if [ $needToStartCCM -ne 0 ]
    then
	echo Starting CCM on $dbpath
    	CCM_ADDR=`ccm start -d $dbpath -m -q -nogui -r build_mgr $pwStr`
	ccmStat=$?
	if [ $ccmStat -eq 0 ]
	then
	    export CCM_ADDR
	    startedCCM="Started CCM"
	    echo ${startedCCM} on $dbpath with addr ${CCM_ADDR}
	else
	    echo Failed to start CCM
	fi
	return $ccmStat
    else
    	dbid=`echo ${dbid}`
    	echo "Using existing [${dbid}] session [${CCM_ADDR}]"
	return 0
    fi
}

# This function is called for a DELIVERY PROJECT only ********
# and determines which CCM database to use. Default is cb2, and prd for patches
# You can override this with an entry in releases_for_cb2
# two args, projectroot , eg GENEVA, TAP3 etc
# release number, eg 5.2.2
# optional 3rd arg password (windows only)
# assumes F: is mapped to /irb/bce on Windows
# the config file
startCCMForRelease()
{
    if [ $WINDIR ] 
    then
	releasesFile='F:/admin/config/releases_for_cb2'
    else
	releasesFile=${BCE_ADMIN}/config/releases_for_cb2
    fi

    pw=''
    if [ $3 ]
    then
	pw=$3
    fi

    searchFor="$1-$2"              # eg GENEVA-5.2.2

    result=`grep "^$searchFor " $releasesFile`
    if [ $? -eq 0 ]
    then
	ccmPath=`echo $result | cut -d' ' -f2`
    else
	# if this is a GENEVA patch release  (a.b.c.d) default is prd, otherwise cb2
	am_i_a_patch $2
	if [ $? -eq 0 ]
	then
        # PATCH project NOT always in prd database check for 5.3IN patches
		echo $2 | grep '[0-9]*\.[0-9]IN\.' > /dev/null
		if [ $? -eq 0 ]
		then
			ccmPath='/ccm/cb2'         # default for a delivery project is cb2
		else
			ccmPath='/ccm/prd'
		fi
	else
	    ccmPath='/ccm/cb2'         # default for a delivery project is cb2
	fi
    fi

    startCCM $ccmPath $pw
    return $?

}

# return a list of regular expressions, for identifying all our delivery projects
deliverySuffixes()
{
    echo INSTALL MAINT PATCH TEST LANG LANG_... DOC DOC_... SDK LBK BO

}

what_suffix ()
{
	suffix_search=$1
	foundSuffix=1
	for i in `deliverySuffixes`
	do
		suffix=`echo $suffix_search | sed -e "s/.*\($i\)$/\1/"`
		if [ $suffix != $suffix_search ]
		then
			foundSuffix=0
			echo $suffix
			break
		fi
	done
	return $foundSuffix
}
# takes one argument, eg GENEVAINSTALL-sqa5.2.2.xxx and will decide to start
# CCM based on the project type and release bit
# optional second arg password (Windows only)
# Designed mainly for install/delivery projects, however should identify DOC
# projects for example by their suffix. If it can't identify a suffix, assumes
# /ccm/prd
# If it identifies it as a delivery project, goes to the file releases_for_cb2
# under /irb/bce/admin/config
startCCMForProject()
{
    fullProject=$1
    ccmPw=''
    if [ $2 ]                    # optional password
    then
	ccmPw=$2
    fi


    project=`echo $fullProject | cut -d- -f1`
    version=`echo $fullProject | cut -d- -f2`

    # attempt to determine the project suffix
    # known suffixes are INSTALL PATCH TEST LANG, LANG_XXX, DOC, DOC_XXX SDK LBK

    foundSuffix=0

    for i in `deliverySuffixes`
    do
	suffix=`echo $project | sed -e "s/.*\($i\)$/\1/"`
	if [ $suffix != $project ]
	then
	    foundSuffix=1
	    break
	fi
    done

    ccmDbPath=''
 
    
    if [ $foundSuffix -eq 1 ]
    then
	# is it a doc project?
	case $suffix in
	    DOC*)
		ccmDbPath='/ccm/prd'          # DOC project always in prd database 
		;;
	    PATCH*)
		am_i_a_patch $fullProject
		if [ $? -eq 0 ]
		then
	        # PATCH project NOT always in prd database check for 5.3IN patches
			echo $fullProject | grep '[0-9]*\.[0-9]IN\.' > /dev/null
			if [ $? -eq 0 ]
			then
				ccmPath='/ccm/cb2'         # default for a delivery project is cb2
			else
				ccmPath='/ccm/prd'
			fi
		fi
		;;
	esac
    else
	# we didnt find the suffix, so we need to start CCM on prd (ie a build project)
	ccmDbPath='/ccm/prd'                  # for build projects etc, always prd
    fi

    if [ $ccmDbPath ]
    then
	startCCM $ccmDbPath $ccmPw
    else
	# we need to look up the path in the temporary file used to decide which releases are in
	# cb2. For this we need the 'root' of the project name (eg GENEVA, TAP3 etc) and the release
	# bit from the version
	projectRoot=`echo $project | sed -e "s/\(.*\)$suffix/\1/"`

	# we just want the numbers after the sqa/test etc.
	projRelease=`echo $version | sed -e 's/[a-zA-Z][a-zA-Z]*//' | sed -e s'/^\([0-9.][0-9.kmINTSc]*\).*/\1/'`
	projRelease=`echo $projRelease | sed -e 's/\.$//'`
	startCCMForRelease $projectRoot $projRelease $ccmPw
    fi
    return $?

}


# Set the role of the user to parameter 1. Remembers the old
# role the user has, and stoed it in $oldRoleCCM. This can
# be used to set the role back again at a later stage.
setRoleCCM() {
    oldRoleCCM=`ccm set role`
    if [ "${oldRoleCCM}" != "${1}" ]
    then
	echo "Setting role:"
    	ccm set role ${1} || throwException "setRoleCCM" ${*}
    	echo "`ccm set role`."
    	roleChangedCCM="yes"
    fi
    return 0
}

# If a CCM was started using any of the functions in this script, it will be
# stopped. First though sets the users role back to its original setting if 
# role was changed using function setRoleCCM.
cleanUpCCM() {
    if [ -n "${roleChangedCCM}" ]
    then
	echo "Resetting role:"
	ccm set role ${oldRoleCCM}
	echo "`ccm set role`."
    fi
    if [ -n "${startedCCM}" ]
    then
	ccm stop
    fi
    return 0
}

# This procedure will return the database where the code base resides for a given product
# Usage: discoverCcmProductDatabase <product>
# e.g. discoverCcmProductDatabase GPI
discoverCcmProductDatabase()
{
	product_cm_database=${BCE_ADMIN}/config/product_cm_database

	product=$1

	product_database=`grep "^${product}," $product_cm_database`
	exist_in_other_db=$?

	if [ $exist_in_other_db -eq 0 ]
	then
		cut_database=`echo $product_database | cut -d',' -f2`
	else
		cut_database=`grep "^default," $product_cm_database | cut -d',' -f2`
	fi

	CCM_DATABASE="/ccm/$cut_database"

	echo $CCM_DATABASE
}

################################################################
# Get Geneva Major Releases function:
################################################################
# Returns a space separated list of Geneva Major Releases:
################################################################

getGenevaMajorReleases() {
    echo "3.2 4.0 4.1 4.2 5.0 5.1 5.2"
    return 0
}

################################################################
# Get User name function
################################################################
# Uses a combination of $LOGNAME, then $USER then whoami in an
# attempt to return an appropriate user name:
################################################################

getUser() {
    echo ${LOGNAME:-${USER:-`whoami`}}
    return 0
}

#discover_wa()
#{
#	projecttobuildlc=`echo $1 | tr "[a-z]" "[A-Z]"`
#	ccm_project=$2
#	majorversion=$3
#
#	case $PROJECT_ARENA in
#		GEN|DEF)
#			echo "/prdbuild/$majorversion/${ccm_project}"
#			;;
#		AC|SOL)
#			echo "/prdbuild/sol/${projecttobuildlc}/${ccm_project}"
#			;;
#		WEB)
#			echo "/prdbuild/web/${projecttobuildlc}/${ccm_project}"
#			;;
#		PFCORE)
#			echo "/prdbuild/IRB/$majorversion/${ccm_project}"
#			;;
#		*)
#			echo "Error: discover_wa: Unknown PROJECT_ARENA $PROJECT_ARENA"
#			return 1
#			;;
#	esac
#	return 0
#}

discover_wa_ccm()
{
	ccm_project=$1
	
	wa=`ccm wa -show -p $ccm_project|tail -1|cut -d"'" -f2`
	if [ -z "$wa" -o "$ccm_project" = "$wa" ]
	then
		return 1
	fi
	echo $wa

	return 0
}

find_depend_project ()
{
	pri_project=$1
	cat ${BCE_ADMIN}/config/projects_i_depend | grep -v '#' | grep "^${pri_project}," | cut -d, -f2- | sed -e 's/	//g' | tr ',' ' '
	return 0
}

find_depend_project_version ()
{
	sec_project=$1
	wa=$2
	place_to_find_info=$3
	pri_project=$4
	pri_release=$5
	releasesToBuildFile=$6

	wa="$wa/"`basename $wa | cut -d'-' -f1`

	if [ -z "$place_to_find_info" ]
	then
		echo "Error: Failed to find $project in file compatibility"
		return 1
	fi

	# Look in the default releases_to_build_autogen file if no override is specified
	if [ -z "$releasesToBuildFile" ]
	then
		releasesToBuildFile=${BCE_ADMIN}/releases_to_build_autogen
	else
		releasesToBuildFile=`echo ${BCE_ADMIN}/${releasesToBuildFile}`
	fi

	case $place_to_find_info in
		release_to_build)
			my_project=`cat ${releasesToBuildFile} | egrep -v "(^$|^#)" | tr ' ' - | grep "$pri_project\-$pri_release"`
			sec_release=`echo $my_project | cut -d_ -f2 | cut -d: -f1 | cut -d- -f2`
			echo "$sec_release"
			;;
		MAIN_PROJECT_WA/build/env.sh)
			place_to_find_info=`echo $place_to_find_info | sed -e "s|MAIN_PROJECT_WA|$wa|g"`
			SHARED_MINOR_VERSION=`grep "^SHARED_MINOR_VERSION=" $place_to_find_info | cut -d'=' -f2`
			SHARED_MAJOR_VERSION=`grep "^SHARED_MAJOR_VERSION=" $place_to_find_info | cut -d'=' -f2`
			echo "$SHARED_MAJOR_VERSION.$SHARED_MINOR_VERSION"
			;;
		*)
			echo "Error: Failed to find dependant project version file"
			return 1
			;;
	esac
	return 0
}

which_change_control()
{
    project=$1

    default_ccm_tool=`grep default ${BCE_ADMIN}/config/change_control_tool | grep -v '#' | awk '{print $2}'`

    override_ccm_tool=`grep "^$project," ${BCE_ADMIN}/config/change_control_tool | grep -v '#' | awk '{print $2}'`

    ccm_tool=${override_ccm_tool:-${default_ccm_tool}}

    echo $ccm_tool

    return 0
}

################################################################
# Reconfigure Wait Function
################################################################
# We wait for a reconfigure flag to appear for a given time out.
################################################################

reconfigureWait() {
    # Checking that the reconfigure has finished. $1=Project, $2=Timeout.
    logFlag="${LOGDIR}/svn-update-$1"
    count=0
    while [ ! -f "${logFlag}-PASSED" -a ! -f "${logFlag}-FAILED" -a ${count} -lt $2 ]
    do
	count=`expr ${count} + 1`
	echo "Waiting for project reconfigure to complete: ${logFlag}"
	echo "Else waiting for $2 times 30 seconds before moving to next project."
	echo "${count}"
	sleep 30
    done
    if [ -f "${logFlag}-PASSED" ]
    then
	echo "Reconfigure is a pass."
	rm -f  "${logFlag}-PASSED"
	return 0
    elif [ -f "${logFlag}-FAILED" ]
    then
	echo "Reconfigure Failed."
	return 1
    else
	echo "Reconfigure timed out."
	return 2
    fi
    return 0
}

################################################################
# Check whether release tag is for a patch function
################################################################
# Pass in a release tag or full project name and voila it tells
# you whether its a patch
################################################################
#
# Return 0 if a patch
# Return 1 if not a patch
#
################################################################

am_i_a_patch ()
{
	tag_to_check=$1
	echo ${tag_to_check} | grep '[0-9]*\.[0-9]*[A-Z]*\.[0-9|a-z]*\.[0-9]' > /dev/null
	if [ $? -eq 0 ]
	then
		return 0
	else
		return 1
	fi
}

################################################################
# Output text when in DEBUG mode
################################################################
# Pass in some text and if in DEBUG mode it will be output
################################################################
#
# No return values just exit gracefully
#
################################################################

script_debug ()
{
	message="$1"
	debug_on=$2
	if [ ! -z "${debug_on}" ]
	then
		echo "$message"
	fi
	return 0
}

################################################################
# Send an email based on parameters passed
################################################################
# Param 1 -  Filename/text to email [MANDATORY]
# Param 2 -  Recipient of email [MANDATORY]
# Param 3 -  Sender Alias [OPTIONAL]
################################################################
#
# Return 0 if OK
# Return 1 if NOK
#
################################################################

send_email ()
{
	# General initialisation
	contentToEmail=$1
	recipientEmail=$2
	senderAlias=$3
	itsAFile="False"
	
	# Output parameters if in DEBUG mode
	script_debug "Contents of email: ${contentToEmail}" ${debug_on}
	script_debug "Recipient: ${recipientEmail}" ${debug_on}
	script_debug "Sender Alias: ${senderAlias}" ${debug_on}
	
	# Sanity check the parameters
	if [ -f ${contentToEmail} ]
	then
		itsAFile="True"
	elif [ -z "${contentToEmail}" ]
	then
		return 1
	fi
	if [ -z "${recipientEmail}" ]
	then
		return 1
	fi
	
	# Put it all together
	if [ "${itsAFile}" = "True" ]
	then
		if [ ! -z "${senderAlias}" ]
		then
			/usr/lib/sendmail -F "${senderAlias}" ${recipientEmail} < ${contentToEmail}
		else
			/usr/lib/sendmail ${recipientEmail} < ${contentToEmail}
		fi
	else
		if [ ! -z "${senderAlias}" ]
		then
			echo ${contentToEmail} | /usr/lib/sendmail -F "${senderAlias}" ${recipientEmail}
		else
			echo ${contentToEmail} | /usr/lib/sendmail ${recipientEmail}
		fi
	fi
	return $?
}

################################################################
# Create a file of checksums
################################################################
# Mandatory Param 1 - Absolute path
# Mandatory Param 2 - File criteria
# Mandatory Param 3 - Output filename
# Mandatory Param 4 - Binary/Text mode switch for md5sum command
#	     binary - Windows platform
#	       text - Unix platform
# Optional  Param 5 - Debug mode
################################################################
#
# Return values
# 0 md5sum success
# 1 md5sum failure
# 50 md5sum not found in PATH
# 99 incorrect params
#
################################################################

generate_md5sum ()
{
	# Init section
	absolutePath="$1"
	fileString="$2"
	md5sumFile="$3"
	readMode="$4"
	debugOn="$5"
	
	echo
	script_debug "[DEBUG] generate_md5sum has been called" ${debugOn}

	# Validate mandatory params
	if [ -z "${absolutePath}" -o -z "${fileString}" -o -z "${md5sumFile}" ]
	then
		# These are mandatory parameters
		echo "[ERROR] Mandatory params were NOT passed in to the function [generate_md5sum]"
		return 99
	fi

	script_debug "[DEBUG] Mandatory params were passed in" ${debugOn}
	# Sanity test mandatory params
	if [ ! -d "${absolutePath}" ]
	then 
		# Invalid path for file locations
		echo "[ERROR] Absolute path to files incorrect [generate_md5sum]"
		return 99
	elif [ `ls ${absolutePath}/${fileString} 2>/dev/null | wc -w` -le 0 ]
	then
		# No valid files found
		echo "[ERROR] No files for checksum generation found [generate_md5sum]"
		return 99
	fi
	# Process optional params
	if [ "${readMode}" = "binary" ]
	then
		readMode="-b"
	elif [ "${readMode}" = "text" ]
	then
		readMode="-t"
	else
		readMode="-t"
	fi

	script_debug "[DEBUG] Sanity Test passed" ${debugOn}
	script_debug "[DEBUG] Path to files [${absolutePath}]" ${debugOn}
	script_debug "[DEBUG] Files to checksum [${fileString}]" ${debugOn}
	# Lets begin
	# Ensure md5sum binary available
	if [ `which md5sum | grep -c "no md5sum"` -gt 0 ]
	then 
		# md5sum support not found
		echo "[ERROR] md5sum support not found on `hostname`"
		return 50
	fi

	# Generate 128bit checksums
	# Change to directory so that the md5sumFile is forced to use a relative name structure
	# This will then handle when the ISO is removed from /gpuiso
	cd ${absolutePath}
	echo "[INFO] Generating checksums at [${absolutePath}/${md5sumFile}]"
	>${md5sumFile}
	script_debug "[DEBUG] Following command will now be generated [md5sum ${readMode} ${fileString} >> ${md5sumFile}]" ${debugOn}
	md5sum ${readMode} ${fileString} >> ${md5sumFile}
	md5sumStatus=$?
	if [ ${md5sumStatus} -eq 0 ]
	then
		echo "[INFO] Checksums generated successfully"
		cat ${md5sumFile}
	else
		echo "[ERROR] Checksums were not generated successfully"
	fi
	return ${md5sumStatus}
}

################################################################
# Verify file(s) using an MD5 checksum
################################################################
# Mandatory Param 1 - Directory location of the MD5 checksum
# Mandatory Param 2 - Directory location of the files to be checked
# Mandatory Param 3 - Release, e.g., 5.2.23
# Mandatory Param 4 - Project, e.g., DOC/MAINT
# Optional  Param 5 - Debug mode
################################################################
#
# Return values
# 0 md5sum success
# 1 md5sum failure
# 99 incorrect params
#
################################################################

verify_md5sum ()
{
# Look for an .md5 file in the directory where ISOs are copied from
# Run the md5sum binary using this file against the newly copied ISOs
        SOURCE_LOCATION=$1
        DEST_LOCATION=$2
        ISO_RELEASE=$3
	PROJ_TYPE=$4
	debugOn="$5"

	echo
	script_debug "[DEBUG] verify_md5sum has been called" ${debugOn}
	
	# Validate mandatory params
	if [ -z "${SOURCE_LOCATION}" -o -z "${DEST_LOCATION}" -o -z "${ISO_RELEASE}" -o -z "${PROJ_TYPE}" ]
	then
		# These are mandatory parameters
		echo "[ERROR] Mandatory params were NOT passed in to the function [verify_md5sum]"
		return 99
	fi

	script_debug "[DEBUG] Mandatory params were passed in" ${debugOn}

	# Sanity test mandatory params
	if [ ! -d "${SOURCE_LOCATION}" ]
	then 
		# Invalid path for file locations
		echo "[ERROR] Absolute path to checksum file does not exist [verify_md5sum]"
		return 99
	elif [ ! -d "${DEST_LOCATION}" ]
	then
		# No valid files found
		echo "[ERROR] No files for checksum verification found [verify_md5sum]"
		return 99
	elif [ -z "${ISO_RELEASE}" ]
	then
		# No release specified
		echo "[ERROR] No release specified [verify_md5sum]"
		return 99
	elif [ -z "${PROJ_TYPE}" ]
	then
		# No project specified
		echo "[ERROR] No project type specified [verify_md5sum]"
		return 99
	fi

	script_debug "[DEBUG] Sanity Test passed" ${debugOn}
	script_debug "[DEBUG] Path to checksum file [${SOURCE_LOCATION}]" ${debugOn}
	script_debug "[DEBUG] Path to files for verification [${DEST_LOCATION}]" ${debugOn}
	script_debug "[DEBUG] Release to check [${ISO_RELEASE}]" ${debugOn}
	script_debug "[DEBUG] Project type [${PROJ_TYPE}]" ${debugOn}

	# Lets begin
	script_debug "[DEBUG] Searching for [${SOURCE_LOCATION}/*${PROJ_TYPE}*${ISO_RELEASE}*.md5]" ${debugOn}
        MD5_FILE=`ls ${SOURCE_LOCATION}/*${PROJ_TYPE}*${ISO_RELEASE}*.md5 2>/dev/null`
	echo "Found: [${MD5_FILE}]"
        if [ ! -z "${MD5_FILE}" ]
        then
		for MD5 in ${MD5_FILE}
		do
		        echo "[INFO] Verifying ISO images for ${ISO_RELEASE} with checksum file [${MD5}]"
	                if [ -f ${MD5} ]
        	        then
                	# We have checksums continue
                        	old_PWD=`pwd`
	                        cd ${DEST_LOCATION}
        	                md5sum -c ${MD5}
                	        md5Status=$?
                        	cd ${old_PWD}
	                        if [ ${md5Status} -eq 0 ]
        	                then
                	                echo "[INFO] ISO images are valid"
	                        else
        	                        echo "[ERROR] ISO images are invalid"
	                        fi
        	        else
                	        echo "[ERROR] The file [${MD5}] was not found"
                        	return 1
	                fi
		done
        else
                echo "[ERROR] No [${MD5_FILE}] file found"
                return 1
        fi
	return ${md5Status}	
}

get_nice_username ()
{
	login_username=$1
	if [ "$login_username" = genadmin ]
	then
		echo "Error: You cannot enter $login_username as your username, please choose your actual username"
		echo "       e.g. nickc for Nick Chastney or sfp for Scott Pritchard"
		return 1
	fi

	users_name=`finger $login_username | grep "In real life" | grep "Login name: $login_username " | head -1 | cut -d: -f3 | sed -e 's/^ //'`
	if [ "$users_name" = '???' ]
	then
		echo "Error: Username: $login_username Unrecognised, please go away and come back again another day."
		return 1
	fi
	echo $users_name
	return 0
}

find_sqlhome ()
{
#	ideal_sql should be a number in the format as normally found in /opt/oracle, eg. 9.2.0.SE
	ideal_sql=$1

	valid_oracle=""
	oracle_homes="/opt/oracle"

	if [ `hostname` = "carnival" ]
	then
		ideal_sql=`echo $ideal_sql | cut -d'.' -f1-3`
		valid_oracle="/apps/oracle-$ideal_sql"
		oracle_homes=""
	elif [ `hostname` = "cognac" ]
	then
		ideal_sql=10.2.0
		valid_oracle="/apps/oracle-$ideal_sql"
		oracle_homes=""
	fi

	if [ ! -z "$ideal_sql" ]
	then
		if [ -d "$oracle_homes/$ideal_sql" ]
		then
			valid_oracle=$oracle_homes/$ideal_sql
		fi
	fi

	if [ -z "$valid_oracle" ]
	then
		for a_potential_oracle_home in $oracle_homes
		do
			if [ -d "$a_potential_oracle_home" ]
			then
				for am_i_valid_oracle in `ls -r $a_potential_oracle_home`
				do
					if [ ! -z "$valid_oracle" ]
					then
						break
					fi
	
					am_i_valid_oracle="$oracle_homes/${am_i_valid_oracle}"
					if [ -f "${am_i_valid_oracle}/bin/sqlplus" ]
					then
						valid_oracle=$am_i_valid_oracle
					fi
				done
			fi
			
		done
	fi

	if [ ! -f "${valid_oracle}/bin/sqlplus" ]
	then
		#echo "Error: Cannot find a suitable oracle version in $oracle_homes"
		return 1
	fi

	ORACLE_HOME=$valid_oracle
	echo $LD_LIBRARY_PATH | grep $valid_oracle > /dev/null
	if [ $? -ne 0 ]
	then
		PATH=$ORACLE_HOME/bin:$PATH
		LD_LIBRARY_PATH=$ORACLE_HOME/lib:$LD_LIBRARY_PATH
		SHLIB_PATH=$LD_LIBRARY_PATH
		LIBPATH=$LD_LIBRARY_PATH
	fi

	export ORACLE_HOME PATH LD_LIBRARY_PATH SHLIB_PATH LIBPATH
	return 0
}

check_username ()
{
	Username=$1
	if [ -z "$Username" ]
	then
		echo "Error: You must enter your username"
		exit 1
	fi
	if [ "$Username" = genadmin ]
	then
		echo "Error: You cannot enter $Username as your username, please choose your actual username"
		echo "       e.g. nickc for Nick Chastney or sfp for Scott Pritchard"
		exit 1
	fi

	real_username=`finger $Username | grep "In real life" | grep "Login name: $Username " | head -1 | cut -d: -f3 | sed -e 's/^ //'`
	if [ "$real_username" = '???' ]
	then
		echo "Error: Username: $Username Unrecognised, please go away and come back again another day."
		exit 1
	fi
	export real_username
}

setup_rsh_command ()
{
	if [ -z "$1" -o -z "$2" ]
	then
		echo "Must enter the machine and username you wish to connect too."
		return 1
	fi

	mach=$1
	username=$2

	case $PLATFORM in
		HP-UX-64|HP-UX-IA64)
			rsh_command="remsh ${mach} -n -l $username "
			;;
		aix)
			rsh_command="rsh ${mach} -n -l $username "
			;;
		*)
			rsh_command="rsh -n -l $username ${mach} "
			;;
	esac

	echo $rsh_command
	return 0
}

get_month_number ()
{
	month=$1
	case $month in
		Jan*)
			no_month=01
			;;
		Feb*)
			no_month=02
			;;
		Mar*)
			no_month=03
			;;
		Apr*)
			no_month=04
			;;
		May*)
			no_month=05
			;;
		Jun*)
			no_month=06
			;;
		Jul*)
			no_month=07
			;;
		Aug*)
			no_month=08
			;;
		Sep*)
			no_month=09
			;;
		Oct*)
			no_month=10
			;;
		Nov*)
			no_month=11
			;;
		Dec*)
			no_month=12
			;;
		*)
			echo "No idea what month $month is"
			return 1
			;;
	esac

	echo $no_month
	return 0
}

################################################################
# write_out
################################################################
# This function writes out messages to screen and to a log.
# On screen, it writes messages green for success, red for
# errors or yellow for warnings, for easy reading.
# To log, it writes without the colour specifications.
# 
# write_out <string to output> <type of message> <log to write>
#  e.g. write_out "This is an error" error /tmp/123.log
################################################################
write_out ()
{
	string_to_write=$1
	color_to_use=$2
	log_to_write=$3

	case $color_to_use in
		success)
			# Green
			color="\033[1;32m"
			;;
		error)
			# Red
			color="\033[1;31m"
			;;
		warning)
			# Yellow
			color="\033[43m\033[1;34m"
			;;
		normal)
			# Default colors
			color="\033[0m"
			;;
		*)
			# Unrecognized option
			echo "ERROR: unrecognized option to write_out()"
			exit
			;;
	esac

	command=`echo $color $string_to_write "\033[0m" | sed "s/ //"`
	echo -e $command 	# with -e, interpretation of the backslash color commands is turned on
	echo $string_to_write >> $log_to_write
}

################################################################
# rel_compare
################################################################
# This function takes 2 release versions as parameters, compares
# them and returns:
#	0	If first earlier than second
# 	1	If first later than second
#	2	If first and second match
#
# NOTE: This function should be used only by tag_compare. If you
# need to compare releases, use tag_compare as that also does
# RB and GEN checks.
# This function also expects that both tags are from the same
# project. e.g. RB and RB, GENEVA and GENEVA, TAP and TAP
################################################################
rel_compare()
{
	first=$1
	second=$2

	# First version number
	first_first=`echo $first | cut -d. -f1`
	first_second=`echo $first | cut -d. -f2`
	first_third=`echo $first | cut -d. -f3`
	first_fourth=`echo $first | cut -d. -f4`

	if [ -z "$first_fourth" ]
	then
		first_fourth=0
	fi
	# If this is an ACPD release, treat it like the base release
	#	e.g. 5.4.22.c1 should be treated like 5.4.22
	echo $first_fourth | grep "^c" > /dev/null
	if [ $? = 0 ]
	then
		first_fourth=0
	fi

	# Second version number
	second_first=`echo $second | cut -d. -f1`
	second_second=`echo $second | cut -d. -f2`
	second_third=`echo $second | cut -d. -f3`
	second_fourth=`echo $second | cut -d. -f4`
	if [ -z "$second_fourth" ]
	then
		second_fourth=0
	fi
	# If this is an ACPD release, treat it like the base release
	#	e.g. 5.4.22.c1 should be treated like 5.4.22
	echo $second_fourth | grep "^c" > /dev/null
	if [ $? = 0 ]
	then
		second_fourth=0
	fi

	if [ -z "$first_third" -o -z "$second_third" ]
	then
		echo "ERROR: Illegal compare $first $second"
		exit
	fi

	compare_rest=0

	# Do the comparison, number by number, from the major number to the minor
	if [ "$first" = "$second" ]
	then
		echo 2
	else
		# If any of the tags are 5.3IN tags, then we need to do a different comparison to just
		# integer comparisons
		first_is_IN=1
		second_is_IN=1
		echo $first | grep '^5.3IN' > /dev/null
		first_is_IN=$?
		echo $second | grep '^5.3IN' > /dev/null
		second_is_IN=$?
	
		if [ "$first_is_IN" = "0" -o "$second_is_IN" = "0" ]
		then
			if [ "$first_is_IN" = "0" ]
			then
				echo $second | grep '^5.4' > /dev/null
				if [ "$?" = "0" ]
				then
					echo 0
				else
					if [ "$second_is_IN" = "0" ]
					then
						compare_rest=1
					else
						echo 1
					fi
				fi
			else
				if [ "$second_is_IN" = "0" ]
				then
					echo $first | grep '^5.4' > /dev/null
					if [ "$?" = "0" ]
					then
						echo 1
					else
						if [ "$first_is_IN" = "0" ]
						then
							compare_rest=1
						else
							echo 0
						fi
					fi
				fi
			fi

			# Now, if they are both 5.3IN, do the comparisons on the third and fourth numbers
			if [ "$compare_rest" = "1" ]
			then
				if [ $first_third -gt $second_third ]
				then
					echo 1
				elif [ $second_third -gt $first_third ]
				then
					echo 0
				else
					if [ $first_fourth -gt $second_fourth ]
					then
						echo 1
					elif [ $second_fourth -gt $first_fourth ]
					then
						echo 0
					else
						echo 2
					fi
				fi
			fi
		else
			if [ $first_first -gt $second_first ]
			then
				echo 1
			elif [ $second_first -gt $first_first ]
			then
				echo 0
			else
				if [ $first_second -gt $second_second ]
				then
					echo 1
				elif [ $second_second -gt $first_second ]
				then
					echo 0
				else
					if [ $first_third -gt $second_third ]
					then
						echo 1
					elif [ $second_third -gt $first_third ]
					then
						echo 0
					else
						if [ $first_fourth -gt $second_fourth ]
						then
							echo 1
						elif [ $second_fourth -gt $first_fourth ]
						then
							echo 0
						else
							echo 2
						fi
					fi
				fi
			fi
		fi
	fi
}


################################################################
# tag_compare
################################################################
# This function takes 2 release_tags as parameters and then
# compares them to check if the first is later than the second.
# e.g. 5.4.16 is later than 5.4.15
#      5.4.16.3 is later than 5.4.16.1
#
# Returns:
#	0	If first is earlier than second
#	1	If first is later than second
#	2	If first and second match
################################################################
tag_compare()
{
	first_tag=$1
	second_tag=$2

	first_proj=`echo $first_tag | cut -d_ -f1`
	first_version=`echo $first_tag | cut -d_ -f2`
	second_proj=`echo $second_tag | cut -d_ -f1`
	second_version=`echo $second_tag | cut -d_ -f2`

	valid_proj=0

	if [ "$first_tag" = "$second_tag" ]
	then
		echo 2
	else
		# Check for valid projects. They're valid only if they're the same, or if they are one of either
		# GEN or RB (for doing GEN and RB comparisons). Continue only if the projects are valid for comparison.
		if [ "$first_proj" = "$second_proj" ]
		then
			valid_proj=1
		elif [ "$first_proj" = "GEN" -o "$first_proj" = "RB" ]
		then
			if [ "$second_proj" = "GEN" -o "$second_proj" = "RB" ]
			then
				valid_proj=1
			fi
		fi
	
		if [ "$valid_proj" = "1" ]
		then
			if [ "$first_proj" = "GEN" ]
			then
				if [ "$second_proj" = "GEN" ]
				then
					rel_compare $first_version $second_version
				else
					# Convert second tag to GEN if this is an RB 2.2 tag
					echo $second_tag | grep '^RB_2.2' > /dev/null
					if [ $? = 0 ]
					then
						second_tag=`echo $second_tag | sed "s/^RB_2.2/GEN_5.4/g"`
						second_proj=`echo $second_tag | cut -d_ -f1`
						second_version=`echo $second_tag | cut -d_ -f2`
					fi
					if [ "$first_proj" = "$second_proj" ]
					then
						rel_compare $first_version $second_version
					else
						# Second = Unconvertable RB tag and First = GEN
						echo 0
					fi
				fi
			elif [ "$first_proj" = "RB" ]
			then
				if [ "$second_proj" = "RB" ]
				then
					rel_compare $first_version $second_version
				else
					# Convert second tag to RB if this is a GEN 5.4 tag
					echo $second_tag | grep '^GEN_5.4' > /dev/null
					if [ $? = 0 ]
					then
						second_tag=`echo $second_tag | sed "s/^GEN_5.4/RB_2.2/g"`
						second_proj=`echo $second_tag | cut -d_ -f1`
						second_version=`echo $second_tag | cut -d_ -f2`
					fi
					if [ "$first_proj" = "$second_proj" ]
					then
						rel_compare $first_version $second_version
					else
						# Second = Unconvertable GEN tag and First = RB
						echo 1
					fi
				fi
			else
				rel_compare $first_version $second_version
			fi
		else
			echo "ERROR: Release tags $first_tag and $second_tag cannot be compared"
			exit
		fi
	fi
}
