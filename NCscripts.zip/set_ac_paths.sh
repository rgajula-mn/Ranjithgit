#!/bin/ksh

. ccm_functions_svn.sh

if [ $# -ne 7 ]; then
  echo "$0 <state> <solution version> <core reltag> <database> <oracle version> <steve version> <project>"
  echo "e.g. $0 sqa 4.3.6 GEN_5.4.22 COB3 10.2.0.SE 1.3 GPI"
  exit 1
fi


export THE_STATE=${1}
export THE_PLATFORM=`/usr/local/bin/platform`
export THE_PROJECT=$7

echo $0 $1 $2 $3 $4 $5 $6 $7

echo ${THE_PLATFORM}

if [ -z "$build_scripts" ]
then
	build_scripts=/irb/bce/admin/build_scripts
fi

if test ${THE_PROJECT} = TAP
then
	export THE_PROJECT=TAP3
fi

export SMALL_PROJECT=`echo $THE_PROJECT | tr '[A-Z]' '[a-z]'`

if test ${THE_PLATFORM} = HP-UX-64
then
        export THE_PLATFORM=hp64
elif test ${THE_PLATFORM} = alpha
then
        export THE_PLATFORM=tru64
elif [ $THE_PLATFORM = HP-UX-IA64 ]
then
    THE_PLATFORM=itanium
fi

if test ${THE_PLATFORM} = RHEL4-EM64T
then
        export THE_PLATFORM=linux
fi
if test ${THE_PLATFORM} = RHEL5-EM64T
then
        export THE_PLATFORM=linux
fi
if test ${THE_PLATFORM} = RHEL6-EM64T
then
        export THE_PLATFORM=linux
fi
if test ${THE_PLATFORM} = RHEL7-EM64T
then
        export THE_PLATFORM=linux
fi
if test ${THE_PLATFORM} = SLE11-EM64T

then
        export THE_PLATFORM=suselinux
fi

if [ "$THE_PLATFORM" = "hp64" -o  "$THE_PLATFORM" = "itanium" ]
then
    export MAKE_CMD=gmake
else
    export MAKE_CMD=make
fi

export THE_VERSION=${2}
export THE_CORERELTAG=${3}
THE_COREPROJECT=`echo $THE_CORERELTAG | cut -d'_' -f1`

if [ "$THE_COREPROJECT" = "GEN" ]
then
	THE_COREPROJECT="GENEVA"
fi
export THE_COREPROJECT
export SMALL_COREPROJECT=`echo $THE_COREPROJECT | tr '[A-Z]' '[a-z]'`
export THE_COREVERSION=`echo $THE_CORERELTAG | cut -d'_' -f2`
export THE_COREVERSIONU=`echo ${THE_COREVERSION} | sed -e "s/\./_/g"`
export THE_DB=${4}
export THE_DB_VERSION=${5}
export STEVE_VERSION=${6}
export GENEVA_MAJOR=`echo $THE_COREVERSION | cut -d'.' -f1-2`
export MAJORRELEASE=$GENEVA_MAJOR
export SOL_MAJOR=`echo $THE_VERSION | cut -d'.' -f1-2`


export ORACLE_HOME=/opt/oracle/${THE_DB_VERSION}
export PATH=${ORACLE_HOME}/bin:${PATH}
if [ "${THE_DB_VERSION}" = "8.1.7.SE" -o "${THE_DB_VERSION}" = "8.1.6" -o "${THE_DB_VERSION}" = "8.1.7" -o "${THE_DB_VERSION}" = "8.1.7.64bit" ]
then
	export DATABASE_VER_NAME=oracle8i
elif [ "${THE_DB_VERSION}" = "9.0.1.SE" ]
then
	export DATABASE_VER_NAME=oracle9i
elif  [ "${THE_DB_VERSION}" = "9.2.0.SE" ]
then
	export DATABASE_VER_NAME=oracle9i2
elif [ "${THE_DB_VERSION}" = "10.1.0.SE" -o "${THE_DB_VERSION}" = "10.2.0.SE" -o "${THE_DB_VERSION}" = "10.2.0.3.SE" -o "${THE_DB_VERSION}" = "10.2.0.4.SE"   ]
then
	export DATABASE_VER_NAME=oracle10g
elif [ "${THE_DB_VERSION}" = "11.1.0.7.SE" -o "${THE_DB_VERSION}" = "11.2.0.1.SE"  -o "${THE_DB_VERSION}" = "11.2.0.3.SE" ]
then
	export DATABASE_VER_NAME=oracle11g
elif [ "${THE_DB_VERSION}" = "12.1.0.1.SE" ]
then
        export DATABASE_VER_NAME=oracle12c
elif [ "${THE_DB_VERSION}" = "12.1.0.2.SE" ]
then
        export DATABASE_VER_NAME=oracle12c

fi

PLATFORM_NAME=${THE_PLATFORM}.${DATABASE_VER_NAME}
get_platform_from_platform_name

export THE_DB_USER=${SMALL_PROJECT}${THE_STATE}${THE_COREVERSIONU}${PLATFORM_ID}
echo $DATABASE_VER_NAME

export oracle="$DATABASE_VER_NAME"
export majorrelease="$GENEVA_MAJOR"

echo oracle = $oracle
echo majorrelease = $majorrelease


core_proj=`echo $3 | cut -d'_' -f1`
core_release=`echo $3 | cut -d'_' -f2`

. ${build_scripts}/setup_bc_env ${core_release} ${core_proj}

if [ "${THE_PROJECT}" = "GPI" ]
then
	setmybce ${THE_PROJECT} ${THE_VERSION} sdk $oracle $PLATFORM $THE_COREPROJECT $majorrelease
else 
	setmybce $THE_COREPROJECT ${THE_COREVERSION} sdk $oracle $PLATFORM
fi

error_status=$?
if [ $error_status -ne 0 ]
then
	echo "Error $error_status reported from setup_oracle_env:setmyoracle"
	exit 1
fi

export SOLARIS_USE_GNU=F

if [ $DATABASE_VER_NAME = oracle9i -o $DATABASE_VER_NAME = oracle9i2 -o $DATABASE_VER_NAME = oracle10g -o $DATABASE_VER_NAME = oracle11g -o $DATABASE_VER_NAME = oracle12c  ]
then
    export ORACLE_VERSION=`echo $DATABASE_VER_NAME | sed -e 's/oracle//'`
elif [ $THE_COREPROJECT = "GENEVA" ]
then
	if [ $majorrelease = "5.1" -o $majorrelease = "5.2" ]
	then
    		export ORACLE_VERSION=8i
	else
    		export SOLARIS_USE_GNU=T
		export ORACLE_VERSION=8i
	fi
else
    export SOLARIS_USE_GNU=T
    export ORACLE_VERSION=8i
fi

export OPT_BUILD=F
first_letter_platform=`echo $THE_PLATFORM | cut -c1`

export PROJ=${THE_PROJECT}-${THE_STATE}${THE_VERSION}.${THE_PLATFORM}.${DATABASE_VER_NAME}
export ORACLE_SID="${THE_DB}.world"
export RUN_SQL_DB=${THE_DB_USER}/${THE_DB_USER}@${THE_DB}.world
export CCM_ROOT=/irb/bce/build/${SMALL_PROJECT}/${SOL_MAJOR}/CORE-${SMALL_PROJECT}${THE_COREVERSION}.${THE_PLATFORM}.${DATABASE_VER_NAME}
export CORE=${CCM_ROOT}/CORE
export VPACORE=`echo $CORE |  sed -e 's/CORE/VPACORE/g'`
export TOOL=$CORE/TOOL
export STEVE=$CCM_ROOT/${THE_PROJECT}/STEVE${STEVE_VERSION}/source
export LOGDIR=/irb/bce/admin/log/sol/${SMALL_PROJECT}

if [ "${THE_PROJECT}" != "PFCORE" ]
then
    export DATABASE=${THE_DB_USER}/${THE_DB_USER}@${THE_DB}.world
fi

if test ! -d ${LOGDIR}
then
    mkdir $LOGDIR
fi

export DATTIM=`date '+%y%m%d%H%M%S'`
export DAT=`date '+%Y%m%d'`

# Adding support for building RB extensions
if [ "$THE_COREPROJECT" = "RB" ]
then
	export RELEASE_DIR=/irb/release/rb/${GENEVA_MAJOR}-FULL/RB-${THE_COREVERSION}${PLATFORM_INF_ID}
elif [ "$THE_COREPROJECT" = "GENEVA" -a "$GENEVA_MAJOR" = "5.4" ]
then
	THE_COREVERSION_54to22=`echo $THE_COREVERSION | sed -e 's/5.4/2.2/'`
	export RELEASE_DIR=/irb/release/rb/2.2-FULL/RB-${THE_COREVERSION_54to22}${PLATFORM_INF_ID}
else
	export RELEASE_DIR=/irb/release/geneva/${GENEVA_MAJOR}-FULL/geneva-${THE_COREVERSION}.${first_letter_platform}${ORACLE_VERSION}
fi

export GENEVA_ROOT=/irb/bce/build/${SMALL_COREPROJECT}/${GENEVA_MAJOR}/${THE_COREPROJECT}-sqa${THE_COREVERSION}.${THE_PLATFORM}.${DATABASE_VER_NAME}

# Is the core project GENEVA 5.3 or later?
# choose a GENEVA project in prdbuild, based on majorrelease. Find the oldest GENEVA project,
# so it will not be in the process of being checked out. Assumes that if we are building components
# we will have at least one Geneva project checked out
if [ "$THE_COREPROJECT" != "RB" ]
then
	if [ -d /irb/bce/build/geneva/${GENEVA_MAJOR} ]
	then
		firstGeneva=`ls -t  /irb/bce/build/geneva/${GENEVA_MAJOR} | grep GENEVA | tail -1`
		if [ -d /irb/bce/build/geneva/${GENEVA_MAJOR}/${firstGeneva}/GENEVA/SCHEMA ]
		then	    
			IS_5_3_OR_LATER=1 
		else
			unset VPACORE
			IS_5_3_OR_LATER=0              # 5.2 or earlier
		fi
	elif [ -d /irb/bce/build/rb/${GENEVA_MAJOR} ]
	then
		IS_5_3_OR_LATER=1
	else
		echo "Error: **** cannot find /irb/bce/build/geneva/${GENEVA_MAJOR}, unable to determine if Geneva 5.3 or later"
		IS_5_3_OR_LATER=2                   # don't know!
	fi
else
	IS_5_3_OR_LATER=1
fi

# is the core project GENEVA 5.4 or later? Basically look at CORE, if it doesn't
# have GDB then it is, and (currently while PFCORE exists) we will need to build PFCORE

export IS_5_4_OR_LATER=0
export IS_3_0_OR_LATER=0
export MESSC=$CORE

if [ -d  ${GENEVA_ROOT}/GENEVA/CORE ]
then
    if [ ! -d ${GENEVA_ROOT}/GENEVA/CORE/GDB ]
    then
	echo "${GENEVA_ROOT}/GENEVA/CORE/GDB doesnt exist so this is 5.4" | tee -a $BUILD_LOG
	export IS_5_4_OR_LATER=1
	export MESSC=${PF_HOME}
    else
	echo "${GENEVA_ROOT}/GENEVA/CORE/GDB does exist so this is pre 5.4" | tee -a $BUILD_LOG
    fi
fi

# is the core project RB 3.0 or later? Messc was moved to Platform for RB, so if it is RB,
# then need to set the MESSC path to PF_HOME.

export release_major_minor=`echo ${THE_COREVERSION} | sed -e "s/\([0-9]\)\(.\)\([0-9]\)\(.\)\([0-9]\)\(.*\)/\1\3\5/g"`

if [ "$THE_COREPROJECT" = "RB" ]
then
	echo "This is RB" | tee -a $BUILD_LOG
	IS_3_0_OR_LATER=1

	if  [ ${release_major_minor} -ge 422 ]
	then
		export SHLIB_PATH=$SHLIB_PATH:$CORE/lib:$VPACORE/lib
		export LIBPATH=$SHLIB_PATH
		export LD_LIBRARY_PATH=$SHLIB_PATH
		echo "[INFO] - $0 LD_LIBRARY_PATH=$LD_LIBRARY_PATH"
		export MESSC="${CORE}"
	else
		export MESSC="${PF_HOME}"
	fi

fi
# Need to find out where else MESSC is used

#export PATH=${PATH}:$MESSC:$CORE/bin
export PATH=${PATH}:$MESSC/bin
export PATH=${PATH}:$CORE/bin
