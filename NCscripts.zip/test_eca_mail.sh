#|/bin/ksh
#set -x

usage() 
{
	echo "Please enter correct values"
	echo "test_mail.sh -p <project> -r <release_tag> -s <build_status> -d <cand_path>"
	echo "test_mail.sh -p RB -r 8.0.4.4 -s T -d /irb/candidate/patch/rb/8.0/RB_8.0.4.4.RC1/"
	exit
}

while getopts d:s:p:r:m: the_option
do
        case $the_option in
        s)
                stat="$OPTARG"
                ;;
        d)
                cand_loc="$OPTARG"
                ;;
        r)
                rel="$OPTARG"
                ;;
        p)
                proj="$OPTARG"
                ;;
	m)
		msg="$OPTARG"
		;;
        [?])
                usage
                ;;
        esac
done

if [ "$stat" = T -o -n "$cand_loc" ]
then
	message="Sucessful"
else
	message="Failed"
fi

                echo "#########################################"
                temp_html=/tmp/temp_RC_html.html
                echo "To: arun.kumar.kulkarni@netcracker.com,sridhar.davuluru@NetCracker.com,ranjith.kumar.gajula@netcracker.com,reshma.goud.ireni@netcracker.com,ravi.katepally@netcracker.com,tulasi.jagabandu@netcracker.com" > ${temp_html}
#                echo "To: arun.kumar.kulkarni@netcracker.com,sridhar.davuluru@NetCracker.com" > ${temp_html}
                echo "Subject: ${proj}"_"${rel} Build $message" >> ${temp_html}
                echo "MIME-Version: 1.0" >> ${temp_html}
                echo "Content-Type: text/html; charset="us-ascii"" >> ${temp_html}
                echo "<html>" >> ${temp_html}
                echo "<body>" >> ${temp_html}
                echo "<p>" >> ${temp_html}
                echo "Hi Team,<br/></br>" >> ${temp_html}
		if [ "$stat" = "T" -o -n "$cand_loc" ]
		then
			echo "<b>${proj}_$rel</b> Build is Sucessful. Please find the package in below location<br/></br><font size="5" color="green"><b> ${cand_loc} </b></font>" >> ${temp_html}
		else
	                echo "<b>${proj}_$rel</b> Build is Failed,<br/> </br> ${msg}" >> ${temp_html}
		fi
                echo "</p>" >> ${temp_html}
                echo "$define_warning" >> ${temp_html}
                echo "</body>" >> ${temp_html}
                echo "</html>" >> ${temp_html}
                /usr/sbin/sendmail arun.kumar.kulkarni@netcracker.com,sridhar.davuluru@NetCracker.com,ranjith.kumar.gajula@netcracker.com,reshma.goud.ireni@netcracker.com,ravi.katepally@netcracker.com,tulasi.jagabandu@netcracker.com < ${temp_html}
#                /usr/sbin/sendmail arun.kumar.kulkarni@netcracker.com,sridhar.davuluru@NetCracker.com < ${temp_html}
                echo "Email Sent Sucessfully"
                echo "#########################################"

