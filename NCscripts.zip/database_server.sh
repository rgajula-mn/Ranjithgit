#!/bin/sh
if [ -z "${BCE_BUILD_SCRIPTS}" ]
then
	BCE_BUILD_SCRIPTS=/irb/bce/admin/build_scripts
fi
. $BCE_BUILD_SCRIPTS/core_functions_svn.sh
. $BCE_BUILD_SCRIPTS/buildweb_functions_svn.sh

find_sqlhome 11.2.0.3.SE
BUILDWEB_DB=`buildweb_connection`

sql="select host from bce_databases where SID='$1';"
RESULT_TMP=`sql_query $BUILDWEB_DB "$sql" N`
echo $RESULT_TMP
