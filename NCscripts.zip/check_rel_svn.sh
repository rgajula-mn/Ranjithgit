#set -x
for project in `cat $BCE_BUILD_SCRIPTS/parameter_info`
#for project in `cat ./parameter_info`
do
project_name=`echo $project |cut -d '_' -f1`
rel=`echo $project |cut -d '_' -f2`
rc=`echo $project |cut -d '_' -f5`
major_rel=`echo $rel |cut -d '.' -f1-2`
platform=`echo $project |cut -d '_' -f3`
oracle_version=`echo $project |cut -d '_' -f4`

echo " Check going on in [ $project_name.sqa$rel.$platform.$oracle_version ]" 
echo "--------------------------------------------------------"
#export CCM_ADDR=`ccm start -m -d /ccm/prd -q -nogui -r build_mgr`
#ccm query "recursive_is_member_of('$project_name-sqa$rel.$platform.$oracle_version:project:CB1#1',none) and (name match '*.h' or name match '*.ksh' or name match '*.sh' or name match '*.pl' or name match '*.awk') " -f "[%name-%version %type:%instance"|cut -d '[' -f2 > /tmp/filecb1.txt
find /irb/bce/build/rb/$major_rel/$project_name-sqa$rel.$platform.$oracle_version -type f -name  "*.h" -o "*.ksh" -o "*.sh" -o "*.pl" -o "*.awk" >  /tmp/filecb1.txt
#export CCM_ADDR=`ccm -q stop`
if [ $project_name = "GENEVA" ]
then
	major_rel=`echo 2.2`
	minor_rel=`echo $rel |cut -d '.' -f3`
	rel=`echo 2.2.$minor_rel`
fi
#export CCM_ADDR=`ccm start -m -d /ccm/cb2 -q -nogui -r build_mgr`
#ccm query "recursive_is_member_of('RBINSTALL-sqa$rel.$platform.$oracle_version:project:CB2#1',none) and (name match '*.h' or name match '*.ksh' or name match '*.sh' or name match '*.pl' or name match '*.awk') " -f "[%name-%version %type:%instance"|cut -d '[' -f2 > /tmp/filecb2.txt
find /irb/bce/release/rb/$major_rel/RBINSTALL-sqa$rel.$platform.$oracle_version -type f -name  "*.h" -o "*.ksh" -o "*.sh" -o "*.pl" -o "*.awk" >  /tmp/filecb2.txt
#export CCM_ADDR=`ccm -q stop`
for i in `cat /tmp/filecb2.txt`
do	
	grep $i /tmp/filecb1.txt > /tmp/temp
	if [ $? -ne 0 ]
	then
		j=`echo $i |cut -d '-' -f1`
		echo "CB1 --> `grep $j /tmp/filecb1.txt` "
		echo "CB2 --> $i  please investigate"
		echo " "
	fi
done
echo "Check for Zero bytes files"
echo "--------------------------"
echo `ls -ltrL /irb/bce/release/rb/$major_rel/RBINSTALL-sqa$rel.$platform.$oracle_version/RBINSTALL/RB/RB/lib | awk '{print \$5 " ---- " \$9}' |grep ^0`
echo `ls -ltrL /irb/bce/release/rb/$major_rel/RBINSTALL-sqa$rel.$platform.$oracle_version/RBINSTALL/RB/RB/bin | awk '{print \$5 " ---- " \$9}' |grep ^0`
echo `ls -ltrL /irb/bce/release/rb/$major_rel/RBINSTALL-sqa$rel.$platform.$oracle_version/RBINSTALL/RB/RB/include | awk '{print \$5 " ---- " \$9}' |grep ^0`
echo "****************************Next**************************"
done
check_xml.sh
ls -ltr /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC.'$rc/full
echo "'RB-'$rel'aP11g'"
echo "================"
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'aP11g.zip'|egrep 'curl|ssh'
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'aP11g.zip'|awk '{print $1,$4}'|grep ^0|egrep 'lib|bin'
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'aP11g.zip'|grep 'release_info'|grep bin
echo "================"
echo "'RB-'$rel'lX11g'"
echo "================"
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'lX11g.zip'|egrep 'curl|ssh'
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'lX11g.zip'|awk '{print $1,$4}'|grep ^0|egrep 'lib|bin'
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'lX11g.zip'|grep 'release_info'|grep bin
echo "================"
echo "'RB-'$rel'sS11g'"
echo "================"
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'sS11g.zip'|egrep 'curl|ssh'
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'sS11g.zip'|awk '{print $1,$4}'|grep ^0|egrep 'lib|bin'
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'sS11g.zip'|grep 'release_info'|grep bin
echo "================"
echo "'RB-'$rel'hI11g'"
echo "================"
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'hI11g.zip'|egrep 'curl|ssh'
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'hI11g.zip'|awk '{print $1,$4}'|grep ^0|egrep 'lib|bin'
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'hI11g.zip'|grep 'release_info'|grep bin
echo "================"
echo "================"
echo "'RB-'$rel'slX11g'"
echo "================"
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'slX11g.zip'|egrep 'curl|ssh'
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'slX11g.zip'|awk '{print $1,$4}'|grep ^0|egrep 'lib|bin'
unzip -l  /irb/candidate/rc/rb/$major_rel/'RB_'$rel'.RC'$rc/full/'RB-'$rel'slX11g.zip'|grep 'release_info'|grep bin
