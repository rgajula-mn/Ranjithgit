#!/bin/sh
#
#  Script:              html_email.sh
#  Instance:            1
#  Author:              sg
#  Start date:          Mon Jun 17 11:11:24 2002
#  Version:             %full_filespec: html_email.sh-5:shsrc:CB1#1 %
#
#  Description:
#
#
# (C) Convergys, 2001.
# Convergys refers to Convergys Corporation or any of its wholly owned
# subsidiaries.

###########################################################################################
#
#     #######
#     #        #    #  #    #   ####    #####     #     ####   #    #   ####
#     #        #    #  ##   #  #    #     #       #    #    #  ##   #  #
#     #####    #    #  # #  #  #          #       #    #    #  # #  #   ####
#     #        #    #  #  # #  #          #       #    #    #  #  # #       #
#     #        #    #  #   ##  #    #     #       #    #    #  #   ##  #    #
#     #         ####   #    #   ####      #       #     ####   #    #   ####
#
###########################################################################################

usage()
{
        echo " "
        echo "Usage: $0 [ -f from email address ] [ -F friendly from email address ]  [ -s subject ]  [ -m email body ]"
        echo "  e.g. $0 -f RBMCIBERGroup@NetCracker.com -F 'Geneva Admin' -s 'Test Message' -m /tmp/email_me"
        echo " "
        echo "  This program adds the header and footer required for an HTML email"
        echo " "
        echo "  Setting -h will display this usage page."
        echo " "
        echo "  Setting -f email address for from field"
        echo "  Setting -F friendly email address for from field"
        echo "  Setting -m path to the main message body"
        echo "  Setting -s The subject of the email"
        echo "  Setting -t Override the default to field" 
        echo " "
        exit_program 1
}

exit_program ()
{
#        echo ""
#        echo "Exiting Program with status $1"
        exit $1
}

debug_me ()
{
        message="$1"
        debug=$2
        if [ ! -z "$debug" ]
        then
                echo "$message"
        fi
}

print_if_set ()
{
        string_to_print=$1
        variable_set=$2
        debug_on=$3
        if [ ! -z "${variable_set}" ]
        then
                debug_me "${string_to_print}" $debug_on
        fi
}

###########################################################################################
#
#     #    #    ##       #    #    #
#     ##  ##   #  #      #    ##   #
#     # ## #  #    #     #    # #  #
#     #    #  ######     #    #  # #
#     #    #  #    #     #    #   ##
#     #    #  #    #     #    #    #
#
###########################################################################################

trap 'exit_program 2'  2

while getopts f:t:F:m:s:hz the_option
do
        case $the_option in
        f)
                from_email="$OPTARG"
                ;;
        F)
                from_friendly_email="$OPTARG"
                ;;
        m)
                mail_message="$OPTARG"
                ;;
        s)
                mail_subject="$OPTARG"
		;;
	t)
		to_email="$OPTARG"
                ;;
        h)
                usage
                ;;
        z)
                debug_on="TRUE"
                ;;
        [?])
                usage
                ;;
        esac
done

if [ -z "$to_email" ]
then
	to_email="Pavan.Vuppla@netcracker.com,venu.gopal.r.pulimamidi@netcracker.com,sridhar.davuluru@netcracker.com,arun.kumar.kulkarni@netcracker.com,krishna.nagidi@netcracker.com,ranjith.kumar.gajula@netcracker.com,reshma.goud.ireni@netcracker.com"
fi

print_if_set "from_email = $from_email" "$from_email" $debug_on
print_if_set "from_friendly_email = $from_friendly_email" "$from_friendly_email" $debug_on
print_if_set "mail_message = $mail_message" "$mail_message" $debug_on
print_if_set "mail_subject = $mail_subject" "$mail_subject" $debug_on

random=$$

tmp_mail_file=/tmp/mailmessage.${random}

if [ -z "$mail_message" -a -z "${mail_subject}" ]
then
        echo 1
        usage
fi

mime_boundary="----=_NextPart_000_0019_01BEA766.A2582120"

# Mine message header

echo "From: \"${from_friendly_email}\" <${from_email}>" > ${tmp_mail_file}
echo "To: ${to_email}" >> ${tmp_mail_file}
echo "Subject: ${mail_subject}" >> ${tmp_mail_file}
echo "MIME-Version: 1.0" >> ${tmp_mail_file}
echo "Content-Type: multipart/alternative;" >> ${tmp_mail_file}
echo "        boundary="$mime_boundary"" >> ${tmp_mail_file}
echo "This is a multi-part message in MIME format." >> ${tmp_mail_file}
echo "--$mime_boundary" >> ${tmp_mail_file}
echo "Content-Type: text/html;" >> ${tmp_mail_file}
echo "        charset=\"iso-8859-1\"" >> ${tmp_mail_file}
echo "Content-Transfer-Encoding: quoted-printable\n" >> ${tmp_mail_file}
# End MIME header

# Now add in the actual email message
echo "<HTML><HEAD></HEAD><BODY>" >> ${tmp_mail_file}
cat ${mail_message} | sed -e 's/^/<br>/g' >> ${tmp_mail_file}
echo "</BODY></HTML>" >> ${tmp_mail_file}
# Finally end the email

echo "\n--$mime_boundary--\n\n" >> ${tmp_mail_file}

cat ${tmp_mail_file}

exit_program 0
