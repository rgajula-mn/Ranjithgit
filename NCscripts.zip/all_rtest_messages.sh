#!/bin/sh

# This script will find all the messages from a build project and concatanate
# all into one file. This is for the rtests to run.

# Usage:
# cd to the top level of a project and the run. Will create a file in 
# mess/ called rtest_messages

echo "Starting to create the rtest messages file"

tmp_mess_files=mess/all_mess_files
tmp_mess_files2=mess/all_mess_files2
rtest_mess_file=mess/rtest_messages

if [ -f "$tmp_mess_files" ]
then
	rm $tmp_mess_files
fi

if [ -f "$rtest_mess_file" ]
then
	rm $rtest_mess_file
fi

find . -name "*.mess" -print | grep -v "CORE/mess" | grep -v ALLBATCH > $tmp_mess_files

echo "finished the find to create the rtest messages file"

for i in `cat $tmp_mess_files | grep -v PDALtestMessages.mess`
do
	ls -la $i | grep "\.\." > /dev/null
	if [ $? -eq 0 ]
	then
		echo "skipping $i"
		continue
	fi
	echo $i
	cat $i >> $rtest_mess_file
done

mv $rtest_mess_file $tmp_mess_files

#cat $tmp_mess_files | grep -v "\*" | grep -v \# | sed '/^$/d' > $rtest_mess_file

cat $tmp_mess_files | egrep "^domain"\|"^message"\|"^error"\|"^warning"\|"^inform"\|"^trace"\|"^retired" > $rtest_mess_file

if [ -f "$tmp_mess_files" ]
then
	rm $tmp_mess_files
fi

echo "Finished creating the rtest messages file"
