#!/bin/ksh
. ~/arku1015

usage ()
{
	echo "Incorrect arguments..."
	echo "[INFO] . exclude_passed_list.sh 9.0.4 solaris 52990 /irb/bce/build/rb/9.0/RB-sqa9.0.4.solaris.oracle12c/RB "
}

version=$1
platform=$2
runID=$3
CCM_ROOT=$4

echo "Version = $version"
echo "Platform = $platform"
echo "Run ID= $runID"
echo "CCM_ROOT = $CCM_ROOT"

rm -rf $CCM_ROOT/${version}_${platform}_passed_list.txt $CCM_ROOT/${version}_${platform}_files.txt $CCM_ROOT/${version}_${platform}_rtest_exclude_files.txt
touch $CCM_ROOT/${version}_${platform}_passed_list.txt
touch $CCM_ROOT/${version}_${platform}_files.txt $CCM_ROOT/${version}_${platform}_rtest_exclude_files.txt

BUILDWEB_DB="rtest/rtest@webca.world"
echo $sql >> $CCM_ROOT/${platform}_Passed_List.txt
sqlquery="select TEST_NAME from RTESTRESULT where RUN_ID='$runID' and RESULT='passed'"

                files=`sqlplus -s $BUILDWEB_DB << +END
                set feed off;
                set head off;
                $sqlquery; 
                exit;
+END`
echo $files > $CCM_ROOT/${version}_${platform}_files.txt
for i in `cat $CCM_ROOT/${version}_${platform}_files.txt`
do
	echo $i >> $CCM_ROOT/${version}_${platform}_rtest_exclude_files.txt
done
cat $CCM_ROOT/${version}_${platform}_rtest_exclude_files.txt|head
cat $CCM_ROOT/${version}_${platform}_rtest_exclude_files.txt|wc -l

cd $CCM_ROOT
sed -i 's/$/.rtest/' ${version}_${platform}_rtest_exclude_files.txt

echo "Start of Finding the path of each passed RTest file..."
for i in `cat ${version}_${platform}_rtest_exclude_files.txt`
do
	find . -name "$i" >> ${version}_${platform}_rtest_exclude_PATH.txt
done
echo "End of Finding the path of each passed RTest file..."
echo "Creating the file to move each file to .bak..."

cat ${version}_${platform}_rtest_exclude_PATH.txt|awk '{print "mv "$1 " " $1".bak"}' > ${version}_pass_exclude_list.txt

value=`find . -name "*.bak"|wc -l`
echo "Current No. files in *.bak are $value"

echo "Moving files to .bak"
. ${version}_pass_exclude_list.txt
echo "All Passed files are moved to *.bak"
value=`find . -name "*.bak"|wc -l`
echo "Current No. files in *.bak are $value"


