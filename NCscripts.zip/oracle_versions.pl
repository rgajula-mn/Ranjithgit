#!/usr/bin/perl -w
#
#  Script:              machine_for_projects.pl
#  Subsystem:           CB1_1
#  Author:              %name: oracle_versions.pl %
#  Start date:          Mon Jan 06 15:26:36 2003
#  Version:             %full_filespec: oracle_versions.pl-3:perl:CB1#1 %
#
#  Description:
#
# (C) Convergys, 2002.
# Convergys refers to Convergys Corporation or any of its wholly
# owned subsidiaries.


##############################################################
#
# INCLUDES

use strict;


##############################################################
#
# VARIABLES

my $overridesFile = "/irb/bce/admin/config/overrides_for_release";
my $defaultsFile = "/irb/bce/admin/config/defaults_for_release";

my $return_oracle;

my %oracleVersions;
my $version;
my $count;

my $usage = "\nUsage: $0\n\n";

##############################################################
#
# UTILITY FUNCTIONS


sub Usage
{
    print $usage;
    exit 2;             # 2 indicates an error
}

sub Abort
{
    print $_[0];
    exit 2;
}

##############################################################
#
# MAIN SCRIPT

getOracleVersions(%oracleVersions);

foreach $version (sort keys %oracleVersions)
{
	print "$version\n";
}

##############################################################
#
# FUNCTIONS

sub getOracleVersions
{
	my $record;
	my @elements;

	open(DRC,"<$defaultsFile") || &Abort ("Cannot open $defaultsFile: $!\n");

	LINE: while(<DRC>)
	{
		next LINE if /^\s*$/;     # Blank line or whitespace only
		next LINE if /^\/\/.*$/;  # // Comment
		next LINE if /^-+$/;      # One or more dashes (-)

		/^(.*)$/;                 # Anything else

		$record = $1;

		@elements = split /,\s*/, $record;

		$oracleVersions{$elements[3]} = $elements[3];
	}
	close(DRC);
}
